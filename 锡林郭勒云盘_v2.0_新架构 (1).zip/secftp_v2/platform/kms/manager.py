# -*- coding: utf-8 -*-
"""
platform/kms/manager.py — KMS（密钥管理系统）

解决的问题：
  1. 多租户密钥隔离：每个组织（org）有独立的加密密钥对
     → 甲方A的私钥解不了甲方B的文件
  2. 密钥轮换：生成新密钥对后，新文件用新密钥加密；
     旧文件在首次访问时透明迁移（懒迁移）
  3. vendor 主密钥：服务商保留一套 vendor 密钥，可解密所有组织文件
     （用于运维、灾难恢复）
  4. 离线紧急解密工具：生成无需数据库的独立解密脚本

数据库表：
  tenant_keys：每个租户（org）的密钥对版本记录
  file_keys：原有字段 vendor_enc + owner_enc 扩展为多版本

使用方式：
  # 为新组织生成密钥对
  km = KMSManager()
  km.create_tenant_key(org_id=3, org_name="dept_xxaq")

  # 上传文件时获取 File Key 保护
  protected = km.protect_file_key(file_key, org_id=3)
  # → {"vendor_enc": "...", "tenant_enc": "..."}

  # 下载时恢复 File Key（用 vendor 私钥即可）
  file_key = km.recover_file_key(vendor_enc_b64)
"""
import base64
import logging
import os
import threading
from datetime import datetime
from functools import lru_cache

from core.crypto.engine import KeyManager, FileEncryptor

log = logging.getLogger("kms")

# vendor 主密钥（从环境变量或密钥文件加载）
_vendor_km: KeyManager | None = None
_vendor_lock = threading.Lock()

# 租户密钥缓存（org_id → KeyManager，避免每次查 DB）
_tenant_cache: dict = {}
_tenant_lock  = threading.Lock()


def _load_vendor_key_manager() -> KeyManager:
    global _vendor_km
    if _vendor_km is not None:
        return _vendor_km
    with _vendor_lock:
        if _vendor_km is not None:
            return _vendor_km
        from core.crypto.key_service import get_key_manager
        _vendor_km = get_key_manager()
        return _vendor_km


class KMSManager:
    """
    密钥管理系统主类。

    职责：
    - 管理每个组织的密钥对（生成/轮换/吊销）
    - 保护 File Key（双重加密：vendor + tenant）
    - 恢复 File Key（运行时解密用）
    """

    def __init__(self):
        self._vendor = _load_vendor_key_manager()

    # ── 租户密钥管理 ──────────────────────────────────
    def create_tenant_key(self, org_id: int, org_name: str = "") -> dict:
        """
        为组织生成一套 RSA-4096 密钥对并存入 DB。
        私钥用 vendor 公钥加密后存储（确保 vendor 可恢复）。
        Returns: {"pub_key_id": int, "public_key_pem": str}
        """
        priv_pem, pub_pem = KeyManager.generate_key_pair(4096)

        # 用 vendor 公钥加密私钥（避免明文私钥存 DB）
        encrypted_priv = self._vendor._vendor_pub and \
            base64.b64encode(KeyManager._rsa_encrypt(
                self._vendor._vendor_pub, priv_pem
            )).decode() or ""

        from core.db import get_conn
        with get_conn() as conn:
            row = conn.execute("""
                INSERT INTO tenant_keys(org_id, org_name, public_key_pem, encrypted_private_key,
                                        key_version, is_active, created_at)
                VALUES(%s, %s, %s, %s, 1, TRUE, NOW())
                ON CONFLICT DO NOTHING
                RETURNING id
            """, (org_id, org_name, pub_pem.decode(), encrypted_priv)).fetchone()
            if not row:
                # 创建新版本（密钥轮换）
                conn.execute(
                    "UPDATE tenant_keys SET is_active=FALSE WHERE org_id=%s", (org_id,)
                )
                row = conn.execute("""
                    INSERT INTO tenant_keys(org_id, org_name, public_key_pem, encrypted_private_key,
                                            key_version, is_active, created_at)
                    VALUES(%s, %s, %s, %s,
                           COALESCE((SELECT MAX(key_version)+1 FROM tenant_keys WHERE org_id=%s), 1),
                           TRUE, NOW()) RETURNING id
                """, (org_id, org_name, pub_pem.decode(), encrypted_priv, org_id)).fetchone()

        # 失效缓存
        with _tenant_lock:
            _tenant_cache.pop(org_id, None)

        log.info(f"为组织 {org_id}({org_name}) 生成新密钥对，id={row[0]}")
        return {"key_id": row[0], "public_key_pem": pub_pem.decode()}

    def get_tenant_public_key(self, org_id: int) -> bytes | None:
        """获取组织当前有效公钥（用于加密 File Key）"""
        with _tenant_lock:
            cached = _tenant_cache.get(org_id)
            if cached:
                return cached

        from core.db import get_conn
        with get_conn() as conn:
            row = conn.execute(
                "SELECT public_key_pem FROM tenant_keys WHERE org_id=%s AND is_active=TRUE",
                (org_id,)
            ).fetchone()

        if not row:
            return None

        from cryptography.hazmat.primitives import serialization
        pub = serialization.load_pem_public_key(row["public_key_pem"].encode())
        with _tenant_lock:
            _tenant_cache[org_id] = pub
        return pub

    def get_tenant_private_key(self, org_id: int):
        """
        获取组织私钥（用于恢复 File Key）。
        私钥用 vendor 公钥加密存储，需要 vendor 私钥解密。
        """
        if not self._vendor._vendor_priv:
            raise RuntimeError("vendor 私钥未加载，无法恢复租户私钥")

        from core.db import get_conn
        with get_conn() as conn:
            row = conn.execute(
                "SELECT encrypted_private_key FROM tenant_keys "
                "WHERE org_id=%s AND is_active=TRUE", (org_id,)
            ).fetchone()

        if not row or not row.get("encrypted_private_key"):
            return None

        # 用 vendor 私钥解密租户私钥
        enc = base64.b64decode(row["encrypted_private_key"])
        priv_pem = KeyManager._rsa_decrypt(self._vendor._vendor_priv, enc)

        from cryptography.hazmat.primitives import serialization
        return serialization.load_pem_private_key(priv_pem, password=None)

    # ── File Key 保护与恢复 ───────────────────────────
    def protect_file_key(self, file_key: bytes, org_id: int | None = None) -> dict:
        """
        用双密钥保护 File Key：
          vendor_enc：vendor 公钥加密（服务商运维用）
          tenant_enc：租户公钥加密（甲方自主解密用）
        """
        result = {"vendor_enc": "", "tenant_enc": ""}

        if self._vendor._vendor_pub:
            enc = KeyManager._rsa_encrypt(self._vendor._vendor_pub, file_key)
            result["vendor_enc"] = base64.b64encode(enc).decode()

        if org_id:
            tenant_pub = self.get_tenant_public_key(org_id)
            if tenant_pub:
                enc = KeyManager._rsa_encrypt(tenant_pub, file_key)
                result["tenant_enc"] = base64.b64encode(enc).decode()

        if not result["vendor_enc"] and not result["tenant_enc"]:
            raise RuntimeError("KMS：无可用公钥")

        return result

    def recover_file_key(self, vendor_enc_b64: str) -> bytes:
        """用 vendor 私钥恢复 File Key（运行时服务端调用）"""
        if not self._vendor._vendor_priv:
            raise RuntimeError("vendor 私钥未加载")
        enc = base64.b64decode(vendor_enc_b64)
        return KeyManager._rsa_decrypt(self._vendor._vendor_priv, enc)

    def recover_file_key_by_tenant(self, tenant_enc_b64: str, org_id: int) -> bytes:
        """用租户私钥恢复 File Key（甲方自主解密工具使用）"""
        priv = self.get_tenant_private_key(org_id)
        if not priv:
            raise RuntimeError(f"org_id={org_id} 无可用私钥")
        enc = base64.b64decode(tenant_enc_b64)
        return KeyManager._rsa_decrypt(priv, enc)

    # ── 密钥轮换 ──────────────────────────────────────
    def rotate_tenant_key(self, org_id: int, org_name: str = "") -> dict:
        """
        为组织执行密钥轮换：
        1. 生成新密钥对
        2. 旧密钥对标记为 inactive（但不删除，历史文件仍可解密）
        3. 新文件用新密钥加密
        4. 历史文件在首次访问时懒迁移（可选）
        """
        log.info(f"开始密钥轮换：org_id={org_id}")
        return self.create_tenant_key(org_id, org_name)


# ── 全局单例 ──────────────────────────────────────────
_kms: KMSManager | None = None
_kms_lock = threading.Lock()


def get_kms() -> KMSManager:
    global _kms
    if _kms: return _kms
    with _kms_lock:
        if _kms: return _kms
        _kms = KMSManager()
        return _kms
