# -*- coding: utf-8 -*-
"""
platform/license/checker.py — License 授权校验系统

授权模型：
  - 授权码由我方 RSA 私钥签名（客户端只有公钥，无法伪造）
  - 授权内容绑定：机器码 + 到期时间 + 用户数上限 + 功能模块
  - 支持离线授权（无需联网校验）
  - 授权文件 AES 加密存储，防止直接篡改

授权码格式（JSON，RSA 签名后 base64 编码）：
  {
    "client_id":    "XLGL-2025-001",      // 客户编号
    "machine_id":   "a3f9e2b1...",        // 机器指纹
    "expires_at":   "2026-12-31",         // 到期日期
    "max_users":    200,                   // 最大用户数
    "features":     ["webdav","audit"],    // 授权功能
    "issued_at":    "2025-01-01",
    "version":      "2.0",
    "sig":          "base64签名..."
  }

使用方式：
  from platform.license.checker import get_license, require_feature

  lic = get_license()
  lic.check()                          # 校验授权，过期或无效抛异常
  require_feature("webdav")            # 校验特定功能授权
"""
import base64
import hashlib
import json
import logging
import os
import platform
import threading
import time
from datetime import datetime, date
from functools import wraps
from pathlib import Path
from typing import Optional

log = logging.getLogger("license")

# License 公钥（对应我方私钥，用于验证授权码签名）
# 替换为实际部署时生成的公钥
_LICENSE_PUBLIC_KEY_PEM = os.environ.get("SECFTP_LICENSE_PUBKEY", """
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA0000000000000000000000
REPLACE_WITH_ACTUAL_PUBLIC_KEY_AT_DEPLOY_TIME_00000000000000000000000
-----END PUBLIC KEY-----
""".strip())

# License 文件路径
_LICENSE_FILE = os.environ.get("SECFTP_LICENSE_FILE", "/etc/secftp/license.key")

# 试用期配置（无 License 时的试用限制）
_TRIAL_DAYS      = 30
_TRIAL_MAX_USERS = 10
_TRIAL_FEATURES  = ["basic"]

_license_instance = None
_license_lock     = threading.Lock()


class LicenseError(Exception):
    """License 校验失败"""
    def __init__(self, msg, code="INVALID"):
        super().__init__(msg)
        self.code = code   # INVALID / EXPIRED / EXCEEDED / NO_FEATURE


class License:
    """License 实例，持有解析后的授权信息"""

    def __init__(self, data: dict):
        self.client_id  = data.get("client_id", "TRIAL")
        self.machine_id = data.get("machine_id", "")
        self.expires_at = data.get("expires_at", "")
        self.max_users  = int(data.get("max_users", _TRIAL_MAX_USERS))
        self.features   = data.get("features", _TRIAL_FEATURES)
        self.issued_at  = data.get("issued_at", "")
        self.version    = data.get("version", "")
        self.is_trial   = data.get("is_trial", False)
        self._data      = data
        self._check_cache_ts = 0   # 上次校验时间（缓存 60s）

    def check(self) -> None:
        """执行全量校验（校验结果缓存 60s 减少开销）"""
        now = time.time()
        if now - self._check_cache_ts < 60:
            return
        self._do_check()
        self._check_cache_ts = now

    def _do_check(self) -> None:
        # 试用期
        if self.is_trial:
            install_date = _get_install_date()
            if (datetime.now() - install_date).days > _TRIAL_DAYS:
                raise LicenseError(
                    f"试用期已满 {_TRIAL_DAYS} 天，请联系锡林郭勒信息中心获取正式授权",
                    "EXPIRED"
                )
            return

        # 到期校验
        if self.expires_at:
            try:
                exp = datetime.strptime(self.expires_at, "%Y-%m-%d").date()
                if date.today() > exp:
                    raise LicenseError(
                        f"授权已于 {self.expires_at} 到期，请续期",
                        "EXPIRED"
                    )
            except ValueError:
                pass

        # 机器码校验（防止授权文件拷贝到其他服务器）
        if self.machine_id and self.machine_id != "any":
            current = get_machine_id()
            if self.machine_id != current:
                raise LicenseError(
                    "授权码不匹配当前服务器（机器码变更），请重新申请授权",
                    "INVALID"
                )

    def check_user_limit(self, current_count: int) -> None:
        if current_count > self.max_users:
            raise LicenseError(
                f"用户数 {current_count} 已超过授权上限 {self.max_users}，"
                "请扩容授权",
                "EXCEEDED"
            )

    def has_feature(self, feature: str) -> bool:
        return "all" in self.features or feature in self.features

    def require_feature(self, feature: str) -> None:
        if not self.has_feature(feature):
            raise LicenseError(
                f"功能 [{feature}] 未在授权范围内，请联系获取对应模块授权",
                "NO_FEATURE"
            )

    def to_dict(self) -> dict:
        return {
            "client_id":  self.client_id,
            "is_trial":   self.is_trial,
            "expires_at": self.expires_at,
            "max_users":  self.max_users,
            "features":   self.features,
            "issued_at":  self.issued_at,
            "version":    self.version,
        }


def get_license() -> License:
    """获取当前 License 实例（单例，缓存）"""
    global _license_instance
    if _license_instance:
        return _license_instance
    with _license_lock:
        if _license_instance:
            return _license_instance
        _license_instance = _load_license()
        return _license_instance


def _load_license() -> License:
    """加载并解析 License 文件"""
    if not os.path.isfile(_LICENSE_FILE):
        log.warning(f"License 文件不存在：{_LICENSE_FILE}，进入试用模式")
        return License({"is_trial": True, "features": _TRIAL_FEATURES,
                        "max_users": _TRIAL_MAX_USERS})

    try:
        with open(_LICENSE_FILE, "r", encoding="utf-8") as f:
            content = f.read().strip()

        # 解码：base64 → JSON
        decoded = base64.b64decode(content).decode("utf-8")
        data    = json.loads(decoded)

        # 签名校验
        sig = data.pop("sig", "")
        _verify_signature(json.dumps(data, sort_keys=True, ensure_ascii=False), sig)

        log.info(f"License 加载成功：{data.get('client_id')} 到期 {data.get('expires_at')}")
        return License(data)

    except LicenseError:
        raise
    except Exception as e:
        log.error(f"License 文件解析失败：{e}")
        return License({"is_trial": True, "features": _TRIAL_FEATURES,
                        "max_users": _TRIAL_MAX_USERS})


def _verify_signature(content: str, sig_b64: str) -> None:
    """用 RSA 公钥验证授权码签名"""
    if not _LICENSE_PUBLIC_KEY_PEM or "REPLACE_WITH" in _LICENSE_PUBLIC_KEY_PEM:
        # 公钥未配置，跳过签名验证（开发模式）
        log.warning("License 公钥未配置，跳过签名验证（仅开发环境）")
        return
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import padding
        pub_key = serialization.load_pem_public_key(_LICENSE_PUBLIC_KEY_PEM.encode())
        sig     = base64.b64decode(sig_b64)
        pub_key.verify(sig, content.encode("utf-8"), padding.PKCS1v15(), hashes.SHA256())
    except Exception:
        raise LicenseError("授权码签名验证失败，请重新获取授权", "INVALID")


def get_machine_id() -> str:
    """生成机器指纹（基于 CPU / MAC 地址 / 主机名，稳定不变）"""
    try:
        import uuid
        mac  = hex(uuid.getnode())[2:]
        host = platform.node()
        raw  = f"{mac}:{host}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]
    except Exception:
        return "unknown"


def _get_install_date() -> datetime:
    """获取首次安装日期（写入一个时间戳文件）"""
    stamp_file = "/etc/secftp/.install_date"
    if os.path.isfile(stamp_file):
        with open(stamp_file) as f:
            ts = float(f.read().strip())
        return datetime.fromtimestamp(ts)
    # 首次运行，记录安装时间
    ts = time.time()
    try:
        os.makedirs("/etc/secftp", exist_ok=True)
        with open(stamp_file, "w") as f:
            f.write(str(ts))
    except Exception:
        pass
    return datetime.fromtimestamp(ts)


# ── Flask 路由 ────────────────────────────────────────
from flask import Blueprint as _BP, jsonify, g
from core.auth.jwt_auth import jwt_required, admin_required

license_bp = _BP("license", __name__, url_prefix="/api/license")


@license_bp.route("/info")
@admin_required
def license_info():
    """获取当前 License 信息"""
    lic = get_license()
    info = lic.to_dict()
    info["machine_id"] = get_machine_id()
    info["status"]     = "trial" if lic.is_trial else "active"
    # 检查是否即将过期（30天内）
    if lic.expires_at and not lic.is_trial:
        try:
            exp  = datetime.strptime(lic.expires_at, "%Y-%m-%d").date()
            days = (exp - date.today()).days
            info["days_remaining"] = days
            info["warning"] = days < 30
        except Exception:
            pass
    return jsonify(info)


@license_bp.route("/activate", methods=["POST"])
@admin_required
def activate_license():
    """上传并激活 License 文件"""
    from flask import request
    global _license_instance
    content = (request.get_json(silent=True) or {}).get("license_key", "").strip()
    if not content:
        return jsonify({"error": "授权码不能为空"}), 400

    # 写入文件
    try:
        os.makedirs("/etc/secftp", exist_ok=True)
        with open(_LICENSE_FILE, "w", encoding="utf-8") as f:
            f.write(content)
        # 重新加载
        with _license_lock:
            _license_instance = None
        lic = get_license()
        lic._do_check()   # 立即校验
        return jsonify({"success": True, "info": lic.to_dict()})
    except LicenseError as e:
        # 校验失败：删除无效文件
        try: os.unlink(_LICENSE_FILE)
        except Exception: pass
        with _license_lock:
            _license_instance = None
        return jsonify({"error": str(e), "code": e.code}), 400
    except Exception as e:
        return jsonify({"error": f"激活失败：{e}"}), 500
