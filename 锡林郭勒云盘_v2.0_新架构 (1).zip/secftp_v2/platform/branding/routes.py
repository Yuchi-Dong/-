# -*- coding: utf-8 -*-
"""platform/branding/routes.py — 品牌定制路由（配置从DB读写）"""
import re
from flask import Blueprint, session, request, jsonify, abort
from core.auth.guards import login_required
from core.db import get_conn
import config

bp = Blueprint("branding", __name__)


def _save_config(cfg: dict):
    """将品牌配置写入 system_config 表"""
    with get_conn() as conn:
        conn.execute("""
            INSERT INTO system_config(key, value)
            VALUES('branding', %s::jsonb)
            ON CONFLICT(key) DO UPDATE SET value=%s::jsonb, updated_at=NOW()
        """, (
            __import__("json").dumps(cfg, ensure_ascii=False),
            __import__("json").dumps(cfg, ensure_ascii=False),
        ))


def _load_config() -> dict:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT value FROM system_config WHERE key='branding'"
        ).fetchone()
    return row["value"] if row else {}


@bp.route("/api/admin/branding/save", methods=["POST"])
@login_required
def save_branding():
    if session.get("role", 2) != 0:
        abort(403)
    data = request.get_json() or {}
    cfg = {
        "system_name":    data.get("system_name", config.SYSTEM_NAME)[:40],
        "system_name_en": data.get("system_name_en", "")[:60],
        "system_org":     data.get("system_org", "")[:60],
        "system_short":   data.get("system_short", "")[:20],
        "primary_color":  data.get("primary_color", "#1560bd"),
        "login_desc":     data.get("login_desc", "")[:200],
        "allow_register": bool(data.get("allow_register")),
        "register_note":  data.get("register_note", "")[:200],
    }
    if not re.match(r'^#[0-9a-fA-F]{6}$', cfg["primary_color"]):
        cfg["primary_color"] = "#1560bd"
    _save_config(cfg)
    # 立即应用
    import config as _c
    for k, v in cfg.items():
        if k == "system_name":     _c.SYSTEM_NAME    = v
        elif k == "allow_register": _c.ALLOW_REGISTER = v
    return jsonify({"success": True})
