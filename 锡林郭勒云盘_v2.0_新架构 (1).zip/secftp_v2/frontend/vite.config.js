import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { resolve } from 'path'

export default defineConfig({
  plugins: [vue()],
  resolve: {
    alias: { '@': resolve(__dirname, 'src') }
  },
  server: {
    proxy: {
      '/api':      { target: 'http://127.0.0.1:8080', changeOrigin: true },
      '/file':     { target: 'http://127.0.0.1:8080', changeOrigin: true },
      '/avatar':   { target: 'http://127.0.0.1:8080', changeOrigin: true },
      '/health':   { target: 'http://127.0.0.1:8080', changeOrigin: true },
    }
  },
  build: {
    outDir: '../static',
    emptyOutDir: true
  }
})
