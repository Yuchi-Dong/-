<template>
  <AppLayout>
    <div class="flex items-center justify-between">
      <div class="page-title">🔗 共享文件</div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <!-- 我发出的分享 -->
      <div class="card">
        <div class="card-header"><span class="card-title">📤 我发出的分享</span></div>
        <div v-if="loading" class="loading-wrap"><div class="spinner"></div></div>
        <div v-else-if="mySent.length===0" class="empty-state" style="padding:24px"><div class="empty-ico" style="font-size:32px">📭</div><div class="empty-desc">暂无发出的分享</div></div>
        <div v-else style="overflow:auto">
          <table class="table">
            <thead><tr><th>文件</th><th>权限</th><th>有效期</th><th style="text-align:right">操作</th></tr></thead>
            <tbody>
              <tr v-for="s in mySent" :key="s.id">
                <td><span class="truncate" style="max-width:150px;display:inline-block">{{s.file_path?.split('/').pop()}}</span></td>
                <td><span :class="['badge',s.perm==='rw'?'badge-green':'badge-gray']" style="font-size:10px">{{s.perm==='rw'?'读写':'只读'}}</span></td>
                <td class="text-muted text-sm">{{s.expires_at?s.expires_at.slice(0,10):'永久'}}</td>
                <td style="text-align:right"><button class="btn btn-ghost btn-xs" style="color:var(--c-danger)" @click="revoke(s.id)">取消</button></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <!-- 收到的分享 -->
      <div class="card">
        <div class="card-header"><span class="card-title">📥 收到的分享</span></div>
        <div v-if="loading" class="loading-wrap"><div class="spinner"></div></div>
        <div v-else-if="received.length===0" class="empty-state" style="padding:24px"><div class="empty-ico" style="font-size:32px">📭</div><div class="empty-desc">暂无收到的分享</div></div>
        <div v-else style="overflow:auto">
          <table class="table">
            <thead><tr><th>文件</th><th>来自</th><th>权限</th><th style="text-align:right">操作</th></tr></thead>
            <tbody>
              <tr v-for="s in received" :key="s.id">
                <td><span class="truncate" style="max-width:130px;display:inline-block">{{s.file_path?.split('/').pop()}}</span></td>
                <td class="text-muted text-sm">{{s.owner_name||s.owner_username}}</td>
                <td><span :class="['badge',s.perm==='rw'?'badge-green':'badge-gray']" style="font-size:10px">{{s.perm==='rw'?'读写':'只读'}}</span></td>
                <td style="text-align:right"><a :href="`/files/${s.file_path}`" class="btn btn-ghost btn-xs">打开</a></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <!-- 我的公开链接 -->
    <div class="card">
      <div class="card-header"><span class="card-title">🌐 我的公开链接</span></div>
      <div v-if="links.length===0" class="empty-state" style="padding:24px"><div class="empty-ico" style="font-size:32px">🔗</div><div class="empty-desc">暂无公开链接</div></div>
      <table v-else class="table">
        <thead><tr><th>文件</th><th>链接</th><th>访问次数</th><th>有效期</th><th>状态</th><th style="text-align:right">操作</th></tr></thead>
        <tbody>
          <tr v-for="l in links" :key="l.id">
            <td class="truncate" style="max-width:150px">{{l.file_path?.split('/').pop()}}</td>
            <td><a :href="`/s/${l.token}`" target="_blank" class="text-xs" style="font-family:var(--font-mono)">/s/{{l.token}}</a></td>
            <td class="text-muted text-sm">{{l.view_count}}{{l.max_views?` / ${l.max_views}`:''}}</td>
            <td class="text-muted text-sm">{{l.expires_at?l.expires_at.slice(0,10):'永久'}}</td>
            <td><span :class="['badge',l.is_active?'badge-green':'badge-gray']" style="font-size:10px">{{l.is_active?'有效':'已失效'}}</span></td>
            <td style="text-align:right">
              <div class="flex gap-1 justify-end">
                <button class="btn btn-ghost btn-xs" @click="copyLink(l.token)">📋</button>
                <button class="btn btn-ghost btn-xs" style="color:var(--c-danger)" @click="revokeLink(l.id)">撤销</button>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </AppLayout>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useToastStore } from '@/stores/toast'
import { shareApi } from '@/api'
const toast=useToastStore()
const mySent=ref([]),received=ref([]),links=ref([]),loading=ref(true)
async function load(){loading.value=true;try{const[s,r,l]=await Promise.all([shareApi.my(),shareApi.received(),shareApi.myLinks()]);mySent.value=s.shares;received.value=r.shares;links.value=l.links}finally{loading.value=false}}
onMounted(load)
async function revoke(id){try{await shareApi.revoke({id});toast.ok('已取消分享');load()}catch(e){toast.err(e?.error||'失败')}}
async function revokeLink(id){try{await shareApi.revokeLink({id});toast.ok('链接已撤销');load()}catch(e){toast.err(e?.error||'失败')}}
async function copyLink(token){try{await navigator.clipboard.writeText(`${location.origin}/s/${token}`);toast.ok('链接已复制')}catch{toast.err('复制失败')}}
</script>
