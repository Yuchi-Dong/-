<template>
  <AppLayout>
    <!-- 欢迎栏 -->
    <div class="flex items-center justify-between flex-wrap gap-3">
      <div>
        <div class="page-title">{{ greeting }}，{{ auth.username }} 👋</div>
        <div class="page-subtitle">{{ dateStr }} &nbsp;·&nbsp; 数据每30秒自动刷新</div>
      </div>
      <div class="flex gap-2">
        <button class="btn btn-outline btn-sm" @click="$router.push('/files')">📂 文件管理</button>
        <button v-if="auth.isAdmin" class="btn btn-outline btn-sm" @click="$router.push('/admin/storage')">📊 存储分析</button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stat-grid">
      <div class="stat-card" @click="$router.push('/files')">
        <div class="stat-icon" style="background:#dbeafe">📁</div>
        <div><div class="stat-value">{{ fmt(stats.file_count) }}</div><div class="stat-label">文件总数</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#dcfce7">💾</div>
        <div><div class="stat-value">{{ fmtSize(stats.total_gb) }}</div><div class="stat-label">存储总量</div></div>
      </div>
      <div class="stat-card" @click="$router.push('/shared')">
        <div class="stat-icon" style="background:#fce7f3">🔗</div>
        <div><div class="stat-value">{{ fmt(stats.share_count) }}</div><div class="stat-label">活跃分享</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#fff7ed">⚡</div>
        <div><div class="stat-value">{{ fmt(stats.today_ops) }}</div><div class="stat-label">今日操作</div></div>
      </div>
      <div class="stat-card">
        <div class="stat-icon" style="background:#f0fdf4">🟢</div>
        <div><div class="stat-value">{{ stats.active_now }}</div><div class="stat-label">在线用户</div></div>
      </div>
      <template v-if="auth.isAdmin">
        <div class="stat-card" @click="$router.push('/admin')">
          <div class="stat-icon" style="background:#ede9fe">👥</div>
          <div><div class="stat-value">{{ stats.user_count }}</div><div class="stat-label">注册用户</div></div>
        </div>
        <div class="stat-card" @click="$router.push('/admin?tab=register')">
          <div class="stat-icon" :style="`background:${stats.pending_reg > 0 ? '#fef3c7' : '#f0fdf4'}`">📝</div>
          <div><div class="stat-value">{{ stats.pending_reg }}</div><div class="stat-label">待审批申请</div></div>
        </div>
      </template>
    </div>

    <!-- 图表区 -->
    <div class="grid-2" style="min-height:280px">
      <!-- 趋势图 -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">📈 操作趋势（近30天）</span>
          <div class="flex gap-3 text-xs text-muted">
            <span><span style="color:#3b82f6">●</span> 总操作</span>
            <span><span style="color:#10b981">●</span> 上传</span>
          </div>
        </div>
        <div class="card-body">
          <canvas ref="trendCanvas" height="170"></canvas>
        </div>
      </div>

      <!-- 文件类型饼图 -->
      <div class="card">
        <div class="card-header">
          <span class="card-title">📊 文件类型分布</span>
        </div>
        <div class="card-body">
          <canvas ref="pieCanvas" height="130"></canvas>
          <div class="flex flex-wrap gap-2" style="margin-top:10px">
            <span
              v-for="t in fileTypes.slice(0,6)" :key="t.ftype"
              class="text-xs text-muted flex items-center gap-1"
            >
              <span :style="`width:8px;height:8px;border-radius:2px;background:${t.color};flex-shrink:0;display:inline-block`"></span>
              {{ t.label }}
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- 热力图 + 最近动态 -->
    <div class="grid-2">
      <!-- 热力图 -->
      <div class="card">
        <div class="card-header"><span class="card-title">🔥 访问热力图（近7天）</span></div>
        <div class="card-body">
          <div style="overflow-x:auto">
            <div ref="heatmapEl" style="display:grid;gap:2px;width:max-content"></div>
          </div>
          <div class="flex justify-between text-xs text-muted" style="margin-top:6px;padding:0 2px">
            <span>0:00</span><span>6:00</span><span>12:00</span><span>18:00</span><span>23:00</span>
          </div>
        </div>
      </div>

      <!-- 最近操作流 -->
      <div class="card">
        <div class="card-header"><span class="card-title">📋 最近操作</span></div>
        <div class="card-body" style="padding:0">
          <div v-if="recentOps.length === 0" class="empty-state" style="padding:24px">
            <div class="empty-ico" style="font-size:32px">📭</div>
            <div class="empty-desc">暂无操作记录</div>
          </div>
          <div
            v-for="op in recentOps" :key="op.ts + op.username"
            class="flex items-center gap-3"
            style="padding:9px 18px;border-bottom:1px solid var(--c-border);font-size:12px"
          >
            <span style="font-size:15px;flex-shrink:0">{{ op.icon }}</span>
            <div style="flex:1;min-width:0">
              <span class="font-medium">{{ op.username }}</span>
              <span class="text-muted" style="margin-left:4px">{{ op.detail }}</span>
            </div>
            <span class="text-muted text-xs" style="white-space:nowrap">{{ op.ts.slice(11) }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 用量排行（管理员） -->
    <div v-if="auth.isAdmin" class="card">
      <div class="card-header"><span class="card-title">🏆 近30天活跃用户</span></div>
      <div class="card-body">
        <div
          v-for="u in topUsers" :key="u.username"
          class="flex items-center gap-3"
          style="padding:6px 0;font-size:12px;border-bottom:1px solid var(--c-border)"
        >
          <span style="min-width:22px;text-align:center;font-weight:700"
            :style="`color:${u.rank<=3?'#f59e0b':'var(--c-text3)'}`">
            {{ u.rank <= 3 ? ['🥇','🥈','🥉'][u.rank-1] : u.rank }}
          </span>
          <span style="min-width:80px;font-weight:500">{{ u.username }}</span>
          <div style="flex:1;height:5px;background:var(--c-bg);border-radius:3px;overflow:hidden">
            <div :style="`width:${Math.round(u.ops/maxOps*100)}%;height:100%;background:var(--c-primary);border-radius:3px`"></div>
          </div>
          <span class="text-muted" style="min-width:44px;text-align:right">{{ u.ops }} 次</span>
        </div>
      </div>
    </div>
  </AppLayout>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useAuthStore } from '@/stores/auth'
import { dashboardApi } from '@/api'

const auth = useAuthStore()

// 时间问候
const now = new Date()
const h   = now.getHours()
const greeting = h < 6 ? '夜深了' : h < 12 ? '早上好' : h < 18 ? '下午好' : '晚上好'
const dateStr  = now.toLocaleDateString('zh-CN', { year:'numeric', month:'long', day:'numeric', weekday:'long' })

// 状态
const stats     = ref({ file_count:0, total_gb:0, share_count:0, today_ops:0, active_now:0, user_count:0, pending_reg:0 })
const fileTypes = ref([])
const recentOps = ref([])
const topUsers  = ref([])
const maxOps    = computed(() => Math.max(...topUsers.value.map(u=>u.ops), 1))

// Canvas refs
const trendCanvas = ref(null)
const pieCanvas   = ref(null)
const heatmapEl   = ref(null)
let trendChart, pieChart, refreshTimer

// 格式化
const fmt     = v => (v||0).toLocaleString()
const fmtSize = gb => {
  if (!gb) return '0 MB'
  if (gb >= 1024) return (gb/1024).toFixed(1)+' TB'
  if (gb >= 1) return gb.toFixed(2)+' GB'
  return (stats.value.total_mb||0)+' MB'
}

// 加载图表库（CDN）
function loadChartJS() {
  return new Promise(resolve => {
    if (window.Chart) { resolve(); return }
    const s = document.createElement('script')
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js'
    s.onload = resolve
    document.head.appendChild(s)
  })
}

async function loadAll() {
  const [s, trend, types, recent, top, heat] = await Promise.all([
    dashboardApi.stats(),
    dashboardApi.trend(),
    dashboardApi.filetype(),
    dashboardApi.recent(),
    auth.isAdmin ? dashboardApi.topusers() : Promise.resolve([]),
    dashboardApi.activity(),
  ])

  stats.value    = s
  fileTypes.value= types
  recentOps.value= recent
  topUsers.value = top

  await loadChartJS()
  drawTrend(trend)
  drawPie(types)
  drawHeatmap(heat)
}

function drawTrend(data) {
  const labels = data.map(r => r.day.slice(5))
  const ctx    = trendCanvas.value?.getContext('2d')
  if (!ctx) return
  if (trendChart) trendChart.destroy()
  trendChart = new window.Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label:'总操作', data:data.map(r=>r.ops),     borderColor:'#3b82f6', backgroundColor:'rgba(59,130,246,.1)', fill:true, tension:.4, pointRadius:2 },
        { label:'上传',   data:data.map(r=>r.uploads), borderColor:'#10b981', backgroundColor:'rgba(16,185,129,.08)', fill:true, tension:.4, pointRadius:2 },
      ]
    },
    options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{display:false} }, scales:{
      x:{ grid:{color:'rgba(0,0,0,.04)'}, ticks:{maxTicksLimit:10} },
      y:{ grid:{color:'rgba(0,0,0,.04)'}, beginAtZero:true }
    }}
  })
}

function drawPie(data) {
  if (!data.length) return
  const ctx = pieCanvas.value?.getContext('2d')
  if (!ctx) return
  if (pieChart) pieChart.destroy()
  pieChart = new window.Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: data.map(t=>t.label),
      datasets: [{ data:data.map(t=>t.count), backgroundColor:data.map(t=>t.color), borderWidth:2, borderColor:'#fff' }]
    },
    options: { responsive:true, maintainAspectRatio:false, cutout:'65%',
      plugins:{ legend:{display:false}, tooltip:{ callbacks:{ label: c=>' '+c.label+': '+c.parsed+' 个' } } }
    }
  })
}

function drawHeatmap(matrix) {
  const el = heatmapEl.value
  if (!el) return
  const max = Math.max(...matrix.flat(), 1)
  el.style.gridTemplateColumns = 'repeat(24, 14px)'
  el.innerHTML = ''
  for (let d = 0; d < 7; d++) {
    for (let h = 0; h < 24; h++) {
      const v = matrix[d]?.[h] || 0
      const a = (0.08 + v/max * 0.88).toFixed(2)
      const cell = document.createElement('div')
      cell.title = `${['日','一','二','三','四','五','六'][d]}曜 ${h}:00  ${v}次`
      cell.style.cssText = `width:14px;height:14px;border-radius:3px;background:rgba(59,130,246,${a})`
      el.appendChild(cell)
    }
  }
}

async function refreshStats() {
  try {
    const s = await dashboardApi.stats()
    stats.value = s
  } catch {}
}

onMounted(async () => {
  await loadAll()
  refreshTimer = setInterval(refreshStats, 30000)
})
onUnmounted(() => {
  clearInterval(refreshTimer)
  trendChart?.destroy()
  pieChart?.destroy()
})
</script>
