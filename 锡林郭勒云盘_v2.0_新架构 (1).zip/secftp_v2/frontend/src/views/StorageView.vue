<template>
  <AppLayout>
    <div class="flex items-center justify-between">
      <div class="page-title">💾 存储分析</div>
      <select v-model="days" class="select" style="width:120px" @change="loadAll">
        <option :value="7">近7天</option><option :value="30">近30天</option><option :value="90">近90天</option>
      </select>
    </div>

    <!-- 概览卡片 -->
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
      <div class="card" style="padding:16px 18px" v-for="s in summaryCards" :key="s.label">
        <div class="text-xs text-muted" style="margin-bottom:6px">{{ s.label }}</div>
        <div style="font-size:24px;font-weight:700">{{ s.value }}</div>
      </div>
    </div>

    <!-- 图表 -->
    <div style="display:grid;grid-template-columns:3fr 2fr;gap:16px">
      <div class="card" style="padding:18px 20px">
        <div class="card-title" style="margin-bottom:14px">操作趋势（堆叠柱状图）</div>
        <canvas ref="trendCanvas" height="200"></canvas>
      </div>
      <div class="card" style="padding:18px 20px">
        <div class="card-title" style="margin-bottom:14px">文件类型占比（按存储量）</div>
        <canvas ref="pieCanvas" height="200"></canvas>
        <div ref="pieLegend" style="margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:4px"></div>
      </div>
    </div>

    <!-- 详情表格 -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <!-- 用户用量排行 -->
      <div class="card" style="padding:18px 20px">
        <div class="card-title" style="margin-bottom:12px">🏆 用户存储用量</div>
        <table class="table">
          <thead><tr><th>用户</th><th>已用</th><th>配额</th><th>占比</th></tr></thead>
          <tbody>
            <tr v-for="u in userQuota" :key="u.username">
              <td class="font-medium text-sm">{{ u.username }}</td>
              <td class="text-muted text-sm">{{ fmtBytes(u.used_bytes) }}</td>
              <td class="text-muted text-sm">{{ (u.quota_mb/1024|0) }} GB</td>
              <td>
                <div style="display:flex;align-items:center;gap:6px">
                  <div style="flex:1;height:4px;background:var(--c-bg);border-radius:2px;overflow:hidden;min-width:40px">
                    <div :style="`width:${Math.min(100,Math.round(u.used_bytes/1048576/(u.quota_mb||1024)*100))}%;height:100%;background:var(--c-primary);border-radius:2px`"></div>
                  </div>
                  <span class="text-xs text-muted">{{ Math.round(u.used_bytes/1048576/(u.quota_mb||1024)*100) }}%</span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- 类型明细 -->
      <div class="card" style="padding:18px 20px">
        <div class="card-title" style="margin-bottom:12px">📂 文件类型明细</div>
        <table class="table">
          <thead><tr><th>类型</th><th>文件数</th><th>大小</th><th>占比</th></tr></thead>
          <tbody>
            <tr v-for="t in typeDetail" :key="t.ftype">
              <td><div class="flex items-center gap-2"><div :style="`width:8px;height:8px;border-radius:2px;background:${t.color};flex-shrink:0`"></div><span class="text-sm">{{ t.label }}</span></div></td>
              <td class="text-muted text-sm">{{ t.cnt?.toLocaleString() }}</td>
              <td class="text-muted text-sm">{{ fmtBytes(t.bytes) }}</td>
              <td class="text-muted text-sm">{{ t.pct }}%</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </AppLayout>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { dashboardApi, adminApi } from '@/api'
const days=ref(30),trendCanvas=ref(null),pieCanvas=ref(null),pieLegend=ref(null)
const stats=ref({}),trend=ref([]),typeData=ref([]),userQuota=ref([])
let trendChart,pieChart
const COLORS={image:'#3b82f6',pdf:'#ef4444',video:'#8b5cf6',audio:'#ec4899',word:'#2563eb',excel:'#16a34a',ppt:'#f59e0b',zip:'#64748b',text:'#06b6d4',code:'#0d9488',other:'#9ca3af'}
const LABELS={image:'图片',pdf:'PDF',video:'视频',audio:'音频',word:'Word',excel:'Excel',ppt:'PPT',zip:'压缩包',text:'文本',code:'代码',other:'其他'}
function fmtBytes(b){if(!b)return'0 B';if(b>1073741824)return(b/1073741824).toFixed(2)+' GB';if(b>1048576)return(b/1048576).toFixed(1)+' MB';if(b>1024)return(b/1024).toFixed(1)+' KB';return b+' B'}
const summaryCards=computed(()=>[
  {label:'文件总数',value:(stats.value.total_files||0).toLocaleString()},
  {label:'存储总量',value:fmtBytes(stats.value.total_bytes||0)},
  {label:'本期操作',value:trend.value.reduce((s,r)=>s+r.ops,0).toLocaleString()},
  {label:'活跃用户',value:userQuota.value.filter(u=>u.used_bytes>0).length},
])
const typeDetail=computed(()=>{const total=typeData.value.reduce((s,t)=>s+t.bytes,0)||1;return typeData.value.map(t=>({...t,label:LABELS[t.ftype]||t.ftype,color:COLORS[t.ftype]||'#9ca3af',pct:((t.bytes/total)*100).toFixed(1)}))})
async function loadAll(){
  const[t,ty,st]=await Promise.all([dashboardApi.trend(days.value),dashboardApi.filetype(),adminApi.storageStats()])
  trend.value=t;typeData.value=ty;stats.value=st;userQuota.value=st.user_quota||[]
  await loadChartJS();drawTrend();drawPie()
}
function loadChartJS(){return new Promise(r=>{if(window.Chart){r();return}const s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js';s.onload=r;document.head.appendChild(s)})}
function drawTrend(){
  if(trendChart)trendChart.destroy()
  trendChart=new window.Chart(trendCanvas.value,{type:'bar',data:{labels:trend.value.map(r=>r.day.slice(5)),datasets:[{label:'上传',data:trend.value.map(r=>r.uploads),backgroundColor:'rgba(16,185,129,.7)',stack:'s'},{label:'其他',data:trend.value.map(r=>r.ops-r.uploads),backgroundColor:'rgba(59,130,246,.55)',stack:'s'}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom'}},scales:{x:{stacked:true,grid:{display:false}},y:{stacked:true,beginAtZero:true}}}})
}
function drawPie(){
  const types=typeDetail.value
  if(!types.length)return
  const total=types.reduce((s,t)=>s+t.bytes,0)||1
  if(pieChart)pieChart.destroy()
  pieChart=new window.Chart(pieCanvas.value,{type:'doughnut',data:{labels:types.map(t=>t.label),datasets:[{data:types.map(t=>t.bytes),backgroundColor:types.map(t=>t.color),borderWidth:2,borderColor:'#fff'}]},options:{responsive:true,maintainAspectRatio:false,cutout:'60%',plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>' '+c.label+': '+fmtBytes(c.parsed)}}}}})
  if(pieLegend.value)pieLegend.value.innerHTML=types.map(t=>`<div style="display:flex;align-items:center;gap:4px;font-size:11px;color:var(--c-text2)"><span style="width:8px;height:8px;border-radius:2px;background:${t.color};flex-shrink:0"></span>${t.label} <span style="color:var(--c-text3)">${t.pct}%</span></div>`).join('')
}
onMounted(loadAll)
onUnmounted(()=>{trendChart?.destroy();pieChart?.destroy()})
</script>
