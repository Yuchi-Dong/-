<template>
  <AppLayout>
    <div class="flex items-center justify-between">
      <div class="page-title">⚙️ 管理后台</div>
    </div>
    <!-- Tab 导航 -->
    <div class="flex gap-1" style="border-bottom:1px solid var(--c-border);padding-bottom:0;margin-bottom:16px">
      <button v-for="t in tabs" :key="t.id"
              :class="['btn','btn-ghost','btn-sm', activeTab===t.id&&'active-tab']"
              @click="activeTab=t.id;loadTab()">{{ t.label }}</button>
    </div>

    <!-- 用户管理 -->
    <template v-if="activeTab==='users'">
      <div class="flex justify-between items-center" style="margin-bottom:12px">
        <input v-model="userSearch" class="input" style="max-width:240px" placeholder="搜索用户名/姓名"/>
        <button class="btn btn-primary btn-sm" @click="openCreateUser">➕ 新建用户</button>
      </div>
      <div class="card" style="overflow:hidden">
        <div v-if="loading" class="loading-wrap"><div class="spinner"></div></div>
        <table v-else class="table">
          <thead><tr><th>用户名</th><th>姓名</th><th>角色</th><th>组织</th><th>配额</th><th>状态</th><th>最后登录</th><th style="text-align:right">操作</th></tr></thead>
          <tbody>
            <tr v-for="u in filteredUsers" :key="u.id">
              <td class="font-medium" style="font-family:var(--font-mono);font-size:12px">{{ u.username }}</td>
              <td>{{ u.display_name || '—' }}</td>
              <td><span :class="['badge',u.role===0?'badge-red':u.role===1?'badge-blue':'badge-gray']" style="font-size:10px">{{ ['超管','管理员','成员'][u.role] }}</span></td>
              <td class="text-muted text-sm">{{ u.org_name||'—' }}</td>
              <td class="text-muted text-sm" style="white-space:nowrap">{{ (u.quota_mb/1024|0) }} GB</td>
              <td><span :class="['badge',u.is_active?'badge-green':'badge-red']" style="font-size:10px">{{ u.is_active?'正常':'已禁用' }}</span></td>
              <td class="text-muted text-sm">{{ u.last_login?.slice(0,10)||'从未' }}</td>
              <td style="text-align:right;white-space:nowrap">
                <div class="flex gap-1 justify-end">
                  <button class="btn btn-ghost btn-xs" @click="openEditUser(u)">编辑</button>
                  <button class="btn btn-ghost btn-xs" @click="resetPw(u)">重置密码</button>
                  <button class="btn btn-ghost btn-xs" :style="`color:${u.is_active?'#dc2626':'#16a34a'}`" @click="toggleUser(u)">{{ u.is_active?'禁用':'启用' }}</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>

    <!-- 组织管理 -->
    <template v-else-if="activeTab==='orgs'">
      <div class="flex justify-between items-center" style="margin-bottom:12px">
        <span class="text-muted text-sm">共 {{ orgs.length }} 个组织</span>
        <button class="btn btn-primary btn-sm" @click="openCreateOrg">➕ 新建组织</button>
      </div>
      <div class="card" style="overflow:hidden">
        <table class="table">
          <thead><tr><th>组织名称</th><th>编码</th><th>层级</th><th>目录</th><th>描述</th><th style="text-align:right">操作</th></tr></thead>
          <tbody>
            <tr v-for="o in orgs" :key="o.id">
              <td class="font-medium">{{ o.name }}</td>
              <td class="text-muted text-sm" style="font-family:var(--font-mono)">{{ o.code }}</td>
              <td class="text-muted text-sm">{{ ['','委办局','业务科室','工作小组'][o.org_level]||o.org_level }}</td>
              <td class="text-muted text-sm" style="font-family:var(--font-mono)">{{ o.dir_path }}</td>
              <td class="text-muted text-sm">{{ o.description||'—' }}</td>
              <td style="text-align:right">
                <div class="flex gap-1 justify-end">
                  <button class="btn btn-ghost btn-xs" @click="openEditOrg(o)">编辑</button>
                  <button class="btn btn-ghost btn-xs" style="color:var(--c-danger)" @click="deleteOrg(o)">删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>

    <!-- 审计日志 -->
    <template v-else-if="activeTab==='audit'">
      <div class="flex gap-2" style="margin-bottom:12px">
        <input v-model="auditFilter.username" class="input" style="max-width:160px" placeholder="用户名" @keydown.enter="loadAudit"/>
        <select v-model="auditFilter.action" class="select" style="width:160px">
          <option value="">全部操作</option>
          <option v-for="a in auditActions" :key="a">{{ a }}</option>
        </select>
        <button class="btn btn-primary btn-sm" @click="loadAudit">🔍 搜索</button>
      </div>
      <div class="card" style="overflow:hidden">
        <table class="table">
          <thead><tr><th>时间</th><th>用户</th><th>操作</th><th>详情</th><th>IP</th><th>级别</th></tr></thead>
          <tbody>
            <tr v-for="l in auditLogs" :key="l.id">
              <td class="text-muted text-sm" style="white-space:nowrap">{{ l.ts?.slice(0,16) }}</td>
              <td class="text-sm font-medium">{{ l.username||'系统' }}</td>
              <td><span class="badge badge-gray" style="font-size:10px">{{ l.action }}</span></td>
              <td class="text-muted text-sm truncate" style="max-width:200px">{{ l.detail }}</td>
              <td class="text-muted text-sm" style="font-family:var(--font-mono);font-size:11px">{{ l.ip }}</td>
              <td><span :class="['badge',l.level==='ERROR'?'badge-red':l.level==='WARN'?'badge-yellow':'badge-gray']" style="font-size:10px">{{ l.level }}</span></td>
            </tr>
          </tbody>
        </table>
        <div class="flex justify-between items-center" style="padding:12px 16px;border-top:1px solid var(--c-border)">
          <span class="text-sm text-muted">共 {{ auditTotal }} 条</span>
          <div class="flex gap-2">
            <button class="btn btn-outline btn-sm" :disabled="auditPage===1" @click="auditPage--;loadAudit()">上一页</button>
            <span class="text-sm text-muted">第 {{ auditPage }} / {{ auditPages }} 页</span>
            <button class="btn btn-outline btn-sm" :disabled="auditPage>=auditPages" @click="auditPage++;loadAudit()">下一页</button>
          </div>
        </div>
      </div>
    </template>

    <!-- 账号申请 -->
    <template v-else-if="activeTab==='register'">
      <div class="card" style="overflow:hidden">
        <div v-if="requests.length===0" class="empty-state" style="padding:32px"><div class="empty-ico" style="font-size:40px">📝</div><div class="empty-title">暂无待审批申请</div></div>
        <table v-else class="table">
          <thead><tr><th>申请用户名</th><th>真实姓名</th><th>邮箱</th><th>申请理由</th><th>申请时间</th><th style="text-align:right">操作</th></tr></thead>
          <tbody>
            <tr v-for="r in requests" :key="r.id">
              <td class="font-medium" style="font-family:var(--font-mono)">{{ r.username }}</td>
              <td>{{ r.realname }}</td>
              <td class="text-muted text-sm">{{ r.email||'—' }}</td>
              <td class="text-muted text-sm truncate" style="max-width:180px">{{ r.reason }}</td>
              <td class="text-muted text-sm">{{ r.created_at?.slice(0,10) }}</td>
              <td style="text-align:right">
                <div class="flex gap-1 justify-end">
                  <button class="btn btn-sm" style="background:var(--c-success);color:#fff;border:none" @click="approve(r)">✓ 通过</button>
                  <button class="btn btn-sm" style="background:var(--c-danger);color:#fff;border:none" @click="reject(r)">✕ 拒绝</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </template>

    <!-- 用户弹窗 -->
    <Teleport to="body">
      <div v-if="userModal.show" class="modal-overlay" @click.self="userModal.show=false">
        <div class="modal">
          <div class="modal-header"><span class="modal-title">{{ userModal.editing?'编辑用户':'新建用户' }}</span><button class="modal-close" @click="userModal.show=false">✕</button></div>
          <div class="modal-body">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
              <div class="form-group" style="margin:0"><label class="form-label">用户名 <span class="req">*</span></label><input v-model="userModal.form.username" class="input" :disabled="userModal.editing"/></div>
              <div class="form-group" style="margin:0"><label class="form-label">显示姓名</label><input v-model="userModal.form.display_name" class="input"/></div>
              <div v-if="!userModal.editing" class="form-group" style="margin:0"><label class="form-label">密码 <span class="req">*</span></label><input v-model="userModal.form.password" class="input" type="password"/></div>
              <div class="form-group" style="margin:0"><label class="form-label">邮箱</label><input v-model="userModal.form.email" class="input" type="email"/></div>
              <div class="form-group" style="margin:0"><label class="form-label">角色</label>
                <select v-model.number="userModal.form.role" class="select"><option :value="2">普通用户</option><option :value="1">组织管理员</option><option :value="0">超级管理员</option></select>
              </div>
              <div class="form-group" style="margin:0"><label class="form-label">配额 (GB)</label>
                <select v-model.number="userModal.form.quota_gb" class="select"><option :value="1">1 GB</option><option :value="10">10 GB</option><option :value="50">50 GB</option><option :value="100">100 GB</option><option :value="500">500 GB</option><option :value="1024">1 TB</option></select>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" @click="userModal.show=false">取消</button>
            <button class="btn btn-primary" :disabled="userModal.saving" @click="saveUser">{{ userModal.saving?'保存中...':'保存' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </AppLayout>
</template>

<script setup>
import { ref, computed, onMounted, reactive } from 'vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useToastStore } from '@/stores/toast'
import { adminApi } from '@/api'
const toast = useToastStore()
const tabs=[{id:'users',label:'👥 用户管理'},{id:'orgs',label:'🏢 组织管理'},{id:'audit',label:'📋 审计日志'},{id:'register',label:'📝 账号申请'}]
const activeTab=ref('users'),loading=ref(false)
const users=ref([]),orgs=ref([]),requests=ref([])
const auditLogs=ref([]),auditTotal=ref(0),auditPages=ref(1),auditPage=ref(1)
const auditFilter=reactive({username:'',action:''}),auditActions=['UPLOAD','DOWNLOAD','LOGIN_SUCCESS','DELETE_TO_TRASH','MKDIR','SHARE_CREATE','CHANGE_PASSWORD']
const userSearch=ref('')
const filteredUsers=computed(()=>{const q=userSearch.value.toLowerCase();return users.value.filter(u=>!q||u.username.toLowerCase().includes(q)||(u.display_name||'').toLowerCase().includes(q))})
const userModal=reactive({show:false,editing:false,saving:false,form:{username:'',display_name:'',password:'',email:'',role:2,quota_gb:10,id:null}})

onMounted(loadTab)
async function loadTab(){
  loading.value=true
  try{
    if(activeTab.value==='users'){const d=await adminApi.users();users.value=d.users}
    else if(activeTab.value==='orgs'){const d=await adminApi.orgs();orgs.value=d.orgs}
    else if(activeTab.value==='audit')await loadAudit()
    else if(activeTab.value==='register'){const d=await adminApi.registerRequests();requests.value=d.requests}
  }finally{loading.value=false}
}
async function loadAudit(){
  const d=await adminApi.auditLogs({page:auditPage.value,...auditFilter})
  auditLogs.value=d.logs;auditTotal.value=d.total;auditPages.value=d.pages
}
function openCreateUser(){userModal.editing=false;Object.assign(userModal.form,{username:'',display_name:'',password:'',email:'',role:2,quota_gb:10,id:null});userModal.show=true}
function openEditUser(u){userModal.editing=true;Object.assign(userModal.form,{id:u.id,username:u.username,display_name:u.display_name||'',email:u.email||'',role:u.role,quota_gb:(u.quota_mb||10240)/1024|0});userModal.show=true}
async function saveUser(){
  userModal.saving=true;try{
    if(userModal.editing)await adminApi.updateUser({id:userModal.form.id,display_name:userModal.form.display_name,email:userModal.form.email,role:userModal.form.role,quota_mb:userModal.form.quota_gb*1024})
    else await adminApi.createUser({...userModal.form,quota_mb:userModal.form.quota_gb*1024})
    toast.ok('保存成功');userModal.show=false;loadTab()
  }catch(e){toast.err(e?.error||'保存失败')}finally{userModal.saving=false}
}
async function resetPw(u){if(!confirm(`重置 ${u.username} 的密码？`))return;try{const r=await adminApi.resetPw({id:u.id});toast.ok(`新密码：${r.new_password}（请立即告知用户）`,10000)}catch(e){toast.err(e?.error||'失败')}}
async function toggleUser(u){try{await adminApi.toggleUser({id:u.id,is_active:!u.is_active});u.is_active=!u.is_active;toast.ok(u.is_active?'已启用':'已禁用')}catch(e){toast.err(e?.error||'失败')}}
function openCreateOrg(){toast.info('组织管理功能开发中')}
function openEditOrg(o){toast.info('编辑组织功能开发中')}
async function deleteOrg(o){if(!confirm(`确认删除组织「${o.name}」？`))return;try{await adminApi.deleteOrg(o.id);orgs.value=orgs.value.filter(x=>x.id!==o.id);toast.ok('已删除')}catch(e){toast.err(e?.error||'失败')}}
async function approve(r){try{const res=await adminApi.approveRequest({id:r.id});toast.ok(`已通过，临时密码：${res.temp_password}`);requests.value=requests.value.filter(x=>x.id!==r.id)}catch(e){toast.err(e?.error||'失败')}}
async function reject(r){try{await adminApi.rejectRequest({id:r.id,note:'不符合要求'});requests.value=requests.value.filter(x=>x.id!==r.id);toast.ok('已拒绝')}catch(e){toast.err(e?.error||'失败')}}
</script>
<style scoped>
.active-tab{border-bottom:2px solid var(--c-primary);border-radius:0;color:var(--c-primary);font-weight:600}
</style>
