<template>
  <AppLayout>
    <div class="flex items-center justify-between flex-wrap gap-2">
      <div class="breadcrumb">
        <span class="bc-item"><a @click="navTo('')" style="cursor:pointer">🏠 根目录</a></span>
        <template v-for="(seg, i) in pathSegs" :key="i">
          <span class="bc-sep">/</span>
          <span class="bc-item">
            <a v-if="i<pathSegs.length-1" @click="navTo(pathSegs.slice(0,i+1).join('/'))" style="cursor:pointer">{{seg}}</a>
            <span v-else class="font-medium">{{seg}}</span>
          </span>
        </template>
      </div>
      <div class="flex gap-2 items-center flex-wrap">
        <span class="text-xs text-muted">{{ store.items.length }} 项</span>
        <template v-if="store.selected.size>0">
          <span class="badge badge-blue">已选 {{store.selected.size}}</span>
          <button class="btn btn-danger btn-sm" @click="batchDelete">🗑 批量删除</button>
          <button class="btn btn-outline btn-sm" @click="store.clearSelect()">取消</button>
        </template>
        <template v-else>
          <button class="btn btn-outline btn-sm" @click="showMkdir=true">📁 新建</button>
          <label class="btn btn-primary btn-sm" style="cursor:pointer">
            ⬆ 上传<input ref="fileInputRef" type="file" multiple style="display:none" @change="onFilePick"/>
          </label>
          <div class="view-switcher">
            <button :class="['vs-btn',store.viewMode==='list'&&'active']" @click="store.setViewMode('list')">☰</button>
            <button :class="['vs-btn',store.viewMode==='grid'&&'active']" @click="store.setViewMode('grid')">⊞</button>
          </div>
        </template>
      </div>
    </div>

    <div v-if="store.items.length===0&&!store.loading" class="upload-zone" :class="{drag:dragging}"
         @dragover.prevent="dragging=true" @dragleave="dragging=false"
         @drop.prevent="onDrop" @click="fileInputRef?.click()">
      <div style="font-size:48px;margin-bottom:12px">☁️</div>
      <p style="font-size:15px">拖拽文件到此处，或 <strong>点击上传</strong></p>
      <p class="text-xs text-muted" style="margin-top:6px">断点续传 · 秒传 · 并发上传 · 大文件支持</p>
    </div>

    <div class="card" style="flex:1;display:flex;flex-direction:column;overflow:hidden"
         @dragover.prevent="dragging=true" @dragleave="dragging=false" @drop.prevent="onDrop">
      <div v-if="store.loading" class="loading-wrap"><div class="spinner"></div></div>
      <div v-else-if="store.viewMode==='list'" style="overflow:auto;flex:1">
        <table class="table">
          <thead>
            <tr>
              <th style="width:32px"><input type="checkbox" @change="toggleAll" :checked="allSelected"/></th>
              <th>文件名</th><th>大小</th><th>修改时间</th><th>权限</th>
              <th style="text-align:right">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in store.items" :key="item.rel" @dblclick="onDbl(item)"
                :style="store.selected.has(item.rel)?'background:var(--c-primary-lt)':''">
              <td><input type="checkbox" :checked="store.selected.has(item.rel)" @click.stop="store.toggleSelect(item.rel)"/></td>
              <td>
                <div class="flex items-center gap-2">
                  <span style="font-size:18px;flex-shrink:0">{{item.icon}}</span>
                  <span class="truncate" style="max-width:260px" :title="item.name">{{item.name}}</span>
                  <span v-if="item.is_encrypted" style="font-size:11px" title="加密">🔒</span>
                </div>
              </td>
              <td class="text-muted text-sm" style="white-space:nowrap">{{item.size_str}}</td>
              <td class="text-muted text-sm" style="white-space:nowrap">{{item.mtime}}</td>
              <td><span :class="['badge',item.can_write?'badge-green':'badge-gray']" style="font-size:10px">{{item.can_write?'读写':'只读'}}</span></td>
              <td style="text-align:right;white-space:nowrap">
                <div class="flex gap-1 justify-end">
                  <button v-if="!item.is_dir" class="btn btn-ghost btn-xs" @click.stop="previewPath=item.rel">👁</button>
                  <a v-if="!item.is_dir" :href="`/api/file/${item.rel}?dl=1`" class="btn btn-ghost btn-xs" @click.stop>⬇</a>
                  <button class="btn btn-ghost btn-xs" @click.stop="sharePath=item.rel">🔗</button>
                  <button v-if="item.can_write" class="btn btn-ghost btn-xs" @click.stop="startRename(item)">✏️</button>
                  <button v-if="item.can_write" class="btn btn-ghost btn-xs" style="color:var(--c-danger)" @click.stop="del(item)">🗑</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-else class="file-grid" style="overflow-y:auto;flex:1">
        <div v-for="item in store.items" :key="item.rel" class="file-card"
             @dblclick="onDbl(item)"
             :style="store.selected.has(item.rel)?'border-color:var(--c-primary);box-shadow:0 0 0 2px var(--c-primary)':''">
          <div class="file-thumb" :style="`background:${item.bg||'#f3f4f6'};position:relative`">
            <img v-if="item.ftype==='image'" :src="`/api/file/${item.rel}`" loading="lazy"
                 style="width:100%;height:100%;object-fit:cover" @error="e=>e.target.style.display='none'"/>
            <span v-else style="font-size:36px">{{item.icon}}</span>
            <span v-if="item.is_encrypted" style="position:absolute;top:4px;right:4px;font-size:11px">🔒</span>
          </div>
          <div class="file-card-info">
            <div class="file-card-name" :title="item.name">{{item.name}}</div>
            <div class="file-card-meta">
              <span class="ftype-tag" :style="`color:${item.color};background:${item.bg}`">{{(item.ftype||'').toUpperCase()}}</span>
              <span class="text-xs text-muted">{{item.size_str}}</span>
            </div>
          </div>
          <div class="file-overlay">
            <button class="overlay-action" @click.stop="onDbl(item)">{{item.is_dir?'📂 打开':'👁 预览'}}</button>
            <a v-if="!item.is_dir" :href="`/api/file/${item.rel}?dl=1`" class="overlay-action" @click.stop>⬇ 下载</a>
            <button class="overlay-action" @click.stop="sharePath=item.rel">🔗 分享</button>
            <button v-if="item.can_write" class="overlay-action is-danger" @click.stop="del(item)">🗑 删除</button>
          </div>
        </div>
      </div>
    </div>

    <!-- 弹窗 -->
    <Teleport to="body">
      <div v-if="showMkdir" class="modal-overlay" @click.self="showMkdir=false">
        <div class="modal" style="max-width:360px">
          <div class="modal-header"><span class="modal-title">📁 新建文件夹</span><button class="modal-close" @click="showMkdir=false">✕</button></div>
          <div class="modal-body"><div class="form-group" style="margin:0"><label class="form-label">文件夹名称</label><input v-model="mkdirName" class="input" @keydown.enter="doMkdir" autofocus/></div></div>
          <div class="modal-footer"><button class="btn btn-outline" @click="showMkdir=false">取消</button><button class="btn btn-primary" @click="doMkdir">创建</button></div>
        </div>
      </div>
      <div v-if="renameItem" class="modal-overlay" @click.self="renameItem=null">
        <div class="modal" style="max-width:360px">
          <div class="modal-header"><span class="modal-title">✏️ 重命名</span><button class="modal-close" @click="renameItem=null">✕</button></div>
          <div class="modal-body"><div class="form-group" style="margin:0"><label class="form-label">新名称</label><input v-model="renameVal" class="input" @keydown.enter="doRename" autofocus/></div></div>
          <div class="modal-footer"><button class="btn btn-outline" @click="renameItem=null">取消</button><button class="btn btn-primary" @click="doRename">确定</button></div>
        </div>
      </div>
    </Teleport>
    <PreviewModal :path="previewPath" :visible="!!previewPath" @close="previewPath=''"/>
    <ShareModal :path="sharePath" :visible="!!sharePath" @close="sharePath=''"/>
    <UploadPanel ref="upPanel" @done="store.loadDir(currentPath)"/>
  </AppLayout>
</template>
<script setup>
import { ref, computed, watch } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import AppLayout from '@/components/layout/AppLayout.vue'
import PreviewModal from '@/components/files/PreviewModal.vue'
import ShareModal from '@/components/files/ShareModal.vue'
import UploadPanel from '@/components/files/UploadPanel.vue'
import { useFilesStore } from '@/stores/files'
import { useToastStore } from '@/stores/toast'
import { fileApi } from '@/api'
const route=useRoute(),router=useRouter(),store=useFilesStore(),toast=useToastStore()
const fileInputRef=ref(null),upPanel=ref(null),dragging=ref(false)
const previewPath=ref(''),sharePath=ref(''),renameItem=ref(null),renameVal=ref('')
const showMkdir=ref(false),mkdirName=ref('')
const currentPath=computed(()=>{const p=route.params.pathMatch;return Array.isArray(p)?p.join('/'):(p||'')})
const pathSegs=computed(()=>currentPath.value.split('/').filter(Boolean))
const allSelected=computed(()=>store.items.length>0&&store.items.every(i=>store.selected.has(i.rel)))
watch(currentPath,p=>store.loadDir(p),{immediate:true})
function navTo(p){router.push(p?`/files/${p}`:'/files')}
function onDbl(item){item.is_dir?navTo(item.rel):(previewPath.value=item.rel)}
function toggleAll(e){if(e.target.checked)store.items.forEach(i=>store.selected.add(i.rel));else store.clearSelect()}
function onFilePick(e){upPanel.value?.addFiles(Array.from(e.target.files),currentPath.value||'');e.target.value=''}
function onDrop(e){dragging.value=false;const f=Array.from(e.dataTransfer.files);if(f.length)upPanel.value?.addFiles(f,currentPath.value||'')}
async function del(item){if(!confirm(`确认将「${item.name}」移入回收站？`))return;try{await fileApi.delete({path:item.rel});toast.ok('已移入回收站');store.loadDir(currentPath.value)}catch(e){toast.err(e?.error||'删除失败')}}
async function batchDelete(){const paths=Array.from(store.selected);if(!confirm(`确认删除 ${paths.length} 项？`))return;try{await fileApi.batch({action:'delete',paths});toast.ok('批量删除成功');store.clearSelect();store.loadDir(currentPath.value)}catch(e){toast.err(e?.error||'批量删除失败')}}
function startRename(item){renameItem.value=item;renameVal.value=item.name}
async function doRename(){if(!renameVal.value.trim())return;try{await fileApi.rename({path:renameItem.value.rel,new_name:renameVal.value.trim()});toast.ok('重命名成功');renameItem.value=null;store.loadDir(currentPath.value)}catch(e){toast.err(e?.error||'失败')}}
async function doMkdir(){if(!mkdirName.value.trim())return;try{await fileApi.mkdir({parent:currentPath.value,name:mkdirName.value.trim()});toast.ok('创建成功');mkdirName.value='';showMkdir.value=false;store.loadDir(currentPath.value)}catch(e){toast.err(e?.error||'失败')}}
</script>
