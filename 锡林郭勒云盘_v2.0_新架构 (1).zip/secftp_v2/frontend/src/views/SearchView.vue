<template>
  <AppLayout>
    <div class="page-title">🔍 全文搜索</div>
    <div class="card" style="padding:16px 18px">
      <div class="flex gap-3">
        <input v-model="keyword" class="input" style="flex:1" placeholder="搜索文件名、内容..." @keydown.enter="doSearch" autofocus/>
        <select v-model="ftype" class="select" style="width:130px">
          <option value="">全部类型</option>
          <option v-for="t in ftypes" :key="t.value" :value="t.value">{{t.label}}</option>
        </select>
        <button class="btn btn-primary" @click="doSearch" :disabled="searching">{{searching?'搜索中...':'🔍 搜索'}}</button>
      </div>
    </div>
    <div v-if="results.length>0" class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
      <div class="card-header">
        <span class="card-title">搜索结果</span>
        <span class="text-sm text-muted">找到 {{results.length}} 个文件</span>
      </div>
      <div style="overflow:auto;flex:1">
        <table class="table">
          <thead><tr><th>文件名</th><th>类型</th><th>大小</th><th>路径</th><th style="text-align:right">操作</th></tr></thead>
          <tbody>
            <tr v-for="item in results" :key="item.file_path">
              <td><div class="flex items-center gap-2"><span style="font-size:18px">{{item.icon||'📦'}}</span><span class="truncate" style="max-width:200px">{{item.file_name}}</span></div></td>
              <td><span class="ftype-tag" :style="`color:${item.color||'#9ca3af'};background:${item.bg||'#f3f4f6'}`">{{(item.ftype||'').toUpperCase()}}</span></td>
              <td class="text-muted text-sm">{{fmtSize(item.file_size)}}</td>
              <td class="text-muted text-sm truncate" style="max-width:180px">{{item.file_path}}</td>
              <td style="text-align:right;white-space:nowrap">
                <div class="flex gap-1 justify-end">
                  <button class="btn btn-ghost btn-xs" @click="previewPath=item.file_path">👁</button>
                  <a :href="`/api/file/${item.file_path}?dl=1`" class="btn btn-ghost btn-xs">⬇</a>
                  <a :href="`/files/${item.file_path.split('/').slice(0,-1).join('/')}`" class="btn btn-ghost btn-xs">📂</a>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div v-else-if="searched&&results.length===0" class="empty-state"><div class="empty-ico">🔍</div><div class="empty-title">未找到相关文件</div><div class="empty-desc">尝试其他关键词或扩大搜索范围</div></div>
    <PreviewModal :path="previewPath" :visible="!!previewPath" @close="previewPath=''"/>
  </AppLayout>
</template>
<script setup>
import { ref, onMounted } from 'vue'
import { useRoute } from 'vue-router'
import AppLayout from '@/components/layout/AppLayout.vue'
import PreviewModal from '@/components/files/PreviewModal.vue'
import { fileApi } from '@/api'
const route=useRoute()
const keyword=ref(''),ftype=ref(''),results=ref([]),searching=ref(false),searched=ref(false),previewPath=ref('')
const ftypes=[{value:'image',label:'图片'},{value:'video',label:'视频'},{value:'pdf',label:'PDF'},{value:'word',label:'Word'},{value:'excel',label:'Excel'},{value:'zip',label:'压缩包'},{value:'text',label:'文本'},{value:'code',label:'代码'}]
function fmtSize(n){if(!n)return'—';if(n>1073741824)return(n/1073741824).toFixed(1)+' GB';if(n>1048576)return(n/1048576).toFixed(1)+' MB';return(n/1024).toFixed(1)+' KB'}
async function doSearch(){if(!keyword.value.trim())return;searching.value=true;searched.value=false;try{const d=await fileApi.search({q:keyword.value,type:ftype.value});results.value=d.items;searched.value=true}finally{searching.value=false}}
onMounted(()=>{const q=route.query.q;if(q){keyword.value=String(q);doSearch()}})
</script>
