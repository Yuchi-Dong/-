<template>
  <AppLayout>
    <div class="page-title">👤 个人中心</div>
    <div class="card" style="overflow:hidden;padding:0">
      <div :style="`height:88px;background:linear-gradient(135deg,${user.avatar_color||'#1560bd'},${user.avatar_color||'#1560bd'}aa)`"></div>
      <div style="padding:0 24px 20px;position:relative">
        <div style="position:relative;display:inline-block;margin-top:-38px;margin-bottom:12px">
          <div :style="`width:76px;height:76px;border-radius:50%;overflow:hidden;border:4px solid white;box-shadow:0 2px 8px rgba(0,0,0,.15);background:${user.avatar_color||'#1560bd'};display:flex;align-items:center;justify-content:center;font-size:34px;font-weight:700;color:#fff;cursor:pointer`"
               @click="$refs.avFile.click()">
            <img v-if="user.avatar_path" :src="`/avatar/${user.avatar_path}?t=${avTs}`" style="width:100%;height:100%;object-fit:cover" @error="e=>e.target.style.display='none'"/>
            <span v-else>{{ (user.display_name||user.username||'U')[0]?.toUpperCase() }}</span>
          </div>
          <div @click="$refs.avFile.click()" style="position:absolute;bottom:2px;right:2px;width:22px;height:22px;background:var(--c-primary);border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;border:2px solid white;font-size:11px">📷</div>
        </div>
        <input ref="avFile" type="file" accept="image/*" style="display:none" @change="onPickAvatar"/>
        <div class="flex justify-between items-start flex-wrap gap-2">
          <div>
            <div style="font-size:19px;font-weight:700">{{ user.display_name || user.username }}</div>
            <div class="text-xs text-muted" style="margin-top:3px">@{{ user.username }}<span v-if="user.department_title"> · {{ user.department_title }}</span></div>
            <div v-if="user.bio" style="font-size:13px;color:var(--c-text2);margin-top:5px">{{ user.bio }}</div>
          </div>
          <span :class="['badge', roleClass]">{{ roleName }}</span>
        </div>
        <div class="flex gap-6" style="margin-top:14px;padding-top:12px;border-top:1px solid var(--c-border)">
          <div v-for="s in statCards" :key="s.label" style="text-align:center">
            <div style="font-size:20px;font-weight:700">{{ s.key==='used_mb' ? (stats.used_mb?.toFixed(1)||0) : (stats[s.key]||0) }}</div>
            <div class="text-xs text-muted">{{ s.label }}</div>
          </div>
        </div>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
      <div style="display:flex;flex-direction:column;gap:16px">
        <div class="card" style="padding:20px 24px">
          <div class="section-label" style="margin-bottom:16px">基本信息</div>
          <div class="form-group"><label class="form-label">登录用户名</label><input class="input" :value="user.username" readonly style="background:var(--c-bg);color:var(--c-text3)"/></div>
          <div class="form-group"><label class="form-label">显示姓名 <span class="req">*</span></label><input v-model="form.display_name" class="input"/></div>
          <div class="form-group"><label class="form-label">工作邮箱</label><input v-model="form.email" class="input" type="email"/></div>
          <div class="form-group" style="margin-bottom:0"><label class="form-label">联系电话</label><input v-model="form.phone" class="input"/></div>
          <div style="margin-top:16px"><button class="btn btn-primary btn-sm" :disabled="saving" @click="saveProfile">{{ saving?'保存中...':'保存信息' }}</button></div>
        </div>

        <div class="card" style="padding:20px 24px">
          <div class="section-label" style="margin-bottom:16px;border-left-color:#7c3aed">个性信息</div>
          <div class="form-group"><label class="form-label">个性签名 <span class="text-xs text-muted">({{ bio.length }}/200)</span></label><textarea v-model="bio" class="textarea" rows="2" maxlength="200" placeholder="一句话介绍自己..."></textarea></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0"><label class="form-label">所在地点</label><input v-model="location" class="input" maxlength="50"/></div>
            <div class="form-group" style="margin:0"><label class="form-label">职位/职称</label><input v-model="deptTitle" class="input" maxlength="50"/></div>
          </div>
          <div style="margin-top:14px"><button class="btn btn-sm" style="background:#7c3aed;color:#fff;border:none" :disabled="savingBio" @click="saveBio">{{ savingBio?'保存中...':'保存个性信息' }}</button></div>
        </div>

        <div class="card" style="padding:20px 24px">
          <div class="section-label" style="margin-bottom:14px;border-left-color:#0f766e">存储空间</div>
          <div class="flex justify-between text-sm text-muted" style="margin-bottom:6px">
            <span>已使用 {{ stats.used_mb?.toFixed(1)||0 }} MB</span>
            <span>配额 {{ (user.quota_mb||1048576)/1024|0 }} GB · {{ quotaPct }}%</span>
          </div>
          <div class="progress"><div class="progress-bar" :style="`width:${quotaPct}%;background:${quotaPct>85?'#dc2626':quotaPct>60?'#f59e0b':'#1560bd'}`"></div></div>
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:16px">
        <div class="card" style="padding:20px 24px">
          <div class="section-label" style="margin-bottom:14px;border-left-color:#de2910">头像颜色</div>
          <div class="flex flex-wrap gap-2" style="margin-bottom:10px">
            <button v-for="c in colorPresets" :key="c"
                    :style="`width:26px;height:26px;border-radius:50%;background:${c};cursor:pointer;border:3px solid ${c===selColor?'#fff':'transparent'};outline:${c===selColor?'2px solid #333':'none'};outline-offset:1px`"
                    @click="selColor=c"></button>
          </div>
          <div class="flex items-center gap-3">
            <div :style="`width:28px;height:28px;border-radius:50%;background:${selColor};border:2px solid var(--c-border);flex-shrink:0`"></div>
            <button class="btn btn-outline btn-sm" @click="saveColor">保存颜色</button>
          </div>
        </div>

        <div class="card" style="padding:20px 24px">
          <div class="section-label" style="margin-bottom:14px;border-left-color:#0369a1">修改密码</div>
          <div class="form-group"><label class="form-label">当前密码</label><input v-model="pw.old" class="input" type="password"/></div>
          <div class="form-group"><label class="form-label">新密码（至少8位含字母数字）</label><input v-model="pw.new1" class="input" type="password"/></div>
          <div class="form-group" style="margin-bottom:0"><label class="form-label">确认新密码</label><input v-model="pw.new2" class="input" type="password"/></div>
          <div v-if="pwError" class="form-error-msg" style="margin-top:8px">{{ pwError }}</div>
          <div style="margin-top:14px"><button class="btn btn-primary btn-sm" :disabled="savingPw" @click="changePw">{{ savingPw?'修改中...':'修改密码' }}</button></div>
        </div>

        <div class="card" style="padding:20px 24px;flex:1">
          <div class="section-label" style="margin-bottom:12px">最近操作</div>
          <div v-for="op in recentOps" :key="op.ts+op.action" class="flex items-center gap-2" style="padding:7px 0;border-bottom:1px solid var(--c-border);font-size:12px">
            <span style="font-size:15px;flex-shrink:0">{{ opIcon(op.action) }}</span>
            <span class="flex-1 truncate text-muted">{{ op.detail||op.action }}</span>
            <span class="text-xs text-muted" style="white-space:nowrap">{{ op.ts?.slice(11) }}</span>
          </div>
          <div v-if="recentOps.length===0" class="empty-state" style="padding:16px 0"><div class="empty-desc">暂无记录</div></div>
        </div>
      </div>
    </div>

    <Teleport to="body">
      <div v-if="cropVisible" class="modal-overlay" @click.self="cropVisible=false">
        <div class="modal" style="max-width:380px">
          <div class="modal-header"><span class="modal-title">裁剪头像</span><button class="modal-close" @click="cropVisible=false">✕</button></div>
          <div class="modal-body">
            <div style="position:relative;margin-bottom:12px;user-select:none;touch-action:none">
              <canvas ref="cropCanvas" style="width:100%;border-radius:6px;border:1px solid var(--c-border);display:block;cursor:move"></canvas>
              <div style="position:absolute;inset:0;pointer-events:none;border-radius:6px;overflow:hidden">
                <div style="position:absolute;inset:0;background:rgba(0,0,0,.42)"></div>
                <div ref="cropRing" style="position:absolute;border-radius:50%;box-shadow:0 0 0 9999px rgba(0,0,0,.42);background:transparent"></div>
              </div>
            </div>
            <div class="flex items-center gap-2" style="margin-bottom:4px">
              <span class="text-xs text-muted">缩放</span>
              <input ref="zoomSlider" type="range" min="0.5" max="3" step="0.02" value="1" style="flex:1" @input="drawCrop"/>
              <span ref="zoomLbl" class="text-xs text-muted" style="min-width:32px">1.0×</span>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" @click="cropVisible=false">取消</button>
            <button class="btn btn-primary" :disabled="uploading" @click="confirmCrop">{{ uploading?'上传中...':'确认上传' }}</button>
          </div>
        </div>
      </div>
    </Teleport>
  </AppLayout>
</template>
<script setup>
import { ref, computed, onMounted, reactive } from 'vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useAuthStore } from '@/stores/auth'
import { useToastStore } from '@/stores/toast'
import { profileApi, authApi } from '@/api'
const auth=useAuthStore(),toast=useToastStore()
const user=computed(()=>auth.user||{})
const form=reactive({display_name:'',email:'',phone:''}),bio=ref(''),location=ref(''),deptTitle=ref('')
const selColor=ref('#1560bd'),pw=reactive({old:'',new1:'',new2:''}),pwError=ref('')
const stats=ref({uploads:0,downloads:0,shares:0,used_mb:0,recent:[]}),recentOps=ref([]),avTs=ref(Date.now())
const saving=ref(false),savingBio=ref(false),savingPw=ref(false),uploading=ref(false),cropVisible=ref(false)
const cropCanvas=ref(null),cropRing=ref(null),zoomSlider=ref(null),zoomLbl=ref(null)
let _ci=null,_cx=0,_cy=0,_drag=false,_sx=0,_sy=0,_ox=0,_oy=0
const colorPresets=['#de2910','#1560bd','#15803d','#7c3aed','#b45309','#0e7de0','#374151','#be185d','#0f766e','#9a3412']
const statCards=[{key:'uploads',label:'上传文件'},{key:'shares',label:'发出分享'},{key:'downloads',label:'下载次数'},{key:'used_mb',label:'已用MB'}]
const quotaPct=computed(()=>Math.min(100,Math.round((stats.value.used_mb||0)/Math.max(1,(user.value.quota_mb||1048576)/1024)*100)))
const roleName=computed(()=>['超级管理员','组织管理员','成员'][user.value.role??2]||'成员')
const roleClass=computed(()=>['badge-red','badge-blue','badge-green'][user.value.role??2]||'badge-gray')
onMounted(async()=>{
  if(user.value){form.display_name=user.value.display_name||'';form.email=user.value.email||'';form.phone=user.value.phone||''
  bio.value=user.value.bio||'';location.value=user.value.location||'';deptTitle.value=user.value.department_title||''
  selColor.value=user.value.avatar_color||'#1560bd'}
  try{const s=await profileApi.stats();stats.value=s;recentOps.value=s.recent||[]}catch{}
})
async function saveProfile(){if(!form.display_name.trim()){toast.err('姓名不能为空');return}saving.value=true;try{await profileApi.update(form);auth.user.display_name=form.display_name;toast.ok('已保存')}catch(e){toast.err(e?.error||'失败')}finally{saving.value=false}}
async function saveBio(){savingBio.value=true;try{await profileApi.updateBio({bio:bio.value,location:location.value,department_title:deptTitle.value});toast.ok('已保存')}catch(e){toast.err(e?.error||'失败')}finally{savingBio.value=false}}
async function saveColor(){try{await profileApi.updateColor({color:selColor.value});auth.user.avatar_color=selColor.value;toast.ok('颜色已保存')}catch(e){toast.err(e?.error||'失败')}}
async function changePw(){pwError.value='';if(!pw.old){pwError.value='请输入当前密码';return}if(pw.new1.length<8){pwError.value='新密码至少8位';return}if(pw.new1!==pw.new2){pwError.value='两次密码不一致';return}savingPw.value=true;try{await authApi.changePw({old_password:pw.old,new_password:pw.new1});pw.old=pw.new1=pw.new2='';toast.ok('密码已修改')}catch(e){pwError.value=e?.error||'修改失败'}finally{savingPw.value=false}}
function opIcon(a){return{UPLOAD:'📤',DOWNLOAD:'📥',LOGIN_SUCCESS:'🔐',DELETE_TO_TRASH:'🗑️',MKDIR:'📁',SHARE_CREATE:'🔗'}[a]||'•'}
function onPickAvatar(e){const file=e.target.files[0];if(!file)return;if(file.size>2*1024*1024){toast.err('图片超过2MB');return}const fr=new FileReader();fr.onload=ev=>openCrop(ev.target.result);fr.readAsDataURL(file);e.target.value=''}
function openCrop(dataUrl){cropVisible.value=true;const img=new Image();img.onload=()=>{_ci=img;_cx=0;_cy=0;if(zoomSlider.value)zoomSlider.value.value=1;if(zoomLbl.value)zoomLbl.value.textContent='1.0×';const canvas=cropCanvas.value;const sz=Math.min(img.width,img.height,340);canvas.width=sz;canvas.height=sz;setTimeout(()=>{const ring=cropRing.value;if(!ring)return;const pad=18,dw=canvas.offsetWidth,cs=dw-pad*2;ring.style.cssText=`position:absolute;width:${cs}px;height:${cs}px;left:${pad}px;top:${pad}px;border-radius:50%;box-shadow:0 0 0 9999px rgba(0,0,0,.42);background:transparent`;drawCrop()},30);canvas.onmousedown=ev=>{_drag=true;_sx=ev.clientX;_sy=ev.clientY;_ox=_cx;_oy=_cy};window.onmousemove=ev=>{if(!_drag)return;const sc=canvas.width/canvas.offsetWidth;_cx=_ox+(ev.clientX-_sx)*sc;_cy=_oy+(ev.clientY-_sy)*sc;drawCrop()};window.onmouseup=()=>_drag=false};img.src=dataUrl}
function drawCrop(){if(!_ci||!cropCanvas.value)return;const canvas=cropCanvas.value,ctx=canvas.getContext('2d');const zoom=parseFloat(zoomSlider.value?.value||1);if(zoomLbl.value)zoomLbl.value.textContent=zoom.toFixed(1)+'×';const sz=canvas.width,sw=_ci.width/zoom,sh=_ci.height/zoom;ctx.clearRect(0,0,sz,sz);ctx.drawImage(_ci,(_ci.width-sw)/2-_cx/zoom,(_ci.height-sh)/2-_cy/zoom,sw,sh,0,0,sz,sz)}
async function confirmCrop(){if(!_ci||!cropCanvas.value)return;const out=document.createElement('canvas');out.width=200;out.height=200;out.getContext('2d').drawImage(cropCanvas.value,0,0,cropCanvas.value.width,cropCanvas.value.height,0,0,200,200);const b64=out.toDataURL('image/jpeg',0.88);uploading.value=true;try{const fd=new FormData();fd.append('image_data',b64);const r=await profileApi.uploadAvatar(fd);auth.user.avatar_path=r.url?.split('/').pop();avTs.value=Date.now();cropVisible.value=false;toast.ok('头像已更新')}catch(e){toast.err(e?.error||'上传失败')}finally{uploading.value=false}}
async function deleteAvatar(){if(!confirm('确认删除头像图片？'))return;try{await profileApi.deleteAvatar();auth.user.avatar_path='';avTs.value=Date.now();toast.ok('已删除')}catch(e){toast.err(e?.error||'失败')}}
</script>
