<template>
  <AppLayout>
    <div class="flex items-center justify-between">
      <div class="page-title">🗑️ 回收站</div>
      <div class="flex gap-2">
        <button v-if="items.length>0" class="btn btn-outline btn-sm" @click="restoreSelected" :disabled="selected.size===0">⬆ 恢复选中</button>
        <button v-if="items.length>0" class="btn btn-danger btn-sm" @click="emptyTrash">🗑 清空回收站</button>
      </div>
    </div>
    <div class="card" style="flex:1;display:flex;flex-direction:column;overflow:hidden">
      <div v-if="loading" class="loading-wrap"><div class="spinner"></div></div>
      <div v-else-if="items.length===0" class="empty-state"><div class="empty-ico">🗑️</div><div class="empty-title">回收站为空</div><div class="empty-desc">已删除的文件会在此显示，{{ ttlDays }} 天后自动清理</div></div>
      <div v-else style="overflow:auto;flex:1">
        <table class="table">
          <thead><tr>
            <th style="width:32px"><input type="checkbox" @change="toggleAll" :checked="allSelected"/></th>
            <th>文件名</th><th>原路径</th><th>大小</th><th>删除时间</th><th style="text-align:right">操作</th>
          </tr></thead>
          <tbody>
            <tr v-for="item in items" :key="item.id" :style="selected.has(item.id)?'background:var(--c-primary-lt)':''">
              <td><input type="checkbox" :checked="selected.has(item.id)" @change="toggleOne(item.id)"/></td>
              <td><div class="flex items-center gap-2"><span style="font-size:18px">{{item.icon}}</span><span class="truncate" style="max-width:200px">{{item.name}}</span></div></td>
              <td class="text-muted text-sm truncate" style="max-width:200px">{{item.orig_path}}</td>
              <td class="text-muted text-sm" style="white-space:nowrap">{{item.size_str}}</td>
              <td class="text-muted text-sm" style="white-space:nowrap">{{item.deleted_at}}</td>
              <td style="text-align:right;white-space:nowrap">
                <div class="flex gap-1 justify-end">
                  <button class="btn btn-ghost btn-xs" @click="restore([item.id])">⬆ 恢复</button>
                  <button class="btn btn-ghost btn-xs" style="color:var(--c-danger)" @click="delPermanent(item.id)">彻底删除</button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </AppLayout>
</template>
<script setup>
import { ref, computed, onMounted } from 'vue'
import AppLayout from '@/components/layout/AppLayout.vue'
import { useToastStore } from '@/stores/toast'
import { fileApi } from '@/api'
const toast=useToastStore()
const items=ref([]),loading=ref(true),selected=ref(new Set()),ttlDays=ref(30)
const allSelected=computed(()=>items.value.length>0&&items.value.every(i=>selected.value.has(i.id)))
async function load(){loading.value=true;try{const d=await fileApi.trash();items.value=d.items}finally{loading.value=false}}
onMounted(load)
function toggleAll(e){if(e.target.checked)items.value.forEach(i=>selected.value.add(i.id));else selected.value.clear()}
function toggleOne(id){if(selected.value.has(id))selected.value.delete(id);else selected.value.add(id)}
async function restore(ids){try{await fileApi.restore({ids});toast.ok('已恢复');selected.value.clear();load()}catch(e){toast.err(e?.error||'恢复失败')}}
async function restoreSelected(){if(selected.value.size===0)return;await restore(Array.from(selected.value))}
async function delPermanent(id){if(!confirm('彻底删除后不可恢复，确认？'))return;try{await fileApi.deletePermanent({id});toast.ok('已彻底删除');load()}catch(e){toast.err(e?.error||'失败')}}
async function emptyTrash(){if(!confirm('清空后无法恢复，确认？'))return;try{await fileApi.emptyTrash();toast.ok('回收站已清空');load()}catch(e){toast.err(e?.error||'失败')}}
</script>
