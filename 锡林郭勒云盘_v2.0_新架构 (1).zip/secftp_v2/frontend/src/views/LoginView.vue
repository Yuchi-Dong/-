<template>
  <div class="login-page">
    <div class="login-header">
      <div class="login-logo">☁</div>
      <div>
        <div class="login-title">{{ systemName }}</div>
        <div class="login-subtitle">{{ systemNameEn }} · {{ systemOrg }}</div>
      </div>
    </div>

    <div class="login-body">
      <div class="login-wrap">
        <!-- 左侧介绍 -->
        <div class="login-info">
          <h2>政务云存储平台</h2>
          <p>{{ loginDesc }}</p>
          <div class="login-feats">
            <div class="feat-item" v-for="f in features" :key="f">
              <span class="feat-ico">✓</span>{{ f }}
            </div>
          </div>
          <div class="feat-encrypt">
            <div class="enc-badge">🔒</div>
            <div>
              <div class="enc-title">端对端文件加密</div>
              <div class="enc-desc">AES-256-GCM · 双密钥保护 · 静态加密存储</div>
            </div>
          </div>
        </div>

        <!-- 右侧登录卡片 -->
        <div class="login-card">
          <div class="login-card-hdr">
            <div class="login-card-title">用户登录</div>
            <div class="login-card-sub">请使用内网账号登录</div>
          </div>
          <div class="login-card-body">
            <!-- 错误提示 -->
            <div v-if="error" class="login-error">⚠ {{ error }}</div>

            <!-- 2FA 验证 -->
            <template v-if="need2fa">
              <div class="form-group">
                <label class="form-label">两步验证码</label>
                <input
                  v-model="totpCode"
                  class="input"
                  type="text"
                  inputmode="numeric"
                  maxlength="6"
                  placeholder="请输入6位验证码"
                  autofocus
                  @keydown.enter="submit2fa"
                />
              </div>
              <button class="btn btn-primary w-full" :disabled="submitting" @click="submit2fa">
                {{ submitting ? '验证中...' : '验证' }}
              </button>
              <div style="text-align:center;margin-top:12px">
                <a @click="need2fa=false;error=''" style="font-size:12px;cursor:pointer">← 返回登录</a>
              </div>
            </template>

            <!-- 普通登录 -->
            <template v-else>
              <div class="form-group">
                <label class="form-label">用户名</label>
                <input
                  v-model="form.username"
                  class="input"
                  type="text"
                  placeholder="请输入用户名"
                  autocomplete="username"
                  autofocus
                  @keydown.enter="focusPw"
                  ref="usernameRef"
                />
              </div>
              <div class="form-group">
                <label class="form-label">密码</label>
                <div style="position:relative">
                  <input
                    v-model="form.password"
                    class="input"
                    :type="showPw ? 'text' : 'password'"
                    placeholder="请输入密码"
                    autocomplete="current-password"
                    @keydown.enter="doLogin"
                    ref="pwRef"
                    style="padding-right:40px"
                  />
                  <button
                    type="button"
                    @click="showPw = !showPw"
                    style="position:absolute;right:10px;top:50%;transform:translateY(-50%);background:none;border:none;color:var(--c-text3);font-size:16px"
                  >{{ showPw ? '🙈' : '👁' }}</button>
                </div>
              </div>
              <button class="btn btn-primary w-full login-submit" :disabled="submitting" @click="doLogin">
                <span v-if="submitting" class="spinner" style="width:16px;height:16px;border-width:2px"></span>
                {{ submitting ? '登录中...' : '登 录' }}
              </button>
              <div class="login-footer">
                内部专用系统 · 未经授权禁止访问
                <span v-if="allowRegister">
                  · <a href="/register" style="color:rgba(255,255,255,.6)">申请账号</a>
                </span>
              </div>
            </template>
          </div>
        </div>
      </div>
    </div>

    <div class="login-bottom">
      {{ systemName }} v2.0 &nbsp;|&nbsp; {{ systemOrg }} &nbsp;|&nbsp; 数据安全 · 自主可控
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { authApi } from '@/api'

const router = useRouter()
const auth   = useAuthStore()

const systemName   = ref('锡林郭勒云盘')
const systemNameEn = ref('Xilingol Cloud Drive')
const systemOrg    = ref('锡林郭勒盟行政公署')
const loginDesc    = ref('为各机关单位提供安全、高效的内部文件存储与共享服务。数据存储于本地服务器，安全可控。')
const features     = ref(['数据本地存储，安全可控', '按组织架构精细化权限管理', '全文检索，支持文档搜索', '操作全程审计，可追溯'])
const allowRegister= ref(false)

const form      = ref({ username: '', password: '' })
const totpCode  = ref('')
const error     = ref('')
const submitting= ref(false)
const showPw    = ref(false)
const need2fa   = ref(false)
const pwRef     = ref(null)
const usernameRef= ref(null)

onMounted(async () => {
  // 获取 CSRF token
  try {
    const d = await authApi.csrf()
    window.__csrf = d.csrf
    sessionStorage.setItem('csrf_token', d.csrf)
    // 加载品牌配置
    if (d.branding) {
      systemName.value    = d.branding.system_name    || systemName.value
      systemNameEn.value  = d.branding.system_name_en || systemNameEn.value
      systemOrg.value     = d.branding.system_org     || systemOrg.value
      loginDesc.value     = d.branding.login_desc     || loginDesc.value
      features.value      = d.branding.login_features || features.value
      allowRegister.value = !!d.branding.allow_register
    }
  } catch {}
})

function focusPw() { pwRef.value?.focus() }

async function doLogin() {
  if (!form.value.username || !form.value.password) {
    error.value = '请填写用户名和密码'
    return
  }
  submitting.value = true
  error.value = ''
  try {
    const data = await auth.login({ username: form.value.username, password: form.value.password })
    if (data.need_2fa) {
      need2fa.value = true
    } else {
      router.push('/dashboard')
    }
  } catch (e) {
    error.value = e?.error || '登录失败，请检查用户名和密码'
  } finally {
    submitting.value = false
  }
}

async function submit2fa() {
  if (!totpCode.value || totpCode.value.length !== 6) {
    error.value = '请输入6位验证码'
    return
  }
  submitting.value = true
  error.value = ''
  try {
    await authApi.verify2fa({ code: totpCode.value })
    await auth.fetchMe()
    router.push('/dashboard')
  } catch (e) {
    error.value = e?.error || '验证码错误'
  } finally {
    submitting.value = false
  }
}
</script>

<style scoped>
.login-page { min-height: 100vh; display: flex; flex-direction: column; background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f172a 100%); }
.login-header { display: flex; align-items: center; gap: 14px; padding: 20px 40px; border-bottom: 1px solid rgba(255,255,255,.08); }
.login-logo { width: 42px; height: 42px; background: var(--c-primary); border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 22px; flex-shrink: 0; }
.login-title { color: #fff; font-size: 18px; font-weight: 700; letter-spacing: .5px; }
.login-subtitle { color: rgba(255,255,255,.4); font-size: 11px; margin-top: 2px; }
.login-body { flex: 1; display: flex; align-items: center; justify-content: center; padding: 40px 20px; }
.login-wrap { display: grid; grid-template-columns: 1fr 380px; gap: 60px; max-width: 900px; width: 100%; align-items: center; }
.login-info h2 { font-size: 22px; font-weight: 700; color: #fff; margin-bottom: 14px; }
.login-info p { color: rgba(255,255,255,.6); font-size: 14px; line-height: 1.7; margin-bottom: 24px; }
.login-feats { display: flex; flex-direction: column; gap: 10px; margin-bottom: 28px; }
.feat-item { display: flex; align-items: center; gap: 10px; color: rgba(255,255,255,.75); font-size: 13px; }
.feat-ico { width: 20px; height: 20px; background: var(--c-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 10px; color: #fff; flex-shrink: 0; }
.feat-encrypt { display: flex; align-items: center; gap: 12px; background: rgba(21,96,189,.15); border: 1px solid rgba(21,96,189,.3); border-radius: var(--r-lg); padding: 14px 16px; }
.enc-badge { font-size: 24px; }
.enc-title { color: #fff; font-size: 13px; font-weight: 600; }
.enc-desc { color: rgba(255,255,255,.5); font-size: 11px; margin-top: 2px; }
.login-card { background: rgba(255,255,255,.05); border: 1px solid rgba(255,255,255,.1); border-radius: 16px; overflow: hidden; backdrop-filter: blur(20px); }
.login-card-hdr { background: var(--c-primary); padding: 18px 24px; }
.login-card-title { color: #fff; font-size: 14px; font-weight: 600; }
.login-card-sub { color: rgba(255,255,255,.6); font-size: 11px; margin-top: 2px; }
.login-card-body { padding: 24px; }
.login-error { background: rgba(220,38,38,.15); border: 1px solid rgba(220,38,38,.3); color: #fca5a5; padding: 10px 12px; border-radius: var(--r); font-size: 12px; margin-bottom: 14px; }
.login-submit { width: 100%; justify-content: center; padding: 10px; font-size: 15px; letter-spacing: 1px; gap: 8px; }
.login-footer { text-align: center; margin-top: 14px; font-size: 11px; color: rgba(255,255,255,.3); }
.login-bottom { text-align: center; padding: 16px; font-size: 12px; color: rgba(255,255,255,.2); border-top: 1px solid rgba(255,255,255,.05); }

/* Override input style for dark bg */
.login-card-body .input { background: rgba(255,255,255,.08); border-color: rgba(255,255,255,.15); color: #fff; }
.login-card-body .input::placeholder { color: rgba(255,255,255,.3); }
.login-card-body .input:focus { border-color: var(--c-primary); background: rgba(255,255,255,.12); box-shadow: 0 0 0 3px rgba(21,96,189,.25); }
.login-card-body .form-label { color: rgba(255,255,255,.6); }

@media (max-width: 768px) {
  .login-wrap { grid-template-columns: 1fr; gap: 30px; }
  .login-info { display: none; }
  .login-header { padding: 16px 20px; }
}
</style>
