import { defineStore } from 'pinia'
import { ref } from 'vue'

export const useToastStore = defineStore('toast', () => {
  const toasts = ref([])
  let _id = 0

  function show(message, type = 'info', duration = 3000) {
    const id = ++_id
    toasts.value.push({ id, message, type })
    setTimeout(() => remove(id), duration)
    return id
  }

  function remove(id) {
    const i = toasts.value.findIndex(t => t.id === id)
    if (i !== -1) toasts.value.splice(i, 1)
  }

  const ok   = (msg, d) => show(msg, 'ok',   d)
  const err  = (msg, d) => show(msg, 'err',  d)
  const warn = (msg, d) => show(msg, 'warn', d)
  const info = (msg, d) => show(msg, 'info', d)

  return { toasts, ok, err, warn, info, remove }
})
