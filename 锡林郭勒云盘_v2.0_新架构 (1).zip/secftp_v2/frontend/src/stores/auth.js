import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { authApi } from '@/api'

export const useAuthStore = defineStore('auth', () => {
  const user     = ref(null)
  const loading  = ref(false)

  const isLoggedIn = computed(() => !!user.value)
  const role       = computed(() => user.value?.role ?? 2)
  const isSuper    = computed(() => role.value === 0)
  const isAdmin    = computed(() => role.value <= 1)
  const username   = computed(() => user.value?.display_name || user.value?.username || '')

  async function fetchMe() {
    try {
      loading.value = true
      const data = await authApi.me()
      user.value = data.user
      if (data.csrf) {
        window.__csrf = data.csrf
        sessionStorage.setItem('csrf_token', data.csrf)
      }
    } catch {
      user.value = null
    } finally {
      loading.value = false
    }
  }

  async function login(credentials) {
    const data = await authApi.login(credentials)
    user.value = data.user
    if (data.csrf) {
      window.__csrf = data.csrf
      sessionStorage.setItem('csrf_token', data.csrf)
    }
    return data
  }

  async function logout() {
    await authApi.logout()
    user.value = null
    sessionStorage.removeItem('csrf_token')
  }

  return { user, loading, isLoggedIn, role, isSuper, isAdmin, username, fetchMe, login, logout }
})
