import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { fileApi } from '@/api'

export const useFilesStore = defineStore('files', () => {
  const items      = ref([])
  const currentPath= ref('')
  const loading    = ref(false)
  const viewMode   = ref(localStorage.getItem('viewMode') || 'list')
  const selected   = ref(new Set())

  const dirs  = computed(() => items.value.filter(i => i.is_dir))
  const files = computed(() => items.value.filter(i => !i.is_dir))

  function setViewMode(m) {
    viewMode.value = m
    localStorage.setItem('viewMode', m)
  }

  async function loadDir(path = '') {
    loading.value = true
    selected.value.clear()
    try {
      const data = await fileApi.list(path)
      items.value    = data.items || []
      currentPath.value = path
    } finally {
      loading.value = false
    }
  }

  function toggleSelect(rel) {
    if (selected.value.has(rel)) selected.value.delete(rel)
    else selected.value.add(rel)
  }

  function clearSelect() { selected.value.clear() }

  return {
    items, currentPath, loading, viewMode, selected,
    dirs, files,
    setViewMode, loadDir, toggleSelect, clearSelect
  }
})
