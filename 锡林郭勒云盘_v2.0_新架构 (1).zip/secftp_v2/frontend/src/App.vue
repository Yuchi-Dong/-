<template>
  <RouterView v-if="!appLoading" />
  <div v-else class="loading-wrap" style="height:100vh">
    <div class="spinner"></div>
  </div>

  <!-- 全局 Toast -->
  <div class="toast-wrap">
    <TransitionGroup name="toast-anim">
      <div
        v-for="t in toastStore.toasts"
        :key="t.id"
        :class="['toast', `is-${t.type}`]"
        @click="toastStore.remove(t.id)"
      >
        <span>{{ t.type === 'ok' ? '✅' : t.type === 'err' ? '❌' : t.type === 'warn' ? '⚠️' : 'ℹ️' }}</span>
        <span>{{ t.message }}</span>
      </div>
    </TransitionGroup>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { RouterView } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import { useToastStore } from '@/stores/toast'

const auth      = useAuthStore()
const toastStore= useToastStore()
const appLoading= ref(true)

// 全局 toast helper（供非 Vue 上下文调用）
window.$toast = toastStore

onMounted(async () => {
  await auth.fetchMe()
  appLoading.value = false
})
</script>

<style>
.toast-anim-enter-active, .toast-anim-leave-active { transition: all .2s ease; }
.toast-anim-enter-from { opacity: 0; transform: translateX(16px); }
.toast-anim-leave-to   { opacity: 0; transform: translateX(16px); }
</style>
