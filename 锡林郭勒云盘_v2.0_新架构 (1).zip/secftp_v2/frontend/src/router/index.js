import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  { path: '/login',     name: 'Login',     component: () => import('@/views/LoginView.vue'), meta: { public: true } },
  { path: '/dashboard', name: 'Dashboard', component: () => import('@/views/DashboardView.vue') },
  { path: '/files',     name: 'Files',     component: () => import('@/views/FilesView.vue') },
  { path: '/files/:pathMatch(.*)', name: 'FilesPath', component: () => import('@/views/FilesView.vue') },
  { path: '/shared',    name: 'Shared',    component: () => import('@/views/SharedView.vue') },
  { path: '/search',    name: 'Search',    component: () => import('@/views/SearchView.vue') },
  { path: '/trash',     name: 'Trash',     component: () => import('@/views/TrashView.vue') },
  { path: '/profile',   name: 'Profile',   component: () => import('@/views/ProfileView.vue') },
  { path: '/admin',     name: 'Admin',     component: () => import('@/views/AdminView.vue'), meta: { adminOnly: true } },
  { path: '/admin/users',   component: () => import('@/views/AdminView.vue'), meta: { adminOnly: true } },
  { path: '/admin/storage', component: () => import('@/views/StorageView.vue'), meta: { adminOnly: true } },
  { path: '/',          redirect: '/dashboard' },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

// Navigation guard
router.beforeEach(async (to) => {
  const auth = useAuthStore()
  if (!auth.isLoggedIn && !auth.loading) {
    await auth.fetchMe()
  }
  if (!to.meta.public && !auth.isLoggedIn) return '/login'
  if (to.meta.adminOnly && !auth.isAdmin) return '/dashboard'
  if (to.name === 'Login' && auth.isLoggedIn) return '/dashboard'
})

export default router
