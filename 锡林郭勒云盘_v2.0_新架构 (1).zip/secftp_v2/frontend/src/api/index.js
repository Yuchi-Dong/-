import axios from 'axios'

// ── axios 实例 ───────────────────────────────────────────────
const http = axios.create({
  baseURL: '/',
  timeout: 30000,
  withCredentials: true,   // 携带 session cookie
})

// 请求拦截：自动附加 CSRF token
http.interceptors.request.use(cfg => {
  const csrf = window.__csrf || sessionStorage.getItem('csrf_token') || ''
  if (csrf && ['post','put','delete','patch'].includes(cfg.method)) {
    cfg.headers['X-CSRF-Token'] = csrf
  }
  return cfg
})

// 响应拦截：统一错误处理
http.interceptors.response.use(
  res => res.data,
  err => {
    if (err.response?.status === 401) {
      window.location.href = '/login'
    }
    return Promise.reject(err.response?.data || { error: '网络错误' })
  }
)

// ── Auth API ─────────────────────────────────────────────────
export const authApi = {
  login:   (data) => http.post('/api/auth/login',   data),
  logout:  ()     => http.post('/api/auth/logout'),
  me:      ()     => http.get('/api/auth/me'),
  csrf:    ()     => http.get('/api/auth/csrf'),
  changePw:(data) => http.post('/api/auth/change-password', data),
  verify2fa:(data)=> http.post('/api/auth/verify-2fa', data),
}

// ── File API ─────────────────────────────────────────────────
export const fileApi = {
  list:    (path = '') => http.get('/api/files/list', { params: { path } }),
  mkdir:   (data)      => http.post('/api/files/mkdir', data),
  delete:  (data)      => http.post('/api/files/delete', data),
  move:    (data)      => http.post('/api/files/move', data),
  copy:    (data)      => http.post('/api/files/copy', data),
  rename:  (data)      => http.post('/api/files/rename', data),
  upload:  (fd, onProgress) => http.post('/api/files/upload', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: onProgress,
    timeout: 300000,
  }),
  // 分片上传
  uploadInit:  (data) => http.post('/api/upload/init', data),
  uploadChunk: (fd)   => http.post('/api/upload/chunk', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
    timeout: 60000,
  }),
  uploadCancel:(data) => http.post('/api/upload/cancel', data),
  uploadStatus:(id)   => http.get(`/api/upload/status/${id}`),
  // 搜索
  search:  (params)   => http.get('/api/files/search', { params }),
  // 文件锁
  lock:    (data)     => http.post('/api/files/lock', data),
  unlock:  (data)     => http.post('/api/files/unlock', data),
  // 标签
  setLabel:(data)     => http.post('/api/files/label', data),
  // 版本
  versions:(path)     => http.get('/api/files/versions', { params: { path } }),
  restoreVersion:(data)=>http.post('/api/files/versions/restore', data),
  // 回收站
  trash:   ()         => http.get('/api/files/trash'),
  restore: (data)     => http.post('/api/files/trash/restore', data),
  deletePermanent:(data)=>http.post('/api/files/trash/delete', data),
  emptyTrash:()       => http.post('/api/files/trash/empty'),
  // 编辑器
  editorOpen:(path)   => http.post('/api/editor/open', { path }),
  // 评论
  comments:(path)     => http.get(`/api/files/comments`, { params: { path } }),
  addComment:(data)   => http.post('/api/files/comments', data),
  deleteComment:(id)  => http.delete(`/api/files/comments/${id}`),
}

// ── Share API ─────────────────────────────────────────────────
export const shareApi = {
  create:  (data)     => http.post('/api/shares', data),
  revoke:  (data)     => http.post('/api/shares/revoke', data),
  my:      ()         => http.get('/api/shares/my'),
  received:()         => http.get('/api/shares/received'),
  targets: (q)        => http.get('/api/shares/targets', { params: { q } }),
  // 公开链接
  createLink:(data)   => http.post('/api/links', data),
  revokeLink:(data)   => http.post('/api/links/revoke', data),
  myLinks:()          => http.get('/api/links/my'),
}

// ── Dashboard API ─────────────────────────────────────────────
export const dashboardApi = {
  stats:    ()         => http.get('/api/dashboard/stats'),
  trend:    (days=30)  => http.get('/api/dashboard/trend', { params: { days } }),
  filetype: ()         => http.get('/api/dashboard/filetype'),
  activity: ()         => http.get('/api/dashboard/activity'),
  topusers: ()         => http.get('/api/dashboard/topusers'),
  recent:   ()         => http.get('/api/dashboard/recent'),
}

// ── Profile API ───────────────────────────────────────────────
export const profileApi = {
  update:      (data) => http.post('/api/profile/update', data),
  updateBio:   (data) => http.post('/api/profile/bio', data),
  updateColor: (data) => http.post('/api/profile/color', data),
  uploadAvatar:(fd)   => http.post('/api/avatar/upload', fd, {
    headers: { 'Content-Type': 'multipart/form-data' },
  }),
  deleteAvatar:()     => http.delete('/api/avatar'),
  stats:       ()     => http.get('/api/profile/stats'),
}

// ── Admin API ─────────────────────────────────────────────────
export const adminApi = {
  // 用户
  users:       ()         => http.get('/api/admin/users'),
  createUser:  (data)     => http.post('/api/admin/users', data),
  updateUser:  (data)     => http.put('/api/admin/users', data),
  deleteUser:  (id)       => http.delete(`/api/admin/users/${id}`),
  toggleUser:  (data)     => http.post('/api/admin/users/toggle', data),
  resetPw:     (data)     => http.post('/api/admin/users/reset-password', data),
  // 组织
  orgs:        ()         => http.get('/api/admin/orgs'),
  createOrg:   (data)     => http.post('/api/admin/orgs', data),
  updateOrg:   (data)     => http.put('/api/admin/orgs', data),
  deleteOrg:   (id)       => http.delete(`/api/admin/orgs/${id}`),
  // 存储
  storageStats:()         => http.get('/api/admin/storage/stats'),
  // 品牌
  branding:    ()         => http.get('/api/admin/branding'),
  saveBranding:(data)     => http.post('/api/admin/branding', data),
  // LDAP
  ldapConfig:  ()         => http.get('/api/admin/ldap'),
  saveLdap:    (data)     => http.post('/api/admin/ldap', data),
  testLdap:    (data)     => http.post('/api/admin/ldap/test', data),
  syncLdap:    ()         => http.post('/api/admin/ldap/sync'),
  // 账号申请
  registerRequests:(status='pending') => http.get('/api/admin/register-requests', { params: { status } }),
  approveRequest:  (data) => http.post('/api/admin/register-requests/approve', data),
  rejectRequest:   (data) => http.post('/api/admin/register-requests/reject', data),
  // 审计
  auditLogs:   (params)   => http.get('/api/audit/logs', { params }),
}

export default http
