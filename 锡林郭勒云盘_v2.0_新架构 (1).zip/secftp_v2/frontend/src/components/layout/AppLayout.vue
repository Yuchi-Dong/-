<template>
  <div class="app-shell">
    <!-- TopBar -->
    <header class="app-topbar topbar">
      <div class="topbar-logo">
        ☁ {{ systemName }}
        <small>政务云存储平台</small>
      </div>

      <!-- 搜索框 -->
      <div class="topbar-search">
        <span class="search-ico">🔍</span>
        <input
          v-model="searchQ"
          placeholder="搜索文件..."
          @keydown.enter="doSearch"
        />
      </div>

      <div class="topbar-actions">
        <ThemeToggle />
        <!-- 加密状态指示 -->
        <span
          class="topbar-btn"
          title="文件加密状态"
          style="font-size:11px"
        >
          🔒 加密存储
        </span>

        <!-- 通知 -->
        <button class="topbar-btn" @click="$router.push('/shared')" title="共享文件">
          🔗 <span v-if="auth.user?.unread_shares > 0" style="color:#fca5a5">{{ auth.user.unread_shares }}</span>
        </button>

        <!-- 用户头像 -->
        <div
          class="topbar-avatar"
          :style="auth.user?.avatar_path ? '' : `background:${auth.user?.avatar_color || '#1560bd'}`"
          @click="showUserMenu = !showUserMenu"
          ref="avatarRef"
        >
          <img v-if="auth.user?.avatar_path" :src="`/avatar/${auth.user.avatar_path}`" />
          <span v-else>{{ auth.username[0]?.toUpperCase() }}</span>
        </div>
        <span class="topbar-username">{{ auth.username }}</span>
        <span :class="['role-badge', roleClass]">{{ roleName }}</span>

        <!-- 用户菜单 -->
        <div v-if="showUserMenu" class="user-dropdown" @click.stop>
          <a @click="goProfile">👤 个人资料</a>
          <a @click="goChangePw">🔑 修改密码</a>
          <a v-if="auth.isAdmin" @click="$router.push('/admin'); showUserMenu=false">⚙️ 管理后台</a>
          <hr />
          <a @click="logout" class="danger">↩️ 退出登录</a>
        </div>
      </div>
    </header>

    <!-- Sidebar -->
    <nav class="app-sidebar sidebar">
      <div class="sidebar-logo">
        <div class="sys-name">{{ systemShort }}</div>
        <div class="sys-ver">v2.0 · 政务云存储</div>
      </div>

      <div class="sidebar-section">文件管理</div>
      <RouterLink class="nav-item" :class="{ active: isActive('/dashboard') }" to="/dashboard">
        <span class="nav-ico">📊</span> 数据仪表盘
      </RouterLink>
      <RouterLink class="nav-item" :class="{ active: isActive('/files') }" to="/files">
        <span class="nav-ico">📁</span> 文件管理
      </RouterLink>
      <RouterLink class="nav-item" :class="{ active: isActive('/shared') }" to="/shared">
        <span class="nav-ico">🔗</span> 共享文件
        <span v-if="auth.user?.unread_shares > 0" class="nav-badge">{{ auth.user.unread_shares }}</span>
      </RouterLink>
      <RouterLink class="nav-item" :class="{ active: isActive('/search') }" to="/search">
        <span class="nav-ico">🔍</span> 全文搜索
      </RouterLink>
      <RouterLink class="nav-item" :class="{ active: isActive('/trash') }" to="/trash">
        <span class="nav-ico">🗑️</span> 回收站
      </RouterLink>

      <template v-if="auth.isAdmin">
        <div class="sidebar-section">系统管理</div>
        <RouterLink class="nav-item" :class="{ active: isActive('/admin') }" to="/admin">
          <span class="nav-ico">👥</span> 用户管理
        </RouterLink>
        <RouterLink class="nav-item" :class="{ active: isActive('/admin/storage') }" to="/admin/storage">
          <span class="nav-ico">💾</span> 存储分析
        </RouterLink>
      </template>

      <div class="sidebar-section">账号</div>
      <RouterLink class="nav-item" :class="{ active: isActive('/profile') }" to="/profile">
        <span class="nav-ico">🎨</span> 个人资料
      </RouterLink>

      <!-- 存储配额 -->
      <div class="sidebar-footer" v-if="auth.user">
        <div class="storage-label">
          <span>存储空间</span>
          <span>{{ quotaPct }}%</span>
        </div>
        <div class="storage-bar">
          <div
            class="storage-fill"
            :style="`width:${quotaPct}%;background:${quotaPct > 85 ? '#dc2626' : quotaPct > 60 ? '#f59e0b' : '#1560bd'}`"
          ></div>
        </div>
        <div style="font-size:10px;color:rgba(255,255,255,.3);margin-top:4px">
          {{ usedMb }} MB / {{ quotaGb }} GB
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="app-main">
      <div class="page-content">
        <slot />
      </div>
    </main>
  </div>

  <!-- 点击外部关闭用户菜单 -->
  <div v-if="showUserMenu" class="menu-backdrop" @click="showUserMenu=false"></div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { useRouter, useRoute, RouterLink } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import ThemeToggle from '@/components/ui/ThemeToggle.vue'

const props = defineProps({
  systemName:  { type: String, default: '锡林郭勒云盘' },
  systemShort: { type: String, default: '锡林郭勒云盘' },
})

const router      = useRouter()
const route       = useRoute()
const auth        = useAuthStore()
const searchQ     = ref('')
const showUserMenu= ref(false)

const roleClass = computed(() => ['super','dept','user'][auth.role] || 'user')
const roleName  = computed(() => ['超级管理员','组织管理员','成员'][auth.role] || '成员')

const usedMb  = computed(() => auth.user?.used_mb?.toFixed(0) || 0)
const quotaGb = computed(() => ((auth.user?.quota_mb || 1048576) / 1024).toFixed(0))
const quotaPct= computed(() => {
  const used  = parseFloat(usedMb.value) || 0
  const quota = parseFloat(quotaGb.value) * 1024 || 1024
  return Math.min(100, Math.round(used / quota * 100))
})

function isActive(path) {
  return route.path === path || route.path.startsWith(path + '/')
}

function doSearch() {
  if (searchQ.value.trim()) {
    router.push({ name: 'Search', query: { q: searchQ.value.trim() } })
    searchQ.value = ''
  }
}

function goProfile() { router.push('/profile'); showUserMenu.value = false }
function goChangePw() { router.push('/profile?tab=security'); showUserMenu.value = false }

async function logout() {
  await auth.logout()
  router.push('/login')
}
</script>

<style scoped>
.user-dropdown {
  position: absolute;
  top: 50px;
  right: 16px;
  background: white;
  border: 1px solid var(--c-border);
  border-radius: var(--r-lg);
  box-shadow: var(--shadow-lg);
  min-width: 160px;
  z-index: 200;
  overflow: hidden;
}
.user-dropdown a {
  display: block;
  padding: 10px 16px;
  font-size: 13px;
  color: var(--c-text);
  cursor: pointer;
  transition: var(--t);
}
.user-dropdown a:hover { background: var(--c-bg); }
.user-dropdown a.danger { color: var(--c-danger); }
.user-dropdown hr { border: none; border-top: 1px solid var(--c-border); margin: 4px 0; }
.menu-backdrop { position: fixed; inset: 0; z-index: 150; }
</style>
