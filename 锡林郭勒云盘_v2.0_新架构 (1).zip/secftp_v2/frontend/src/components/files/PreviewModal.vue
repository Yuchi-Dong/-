<template>
  <Teleport to="body">
    <div v-if="visible" class="preview-overlay" @click.self="close">
      <div class="preview-shell">
        <!-- Header -->
        <div class="preview-hdr">
          <div class="flex items-center gap-3" style="min-width:0">
            <span style="font-size:20px">{{ meta.icon }}</span>
            <span class="truncate" style="font-weight:600;max-width:400px">{{ filename }}</span>
            <span class="badge badge-gray text-xs">{{ ext.toUpperCase() }}</span>
          </div>
          <div class="flex gap-2 items-center">
            <a :href="fileUrl + '?dl=1'" class="btn btn-outline btn-sm" target="_blank">⬇ 下载</a>
            <button class="btn btn-ghost btn-sm btn-icon" @click="close" title="关闭">✕</button>
          </div>
        </div>

        <!-- Content -->
        <div class="preview-body">
          <!-- 加载中 -->
          <div v-if="loading" class="loading-wrap" style="height:400px"><div class="spinner"></div></div>

          <!-- 图片 -->
          <div v-else-if="ftype==='image'" class="preview-img-wrap">
            <img :src="fileUrl" class="preview-img" :alt="filename"
                 @load="loading=false" @error="onImgError" />
          </div>

          <!-- 视频 -->
          <div v-else-if="ftype==='video'" class="preview-video-wrap">
            <video controls autoplay class="preview-video" :src="fileUrl"
                   @loadeddata="loading=false">
              <p>您的浏览器不支持视频预览，请 <a :href="fileUrl+'?dl=1'">下载文件</a></p>
            </video>
          </div>

          <!-- 音频 -->
          <div v-else-if="ftype==='audio'" class="preview-audio-wrap">
            <div class="audio-art">🎵</div>
            <div class="audio-name">{{ filename }}</div>
            <audio controls autoplay class="preview-audio" :src="fileUrl" @loadeddata="loading=false">
              <p>您的浏览器不支持音频播放</p>
            </audio>
          </div>

          <!-- PDF -->
          <div v-else-if="ftype==='pdf'" class="preview-pdf-wrap">
            <iframe :src="`${fileUrl}#toolbar=1`" class="preview-pdf"
                    @load="loading=false"></iframe>
          </div>

          <!-- 文本/代码 -->
          <div v-else-if="ftype==='text'||ftype==='code'" class="preview-text-wrap">
            <div class="preview-text-toolbar">
              <span class="text-xs text-muted">{{ encoding }}</span>
              <span class="text-xs text-muted">{{ lineCount }} 行</span>
              <button class="btn btn-ghost btn-xs" @click="copyText">📋 复制</button>
            </div>
            <pre class="preview-text" :class="{'preview-code': ftype==='code'}"><code>{{ content }}</code></pre>
          </div>

          <!-- 不支持预览 -->
          <div v-else class="empty-state" style="height:300px;justify-content:center;display:flex;flex-direction:column;align-items:center">
            <div class="empty-ico" style="font-size:64px">{{ meta.icon }}</div>
            <div class="empty-title">该格式暂不支持在线预览</div>
            <div style="margin-top:16px">
              <a :href="fileUrl+'?dl=1'" class="btn btn-primary">⬇ 下载文件</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useToastStore } from '@/stores/toast'
import { fileApi } from '@/api'

const props = defineProps({
  path:    { type: String, default: '' },
  visible: { type: Boolean, default: false },
})
const emit = defineEmits(['close'])

const toast   = useToastStore()
const loading = ref(true)
const content = ref('')
const encoding= ref('utf-8')
const ftype   = ref('other')
const filename= ref('')
const ext     = ref('')
const fileUrl = ref('')
const error   = ref('')

const FTYPE_META = {
  dir:'📁', image:'🖼️', video:'🎬', audio:'🎵', pdf:'📄',
  word:'📝', excel:'📊', ppt:'📈', zip:'🗜️', text:'📃', code:'💻', other:'📦'
}
const meta = computed(() => ({ icon: FTYPE_META[ftype.value] || '📦' }))
const lineCount = computed(() => content.value.split('\n').length)

watch(() => props.visible, async (v) => {
  if (!v || !props.path) return
  loading.value = true
  content.value = ''
  error.value   = ''

  filename.value = props.path.split('/').pop()
  ext.value      = filename.value.includes('.') ? filename.value.split('.').pop() : ''
  fileUrl.value  = `/api/file/${props.path}`

  try {
    const info = await fileApi.preview({ path: props.path })
    ftype.value    = info.ftype || 'other'
    if (info.content !== undefined) {
      content.value  = info.content
      encoding.value = info.encoding || 'utf-8'
    }
    loading.value = false
  } catch (e) {
    loading.value = false
    ftype.value   = _guessFtype(ext.value)
  }
})

function _guessFtype(e) {
  e = e.toLowerCase()
  if (['jpg','jpeg','png','gif','webp','bmp'].includes(e)) return 'image'
  if (['mp4','mkv','avi','mov'].includes(e))               return 'video'
  if (['mp3','wav','flac','aac'].includes(e))              return 'audio'
  if (e === 'pdf')                                          return 'pdf'
  if (['txt','md','log','conf','ini'].includes(e))          return 'text'
  if (['py','js','ts','vue','html','css','json'].includes(e)) return 'code'
  return 'other'
}

function onImgError() { loading.value = false; ftype.value = 'other' }
function close() { emit('close') }
async function copyText() {
  try { await navigator.clipboard.writeText(content.value); toast.ok('已复制') }
  catch { toast.err('复制失败') }
}
</script>

<style scoped>
.preview-overlay {
  position: fixed; inset: 0;
  background: rgba(0,0,0,.8);
  z-index: 2000;
  display: flex; align-items: center; justify-content: center;
  padding: 20px;
}
.preview-shell {
  background: var(--c-surface);
  border-radius: 12px;
  box-shadow: 0 25px 50px rgba(0,0,0,.5);
  width: 90vw; max-width: 1100px;
  height: 88vh;
  display: flex; flex-direction: column;
  overflow: hidden;
}
.preview-hdr {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 20px;
  border-bottom: 1px solid var(--c-border);
  flex-shrink: 0;
}
.preview-body {
  flex: 1; overflow: hidden;
  display: flex; align-items: center; justify-content: center;
  background: var(--c-bg);
}
.preview-img-wrap { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; overflow: auto; }
.preview-img { max-width: 100%; max-height: 100%; object-fit: contain; border-radius: 4px; }
.preview-video-wrap { width: 100%; height: 100%; display: flex; align-items: center; justify-content: center; background: #000; }
.preview-video { max-width: 100%; max-height: 100%; }
.preview-audio-wrap { display: flex; flex-direction: column; align-items: center; gap: 20px; padding: 40px; }
.audio-art { font-size: 80px; }
.audio-name { font-size: 16px; font-weight: 600; color: var(--c-text); }
.preview-audio { width: 400px; max-width: 100%; }
.preview-pdf-wrap { width: 100%; height: 100%; }
.preview-pdf { width: 100%; height: 100%; border: none; }
.preview-text-wrap { width: 100%; height: 100%; display: flex; flex-direction: column; overflow: hidden; }
.preview-text-toolbar {
  display: flex; align-items: center; gap: 12px; justify-content: flex-end;
  padding: 8px 16px;
  border-bottom: 1px solid var(--c-border);
  background: var(--c-surface);
  flex-shrink: 0;
}
.preview-text {
  flex: 1; overflow: auto;
  padding: 20px;
  font-family: var(--font-mono);
  font-size: 13px;
  line-height: 1.6;
  color: var(--c-text);
  background: var(--c-bg);
  margin: 0;
  white-space: pre-wrap;
  word-break: break-all;
}
.preview-code { color: #e2e8f0; background: #1e293b; }
</style>
