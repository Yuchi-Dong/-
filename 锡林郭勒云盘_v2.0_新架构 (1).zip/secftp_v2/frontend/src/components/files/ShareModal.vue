<template>
  <Teleport to="body">
    <div v-if="visible" class="modal-overlay" @click.self="close">
      <div class="modal" style="max-width:520px">
        <div class="modal-header">
          <span class="modal-title">🔗 分享文件</span>
          <button class="modal-close" @click="close">✕</button>
        </div>
        <div class="modal-body">
          <div class="flex items-center gap-3" style="margin-bottom:20px;padding:12px 14px;background:var(--c-bg);border-radius:var(--r-lg)">
            <span style="font-size:24px">{{ icon }}</span>
            <div style="min-width:0">
              <div class="font-medium truncate">{{ filename }}</div>
              <div class="text-xs text-muted">{{ path }}</div>
            </div>
          </div>

          <!-- Tabs -->
          <div class="flex gap-1" style="margin-bottom:20px;border-bottom:1px solid var(--c-border);padding-bottom:0">
            <button v-for="t in tabs" :key="t.id"
                    :class="['btn btn-ghost btn-sm', activeTab===t.id && 'active-tab']"
                    @click="activeTab=t.id">{{ t.label }}</button>
          </div>

          <!-- Tab: 指定用户/组织 -->
          <div v-if="activeTab==='target'">
            <div class="form-group">
              <label class="form-label">搜索用户或组织</label>
              <input v-model="searchQ" class="input" placeholder="输入姓名/用户名..." @input="searchTargets" />
            </div>
            <div v-if="searchResults.length" style="max-height:160px;overflow-y:auto;border:1px solid var(--c-border);border-radius:var(--r);margin-bottom:14px">
              <div v-for="r in searchResults" :key="r.type+r.id"
                   class="flex items-center gap-2"
                   style="padding:9px 12px;cursor:pointer;border-bottom:1px solid var(--c-border);font-size:13px"
                   :style="selectedTarget?.id===r.id?'background:var(--c-primary-lt)':''"
                   @click="selectedTarget=r">
                <span>{{ r.type==='user' ? '👤' : '🏢' }}</span>
                <span>{{ r.label }}</span>
                <span class="badge badge-gray text-xs" style="margin-left:auto">{{ r.type==='user'?'用户':'组织' }}</span>
              </div>
            </div>
            <div v-if="selectedTarget" class="flex items-center gap-2" style="margin-bottom:14px;padding:8px 12px;background:var(--c-primary-lt);border-radius:var(--r)">
              <span>{{ selectedTarget.type==='user'?'👤':'🏢' }}</span>
              <span class="font-medium">{{ selectedTarget.label }}</span>
              <button class="btn btn-ghost btn-xs btn-icon" style="margin-left:auto" @click="selectedTarget=null">✕</button>
            </div>
          </div>

          <!-- Tab: 公开链接 -->
          <div v-if="activeTab==='link'">
            <div v-if="linkResult" class="link-result">
              <div class="link-url-box">
                <span class="truncate">{{ linkUrl }}</span>
                <button class="btn btn-primary btn-sm" @click="copyLink">📋 复制</button>
              </div>
              <div v-if="linkPassword" class="text-sm text-muted" style="margin-top:8px">
                提取码：<strong>{{ linkPassword }}</strong>
              </div>
              <button class="btn btn-outline btn-sm" style="margin-top:12px" @click="linkResult=null">重新生成</button>
            </div>
          </div>

          <!-- 公共设置 -->
          <div class="grid-2" style="gap:12px;margin-bottom:16px">
            <div class="form-group" style="margin:0">
              <label class="form-label">权限</label>
              <select v-model="perm" class="select">
                <option value="ro">只读</option>
                <option value="rw">读写</option>
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">有效期</label>
              <select v-model="expiresDays" class="select">
                <option value="0">永久</option>
                <option value="1">1天</option>
                <option value="7">7天</option>
                <option value="30">30天</option>
                <option value="90">90天</option>
              </select>
            </div>
          </div>

          <div v-if="activeTab==='link'" class="form-group">
            <label class="form-label">提取码（可选）</label>
            <div class="flex gap-2">
              <input v-model="linkPassword" class="input" placeholder="留空则无需提取码" maxlength="20" style="flex:1" />
              <button class="btn btn-outline btn-sm" @click="linkPassword=_randCode()">随机</button>
            </div>
          </div>

          <div v-if="activeTab==='link'" class="form-group">
            <label class="form-label">下载次数限制</label>
            <input v-model.number="maxViews" class="input" type="number" min="0" placeholder="0 = 不限" />
          </div>

          <div v-if="error" class="form-error-msg" style="margin-bottom:12px">{{ error }}</div>
        </div>

        <div class="modal-footer">
          <button class="btn btn-outline" @click="close">取消</button>
          <button class="btn btn-primary" :disabled="submitting" @click="submit">
            {{ submitting ? '处理中...' : (activeTab==='link' ? '生成链接' : '创建分享') }}
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { useToastStore } from '@/stores/toast'
import { shareApi } from '@/api'

const props = defineProps({
  path:    { type: String, default: '' },
  visible: { type: Boolean, default: false },
})
const emit   = defineEmits(['close', 'shared'])
const toast  = useToastStore()

const tabs = [
  { id: 'target', label: '👤 指定用户/组织' },
  { id: 'public', label: '🌐 全员公开' },
  { id: 'link',   label: '🔗 公开链接' },
]
const activeTab     = ref('target')
const perm          = ref('ro')
const expiresDays   = ref(7)
const linkPassword  = ref('')
const maxViews      = ref(0)
const searchQ       = ref('')
const searchResults = ref([])
const selectedTarget= ref(null)
const submitting    = ref(false)
const error         = ref('')
const linkResult    = ref(null)
const linkUrl       = ref('')

const filename = computed(() => props.path.split('/').pop())
const icon     = computed(() => {
  const e = filename.value.split('.').pop().toLowerCase()
  if (['jpg','jpeg','png','gif','webp'].includes(e)) return '🖼️'
  if (e === 'pdf') return '📄'
  if (['doc','docx'].includes(e)) return '📝'
  if (['mp4','mkv'].includes(e)) return '🎬'
  return '📁'
})

let searchTimer
function searchTargets() {
  clearTimeout(searchTimer)
  if (!searchQ.value.trim()) { searchResults.value = []; return }
  searchTimer = setTimeout(async () => {
    try {
      const r = await shareApi.targets(searchQ.value)
      searchResults.value = [...r.users, ...r.orgs]
    } catch {}
  }, 300)
}

async function submit() {
  error.value = ''
  submitting.value = true
  try {
    if (activeTab.value === 'link') {
      const r = await shareApi.createLink({
        path:         props.path,
        password:     linkPassword.value,
        expires_days: expiresDays.value,
        max_views:    maxViews.value,
      })
      linkResult.value = r
      linkUrl.value    = `${location.origin}/s/${r.token}`
      toast.ok('公开链接已生成')
    } else {
      const shareType = activeTab.value === 'public' ? 'public' :
                        selectedTarget.value?.type === 'org' ? 'org' : 'user'
      if (shareType !== 'public' && !selectedTarget.value) {
        error.value = '请选择分享对象'
        return
      }
      await shareApi.create({
        path:        props.path,
        type:        shareType,
        target_id:   selectedTarget.value?.id,
        perm:        perm.value,
        expires_days: expiresDays.value,
      })
      toast.ok('分享创建成功')
      emit('shared')
      close()
    }
  } catch (e) {
    error.value = e?.error || '操作失败'
  } finally {
    submitting.value = false
  }
}

async function copyLink() {
  try { await navigator.clipboard.writeText(linkUrl.value); toast.ok('链接已复制') }
  catch { toast.err('复制失败') }
}

function _randCode() {
  return Math.random().toString(36).slice(2, 6).toUpperCase()
}

function close() {
  linkResult.value = null; selectedTarget.value = null
  searchQ.value = ''; error.value = ''
  emit('close')
}
</script>

<style scoped>
.active-tab { border-bottom: 2px solid var(--c-primary); border-radius: 0; color: var(--c-primary); font-weight: 600; }
.link-result { background: var(--c-bg); border-radius: var(--r-lg); padding: 16px; }
.link-url-box { display: flex; align-items: center; gap: 10px; background: var(--c-surface); border: 1px solid var(--c-border); border-radius: var(--r); padding: 10px 14px; }
</style>
