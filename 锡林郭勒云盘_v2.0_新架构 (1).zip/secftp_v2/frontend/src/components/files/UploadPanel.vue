<template>
  <!-- 浮动上传面板 -->
  <div v-if="tasks.length > 0" class="upload-panel" :class="{ minimized }">
    <div class="up-header" @click="minimized = !minimized">
      <span class="up-title">
        📤 上传任务
        <span v-if="activeCount > 0" class="up-badge">{{ activeCount }}</span>
      </span>
      <div class="flex gap-1">
        <button class="btn btn-ghost btn-xs btn-icon" @click.stop="minimized=!minimized">
          {{ minimized ? '▲' : '▼' }}
        </button>
        <button class="btn btn-ghost btn-xs btn-icon" @click.stop="clearDone" title="清除已完成">✕</button>
      </div>
    </div>

    <div v-show="!minimized" class="up-list">
      <div v-for="task in tasks" :key="task.id" class="up-task">
        <div class="flex items-center gap-2" style="min-width:0">
          <span class="up-ico">{{ task.ftype_icon }}</span>
          <div style="min-width:0;flex:1">
            <div class="up-name truncate">{{ task.filename }}</div>
            <div class="flex items-center gap-2" style="margin-top:3px">
              <div class="progress" style="flex:1;height:3px">
                <div class="progress-bar" :style="`width:${task.pct}%;background:${statusColor(task.status)}`"></div>
              </div>
              <span class="text-xs" :style="`color:${statusColor(task.status)};white-space:nowrap`">
                {{ statusText(task) }}
              </span>
            </div>
          </div>
        </div>
        <div class="flex gap-1 flex-shrink-0">
          <button v-if="task.status==='uploading'" class="btn btn-ghost btn-xs btn-icon"
                  @click="pause(task)" title="暂停">⏸</button>
          <button v-if="task.status==='paused'" class="btn btn-ghost btn-xs btn-icon"
                  @click="resume(task)" title="继续">▶</button>
          <button v-if="['error','cancelled'].includes(task.status)" class="btn btn-ghost btn-xs btn-icon"
                  @click="retry(task)" title="重试">🔄</button>
          <button v-if="task.status!=='uploading'" class="btn btn-ghost btn-xs btn-icon"
                  @click="cancel(task)" title="取消/移除">✕</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onUnmounted } from 'vue'
import { useToastStore } from '@/stores/toast'
import { fileApi } from '@/api'

const toast = useToastStore()
const tasks = ref([])
const minimized = ref(false)

const activeCount = computed(() => tasks.value.filter(t => t.status === 'uploading').length)

// ── 外部调用：添加文件上传任务 ──────────────────────
function addFiles(files, path) {
  for (const file of files) {
    const id = Date.now() + Math.random()
    tasks.value.push({
      id,
      file,
      filename:   file.name,
      path,
      ftype_icon: _icon(file.name),
      status:     'pending',   // pending | uploading | paused | done | error | instant
      pct:        0,
      speed:      '',
      upload_id:  null,
      done_chunks: [],
      _aborted:   false,
    })
  }
  _processQueue()
}

defineExpose({ addFiles })
const emit = defineEmits(['done'])

// ── 并发控制：最多 3 个同时上传 ────────────────────
const CONCURRENCY = 3
const CHUNK_SIZE  = 5 * 1024 * 1024  // 5MB

async function _processQueue() {
  while (activeCount.value < CONCURRENCY) {
    const pending = tasks.value.find(t => t.status === 'pending')
    if (!pending) break
    pending.status = 'uploading'
    _uploadTask(pending)
  }
}

async function _uploadTask(task) {
  const file = task.file
  try {
    // 1. 计算文件 Hash（用于秒传）
    const hash = await _calcHash(file)
    task.pct   = 2

    // 2. 初始化上传（秒传检查 + 断点续传）
    const total_chunks = Math.ceil(file.size / CHUNK_SIZE)
    const initResp = await fileApi.uploadInit({
      filename:     file.name,
      size:         file.size,
      hash,
      total_chunks,
      path:         task.path,
    })

    if (initResp.instant) {
      task.status = 'instant'
      task.pct    = 100
      toast.ok(`⚡ ${file.name} 秒传成功`)
      emit('done', task.path)
      _afterDone()
      return
    }

    task.upload_id   = initResp.upload_id
    const uploaded   = new Set(initResp.uploaded_chunks || [])
    const allChunks  = Array.from({ length: total_chunks }, (_, i) => i)
    const remaining  = allChunks.filter(i => !uploaded.has(i))

    if (initResp.resuming && remaining.length < total_chunks) {
      toast.info(`🔄 ${file.name} 断点续传，已完成 ${uploaded.size}/${total_chunks} 块`)
    }

    // 3. 并发上传分片（同时发 3 个）
    const CHUNK_CONCURRENCY = 3
    let idx = 0
    const _uploadChunk = async (chunkIndex) => {
      if (task._aborted || task.status === 'paused') return

      const start = chunkIndex * CHUNK_SIZE
      const end   = Math.min(start + CHUNK_SIZE, file.size)
      const blob  = file.slice(start, end)

      const fd = new FormData()
      fd.append('upload_id',   task.upload_id)
      fd.append('chunk_index', chunkIndex)
      fd.append('chunk',       blob)

      const t0 = Date.now()
      const result = await fileApi.uploadChunk(fd)

      if (result.done) {
        task.status = 'done'
        task.pct    = 100
        toast.ok(`✅ ${file.name} 上传完成`)
        emit('done', task.path)
        _afterDone()
      } else {
        uploaded.add(chunkIndex)
        const done = uploaded.size
        task.pct   = Math.round((done / total_chunks) * 100)
        const mbps = ((end - start) / 1024 / 1024 / ((Date.now()-t0)/1000)).toFixed(1)
        task.speed = `${mbps} MB/s`
      }
    }

    // 批量并发
    while (idx < remaining.length && !task._aborted) {
      if (task.status === 'paused') {
        await _sleep(500)
        continue
      }
      const batch = remaining.slice(idx, idx + CHUNK_CONCURRENCY)
      await Promise.all(batch.map(ci => _uploadChunk(ci)))
      idx += CHUNK_CONCURRENCY
    }

    if (!task._aborted && task.status !== 'done') {
      // 手动触发合并
      const result = await fileApi.uploadComplete({ upload_id: task.upload_id })
      if (result.done) {
        task.status = 'done'; task.pct = 100
        toast.ok(`✅ ${file.name} 上传完成`)
        emit('done', task.path)
      }
    }
  } catch (e) {
    if (!task._aborted) {
      task.status = 'error'
      toast.err(`❌ ${file.name} 上传失败: ${e?.error || '网络错误'}`)
    }
  }
  _afterDone()
}

function _afterDone() {
  // 继续处理队列中的下一个任务
  setTimeout(_processQueue, 100)
}

// ── 暂停 / 继续 / 取消 / 重试 ────────────────────
function pause(task) { task.status = 'paused'; task.speed = '' }
function resume(task) { task.status = 'uploading'; _uploadTask(task) }
function cancel(task) {
  task._aborted = true
  task.status   = 'cancelled'
  if (task.upload_id) {
    fileApi.uploadCancel({ upload_id: task.upload_id }).catch(() => {})
  }
  tasks.value = tasks.value.filter(t => t.id !== task.id)
  _processQueue()
}
function retry(task) {
  task.status   = 'pending'
  task._aborted = false
  task.pct      = 0
  task.speed    = ''
  _processQueue()
}
function clearDone() {
  tasks.value = tasks.value.filter(t => !['done','instant','cancelled'].includes(t.status))
}

// ── 工具函数 ──────────────────────────────────────
async function _calcHash(file) {
  // 大文件只哈希前后各 1MB + 文件大小（近似秒传，避免长时间阻塞）
  const SAMPLE = 1 * 1024 * 1024
  let buf
  if (file.size <= SAMPLE * 2) {
    buf = await file.arrayBuffer()
  } else {
    const head = file.slice(0, SAMPLE)
    const tail = file.slice(file.size - SAMPLE)
    const [hb, tb] = await Promise.all([head.arrayBuffer(), tail.arrayBuffer()])
    const combined = new Uint8Array(hb.byteLength + tb.byteLength)
    combined.set(new Uint8Array(hb), 0)
    combined.set(new Uint8Array(tb), hb.byteLength)
    buf = combined.buffer
  }
  const hash = await crypto.subtle.digest('SHA-256', buf)
  const hex  = Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2,'0')).join('')
  // 加入文件大小使 hash 更唯一
  return hex.slice(0,32) + file.size.toString(16).padStart(16,'0')
}

function _sleep(ms) { return new Promise(r => setTimeout(r, ms)) }

function _icon(name) {
  const e = name.split('.').pop().toLowerCase()
  if (['jpg','jpeg','png','gif','webp'].includes(e)) return '🖼️'
  if (['mp4','mkv','avi','mov'].includes(e))          return '🎬'
  if (['mp3','wav','flac'].includes(e))                return '🎵'
  if (e === 'pdf')                                     return '📄'
  if (['doc','docx'].includes(e))                      return '📝'
  if (['xls','xlsx','csv'].includes(e))                return '📊'
  if (['zip','rar','7z'].includes(e))                  return '🗜️'
  return '📦'
}

function statusColor(s) {
  return { uploading:'#3b82f6', done:'#16a34a', instant:'#16a34a',
           paused:'#f59e0b', error:'#dc2626', cancelled:'#94a3b8', pending:'#94a3b8' }[s] || '#94a3b8'
}
function statusText(task) {
  const m = { done:'✓ 完成', instant:'⚡ 秒传', paused:'已暂停', error:'失败',
               cancelled:'已取消', pending:'等待中' }
  if (task.status === 'uploading')
    return task.speed ? `${task.pct}% · ${task.speed}` : `${task.pct}%`
  return m[task.status] || task.status
}
</script>

<style scoped>
.upload-panel {
  position: fixed; bottom: 24px; right: 24px;
  width: 360px; z-index: 500;
  background: var(--c-surface);
  border: 1px solid var(--c-border);
  border-radius: 10px;
  box-shadow: 0 8px 30px rgba(0,0,0,.15);
  overflow: hidden;
}
.upload-panel.minimized .up-list { display: none; }
.up-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 12px 14px;
  background: var(--c-primary);
  color: #fff;
  cursor: pointer;
  user-select: none;
}
.up-title { font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 8px; }
.up-badge { background: rgba(255,255,255,.3); font-size: 11px; padding: 1px 6px; border-radius: 10px; }
.up-list { max-height: 300px; overflow-y: auto; }
.up-task {
  display: flex; align-items: center; justify-content: space-between;
  padding: 10px 14px; gap: 10px;
  border-bottom: 1px solid var(--c-border);
}
.up-task:last-child { border-bottom: none; }
.up-ico { font-size: 18px; flex-shrink: 0; }
.up-name { font-size: 12px; font-weight: 500; color: var(--c-text); }
</style>
