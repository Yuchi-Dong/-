# -*- coding: utf-8 -*-
"""
infra/metrics.py — Prometheus 监控指标

暴露 /metrics 端点，Prometheus 拉取数据。
不依赖 prometheus_client（避免增加部署复杂度），手写 text 格式。

指标列表：
  secftp_http_requests_total        HTTP 请求总数（按 method/path/status）
  secftp_file_uploads_total         文件上传总数
  secftp_file_downloads_total       文件下载总数
  secftp_active_users               当前在线用户数
  secftp_storage_bytes              存储总量（字节）
  secftp_db_pool_used               DB 连接池已用连接数
  secftp_error_total                错误总数（按类型）
  secftp_response_time_seconds      响应时间分位数（P50/P95/P99）
"""
import time
import threading
import collections
import logging
import os
from flask import Blueprint, Response, request, g

log = logging.getLogger("metrics")
bp  = Blueprint("metrics", __name__)

# ── 指标收集器 ────────────────────────────────────────
_counters: dict = collections.defaultdict(int)
_histograms: dict = collections.defaultdict(list)
_lock = threading.Lock()


def inc(name: str, labels: dict = None, value: int = 1):
    key = _label_key(name, labels or {})
    with _lock:
        _counters[key] += value


def observe(name: str, value: float, labels: dict = None):
    key = _label_key(name, labels or {})
    with _lock:
        hist = _histograms[key]
        hist.append(value)
        if len(hist) > 10000:   # 保留最近 10000 个样本
            hist.pop(0)


def _label_key(name: str, labels: dict) -> str:
    if not labels:
        return name
    lstr = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
    return f"{name}{{{lstr}}}"


def _percentile(data: list, p: float) -> float:
    if not data: return 0.0
    s = sorted(data)
    i = int(len(s) * p / 100)
    return s[min(i, len(s)-1)]


# ── Flask 请求中间件 ───────────────────────────────────
def init_metrics(app):
    """在 app factory 中调用，注册指标中间件"""
    app.register_blueprint(bp)

    @app.before_request
    def _before():
        g._req_start = time.perf_counter()

    @app.after_request
    def _after(response):
        duration = time.perf_counter() - getattr(g, "_req_start", time.perf_counter())
        path = request.path.split("/")[1:3]
        path_label = "/" + "/".join(path) if path else "/"
        inc("secftp_http_requests_total", {
            "method": request.method, "path": path_label,
            "status": str(response.status_code)
        })
        observe("secftp_response_time_seconds", duration, {"path": path_label})
        if request.path.startswith("/api/files/upload") and response.status_code < 300:
            inc("secftp_file_uploads_total")
        if request.path.startswith("/api/file/") and response.status_code < 300:
            inc("secftp_file_downloads_total")
        if response.status_code >= 500:
            inc("secftp_error_total", {"type": "server_error"})
        return response


# ── /metrics 端点 ─────────────────────────────────────
@bp.route("/metrics")
def metrics():
    """Prometheus text format"""
    lines = [
        "# HELP secftp_http_requests_total Total HTTP requests",
        "# TYPE secftp_http_requests_total counter",
    ]

    with _lock:
        counters_snap = dict(_counters)
        histograms_snap = {k: list(v) for k, v in _histograms.items()}

    for key, val in counters_snap.items():
        lines.append(f"{key} {val}")

    lines += [
        "# HELP secftp_response_time_seconds Response latency",
        "# TYPE secftp_response_time_seconds summary",
    ]
    for key, samples in histograms_snap.items():
        name = key.split("{")[0]
        labels_part = ("{" + key.split("{")[1]) if "{" in key else ""
        for q in (50, 95, 99):
            qkey = name + (labels_part[:-1] + f',quantile="{q/100}"' + "}") if labels_part else f'{name}{{quantile="{q/100}"}}'
            lines.append(f"{qkey} {_percentile(samples, q):.6f}")

    # 实时指标（从 DB 查）
    try:
        _add_db_metrics(lines)
    except Exception as e:
        lines.append(f"# DB metrics error: {e}")

    return Response("\n".join(lines) + "\n", mimetype="text/plain; version=0.0.4")


def _add_db_metrics(lines: list):
    from core.db import get_conn
    with get_conn() as conn:
        # 在线用户
        active = conn.execute(
            "SELECT COUNT(DISTINCT user_id) as c FROM active_sessions "
            "WHERE is_active=TRUE AND last_active > NOW() - INTERVAL '30 minutes'"
        ).fetchone()["c"]
        lines += [
            "# HELP secftp_active_users Currently active users (30min window)",
            "# TYPE secftp_active_users gauge",
            f"secftp_active_users {active}",
        ]

        # 存储量
        storage_bytes = conn.execute(
            "SELECT COALESCE(SUM(file_size), 0) as s FROM file_index"
        ).fetchone()["s"]
        lines += [
            "# HELP secftp_storage_bytes Total storage used bytes",
            "# TYPE secftp_storage_bytes gauge",
            f"secftp_storage_bytes {storage_bytes}",
        ]

        # 今日操作数
        today_ops = conn.execute(
            "SELECT COUNT(*) as c FROM audit_log WHERE ts::date = NOW()::date"
        ).fetchone()["c"]
        lines += [
            "# HELP secftp_today_operations Operations today",
            "# TYPE secftp_today_operations gauge",
            f"secftp_today_operations {today_ops}",
        ]
