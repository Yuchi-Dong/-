# -*- coding: utf-8 -*-
"""
infra/models.py — 数据库 Schema 定义与初始化

规则：
  - 所有 CREATE TABLE 使用 IF NOT EXISTS（幂等）
  - 所有 ALTER TABLE 用 ADD COLUMN IF NOT EXISTS（升级安全）
  - 表注释说明每张表的职责
  - 不含任何业务逻辑，只负责 DDL
"""
import hashlib
import logging
import os
import secrets

log = logging.getLogger("models")


def init_db() -> None:
    """初始化全部数据库表，幂等，启动时调用"""
    from core.db import get_conn
    with get_conn() as conn:
        _create_tables(conn)
        _create_indexes(conn)
        _seed_defaults(conn)
    # 初始化全文搜索索引
    try:
        from product.files.search_pg import ensure_search_index
        ensure_search_index()
    except Exception as e:
        log.warning(f"全文搜索索引初始化失败（可忽略）: {e}")
    log.info("数据库初始化完成")


def _create_tables(conn) -> None:
    # ── 组织架构 ──────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS organizations (
            id          SERIAL PRIMARY KEY,
            name        TEXT NOT NULL,
            code        TEXT NOT NULL,
            parent_id   INTEGER REFERENCES organizations(id),
            org_level   INTEGER NOT NULL DEFAULT 1,
            dir_path    TEXT NOT NULL,
            description TEXT DEFAULT '',
            created_by  INTEGER,
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            updated_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 用户 ──────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id                  SERIAL PRIMARY KEY,
            username            TEXT UNIQUE NOT NULL,
            password_hash       TEXT NOT NULL,
            password_salt       TEXT NOT NULL,
            role                INTEGER NOT NULL DEFAULT 2,
            org_id              INTEGER REFERENCES organizations(id),
            display_name        TEXT DEFAULT '',
            email               TEXT DEFAULT '',
            phone               TEXT DEFAULT '',
            bio                 TEXT DEFAULT '',
            location            TEXT DEFAULT '',
            department_title    TEXT DEFAULT '',
            avatar_color        TEXT DEFAULT '#1560bd',
            avatar_path         TEXT DEFAULT '',
            is_active           BOOLEAN NOT NULL DEFAULT TRUE,
            is_ldap_user        BOOLEAN NOT NULL DEFAULT FALSE,
            fail_count          INTEGER DEFAULT 0,
            locked_until        TIMESTAMPTZ,
            quota_mb            BIGINT DEFAULT 1048576,
            totp_secret         TEXT DEFAULT '',
            totp_enabled        BOOLEAN DEFAULT FALSE,
            force_pw_change     BOOLEAN DEFAULT FALSE,
            pw_changed_at       TIMESTAMPTZ,
            created_by          INTEGER,
            created_at          TIMESTAMPTZ DEFAULT NOW(),
            last_login          TIMESTAMPTZ,
            -- 甲方公钥（用于保护该用户文件的 owner_enc File Key）
            -- 为空时不生成 owner_enc
            owner_public_key_pem TEXT DEFAULT ''
        )
    """)

    # ── KMS 租户密钥表 ──────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tenant_keys (
            id                    SERIAL PRIMARY KEY,
            org_id                INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
            org_name              TEXT DEFAULT '',
            public_key_pem        TEXT NOT NULL,
            encrypted_private_key TEXT NOT NULL,
            key_version           INTEGER NOT NULL DEFAULT 1,
            is_active             BOOLEAN NOT NULL DEFAULT TRUE,
            rotated_at            TIMESTAMPTZ,
            created_at            TIMESTAMPTZ DEFAULT NOW()
        )
    """)

        # ── 文件密钥表（核心安全表）──────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_keys (
            id          SERIAL PRIMARY KEY,
            -- 加密文件的相对路径（与 file_index 联动）
            file_path   TEXT NOT NULL UNIQUE,
            -- vendor 公钥加密的 File Key（base64）
            vendor_enc  TEXT NOT NULL,
            -- owner 公钥加密的 File Key（base64），可为空
            owner_enc   TEXT DEFAULT '',
            -- 租户公钥加密的 File Key（KMS 多租户隔离）
            tenant_enc  TEXT DEFAULT '',
            -- 文件大小（明文字节数，不含加密 overhead）
            plaintext_size BIGINT DEFAULT 0,
            -- 加密算法版本（用于未来升级）
            algo_version INTEGER DEFAULT 1,
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            updated_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 目录权限 ────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS dir_perms (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            dir_path    TEXT NOT NULL,
            perm        TEXT NOT NULL DEFAULT 'ro',
            granted_by  INTEGER REFERENCES users(id),
            granted_at  TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(user_id, dir_path)
        )
    """)

    # ── 组织权限 ────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS org_permissions (
            id          SERIAL PRIMARY KEY,
            org_id      INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
            path        TEXT NOT NULL,
            perm        TEXT NOT NULL DEFAULT 'ro',
            inherit     BOOLEAN DEFAULT TRUE,
            granted_by  INTEGER REFERENCES users(id),
            granted_at  TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(org_id, path)
        )
    """)

    # ── 文件分享 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_shares (
            id          SERIAL PRIMARY KEY,
            owner_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            file_path   TEXT NOT NULL,
            is_dir      BOOLEAN DEFAULT FALSE,
            share_type  TEXT NOT NULL DEFAULT 'user',
            target_id   INTEGER,
            perm        TEXT NOT NULL DEFAULT 'ro',
            expires_at  TIMESTAMPTZ,
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            is_active   BOOLEAN DEFAULT TRUE
        )
    """)

    # ── 文件版本 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_versions (
            id          SERIAL PRIMARY KEY,
            file_path   TEXT NOT NULL,
            version_no  INTEGER NOT NULL DEFAULT 1,
            file_size   BIGINT DEFAULT 0,
            backup_path TEXT NOT NULL,
            -- 版本文件也是加密的，独立 File Key
            vendor_enc  TEXT DEFAULT '',
            comment     TEXT DEFAULT '',
            created_by  INTEGER REFERENCES users(id),
            created_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 回收站 ────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS trash_items (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            orig_path   TEXT NOT NULL,
            trash_path  TEXT NOT NULL,
            is_dir      BOOLEAN DEFAULT FALSE,
            file_size   BIGINT DEFAULT 0,
            -- 加密文件的 vendor_enc 随文件移动，此处记录原 file_key 记录 id
            file_key_id INTEGER REFERENCES file_keys(id) ON DELETE SET NULL,
            deleted_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 公开链接 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS public_links (
            id          SERIAL PRIMARY KEY,
            owner_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            file_path   TEXT NOT NULL,
            token       TEXT UNIQUE NOT NULL,
            password    TEXT DEFAULT '',
            expires_at  TIMESTAMPTZ,
            max_views   INTEGER DEFAULT 0,
            view_count  INTEGER DEFAULT 0,
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            is_active   BOOLEAN DEFAULT TRUE
        )
    """)

    # ── 文件锁 ────────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_locks (
            file_path   TEXT PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            locked_at   TIMESTAMPTZ DEFAULT NOW(),
            expires_at  TIMESTAMPTZ
        )
    """)

    # ── 文件标签 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_labels (
            id          SERIAL PRIMARY KEY,
            file_path   TEXT NOT NULL,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            label       TEXT NOT NULL,
            color       TEXT DEFAULT '#64748b',
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(file_path, user_id, label)
        )
    """)

    # ── 审计日志（哈希链，防篡改）────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id          BIGSERIAL PRIMARY KEY,
            ts          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            user_id     INTEGER,
            username    TEXT,
            action      TEXT NOT NULL,
            detail      TEXT DEFAULT '',
            ip          TEXT DEFAULT '',
            level       TEXT DEFAULT 'INFO',
            category    TEXT DEFAULT 'FILE',
            resource    TEXT DEFAULT '',
            result      TEXT DEFAULT 'SUCCESS',
            chain_hash  TEXT NOT NULL DEFAULT ''
        )
    """)

    # ── 会话管理 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS active_sessions (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            token       TEXT UNIQUE NOT NULL,
            ip          TEXT DEFAULT '',
            ua_hash     TEXT DEFAULT '',
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            last_active TIMESTAMPTZ DEFAULT NOW(),
            is_active   BOOLEAN DEFAULT TRUE,
            kicked_at   TIMESTAMPTZ
        )
    """)

    # ── IP 白名单 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS user_ip_whitelist (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            allowed_ip  TEXT NOT NULL,
            note        TEXT DEFAULT '',
            is_active   BOOLEAN DEFAULT TRUE,
            created_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 密码历史 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS password_history (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            pw_hash     TEXT NOT NULL,
            pw_salt     TEXT NOT NULL,
            created_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 导出申请 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS export_requests (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            file_path   TEXT NOT NULL,
            reason      TEXT NOT NULL,
            status      TEXT DEFAULT 'pending',
            reviewer_id INTEGER REFERENCES users(id),
            review_note TEXT DEFAULT '',
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            reviewed_at TIMESTAMPTZ
        )
    """)

    # ── 设备管理 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS user_devices (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            device_id   TEXT NOT NULL,
            device_name TEXT DEFAULT '',
            first_seen  TIMESTAMPTZ DEFAULT NOW(),
            last_seen   TIMESTAMPTZ DEFAULT NOW(),
            is_trusted  BOOLEAN DEFAULT FALSE,
            is_active   BOOLEAN DEFAULT TRUE,
            UNIQUE(user_id, device_id)
        )
    """)

    # ── 分片上传会话 ─────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS upload_sessions (
            id            TEXT PRIMARY KEY,
            user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            filename      TEXT NOT NULL,
            rel_path      TEXT NOT NULL,
            file_size     BIGINT DEFAULT 0,
            file_hash     TEXT DEFAULT '',
            total_chunks  INTEGER NOT NULL,
            done_chunks   JSONB DEFAULT '[]',
            status        TEXT DEFAULT 'active',
            created_at    TIMESTAMPTZ DEFAULT NOW(),
            updated_at    TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 编辑器会话 ───────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS editor_sessions (
            token       TEXT PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            username    TEXT NOT NULL,
            file_path   TEXT NOT NULL,
            can_write   BOOLEAN DEFAULT FALSE,
            expires_at  TIMESTAMPTZ NOT NULL,
            created_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    # ── 文件评论 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_comments (
            id          SERIAL PRIMARY KEY,
            file_path   TEXT NOT NULL,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            parent_id   INTEGER REFERENCES file_comments(id) ON DELETE CASCADE,
            content     TEXT NOT NULL,
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            updated_at  TIMESTAMPTZ DEFAULT NOW(),
            is_deleted  BOOLEAN DEFAULT FALSE
        )
    """)

    # ── 账号申请 ─────────────────────────────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS register_requests (
            id          SERIAL PRIMARY KEY,
            realname    TEXT NOT NULL,
            username    TEXT NOT NULL,
            email       TEXT DEFAULT '',
            phone       TEXT DEFAULT '',
            department  TEXT DEFAULT '',
            reason      TEXT NOT NULL,
            status      TEXT DEFAULT 'pending',
            reviewer_id INTEGER REFERENCES users(id),
            review_note TEXT DEFAULT '',
            ip          TEXT DEFAULT '',
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            reviewed_at TIMESTAMPTZ
        )
    """)

    # ── 文件索引（只索引元数据，不含文件内容）───────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS file_index (
            id          BIGSERIAL PRIMARY KEY,
            file_path   TEXT UNIQUE NOT NULL,
            file_name   TEXT NOT NULL,
            ftype       TEXT DEFAULT 'other',
            file_size   BIGINT DEFAULT 0,
            mtime       DOUBLE PRECISION DEFAULT 0,
            tags        TEXT DEFAULT '',
            summary     TEXT DEFAULT '',
            indexed_at  TIMESTAMPTZ DEFAULT NOW(),
            is_encrypted BOOLEAN DEFAULT FALSE
        )
    """)

    # ── 系统配置（替代 JSON 文件存储）───────────────────
    conn.execute("""
        CREATE TABLE IF NOT EXISTS system_config (
            key         TEXT PRIMARY KEY,
            value       JSONB NOT NULL DEFAULT '{}',
            updated_by  INTEGER REFERENCES users(id),
            updated_at  TIMESTAMPTZ DEFAULT NOW()
        )
    """)


def _create_indexes(conn) -> None:
    indexes = [
        # 组织
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_org_parent_name ON organizations(COALESCE(parent_id,-1), name)",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_org_parent_code ON organizations(COALESCE(parent_id,-1), code)",
        # 用户
        "CREATE INDEX IF NOT EXISTS idx_user_org    ON users(org_id)",
        "CREATE INDEX IF NOT EXISTS idx_user_active ON users(is_active)",
        # 文件密钥
        "CREATE INDEX IF NOT EXISTS idx_tk_org      ON tenant_keys(org_id, is_active)",
        "CREATE INDEX IF NOT EXISTS idx_fk_path     ON file_keys(file_path)",
        # 文件分享
        "CREATE INDEX IF NOT EXISTS idx_fs_owner    ON file_shares(owner_id)",
        "CREATE INDEX IF NOT EXISTS idx_fs_target   ON file_shares(target_id)",
        "CREATE INDEX IF NOT EXISTS idx_fs_path     ON file_shares(file_path)",
        "CREATE INDEX IF NOT EXISTS idx_fs_active   ON file_shares(is_active)",
        # 文件版本
        "CREATE INDEX IF NOT EXISTS idx_fv_path     ON file_versions(file_path)",
        # 公开链接
        "CREATE INDEX IF NOT EXISTS idx_pl_token    ON public_links(token)",
        # 审计日志
        "CREATE INDEX IF NOT EXISTS idx_al_user     ON audit_log(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_al_ts       ON audit_log(ts DESC)",
        "CREATE INDEX IF NOT EXISTS idx_al_action   ON audit_log(action)",
        # 会话
        "CREATE INDEX IF NOT EXISTS idx_as_user     ON active_sessions(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_as_token    ON active_sessions(token)",
        "CREATE INDEX IF NOT EXISTS idx_as_active   ON active_sessions(is_active, last_active)",
        # 密码历史
        "CREATE INDEX IF NOT EXISTS idx_ph_user     ON password_history(user_id)",
        # 分片上传
        "CREATE INDEX IF NOT EXISTS idx_us_user     ON upload_sessions(user_id)",
        "CREATE INDEX IF NOT EXISTS idx_us_status   ON upload_sessions(status, updated_at)",
        # 编辑器
        "CREATE INDEX IF NOT EXISTS idx_es_exp      ON editor_sessions(expires_at)",
        # 评论
        "CREATE INDEX IF NOT EXISTS idx_fc_path     ON file_comments(file_path)",
        # 文件索引
        "CREATE INDEX IF NOT EXISTS idx_fi_name     ON file_index(file_name)",
        "CREATE INDEX IF NOT EXISTS idx_fi_ftype    ON file_index(ftype)",
        "CREATE INDEX IF NOT EXISTS idx_fi_mtime    ON file_index(mtime DESC)",
        "CREATE INDEX IF NOT EXISTS idx_fi_hash     ON file_index(file_hash) WHERE file_hash!=''",
        # 标签
        "CREATE INDEX IF NOT EXISTS idx_fl_path     ON file_labels(file_path)",
        "CREATE INDEX IF NOT EXISTS idx_fl_user     ON file_labels(user_id)",
        # 申请
        "CREATE INDEX IF NOT EXISTS idx_rr_status   ON register_requests(status)",
        # 系统配置
        # (key 是 PK，已有索引)
    ]
    for ddl in indexes:
        try:
            conn.execute(ddl)
        except Exception as e:
            log.warning(f"索引创建跳过: {e}")


def _seed_defaults(conn) -> None:
    """插入默认数据（幂等）"""
    import config as _cfg

    # 默认组织
    for name, code, dirp, desc, level in [
        ("公共资源",   "shared",    "shared",    "所有用户可读的公共区域", 1),
        ("综合办公室", "dept_zzb",  "dept_zzb",  "综合办公",             1),
        ("数据管理部", "dept_sjgl", "dept_sjgl", "数据管理与运维",        1),
        ("业务支撑部", "dept_ywzc", "dept_ywzc", "业务系统支撑",          1),
        ("信息安全部", "dept_xxaq", "dept_xxaq", "信息安全管理",          1),
    ]:
        conn.execute("""
            INSERT INTO organizations(name,code,dir_path,description,org_level)
            VALUES(%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING
        """, (name, code, dirp, desc, level))
        try:
            os.makedirs(os.path.join(_cfg.FILE_ROOT, dirp), exist_ok=True)
        except Exception:
            pass

    # 默认超管（首次部署）
    if not conn.execute("SELECT id FROM users WHERE role=0 LIMIT 1").fetchone():
        salt    = secrets.token_hex(16)
        import hashlib
        pw_hash = hashlib.pbkdf2_hmac(
            "sha256", b"Admin@2025!", salt.encode(), 100_000
        ).hex()
        conn.execute("""
            INSERT INTO users(username, password_hash, password_salt, role, display_name)
            VALUES('admin', %s, %s, 0, '系统管理员')
        """, (pw_hash, salt))
        try:
            os.makedirs(os.path.join(_cfg.FILE_ROOT, "users", "admin"), exist_ok=True)
        except Exception:
            pass
        log.warning("✅ 默认超管已创建：admin / Admin@2025!  请登录后立即修改密码！")
