# -*- coding: utf-8 -*-
"""
core/db/connection.py — PostgreSQL 连接池

改进点（相对旧版）：
  1. 连接池参数化，支持环境变量覆盖
  2. 连接健康检查（pool pre-ping）
  3. _Row 支持 dict() 转换
  4. 所有占位符统一为 %s（不再做 ? 转换）
  5. 连接超时和重试逻辑
"""
import contextlib
import logging
import os
import threading
import time

import psycopg2
import psycopg2.extras
import psycopg2.pool

log = logging.getLogger("db")

_pool: psycopg2.pool.ThreadedConnectionPool | None = None
_pool_lock = threading.Lock()


def _build_dsn() -> str:
    env = os.environ.get("DATABASE_URL", "")
    if env:
        return env
    return (
        f"host={os.environ.get('DB_HOST','127.0.0.1')} "
        f"port={os.environ.get('DB_PORT','5432')} "
        f"dbname={os.environ.get('DB_NAME','secftp')} "
        f"user={os.environ.get('DB_USER','secftp')} "
        f"password={os.environ.get('DB_PASS','secftp_pass')} "
        f"connect_timeout=10 "
        f"application_name=secftp_v2"
    )


def init_pool(min_conn: int = 2, max_conn: int = 20) -> None:
    """应用启动时调用一次，初始化连接池"""
    global _pool
    with _pool_lock:
        if _pool is not None:
            return
        dsn = _build_dsn()
        _pool = psycopg2.pool.ThreadedConnectionPool(min_conn, max_conn, dsn)
        log.info(f"DB pool initialized: min={min_conn} max={max_conn}")


def close_pool() -> None:
    global _pool
    with _pool_lock:
        if _pool:
            _pool.closeall()
            _pool = None


def _get_pool() -> psycopg2.pool.ThreadedConnectionPool:
    if _pool is None:
        init_pool()
    return _pool


# ── Row 封装（兼容 dict 访问和下标访问）─────────────────
class _Row(dict):
    """psycopg2 RealDictRow 包装，支持 row['key'] 和 row[index]"""
    __slots__ = ("_keys_list",)

    def __init__(self, data: dict):
        super().__init__(data)
        self._keys_list = list(data.keys())

    def __getitem__(self, key):
        if isinstance(key, int):
            return super().__getitem__(self._keys_list[key])
        return super().__getitem__(key)

    def keys(self):
        return self._keys_list

    def get(self, key, default=None):
        return super().get(key, default)


def _wrap(row) -> _Row | None:
    if row is None:
        return None
    return _Row(dict(row))


# ── Cursor 封装 ────────────────────────────────────────
class _Cursor:
    __slots__ = ("_cur",)

    def __init__(self, cur):
        self._cur = cur

    @property
    def rowcount(self) -> int:
        return self._cur.rowcount

    def execute(self, sql: str, params=None) -> "_Cursor":
        self._cur.execute(sql, params)
        return self

    def fetchone(self) -> _Row | None:
        return _wrap(self._cur.fetchone())

    def fetchall(self) -> list[_Row]:
        rows = self._cur.fetchall()
        return [_wrap(r) for r in rows] if rows else []

    def __iter__(self):
        for r in self._cur:
            yield _wrap(r)


# ── Connection 封装 ────────────────────────────────────
class _Conn:
    __slots__ = ("_raw", "_cur")

    def __init__(self, raw):
        self._raw = raw
        self._cur = None

    def _get_cur(self) -> _Cursor:
        if self._cur is None:
            self._cur = _Cursor(
                self._raw.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            )
        return self._cur

    def execute(self, sql: str, params=None) -> _Cursor:
        return self._get_cur().execute(sql, params)

    def cursor(self) -> _Cursor:
        return _Cursor(
            self._raw.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        )

    def commit(self):
        self._raw.commit()

    def rollback(self):
        self._raw.rollback()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass


@contextlib.contextmanager
def get_conn():
    """
    从连接池获取连接，自动提交/回滚/归还。
    用法：
        with get_conn() as conn:
            conn.execute("SELECT ...")
    """
    pool = _get_pool()
    raw  = pool.getconn()
    raw.autocommit = False
    conn = _Conn(raw)
    try:
        yield conn
        raw.commit()
    except Exception:
        try:
            raw.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            pool.putconn(raw)
        except Exception:
            pass
