# -*- coding: utf-8 -*-
"""
routes/auth_routes.py — 登录 / 登出 / 修改密码 / 个人资料
"""
import secrets
from flask import Blueprint, session, request, redirect, jsonify
from auth import login_required, generate_csrf_token, csrf_ok, secure_filename
from core.auth.session import (create_session_token, validate_session_token,
    refresh_session_token, invalidate_session, check_ip_allowed, detect_anomaly)
from product.audit.log import write as audit_write, AuditCategory
from core.auth.password import validate_password, save_password_history
from core.auth.totp import verify_totp, is_2fa_required, get_2fa_status
from product.audit.alert import send_alert
from routes.device_routes import register_device
from core.auth.user import verify_password, change_password, verify_current_password
from product.files.dao import log_action
from core.auth.user_dao import (update_profile, update_avatar, update_info,
                          update_avatar_image, update_bio, get_stats)
from core.db import get_conn
from infra.templates import layout, get_login_html
import config

bp = Blueprint("auth", __name__)


# ── 登录 ─────────────────────────────────────────────
@bp.route("/login", methods=["GET", "POST"])
def login():
    if "uid" in session:
        return redirect("/browse")

    csrf = generate_csrf_token()
    err_msg = ""

    if request.method == "POST":
        token = request.form.get("csrf_token", "")
        if not secrets.compare_digest(token, session.get("csrf_token", "")):
            err_msg = "页面已过期，请重试"
        else:
            user, msg = verify_password(
                request.form.get("username", "").strip(),
                request.form.get("password", "")
            )
            if user:
                uid  = user["id"]
                ip   = request.remote_addr

                # IP 绑定检查
                ip_ok, ip_err = check_ip_allowed(uid, ip)
                if not ip_ok:
                    audit_write(uid, user["username"], "LOGIN_BLOCKED_IP",
                                ip_err, ip, "WARN", AuditCategory.SECURITY, result="BLOCKED")
                    err_msg = ip_err
                elif is_2fa_required(uid):
                    # 2FA 验证阶段：把用户信息存 session 但标记为未完成认证
                    session["pending_2fa_uid"]   = uid
                    session["pending_2fa_uname"] = user["username"]
                    return redirect("/login/2fa")
                else:
                    # 创建会话令牌（互踢旧会话）
                    token = create_session_token(uid, ip, request.headers.get("User-Agent",""))
                    session["uid"]          = uid
                    session["uname"]        = user["username"]
                    session["display_name"] = user.get("display_name") or user["username"]
                    session["role"]         = user["role"]
                    session["org_id"]       = user.get("org_id") or user.get("dept_id")
                    session["_stoken"]      = token
                    session["last_active"]  = __import__("time").time()
                    session.permanent       = False
                    # 异常检测
                    anomaly = detect_anomaly(uid, ip)
                    log_action(uid, user["username"], "LOGIN",
                               request.remote_addr, request.remote_addr)
                    # 注册设备
                    register_device(uid, request.headers.get("User-Agent",""), ip)
                    # 异常登录告警
                    if anomaly["has_anomaly"]:
                        send_alert("LOGIN_ANOMALY", user, ip,
                                   ";".join(anomaly["details"]))
                    audit_write(uid, user["username"], "LOGIN_SUCCESS",
                                f"ip={ip}" + (" [异常:" + ";".join(anomaly["details"]) + "]"
                                              if anomaly["has_anomaly"] else ""),
                                ip, "WARN" if anomaly["has_anomaly"] else "INFO",
                                AuditCategory.AUTH, result="SUCCESS")
                    return redirect("/dashboard")
            else:
                audit_write(0, request.form.get("username",""), "LOGIN_FAIL",
                            f"ip={request.remote_addr}", request.remote_addr,
                            "WARN", AuditCategory.SECURITY, result="FAILURE")
                err_msg = msg

    session["csrf_token"] = csrf
    html = get_login_html(csrf)
    if err_msg:
        html = html.replace(
            '<div class="lerr" id="lerr"></div>',
            f'<div class="lerr" id="lerr" style="display:block">⚠ {err_msg}</div>'
        )
    return html


@bp.route("/login/2fa", methods=["GET", "POST"])
def login_2fa():
    """2FA 验证步骤（在密码验证通过后）"""
    uid   = session.get("pending_2fa_uid")
    uname = session.get("pending_2fa_uname", "")
    if not uid:
        return redirect("/login")

    err_msg = ""
    if request.method == "POST":
        code = request.form.get("code", "").strip()
        st   = get_2fa_status(uid)
        if verify_totp(st.get("secret", ""), code):
            from core.auth.user_dao import record_login_success
            user = record_login_success(uid)
            ip   = request.remote_addr
            token = create_session_token(uid, ip, request.headers.get("User-Agent",""))
            session.pop("pending_2fa_uid", None)
            session.pop("pending_2fa_uname", None)
            session["uid"]          = uid
            session["uname"]        = uname
            session["display_name"] = user.get("display_name") or uname
            session["role"]         = user["role"]
            session["org_id"]       = user.get("org_id")
            session["_stoken"]      = token
            session["last_active"]  = __import__("time").time()
            audit_write(uid, uname, "LOGIN_2FA_SUCCESS",
                        f"ip={ip}", ip, "INFO", AuditCategory.AUTH)
            return redirect("/browse")
        else:
            err_msg = "验证码错误，请重试"
            audit_write(uid, uname, "LOGIN_2FA_FAIL",
                        request.remote_addr, request.remote_addr,
                        "WARN", AuditCategory.SECURITY, result="FAILURE")

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf
    return (f'<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8">'

            f'<meta name="viewport" content="width=device-width,initial-scale=1">'

            f'<title>双因素验证</title>'

            f'<style>body{{margin:0;font-family:"Microsoft YaHei",sans-serif;'

            f'background:#f4f7fb;display:flex;align-items:center;justify-content:center;min-height:100vh}}'

            f'.box{{background:#fff;border-radius:8px;padding:36px 40px;max-width:360px;width:100%;'

            f'box-shadow:0 4px 20px rgba(0,0,0,.1)}}'

            f'.inp{{width:100%;padding:10px 12px;border:1.5px solid #e2e8f0;border-radius:6px;'

            f'font-size:14px;box-sizing:border-box;letter-spacing:4px;font-size:22px;text-align:center}}'

            f'.btn{{width:100%;padding:11px;background:#1560bd;color:#fff;border:none;'

            f'border-radius:6px;font-size:14px;cursor:pointer;margin-top:12px}}'

            f'.err{{color:#c62828;font-size:12px;margin:8px 0}}</style></head><body>'

            f'<div class="box"><div style="text-align:center;margin-bottom:20px">'

            f'<div style="font-size:40px">🔑</div>'

            f'<h2 style="margin:8px 0;font-size:18px">双因素验证</h2>'

            f'<p style="font-size:13px;color:#64748b">请输入 Authenticator 应用中的 6 位验证码</p></div>'

            f'{"<p class=\'err\'>" + err_msg + "</p>" if err_msg else ""}'

            f'<form method="POST"><input type="hidden" name="csrf_token" value="{csrf}">'

            f'<input class="inp" name="code" maxlength="6" placeholder="000000" autofocus'

            f' inputmode="numeric" autocomplete="one-time-code">'

            f'<button class="btn" type="submit">验证</button></form>'

            f'<p style="text-align:center;margin-top:14px;font-size:12px">'

            f'<a href="/logout" style="color:#94a3b8">取消登录</a></p></div></body></html>')


@bp.route("/logout")
def logout():
    if "uid" in session:
        log_action(session["uid"], session.get("uname", ""), "LOGOUT", "", request.remote_addr)
    session.clear()
    return redirect("/login")


@bp.route("/")
def index():
    return redirect("/browse")


@bp.route("/favicon.ico")
def favicon():
    import os
    from flask import send_file
    fav = os.path.join(os.path.dirname(__file__), "..", "favicon.ico")
    if os.path.isfile(fav):
        return send_file(fav, mimetype="image/x-icon")
    return "", 204


# ── 修改密码 ─────────────────────────────────────────
@bp.route("/change-password", methods=["GET", "POST"])
@login_required
def change_pw():
    err = ""
    ok  = ""
    if request.method == "POST":
        csrf = request.form.get("csrf_token", "")
        if not secrets.compare_digest(csrf, session.get("csrf_token", "")):
            err = "CSRF 校验失败"
        else:
            old_pw = request.form.get("old_password", "")
            new_pw = request.form.get("new_password", "")
            cfm_pw = request.form.get("confirm_password", "")
            if not verify_current_password(session["uid"], old_pw):
                err = "当前密码错误"
            elif len(new_pw) < 8:
                err = "新密码至少 8 位"
            elif new_pw != cfm_pw:
                err = "两次密码不一致"
            else:
                # 密码策略校验
                pw_ok, pw_err = validate_password(new_pw, session["uname"])
                if not pw_ok:
                    err = pw_err
                else:
                    change_password(session["uid"], new_pw)
                    # 保存密码历史
                    import hashlib as _hl, secrets as _sec
                    _salt = _sec.token_hex(16)
                    _hash = _hl.pbkdf2_hmac("sha256", new_pw.encode(), _salt.encode(), 100_000).hex()
                    save_password_history(session["uid"], _hash, _salt)
                    log_action(session["uid"], session["uname"], "CHANGE_PASSWORD", "", request.remote_addr)
                    audit_write(session["uid"], session["uname"], "CHANGE_PASSWORD",
                                "", request.remote_addr, "WARN", AuditCategory.AUTH)
                    ok = "密码修改成功"

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf
    err_html = f'<div class="toast err" style="margin-bottom:12px">❌ {err}</div>' if err else ""
    ok_html  = f'<div class="toast ok"  style="margin-bottom:12px">✅ {ok}</div>'  if ok  else ""
    content  = f"""
<div class="view show" style="max-width:480px">
  <div class="page-title"><span class="pt-icon">🔐</span>修改密码</div>
  <div class="card" style="padding:24px">
    {err_html}{ok_html}
    <form method="POST" action="/change-password">
      <input type="hidden" name="csrf_token" value="{csrf}">
      <div class="fg"><label>当前密码</label>
        <input class="inp" type="password" name="old_password" required placeholder="输入当前密码"></div>
      <div class="fg"><label>新密码（至少 8 位）</label>
        <input class="inp" type="password" name="new_password" required placeholder="新密码"></div>
      <div class="fg"><label>确认新密码</label>
        <input class="inp" type="password" name="confirm_password" required placeholder="再次输入新密码"></div>
      <button type="submit" class="btn btn-primary">保存修改</button>
    </form>
  </div>
</div>"""
    from core.auth.context import ctx
    return layout(content, "修改密码", "changepw", **ctx())


# ── 个人资料 ─────────────────────────────────────────
@bp.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    return redirect("/profile/v2")  # 使用新版个人中心
    import re
    uid = session["uid"]
    with get_conn() as conn:
        user = dict(conn.execute("SELECT * FROM users WHERE id=%s", (uid,)).fetchone())
    err = ""
    ok  = ""

    if request.method == "POST":
        action = request.form.get("action", "")
        csrf   = request.form.get("csrf_token", "")
        if not secrets.compare_digest(csrf, session.get("csrf_token", "")):
            err = "CSRF 校验失败"
        elif action == "profile":
            display_name = request.form.get("display_name", "").strip()
            email        = request.form.get("email", "").strip()
            phone        = request.form.get("phone", "").strip()
            if not display_name:
                err = "姓名不能为空"
            else:
                update_profile(uid, display_name, email, phone)
                session["display_name"] = display_name
                user.update(display_name=display_name, email=email, phone=phone)
                log_action(uid, session["uname"], "UPDATE_PROFILE", "", request.remote_addr)
                ok = "个人信息已更新"
        elif action == "avatar":
            color = request.form.get("avatar_color", "#de2910")
            if not re.match(r"^#[0-9a-fA-F]{6}$", color):
                color = "#de2910"
            update_avatar(uid, color)
            user["avatar_color"] = color
            ok = "头像颜色已更新"

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf
    uname    = user.get("display_name") or user["username"]
    av_char  = uname[0].upper()
    av_color = user.get("avatar_color") or "#de2910"
    err_html = f'<div class="toast err" style="margin-bottom:12px">❌ {err}</div>' if err else ""
    ok_html  = f'<div class="toast ok"  style="margin-bottom:12px">✅ {ok}</div>'  if ok  else ""

    preset = ["#de2910","#1a4b9b","#15803d","#7c3aed","#b45309",
              "#0e7de0","#374151","#be185d","#0f766e","#9a3412"]
    def _cbtn(c, sel):
        border = "#333" if c == sel else "transparent"
        return (f'<button type="button" onclick="setColor(\'{c}\')" '
                f'style="width:28px;height:28px;border-radius:50%;background:{c};'
                f'border:3px solid {border};cursor:pointer" id="cb_{c[1:]}"></button>')
    color_btns = "".join(_cbtn(c, av_color) for c in preset)

    content = f"""
<div class="view show" style="max-width:600px">
  <div class="page-title"><span class="pt-icon">👤</span>个人资料</div>
  {err_html}{ok_html}
  <div class="card" style="padding:24px">
    <h3 style="font-size:14px;font-weight:600;margin-bottom:16px;color:var(--text);
      border-left:3px solid var(--red);padding-left:8px">头像设置</h3>
    <div style="display:flex;align-items:center;gap:20px;margin-bottom:16px">
      <div id="avatar-preview" style="width:64px;height:64px;border-radius:50%;
        background:{av_color};display:flex;align-items:center;justify-content:center;
        font-size:28px;font-weight:700;color:#fff;flex-shrink:0">{av_char}</div>
      <div>
        <div style="font-size:13px;color:var(--text2);margin-bottom:10px">选择颜色：</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">{color_btns}</div>
      </div>
    </div>
    <form method="POST" action="/profile" style="display:flex;align-items:center;gap:10px">
      <input type="hidden" name="csrf_token" value="{csrf}">
      <input type="hidden" name="action" value="avatar">
      <input type="hidden" name="avatar_color" id="avatar_color_input" value="{av_color}">
      <button type="submit" class="btn btn-primary btn-sm">保存头像</button>
    </form>
  </div>
  <div class="card" style="padding:24px">
    <h3 style="font-size:14px;font-weight:600;margin-bottom:16px;color:var(--text);
      border-left:3px solid var(--primary);padding-left:8px">基本信息</h3>
    <form method="POST" action="/profile">
      <input type="hidden" name="csrf_token" value="{csrf}">
      <input type="hidden" name="action" value="profile">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <div class="fg" style="margin:0"><label>登录用户名</label>
          <input class="inp" value="{user['username']}" readonly
            style="background:var(--gray50);color:var(--text3)"></div>
        <div class="fg" style="margin:0"><label>姓名 *</label>
          <input class="inp" name="display_name" required
            value="{user.get('display_name') or ''}" placeholder="真实姓名"></div>
        <div class="fg" style="margin:0"><label>邮箱</label>
          <input class="inp" name="email" type="email"
            value="{user.get('email') or ''}" placeholder="工作邮箱（可选）"></div>
        <div class="fg" style="margin:0"><label>手机号</label>
          <input class="inp" name="phone"
            value="{user.get('phone') or ''}" placeholder="联系电话（可选）"></div>
      </div>
      <div style="margin-top:16px">
        <button type="submit" class="btn btn-primary">保存信息</button>
      </div>
    </form>
  </div>
</div>
<script>
function setColor(c){{
  document.getElementById('avatar_color_input').value=c;
  document.getElementById('avatar-preview').style.background=c;
  document.querySelectorAll('[id^="cb_"]').forEach(b=>b.style.border='3px solid transparent');
  const btn=document.getElementById('cb_'+c.slice(1));
  if(btn) btn.style.border='3px solid #333';
}}
</script>"""
    from core.auth.context import ctx
    return layout(content, "个人资料", "profile", **ctx())
