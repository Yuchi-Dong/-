# -*- coding: utf-8 -*-
"""
routes/ldap_routes.py — LDAP/AD 配置与管理路由

路由：
  GET  /admin/ldap          LDAP 配置页面
  POST /api/admin/ldap/save 保存 LDAP 配置
  POST /api/admin/ldap/test 测试 LDAP 连接
  POST /api/admin/ldap/sync 立即同步所有用户
  GET  /api/admin/ldap/status 获取当前 LDAP 状态
"""
import json
import os
from flask import Blueprint, session, request, jsonify

from auth import login_required, role_required, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER
from infra.templates import layout
from core.db import get_conn

bp = Blueprint("ldap", __name__)

# LDAP 配置存储路径（写入磁盘，服务重启后保留）
_LDAP_CFG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "ldap_config.json"
)


def _load_ldap_config() -> dict:
    try:
        with open(_LDAP_CFG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_ldap_config(cfg: dict):
    with open(_LDAP_CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    # 写入后动态更新 config 模块（无需重启）
    _apply_to_config(cfg)


def _apply_to_config(cfg: dict):
    """将 LDAP 配置写入 config 模块，使其立即生效"""
    import config as _c
    mapping = {
        "LDAP_ENABLED":          cfg.get("enabled", False),
        "LDAP_SERVER":           cfg.get("server", ""),
        "LDAP_PORT":             int(cfg.get("port", 389)),
        "LDAP_USE_SSL":          cfg.get("use_ssl", False),
        "LDAP_BIND_DN":          cfg.get("bind_dn", ""),
        "LDAP_BIND_PASSWORD":    cfg.get("bind_password", ""),
        "LDAP_BASE_DN":          cfg.get("base_dn", ""),
        "LDAP_USER_FILTER":      cfg.get("user_filter", "(sAMAccountName={username})"),
        "LDAP_SYNC_FILTER":      cfg.get("sync_filter", "(objectClass=person)"),
        "LDAP_ATTR_DISPLAY_NAME":cfg.get("attr_display_name", "displayName"),
        "LDAP_ATTR_EMAIL":       cfg.get("attr_email", "mail"),
        "LDAP_ATTR_PHONE":       cfg.get("attr_phone", "telephoneNumber"),
        "LDAP_ATTR_DEPARTMENT":  cfg.get("attr_department", "department"),
        "LDAP_ATTR_USERNAME":    cfg.get("attr_username", "sAMAccountName"),
        "LDAP_DEFAULT_ROLE":     int(cfg.get("default_role", 2)),
        "LDAP_DEFAULT_QUOTA_MB": int(cfg.get("default_quota_mb", 1024000)),
    }
    for k, v in mapping.items():
        setattr(_c, k, v)


# 启动时加载配置
try:
    _apply_to_config(_load_ldap_config())
except Exception:
    pass


# ── 配置页面 ─────────────────────────────────────────
@bp.route("/admin/ldap")
@login_required
@role_required(ROLE_SUPER)
def admin_ldap():
    cfg  = _load_ldap_config()
    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    # 预设模板
    presets = {
        "windows_ad": {
            "label": "Windows Active Directory",
            "port": 389, "use_ssl": False,
            "user_filter": "(sAMAccountName={username})",
            "sync_filter": "(&(objectClass=user)(objectCategory=person))",
            "attr_username": "sAMAccountName",
            "attr_display_name": "displayName",
            "attr_email": "mail",
            "attr_phone": "telephoneNumber",
            "attr_department": "department",
        },
        "openldap": {
            "label": "OpenLDAP",
            "port": 389, "use_ssl": False,
            "user_filter": "(uid={username})",
            "sync_filter": "(objectClass=inetOrgPerson)",
            "attr_username": "uid",
            "attr_display_name": "cn",
            "attr_email": "mail",
            "attr_phone": "mobile",
            "attr_department": "ou",
        },
        "cas_ldap": {
            "label": "国产统一认证平台",
            "port": 389, "use_ssl": False,
            "user_filter": "(userPrincipalName={username})",
            "sync_filter": "(objectClass=person)",
            "attr_username": "userPrincipalName",
            "attr_display_name": "cn",
            "attr_email": "mail",
            "attr_phone": "mobile",
            "attr_department": "departmentNumber",
        },
    }

    def _val(key, default=""):
        v = cfg.get(key, default)
        return str(v) if v is not None else default

    def _checked(key):
        return "checked" if cfg.get(key) else ""

    status_html = ""
    try:
        from integrations.ldap_auth import is_ldap_enabled
        if is_ldap_enabled():
            status_html = '<span class="badge badge-green">● 已启用</span>'
        else:
            status_html = '<span class="badge badge-gray">○ 未启用</span>'
    except Exception:
        status_html = '<span class="badge badge-gray">○ 未启用</span>'

    preset_opts = "".join(
        f'<option value="{k}">{v["label"]}</option>'
        for k, v in presets.items()
    )

    content = f"""
<div class="view show" style="max-width:860px">
  <div class="page-title"><span class="pt-icon">🔗</span>LDAP / AD 集成配置</div>

  <div class="card" style="padding:16px 20px;margin-bottom:12px">
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <span style="font-size:13px;font-weight:600">当前状态：</span>{status_html}
      <span style="flex:1"></span>
      <select class="inp inp-sel" id="preset-sel" style="width:220px" onchange="applyPreset(this.value)">
        <option value="">── 选择预设模板 ──</option>
        {preset_opts}
      </select>
    </div>
  </div>

  <div class="card" style="padding:20px 24px">
    <form id="ldap-form">
      <input type="hidden" name="csrf_token" value="{csrf}">

      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">

        <div class="fg" style="grid-column:1/-1">
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox" id="ldap-enabled" name="enabled" {_checked('enabled')}
              style="width:16px;height:16px">
            <span style="font-weight:600">启用 LDAP/AD 认证</span>
          </label>
          <div style="font-size:11px;color:var(--text3);margin-top:4px">
            启用后，用户登录时优先验证 LDAP，LDAP 中不存在的用户仍可使用本地账号登录
          </div>
        </div>

        <div class="fg" style="margin:0">
          <label>服务器地址 <span style="color:var(--danger)">*</span></label>
          <input class="inp" id="ldap-server" name="server" value="{_val('server')}"
            placeholder="192.168.1.10 或 ldap.example.com">
        </div>
        <div class="fg" style="margin:0">
          <label>端口</label>
          <div style="display:flex;gap:8px;align-items:center">
            <input class="inp" id="ldap-port" name="port" type="number"
              value="{_val('port', '389')}" style="width:100px">
            <label style="display:flex;align-items:center;gap:6px;font-size:13px">
              <input type="checkbox" id="ldap-ssl" name="use_ssl" {_checked('use_ssl')}
                onchange="document.getElementById('ldap-port').value=this.checked?'636':'389'">
              使用 LDAPS（SSL/TLS）
            </label>
          </div>
        </div>

        <div class="fg" style="margin:0">
          <label>绑定账号 DN（Bind DN）<span style="color:var(--danger)">*</span></label>
          <input class="inp" id="ldap-bind-dn" name="bind_dn" value="{_val('bind_dn')}"
            placeholder="CN=ldap_reader,CN=Users,DC=example,DC=com">
        </div>
        <div class="fg" style="margin:0">
          <label>绑定账号密码</label>
          <input class="inp" id="ldap-bind-pw" name="bind_password" type="password"
            value="{_val('bind_password')}" placeholder="留空表示不修改">
        </div>

        <div class="fg" style="grid-column:1/-1;margin:0">
          <label>搜索基准 DN（Base DN）<span style="color:var(--danger)">*</span></label>
          <input class="inp" id="ldap-base-dn" name="base_dn" value="{_val('base_dn')}"
            placeholder="DC=example,DC=com 或 OU=Staff,DC=example,DC=com">
        </div>

        <div class="fg" style="margin:0">
          <label>用户搜索过滤器</label>
          <input class="inp" id="ldap-user-filter" name="user_filter"
            value="{_val('user_filter', '(sAMAccountName={{username}})')}"
            placeholder="(sAMAccountName={{username}})">
          <div style="font-size:11px;color:var(--text3);margin-top:3px">
            {{username}} 为登录名占位符，AD 用 sAMAccountName，OpenLDAP 用 uid
          </div>
        </div>
        <div class="fg" style="margin:0">
          <label>全量同步过滤器</label>
          <input class="inp" id="ldap-sync-filter" name="sync_filter"
            value="{_val('sync_filter', '(objectClass=person)')}"
            placeholder="(&(objectClass=user)(objectCategory=person))">
        </div>

        <div class="fg" style="grid-column:1/-1;margin:8px 0 4px">
          <div style="font-weight:600;font-size:13px;border-left:3px solid var(--primary);
            padding-left:8px">属性映射</div>
        </div>

        <div class="fg" style="margin:0">
          <label>用户名属性</label>
          <input class="inp" id="attr-username" name="attr_username"
            value="{_val('attr_username', 'sAMAccountName')}" placeholder="sAMAccountName">
        </div>
        <div class="fg" style="margin:0">
          <label>姓名属性</label>
          <input class="inp" id="attr-dn" name="attr_display_name"
            value="{_val('attr_display_name', 'displayName')}" placeholder="displayName">
        </div>
        <div class="fg" style="margin:0">
          <label>邮件属性</label>
          <input class="inp" id="attr-email" name="attr_email"
            value="{_val('attr_email', 'mail')}" placeholder="mail">
        </div>
        <div class="fg" style="margin:0">
          <label>手机属性</label>
          <input class="inp" id="attr-phone" name="attr_phone"
            value="{_val('attr_phone', 'telephoneNumber')}" placeholder="telephoneNumber">
        </div>
        <div class="fg" style="margin:0">
          <label>部门属性（匹配本地组织）</label>
          <input class="inp" id="attr-dept" name="attr_department"
            value="{_val('attr_department', 'department')}" placeholder="department">
        </div>

        <div class="fg" style="grid-column:1/-1;margin:8px 0 4px">
          <div style="font-weight:600;font-size:13px;border-left:3px solid var(--primary);
            padding-left:8px">新用户默认设置</div>
        </div>

        <div class="fg" style="margin:0">
          <label>默认角色</label>
          <select class="inp inp-sel" name="default_role">
            <option value="2" {"selected" if _val("default_role","2")=="2" else ""}>普通用户</option>
            <option value="1" {"selected" if _val("default_role","2")=="1" else ""}>组织管理员</option>
          </select>
        </div>
        <div class="fg" style="margin:0">
          <label>默认存储配额</label>
          <select class="inp inp-sel" name="default_quota_mb">
            <option value="102400"  {"selected" if _val("default_quota_mb")=="102400"  else ""}>100 GB</option>
            <option value="512000"  {"selected" if _val("default_quota_mb")=="512000"  else ""}>500 GB</option>
            <option value="1024000" {"selected" if _val("default_quota_mb","1024000")=="1024000" else ""}>1 TB</option>
            <option value="5120000" {"selected" if _val("default_quota_mb")=="5120000" else ""}>5 TB</option>
          </select>
        </div>

      </div>

      <div style="display:flex;gap:10px;margin-top:20px">
        <button type="button" class="btn btn-outline" onclick="testConn()">🔌 测试连接</button>
        <button type="button" class="btn btn-outline" onclick="syncNow()">🔄 立即同步用户</button>
        <span style="flex:1"></span>
        <button type="button" class="btn btn-primary" onclick="saveCfg()">💾 保存配置</button>
      </div>
    </form>
  </div>

  <div id="result-box" style="display:none;margin-top:12px"></div>
</div>

<script>
const _presets = {json.dumps(presets, ensure_ascii=False)};

function applyPreset(key) {{
  if (!key) return;
  const p = _presets[key];
  if (!p) return;
  document.getElementById('ldap-port').value = p.port || 389;
  document.getElementById('ldap-ssl').checked = !!p.use_ssl;
  document.getElementById('ldap-user-filter').value = p.user_filter || '';
  document.getElementById('ldap-sync-filter').value = p.sync_filter || '';
  document.getElementById('attr-username').value = p.attr_username || '';
  document.getElementById('attr-dn').value = p.attr_display_name || '';
  document.getElementById('attr-email').value = p.attr_email || '';
  document.getElementById('attr-phone').value = p.attr_phone || '';
  document.getElementById('attr-dept').value = p.attr_department || '';
  toast('已应用预设：' + p.label, 'ok');
}}

function _formData() {{
  const f = document.getElementById('ldap-form');
  const fd = new FormData(f);
  const data = Object.fromEntries(fd.entries());
  data.enabled = document.getElementById('ldap-enabled').checked;
  data.use_ssl = document.getElementById('ldap-ssl').checked;
  data.port = parseInt(data.port) || 389;
  data.default_role = parseInt(data.default_role) || 2;
  data.default_quota_mb = parseInt(data.default_quota_mb) || 1024000;
  return data;
}}

async function saveCfg() {{
  const r = await fetch('/api/admin/ldap/save', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{..._formData(), csrf_token: window._csrf}})
  }});
  const d = await r.json();
  if (d.success) toast('配置已保存', 'ok');
  else toast('保存失败：' + d.error, 'err');
}}

async function testConn() {{
  showResult('testing');
  const r = await fetch('/api/admin/ldap/test', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{..._formData(), csrf_token: window._csrf}})
  }});
  const d = await r.json();
  showResult(d.ok ? 'ok' : 'err', d.message + (d.server_info ? '（' + d.server_info + '）' : ''));
}}

async function syncNow() {{
  showResult('testing', '正在同步，请稍候...');
  const r = await fetch('/api/admin/ldap/sync', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{csrf_token: window._csrf}})
  }});
  const d = await r.json();
  if (d.success) {{
    const s = d.stats;
    showResult('ok', `同步完成：共 ${{s.synced}} 人，新增 ${{s.created}}，更新 ${{s.updated}}` +
      (s.errors?.length ? `，失败 ${{s.errors.length}} 条` : ''));
  }} else showResult('err', d.error);
}}

function showResult(type, msg) {{
  const box = document.getElementById('result-box');
  if (type === 'testing') {{
    box.innerHTML = '<div class="card" style="padding:12px 16px;color:var(--text2)">⏳ ' + (msg||'连接中...') + '</div>';
  }} else {{
    const cls = type === 'ok' ? 'toast ok' : 'toast err';
    box.innerHTML = '<div class="' + cls + '" style="padding:12px 16px;border-radius:6px">' +
      (type==='ok'?'✅':'❌') + ' ' + msg + '</div>';
  }}
  box.style.display = '';
}}
</script>"""

    from core.auth.context import ctx
    return layout(content, "LDAP/AD 配置", "ldap", **ctx())


# ── API：保存配置 ─────────────────────────────────────
@bp.route("/api/admin/ldap/save", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_ldap_save():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    cfg = {
        "enabled":           bool(data.get("enabled")),
        "server":            data.get("server", "").strip(),
        "port":              int(data.get("port", 389)),
        "use_ssl":           bool(data.get("use_ssl")),
        "bind_dn":           data.get("bind_dn", "").strip(),
        "base_dn":           data.get("base_dn", "").strip(),
        "user_filter":       data.get("user_filter", "(sAMAccountName={username})").strip(),
        "sync_filter":       data.get("sync_filter", "(objectClass=person)").strip(),
        "attr_username":     data.get("attr_username", "sAMAccountName").strip(),
        "attr_display_name": data.get("attr_display_name", "displayName").strip(),
        "attr_email":        data.get("attr_email", "mail").strip(),
        "attr_phone":        data.get("attr_phone", "telephoneNumber").strip(),
        "attr_department":   data.get("attr_department", "department").strip(),
        "default_role":      int(data.get("default_role", 2)),
        "default_quota_mb":  int(data.get("default_quota_mb", 1024000)),
    }
    # 密码：留空则保留旧值
    if data.get("bind_password"):
        cfg["bind_password"] = data["bind_password"]
    else:
        old = _load_ldap_config()
        cfg["bind_password"] = old.get("bind_password", "")

    try:
        _save_ldap_config(cfg)
        from product.audit.log import write as audit_write, AuditCategory
        audit_write(session["uid"], session["uname"], "LDAP_CONFIG_SAVED",
                    f"server={cfg['server']} enabled={cfg['enabled']}",
                    request.remote_addr, "WARN", AuditCategory.ADMIN)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# ── API：测试连接 ─────────────────────────────────────
@bp.route("/api/admin/ldap/test", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_ldap_test():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"ok": False, "message": "CSRF", "server_info": ""}), 403

    # 临时应用提交的配置（不保存），用于测试
    _apply_to_config(data)
    # 如果密码为空，从已保存配置里取
    if not data.get("bind_password"):
        old = _load_ldap_config()
        import config as _c
        _c.LDAP_BIND_PASSWORD = old.get("bind_password", "")

    try:
        from integrations.ldap_auth import test_connection
        result = test_connection()
        return jsonify(result)
    except Exception as e:
        return jsonify({"ok": False, "message": str(e), "server_info": ""})
    finally:
        # 测试后恢复已保存配置
        _apply_to_config(_load_ldap_config())


# ── API：立即同步 ─────────────────────────────────────
@bp.route("/api/admin/ldap/sync", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_ldap_sync():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    try:
        from integrations.ldap_auth import sync_all_users
        stats = sync_all_users()
        from product.audit.log import write as audit_write, AuditCategory
        audit_write(session["uid"], session["uname"], "LDAP_SYNC",
                    f"synced={stats['synced']} created={stats['created']} updated={stats['updated']}",
                    request.remote_addr, "INFO", AuditCategory.ADMIN)
        return jsonify({"success": True, "stats": stats})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# ── API：状态查询 ─────────────────────────────────────
@bp.route("/api/admin/ldap/status")
@login_required
@role_required(ROLE_SUPER)
def api_ldap_status():
    try:
        from integrations.ldap_auth import is_ldap_enabled
        cfg = _load_ldap_config()
        return jsonify({
            "enabled": is_ldap_enabled(),
            "server":  cfg.get("server", ""),
            "base_dn": cfg.get("base_dn", ""),
        })
    except Exception as e:
        return jsonify({"enabled": False, "error": str(e)})
