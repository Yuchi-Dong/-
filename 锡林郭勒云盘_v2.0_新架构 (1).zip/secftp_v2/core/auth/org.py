# -*- coding: utf-8 -*-
"""
services/org_service.py — 组织业务逻辑
"""
import re
from core.auth import org_dao
import config


def get_level_label(level: int) -> str:
    return config.ORG_LEVEL_NAMES.get(level, f"第{level}级")


def get_org_tree() -> list:
    """返回带 children 的树形结构"""
    all_orgs = org_dao.get_all()
    by_id = {o["id"]: {**o, "children": []} for o in all_orgs}
    roots = []
    for o in by_id.values():
        pid = o.get("parent_id")
        if pid and pid in by_id:
            by_id[pid]["children"].append(o)
        else:
            roots.append(o)
    return roots


def get_flat_list() -> list:
    """返回带 children 引用的扁平列表（供前端联动用）"""
    all_orgs = org_dao.get_all()
    by_id = {o["id"]: {**o, "children": []} for o in all_orgs}
    for o in by_id.values():
        pid = o.get("parent_id")
        if pid and pid in by_id:
            by_id[pid]["children"].append(o)
    return list(by_id.values())


def create_organization(name, code, desc, parent_id, org_level, level_label, created_by):
    if not re.match(r'^[a-zA-Z0-9_\u4e00-\u9fff\-]+$', code):
        return None, "组织代码只允许字母、数字、下划线、中文、连字符"
    if org_level not in (1, 2, 3):
        return None, "层级只能是 1/2/3"
    if org_level > 1 and not parent_id:
        return None, f"{get_level_label(org_level)}必须选择上级组织"

    # 构建目录路径
    if parent_id:
        parent = org_dao.get_by_id(parent_id)
        if not parent:
            return None, "上级组织不存在"
        # 层级约束
        if parent["org_level"] != org_level - 1:
            return None, f"层级不匹配：上级应为{get_level_label(org_level-1)}"
        dir_path = f"{parent['dir_path']}/{code}"
    else:
        dir_path = code

    try:
        oid = org_dao.create(name, code, dir_path, desc, parent_id,
                             org_level, level_label, created_by)
        return oid, None
    except Exception as e:
        if "UNIQUE" in str(e):
            return None, "同一上级组织下已存在相同名称或代码"
        return None, str(e)


def update_organization(org_id, name, desc, level_label=None):
    try:
        org_dao.update(org_id, name, desc, level_label)
        return True, None
    except Exception as e:
        return False, str(e)


def delete_organization(org_id):
    child_count  = org_dao.count_children(org_id)
    if child_count > 0:
        return False, f"该组织下还有 {child_count} 个子组织，请先删除"
    member_count = org_dao.count_members(org_id)
    if member_count > 0:
        return False, f"该组织下还有 {member_count} 名用户，请先移出"
    try:
        org_dao.delete(org_id)
        return True, None
    except Exception as e:
        return False, str(e)
