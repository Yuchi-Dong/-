# -*- coding: utf-8 -*-
"""
services/user_service.py — 用户业务逻辑

verify_password 支持双轨认证：
  1. 优先走 LDAP（如已启用且用户存在于 LDAP）
  2. 回落到本地密码验证（LDAP 未启用 / 本地专用账号）
"""
import re
import secrets
import hashlib
import logging
from datetime import datetime, timedelta
from core.auth import user_dao
import config

log = logging.getLogger("user_service")


def _hash_pw(salt: str, password: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()


def verify_password(username: str, password: str):
    """
    验证用户名密码。
    认证顺序：
      1. LDAP 已启用 → 先 LDAP，用户不存在于 LDAP → 回落本地
      2. LDAP 认证找到用户但密码错 → 直接拒绝，不允许用本地密码绕过
      3. LDAP 未启用 → 纯本地
    """
    try:
        from integrations.ldap_auth import is_ldap_enabled, ldap_authenticate
        ldap_on = is_ldap_enabled()
    except Exception:
        ldap_on = False

    if ldap_on:
        ldap_user, ldap_err = ldap_authenticate(username, password)
        if ldap_user is not None:
            try:
                user_dao.record_login_success(ldap_user["id"])
            except Exception:
                pass
            return ldap_user, None
        # 找到用户但密码错 → 拒绝，不回落
        if ldap_err and ("密码错误" in ldap_err or "invalid credentials" in ldap_err.lower()):
            row = user_dao.get_by_username(username)
            if row:
                new_fail = row["fail_count"] + 1
                lock_until = None
                if new_fail >= config.MAX_LOGIN_FAIL:
                    lock_until = (datetime.now() + timedelta(
                        seconds=config.LOCKOUT_SECONDS)).isoformat()
                user_dao.record_login_fail(row["id"], new_fail, lock_until)
            return None, ldap_err
        log.debug(f"LDAP 回落本地: user={username} err={ldap_err}")

    return _local_verify(username, password)


def _local_verify(username: str, password: str):
    row = user_dao.get_by_username(username)
    if not row:
        return None, "用户不存在或账号已禁用"

    locked_until = row.get("locked_until")
    if locked_until:
        try:
            lu = locked_until if isinstance(locked_until, datetime) else datetime.fromisoformat(str(locked_until))
            lu = lu.replace(tzinfo=None)
            if datetime.now() < lu:
                remaining = max(1, int((lu - datetime.now()).total_seconds() // 60) + 1)
                return None, f"账号已锁定，请 {remaining} 分钟后重试"
        except Exception:
            pass

    if not secrets.compare_digest(_hash_pw(row["salt"], password), row["password"]):
        new_fail = row["fail_count"] + 1
        lock_until = None
        if new_fail >= config.MAX_LOGIN_FAIL:
            lock_until = (datetime.now() + timedelta(seconds=config.LOCKOUT_SECONDS)).isoformat()
        user_dao.record_login_fail(row["id"], new_fail, lock_until)
        return None, f"密码错误（剩余 {max(0, config.MAX_LOGIN_FAIL - new_fail)} 次机会）"

    fresh = user_dao.record_login_success(row["id"])
    return fresh, None


def create_user(username, password, role, org_id, display_name, email, quota_mb, created_by):
    try:
        from license.middleware import check_create_user_limit
        check_create_user_limit()
    except Exception as _le:
        if "上限" in str(_le):
            return None, str(_le)

    if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]{2,19}$', username):
        return None, "用户名格式错误（字母开头，3-20位字母数字下划线）"
    from core.auth.password import validate_password
    pw_ok, pw_err = validate_password(password, username)
    if not pw_ok:
        return None, pw_err
    salt    = secrets.token_hex(16)
    pw_hash = _hash_pw(salt, password)
    try:
        uid = user_dao.create(username, pw_hash, salt, role, org_id,
                              display_name, email, quota_mb, created_by)
        return uid, None
    except Exception as e:
        if "UNIQUE" in str(e):
            return None, "用户名已存在"
        return None, str(e)


def change_password(user_id, new_password):
    salt = secrets.token_hex(16)
    user_dao.update_password(user_id, _hash_pw(salt, new_password), salt)


def verify_current_password(user_id, current_password) -> bool:
    from core.db import get_conn
    with get_conn() as conn:
        row = conn.execute(
            "SELECT password,salt FROM users WHERE id=%s", (user_id,)
        ).fetchone()
    if not row:
        return False
    return secrets.compare_digest(_hash_pw(row["salt"], current_password), row["password"])
