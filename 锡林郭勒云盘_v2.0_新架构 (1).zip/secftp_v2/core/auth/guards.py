# -*- coding: utf-8 -*-
"""
auth.py — 认证装饰器与安全工具
职责：装饰器、CSRF、路径安全、文件名处理
业务逻辑由 services/user_service.py 负责
"""
import os
import re
import secrets
import time
from functools import wraps
from flask import session, request, redirect, abort, jsonify
import config

ROLE_SUPER = config.ROLE_SUPER
ROLE_DEPT  = config.ROLE_DEPT
ROLE_USER  = config.ROLE_USER

_WIN_RESERVED = {
    "CON","PRN","AUX","NUL",
    "COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9",
    "LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9",
}


# ── 登录守卫 ─────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def wrap(*a, **kw):
        if "uid" not in session:
            if request.is_json or request.path.startswith("/api/"):
                return jsonify({"error": "未登录", "code": 401}), 401
            return redirect("/login")
        last = session.get("last_active", time.time())
        if time.time() - last > config.SESSION_TIMEOUT:
            session.clear()
            if request.is_json:
                return jsonify({"error": "会话已超时", "code": 401}), 401
            return redirect("/login?reason=timeout")
        session["last_active"] = time.time()
        return f(*a, **kw)
    return wrap


def role_required(min_role):
    def deco(f):
        @wraps(f)
        def wrap(*a, **kw):
            if "uid" not in session:
                if request.is_json or request.path.startswith("/api/"):
                    return jsonify({"error": "未登录", "code": 401}), 401
                return redirect("/login")
            last = session.get("last_active", time.time())
            if time.time() - last > config.SESSION_TIMEOUT:
                session.clear()
                if request.is_json:
                    return jsonify({"error": "会话已超时", "code": 401}), 401
                return redirect("/login?reason=timeout")
            session["last_active"] = time.time()
            if session.get("role", 99) > min_role:
                if request.is_json:
                    return jsonify({"error": "权限不足", "code": 403}), 403
                abort(403)
            return f(*a, **kw)
        return wrap
    return deco


# ── 路径安全 ─────────────────────────────────────────
def safe_join(base: str, *parts) -> str:
    base = os.path.realpath(base)
    clean = [p.replace("\x00", "").lstrip("/\\") for p in parts if p]
    target = os.path.realpath(os.path.join(base, *clean)) if clean else base
    if not (target == base or target.startswith(base + os.sep)):
        abort(403)
    return target


# ── CSRF ─────────────────────────────────────────────
def generate_csrf_token() -> str:
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(24)
    return session["csrf_token"]


def csrf_ok(token: str) -> bool:
    expected = session.get("csrf_token", "")
    if not token or not expected:
        return False
    return secrets.compare_digest(token, expected)


def csrf_protect(f):
    @wraps(f)
    def wrap(*a, **kw):
        if request.method in ("POST", "PUT", "DELETE", "PATCH"):
            token = (request.form.get("csrf_token")
                     or request.headers.get("X-CSRF-Token")
                     or (request.get_json(silent=True) or {}).get("csrf_token"))
            if not csrf_ok(token or ""):
                abort(403)
        return f(*a, **kw)
    return wrap


# ── 文件名安全 ────────────────────────────────────────
def secure_filename(filename: str) -> str:
    if not filename:
        return "unnamed_file"
    filename = os.path.basename(filename).replace("\x00", "")
    filename = re.sub(r'[^\w\u4e00-\u9fff\-_. ]', '_', filename)
    filename = filename.strip(". ")
    stem = filename.split(".")[0].upper()
    if stem in _WIN_RESERVED:
        filename = "_" + filename
    return filename or "unnamed_file"


# ── IP 管控 ──────────────────────────────────────────
def ip_guard():
    ip = request.remote_addr
    if ip in config.IP_BLACKLIST:
        abort(403)
    whitelist = getattr(config, "IP_WHITELIST", None)
    if whitelist and ip not in whitelist:
        abort(403)
