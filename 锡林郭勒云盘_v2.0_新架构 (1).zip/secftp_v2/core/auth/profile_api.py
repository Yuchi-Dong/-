# -*- coding: utf-8 -*-
"""core/auth/profile_api.py — 个人中心 REST API"""
import hashlib, io, os, base64, re
from flask import Blueprint, jsonify, request, g
from core.auth.jwt_auth import jwt_required
from core.auth.passwd import hash_password, verify_password, is_bcrypt_hash
from core.db import get_conn
import config

bp = Blueprint("profile_api", __name__, url_prefix="/api/profile")


@bp.route("/update", methods=["POST"])
@jwt_required
def update_profile():
    data = request.get_json(silent=True) or {}
    dn   = (data.get("display_name") or "").strip()
    if not dn:
        return jsonify({"error": "姓名不能为空"}), 400
    fields = {"display_name": dn}
    for k in ("email","phone"):
        if k in data: fields[k] = (data[k] or "").strip()
    dn    = (data.get("display_name") or "").strip()
    email = (data.get("email") or "").strip()
    phone = (data.get("phone") or "").strip()
    if not dn:
        return jsonify({"error": "姓名不能为空"}), 400
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET display_name=%s, email=%s, phone=%s WHERE id=%s",
            (dn, email, phone, g.uid)
        )
    return jsonify({"success": True})


@bp.route("/bio", methods=["POST"])
@jwt_required
def update_bio():
    data = request.get_json(silent=True) or {}
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET bio=%s, location=%s, department_title=%s WHERE id=%s",
            ((data.get("bio") or "")[:200], (data.get("location") or "")[:50],
             (data.get("department_title") or "")[:50], g.uid)
        )
    return jsonify({"success": True})


@bp.route("/color", methods=["POST"])
@jwt_required
def update_color():
    data  = request.get_json(silent=True) or {}
    color = data.get("color", "#1560bd")
    if not re.match(r'^#[0-9a-fA-F]{6}$', color):
        return jsonify({"error": "颜色格式错误"}), 400
    with get_conn() as conn:
        conn.execute("UPDATE users SET avatar_color=%s WHERE id=%s", (color, g.uid))
    return jsonify({"success": True})


@bp.route("/stats")
@jwt_required
def profile_stats():
    with get_conn() as conn:
        uploads  = conn.execute("SELECT COUNT(*) as c FROM audit_log WHERE user_id=%s AND action='UPLOAD'", (g.uid,)).fetchone()["c"]
        downloads= conn.execute("SELECT COUNT(*) as c FROM audit_log WHERE user_id=%s AND action='DOWNLOAD'", (g.uid,)).fetchone()["c"]
        shares   = conn.execute("SELECT COUNT(*) as c FROM file_shares WHERE owner_id=%s AND is_active=TRUE", (g.uid,)).fetchone()["c"]
        recent   = conn.execute(
            "SELECT action, detail, ts FROM audit_log WHERE user_id=%s ORDER BY id DESC LIMIT 8",
            (g.uid,)
        ).fetchall()
    # 磁盘已用
    used_mb = 0.0
    try:
        udir = os.path.join(config.FILE_ROOT, "users", g.username)
        if os.path.isdir(udir):
            used_mb = sum(os.path.getsize(os.path.join(dp,fn))
                          for dp,_,fns in os.walk(udir) for fn in fns) / 1024 / 1024
    except Exception:
        pass
    return jsonify({
        "uploads": uploads, "downloads": downloads, "shares": shares,
        "used_mb": round(used_mb, 2),
        "recent": [dict(r) for r in recent],
    })
