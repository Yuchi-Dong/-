# -*- coding: utf-8 -*-
"""
compliance/password_policy.py — 密码策略

满足等保三级要求（GB/T 22239-2019 身份鉴别控制点）：
  - 最短长度 ≥ 8 位
  - 必须包含大写字母 + 小写字母 + 数字 + 特殊字符
  - 不能与用户名相同或包含用户名
  - 不能是常见弱密码
  - 密码历史（防止重复使用最近N个密码）
"""
import re
import hashlib

# 常见弱密码集合
_WEAK_PASSWORDS = {
    'password', 'password1', 'password123', '123456', '12345678',
    'qwerty', 'abc123', 'admin', 'admin123', 'admin@123',
    'welcome', 'welcome1', 'iloveyou', 'sunshine', 'monkey',
    'dragon', 'master', 'letmein', 'login', 'pass',
    'test', 'test123', 'guest', 'changeme', 'default',
    '111111', '000000', '123123', '654321', '112233',
    'qwerty123', 'password!', 'p@ssword', 'p@ss123', 'P@ssw0rd',
}

_MIN_LENGTH             = 8
_REQUIRE_UPPER          = True
_REQUIRE_LOWER          = True
_REQUIRE_DIGIT          = True
_REQUIRE_SPECIAL        = True
_SPECIAL_CHARS          = r'!@#$%^&*()_+\-=\[\]{};\':"\\|,.<>\/?`~'
_PASSWORD_HISTORY_COUNT = 5


def validate_password(password: str, username: str = '') -> tuple:
    """
    校验密码强度。
    返回 (ok: bool, error_message: str)
    """
    if not password:
        return False, "密码不能为空"
    if len(password) < _MIN_LENGTH:
        return False, f"密码长度至少 {_MIN_LENGTH} 位"
    if _REQUIRE_UPPER and not re.search(r'[A-Z]', password):
        return False, "密码必须包含至少一个大写字母（A-Z）"
    if _REQUIRE_LOWER and not re.search(r'[a-z]', password):
        return False, "密码必须包含至少一个小写字母（a-z）"
    if _REQUIRE_DIGIT and not re.search(r'\d', password):
        return False, "密码必须包含至少一个数字（0-9）"
    if _REQUIRE_SPECIAL and not re.search(rf'[{_SPECIAL_CHARS}]', password):
        return False, "密码必须包含至少一个特殊字符（如 !@#$%^&*）"
    if username and username.lower() in password.lower():
        return False, "密码不能包含用户名"
    if password.lower() in _WEAK_PASSWORDS:
        return False, "密码过于简单，请使用更复杂的密码"
    return True, ''


def check_password_history(user_id: int, new_password: str) -> tuple:
    """
    检查新密码是否与历史密码重复。
    返回 (ok: bool, error_message: str)
    """
    def _hash(salt, pw):
        return hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100_000).hex()

    try:
        from core.db import get_conn
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT password_hash, salt FROM password_history "
                "WHERE user_id=%s ORDER BY created_at DESC LIMIT %s",
                (user_id, _PASSWORD_HISTORY_COUNT)
            ).fetchall()
        for row in rows:
            if _hash(row['salt'], new_password) == row['password_hash']:
                return False, f"不能重复使用最近 {_PASSWORD_HISTORY_COUNT} 次使用过的密码"
    except Exception:
        pass
    return True, ''


def save_password_history(user_id: int, password_hash: str, salt: str):
    """保存密码到历史记录，只保留最近 N 条"""
    try:
        from core.db import get_conn
        with get_conn() as conn:
            conn.execute(
                "INSERT INTO password_history(user_id, password_hash, salt) VALUES(%s,%s,%s)",
                (user_id, password_hash, salt)
            )
            # 只保留最近N条（PostgreSQL 写法）
            conn.execute("""
                DELETE FROM password_history
                WHERE user_id=%s AND id NOT IN (
                    SELECT id FROM password_history
                    WHERE user_id=%s
                    ORDER BY created_at DESC
                    LIMIT %s
                )
            """, (user_id, user_id, _PASSWORD_HISTORY_COUNT))
    except Exception:
        pass


def get_strength_score(password: str) -> dict:
    """
    密码强度评分（供前端显示强度条）
    返回 {score: 0-100, level: 'weak'|'medium'|'strong'|'very_strong', tips: [...]}
    """
    score = 0
    tips  = []

    if len(password) >= 8:  score += 20
    if len(password) >= 12: score += 10
    if len(password) >= 16: score += 10

    if re.search(r'[A-Z]', password): score += 15
    else: tips.append("添加大写字母可提高强度")

    if re.search(r'[a-z]', password): score += 15
    else: tips.append("添加小写字母可提高强度")

    if re.search(r'\d', password): score += 15
    else: tips.append("添加数字可提高强度")

    if re.search(rf'[{_SPECIAL_CHARS}]', password): score += 15
    else: tips.append("添加特殊字符（!@#$%）可大幅提高强度")

    if password.lower() in _WEAK_PASSWORDS:
        score = min(score, 20)

    score = min(score, 100)

    if score < 40:   level = 'weak'
    elif score < 60: level = 'medium'
    elif score < 80: level = 'strong'
    else:            level = 'very_strong'

    return {'score': score, 'level': level, 'tips': tips}
