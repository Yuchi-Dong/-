# -*- coding: utf-8 -*-
"""
core/auth/jwt_auth.py — JWT 身份认证核心

设计：
  - Access Token：15分钟有效，存 httpOnly Cookie
  - Refresh Token：7天有效，存 httpOnly Cookie（独立路径）
  - Token Rotation：每次刷新生成新 Refresh Token（防重放）
  - 双 Cookie：避免 XSS 盗取 token，CSRF 通过 SameSite=Lax 防护
  - Payload 含：uid, username, role, org_id, jti（JWT ID，用于吊销）

吊销机制：
  - Refresh Token 存 DB active_sessions 表
  - logout 时将 token 标记失效
  - 强制下线：将用户所有 session 标记失效
"""
import hashlib
import secrets
import time
from datetime import datetime, timedelta, timezone
from functools import wraps
from typing import Optional

import jwt
from flask import current_app, request, jsonify, g

import config

# Token 配置
ACCESS_TOKEN_EXPIRE  = 15 * 60        # 15 分钟（秒）
REFRESH_TOKEN_EXPIRE = 7 * 24 * 3600  # 7 天（秒）
ALGORITHM            = "HS256"

# Cookie 名称
ACCESS_COOKIE  = "access_token"
REFRESH_COOKIE = "refresh_token"


# ── Token 生成 ────────────────────────────────────────
def _make_token(payload: dict, expire_seconds: int) -> str:
    now = datetime.now(timezone.utc)
    payload.update({
        "iat": now,
        "exp": now + timedelta(seconds=expire_seconds),
        "jti": secrets.token_hex(16),
    })
    return jwt.encode(payload, config.SECRET_KEY, algorithm=ALGORITHM)


def create_tokens(user: dict) -> tuple[str, str]:
    """
    生成 Access Token + Refresh Token。
    Returns: (access_token, refresh_token)
    """
    base = {
        "uid":      user["id"],
        "username": user["username"],
        "role":     user.get("role", 2),
        "org_id":   user.get("org_id"),
    }
    access  = _make_token({**base, "type": "access"},  ACCESS_TOKEN_EXPIRE)
    refresh = _make_token({**base, "type": "refresh"}, REFRESH_TOKEN_EXPIRE)
    return access, refresh


def decode_token(token: str) -> Optional[dict]:
    """解码 token，失败返回 None"""
    try:
        return jwt.decode(token, config.SECRET_KEY, algorithms=[ALGORITHM])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None


# ── Cookie 操作 ───────────────────────────────────────
def set_auth_cookies(response, access_token: str, refresh_token: str):
    """将 JWT 写入 httpOnly Cookie"""
    secure = config.SESSION_COOKIE_SECURE
    response.set_cookie(
        ACCESS_COOKIE,
        access_token,
        max_age=ACCESS_TOKEN_EXPIRE,
        httponly=True,
        secure=secure,
        samesite="Lax",
        path="/",
    )
    response.set_cookie(
        REFRESH_COOKIE,
        refresh_token,
        max_age=REFRESH_TOKEN_EXPIRE,
        httponly=True,
        secure=secure,
        samesite="Lax",
        path="/api/auth/refresh",   # Refresh token 只在 /api/auth/refresh 可用
    )
    return response


def clear_auth_cookies(response):
    """清除 Cookie（logout 用）"""
    response.delete_cookie(ACCESS_COOKIE, path="/")
    response.delete_cookie(REFRESH_COOKIE, path="/api/auth/refresh")
    return response


def get_access_token() -> Optional[str]:
    """从 Cookie 或 Authorization header 取 access token"""
    # Cookie 优先
    token = request.cookies.get(ACCESS_COOKIE)
    if token:
        return token
    # Bearer header（API 调用兼容）
    auth = request.headers.get("Authorization", "")
    if auth.startswith("Bearer "):
        return auth[7:]
    return None


# ── DB Session 管理 ───────────────────────────────────
def save_refresh_token(uid: int, refresh_token: str, ip: str, ua: str):
    """将 Refresh Token 存入 DB（用于吊销控制）"""
    from core.db import get_conn
    payload = decode_token(refresh_token)
    if not payload:
        return
    jti     = payload.get("jti", "")
    exp_ts  = payload.get("exp", 0)
    ua_hash = hashlib.sha256(ua.encode()).hexdigest()[:16]
    with get_conn() as conn:
        # 清理同用户旧 token
        conn.execute(
            "DELETE FROM active_sessions WHERE user_id=%s "
            "AND created_at < NOW() - INTERVAL '8 days'",
            (uid,)
        )
        conn.execute(
            "INSERT INTO active_sessions(user_id, token, ip, ua_hash, created_at, last_active) "
            "VALUES(%s,%s,%s,%s,NOW(),NOW())",
            (uid, jti, ip, ua_hash)
        )


def validate_refresh_token_db(refresh_token: str) -> Optional[dict]:
    """验证 Refresh Token 的 jti 是否在 DB 中有效（防重放/吊销）"""
    payload = decode_token(refresh_token)
    if not payload or payload.get("type") != "refresh":
        return None

    jti = payload.get("jti", "")
    from core.db import get_conn
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT id, user_id FROM active_sessions "
                "WHERE token=%s AND is_active=TRUE",
                (jti,)
            ).fetchone()
        return payload if row else None
    except Exception:
        return None


def revoke_refresh_token(refresh_token: str):
    """吊销单个 Refresh Token"""
    payload = decode_token(refresh_token)
    if not payload:
        return
    jti = payload.get("jti", "")
    from core.db import get_conn
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE active_sessions SET is_active=FALSE, kicked_at=NOW() WHERE token=%s",
                (jti,)
            )
    except Exception:
        pass


def revoke_all_user_tokens(uid: int):
    """吊销用户所有 Refresh Token（强制下线）"""
    from core.db import get_conn
    with get_conn() as conn:
        conn.execute(
            "UPDATE active_sessions SET is_active=FALSE, kicked_at=NOW() WHERE user_id=%s",
            (uid,)
        )


# ── 装饰器 ────────────────────────────────────────────
def jwt_required(f):
    """
    JWT 认证装饰器。
    验证通过后将 payload 注入 g.jwt_payload，
    同时注入 g.uid, g.username, g.role, g.org_id。
    """
    @wraps(f)
    def wrapper(*args, **kwargs):
        token = get_access_token()
        if not token:
            return jsonify({"error": "未登录", "code": "UNAUTHORIZED"}), 401

        payload = decode_token(token)
        if not payload:
            return jsonify({"error": "Token 已过期，请重新登录", "code": "TOKEN_EXPIRED"}), 401

        if payload.get("type") != "access":
            return jsonify({"error": "Token 类型错误", "code": "INVALID_TOKEN"}), 401

        g.jwt_payload = payload
        g.uid         = payload["uid"]
        g.username    = payload["username"]
        g.role        = payload.get("role", 2)
        g.org_id      = payload.get("org_id")
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    """要求管理员角色（role <= 1）"""
    @wraps(f)
    @jwt_required
    def wrapper(*args, **kwargs):
        if g.role > 1:
            return jsonify({"error": "需要管理员权限"}), 403
        return f(*args, **kwargs)
    return wrapper


def super_required(f):
    """要求超级管理员（role == 0）"""
    @wraps(f)
    @jwt_required
    def wrapper(*args, **kwargs):
        if g.role != 0:
            return jsonify({"error": "需要超级管理员权限"}), 403
        return f(*args, **kwargs)
    return wrapper
