# -*- coding: utf-8 -*-
"""
core/auth/passwd.py — bcrypt 密码模块

替代旧版 PBKDF2-HMAC-SHA256。
bcrypt 自带 salt，默认 rounds=12（约 250ms/次，防暴力破解）。

安全属性：
  - 自适应哈希（rounds 可升级）
  - 内置 salt（不需要单独存储）
  - 防 GPU 暴力破解（内存密集型）
  - 常数时间比较（防时序攻击）
"""
import bcrypt

# work factor：12 约 250ms，安全与性能的平衡点
ROUNDS = 12


def hash_password(plain: str) -> str:
    """
    哈希密码，返回 bcrypt hash 字符串（含 salt，可直接存 DB）。
    格式：$2b$12$<22字节salt><31字节hash>
    """
    return bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt(rounds=ROUNDS)).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """
    验证密码，常数时间比较（防时序攻击）。
    兼容旧版 PBKDF2 hash（通过字段前缀区分）。
    """
    if not plain or not hashed:
        return False

    # bcrypt hash 以 $2b$ 或 $2a$ 开头
    if hashed.startswith(("$2b$", "$2a$", "$2y$")):
        try:
            return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
        except Exception:
            return False

    # 兼容旧版 PBKDF2（从 DB 读出的旧 hash，格式：hex字符串）
    # 旧版需要 salt，如果没有 salt 返回 False（用户需要重置密码）
    return False


def needs_rehash(hashed: str) -> bool:
    """
    检查 hash 是否需要升级（rounds 变更时触发）。
    登录成功后调用，透明升级用户密码 hash。
    """
    if not hashed.startswith(("$2b$", "$2a$")):
        return True   # 旧版 PBKDF2，需要迁移
    try:
        return bcrypt.checkpw(b"", hashed.encode()) or bcrypt.gensalt(rounds=ROUNDS) != b""
    except Exception:
        pass
    # 检查 rounds
    try:
        parts = hashed.split("$")
        current_rounds = int(parts[2])
        return current_rounds < ROUNDS
    except Exception:
        return False


def is_bcrypt_hash(s: str) -> bool:
    """判断字符串是否是 bcrypt hash"""
    return s.startswith(("$2b$", "$2a$", "$2y$"))
