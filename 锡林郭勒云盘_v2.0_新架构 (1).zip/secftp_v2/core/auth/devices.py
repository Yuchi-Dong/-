# -*- coding: utf-8 -*-
"""
routes/device_routes.py — 设备绑定管理 + 登录 IP 白名单管理

设备绑定：
  - 首次从新设备登录时记录设备指纹（User-Agent Hash）
  - 管理员可标记设备为"可信"或吊销
  - 可开启"仅允许可信设备登录"策略

IP 白名单管理：
  - 管理员可为指定用户设置允许登录的 IP/IP段
  - 支持精确 IP 和 CIDR 前三段匹配
"""
import hashlib
from flask import Blueprint, session, request, jsonify, abort

from auth import login_required, role_required, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER, ROLE_DEPT
from core.db import get_conn
from product.audit.log import write as audit_write, AuditCategory
from infra.templates import layout

bp = Blueprint('device', __name__)


# ── 设备管理页（个人）────────────────────────────────────
@bp.route('/profile/devices')
@login_required
def my_devices():
    uid  = session['uid']
    csrf = session.get('csrf_token', generate_csrf_token())
    session['csrf_token'] = csrf

    with get_conn() as conn:
        devices = conn.execute("""
            SELECT * FROM user_devices WHERE user_id=%s AND is_active=1
            ORDER BY last_seen DESC
        """, (uid,)).fetchall()

    rows_html = ''
    for d in devices:
        trust_btn = ''
        if d['is_trusted']:
            trust_label = '<span class="badge badge-green">✓ 可信设备</span>'
            trust_btn   = f'<button class="btn btn-xs btn-outline" onclick="untrustDevice({d["id"]})">撤销信任</button>'
        else:
            trust_label = '<span class="badge badge-gray">未信任</span>'
            trust_btn   = f'<button class="btn btn-xs btn-primary" onclick="trustDevice({d["id"]})">设为可信</button>'

        rows_html += f"""<tr>
          <td>{d.get('device_name') or '未知设备'}</td>
          <td style="font-size:11px;font-family:var(--font-mono)">{d.get('ua_hash','')[:16]}...</td>
          <td>{d.get('platform','—')}</td>
          <td class="fdate">{str(d.get('last_seen',''))[:16]}</td>
          <td>{trust_label}</td>
          <td style="text-align:right;white-space:nowrap">
            {trust_btn}
            <button class="btn btn-xs btn-danger" onclick="removeDevice({d['id']})">删除</button>
          </td>
        </tr>"""

    if not rows_html:
        rows_html = '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">💻</div><p>暂无设备记录</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">💻</span>我的设备</div>
  <div class="card" style="padding:14px 16px;margin-bottom:12px">
    <div style="font-size:12px;color:var(--text3);line-height:1.8">
      <div>系统会自动记录您登录时使用的设备（通过浏览器指纹识别）。</div>
      <div>将常用设备标记为"可信"，以便管理员了解您的正常登录模式。</div>
    </div>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>已记录设备</h2>
      <span class="badge badge-gray">{len(devices)} 台</span></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th>设备名称</th><th>指纹</th><th>平台</th><th>最后使用</th><th>状态</th>
        <th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>
<script>
async function trustDevice(id){{
  const r=await fetch('/api/device/trust',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{device_id:id,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已设为可信设备','ok');location.reload();}} else toast(d.error,'err');
}}
async function untrustDevice(id){{
  const r=await fetch('/api/device/untrust',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{device_id:id,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已撤销信任','ok');location.reload();}} else toast(d.error,'err');
}}
async function removeDevice(id){{
  if(!confirm('确认删除此设备记录？')) return;
  const r=await fetch('/api/device/remove',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{device_id:id,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已删除','ok');location.reload();}} else toast(d.error,'err');
}}
</script>"""
    from core.auth.context import ctx
    return layout(content, '我的设备', 'profile', **ctx())


@bp.route('/api/device/trust', methods=['POST'])
@login_required
def api_trust():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403
    with get_conn() as conn:
        conn.execute("UPDATE user_devices SET is_trusted=1 WHERE id=%s AND user_id=%s",
                     (data.get('device_id'), session['uid']))
    return jsonify({'success': True})


@bp.route('/api/device/untrust', methods=['POST'])
@login_required
def api_untrust():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403
    with get_conn() as conn:
        conn.execute("UPDATE user_devices SET is_trusted=0 WHERE id=%s AND user_id=%s",
                     (data.get('device_id'), session['uid']))
    return jsonify({'success': True})


@bp.route('/api/device/remove', methods=['POST'])
@login_required
def api_remove_device():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403
    with get_conn() as conn:
        conn.execute("UPDATE user_devices SET is_active=0 WHERE id=%s AND user_id=%s",
                     (data.get('device_id'), session['uid']))
    return jsonify({'success': True})


# ── 自动注册设备（登录时调用）────────────────────────────
def register_device(user_id: int, ua: str, ip: str):
    """登录成功后自动注册/更新设备记录"""
    ua_hash   = hashlib.sha256(ua.encode()).hexdigest()[:16]
    device_id = ua_hash  # 简化：以UA哈希作为设备ID

    # 判断平台
    ua_lower = ua.lower()
    if 'windows' in ua_lower:     platform = 'Windows'
    elif 'mac' in ua_lower:       platform = 'macOS'
    elif 'linux' in ua_lower:     platform = 'Linux'
    elif 'android' in ua_lower:   platform = 'Android'
    elif 'iphone' in ua_lower or 'ipad' in ua_lower: platform = 'iOS'
    else:                          platform = '未知'

    # 尝试提取浏览器名
    browser = '未知浏览器'
    for b in ['Chrome', 'Firefox', 'Safari', 'Edge', 'Opera']:
        if b.lower() in ua_lower:
            browser = b
            break

    device_name = f'{browser} / {platform}'

    try:
        with get_conn() as conn:
            existing = conn.execute(
                "SELECT id FROM user_devices WHERE user_id=%s AND device_id=%s",
                (user_id, device_id)
            ).fetchone()
            if existing:
                conn.execute("""
                    UPDATE user_devices SET last_seen=NOW(), is_active=1
                    WHERE user_id=%s AND device_id=%s
                """, (user_id, device_id))
            else:
                conn.execute("""
                    INSERT INTO user_devices(user_id, device_id, device_name, ua_hash, platform)
                    VALUES(%s, %s, %s, %s, %s)
                    ON CONFLICT(user_id, device_id) DO UPDATE
                    SET last_seen=NOW(), is_active=1
                """, (user_id, device_id, device_name, ua_hash, platform))
    except Exception:
        pass


# ── IP 白名单管理（管理员）───────────────────────────────
@bp.route('/admin/ip-whitelist')
@login_required
@role_required(ROLE_DEPT)
def admin_ip_whitelist():
    uid  = session['uid']
    role = session['role']
    csrf = session.get('csrf_token', generate_csrf_token())
    session['csrf_token'] = csrf

    with get_conn() as conn:
        if role == ROLE_SUPER:
            rows = conn.execute("""
                SELECT w.*, u.username, u.display_name
                FROM user_ip_whitelist w JOIN users u ON u.id=w.user_id
                WHERE w.is_active=1 ORDER BY u.username, w.allowed_ip
            """).fetchall()
            users = conn.execute(
                "SELECT id, username, display_name FROM users WHERE is_active=1 ORDER BY display_name"
            ).fetchall()
        else:
            rows = conn.execute("""
                SELECT w.*, u.username, u.display_name
                FROM user_ip_whitelist w JOIN users u ON u.id=w.user_id
                WHERE w.is_active=1 AND u.org_id=(SELECT org_id FROM users WHERE id=%s)
                ORDER BY u.username, w.allowed_ip
            """, (uid,)).fetchall()
            users = conn.execute("""
                SELECT id, username, display_name FROM users
                WHERE is_active=1 AND org_id=(SELECT org_id FROM users WHERE id=%s)
                ORDER BY display_name
            """, (uid,)).fetchall()

    rows_html = ''
    for r in rows:
        name = r.get('display_name') or r.get('username', '')
        rows_html += f"""<tr>
          <td>{name} (@{r.get('username','')})</td>
          <td style="font-family:var(--font-mono)">{r['allowed_ip']}</td>
          <td style="font-size:12px;color:var(--text3)">{r.get('note','')}</td>
          <td class="fdate">{str(r.get('created_at',''))[:10]}</td>
          <td style="text-align:right">
            <button class="btn btn-xs btn-danger" onclick="deleteIP({r['id']})">删除</button>
          </td>
        </tr>"""

    if not rows_html:
        rows_html = '<tr><td colspan="5"><div class="empty-state"><div class="es-icon">🔒</div><p>暂未配置IP限制，所有IP均可登录</p></div></td></tr>'

    user_opts = ''.join(f'<option value="{u["id"]}">{u.get("display_name") or u["username"]} (@{u["username"]})</option>'
                        for u in users)

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between">
    <div class="page-title"><span class="pt-icon">🔒</span>登录 IP 白名单管理</div>
    <button class="btn btn-primary btn-sm" onclick="showModal('m-add-ip')">➕ 添加 IP 规则</button>
  </div>
  <div class="card" style="padding:12px 16px;margin-bottom:12px">
    <div style="font-size:12px;color:var(--text3);line-height:1.8">
      <div>· 为用户添加 IP 限制后，该用户只能从指定 IP 登录</div>
      <div>· 支持精确 IP（如 192.168.1.100）和段匹配（如 192.168.1.0/24）</div>
      <div>· 未配置任何 IP 规则的用户不受限制</div>
    </div>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>IP 规则列表</h2>
      <span class="badge badge-gray">{len(rows)} 条</span></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th>用户</th><th>允许的 IP/段</th><th>备注</th><th>添加时间</th>
        <th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>

<div class="overlay" id="m-add-ip" onclick="if(event.target===this)hideModal('m-add-ip')">
  <div class="modal">
    <div class="modal-hdr"><h3>➕ 添加 IP 规则</h3>
      <button class="modal-close" onclick="hideModal('m-add-ip')">✕</button></div>
    <div class="fg"><label>选择用户</label>
      <select class="inp inp-sel" id="ip-user">{user_opts}</select></div>
    <div class="fg"><label>IP 地址或段</label>
      <input class="inp" id="ip-addr" placeholder="如 192.168.1.100 或 192.168.1.0/24"></div>
    <div class="fg"><label>备注（可选）</label>
      <input class="inp" id="ip-note" placeholder="如：办公室固定IP"></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-add-ip')">取消</button>
      <button class="btn btn-primary" onclick="addIP()">添加</button>
    </div>
  </div>
</div>

<script>
async function addIP(){{
  const uid=document.getElementById('ip-user').value;
  const ip=document.getElementById('ip-addr').value.trim();
  const note=document.getElementById('ip-note').value.trim();
  if(!ip){{toast('请填写IP地址','err');return;}}
  const r=await fetch('/api/ip-whitelist/add',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{user_id:uid,allowed_ip:ip,note:note,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{hideModal('m-add-ip');toast('已添加','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
async function deleteIP(id){{
  if(!confirm('确认删除此IP规则？')) return;
  const r=await fetch('/api/ip-whitelist/delete',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{rule_id:id,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已删除','ok');location.reload();}} else toast(d.error,'err');
}}
</script>"""
    from core.auth.context import ctx
    return layout(content, 'IP白名单管理', 'security', **ctx())


@bp.route('/api/ip-whitelist/add', methods=['POST'])
@login_required
@role_required(ROLE_DEPT)
def api_add_ip():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403
    user_id    = data.get('user_id')
    allowed_ip = (data.get('allowed_ip') or '').strip()
    note       = data.get('note', '')
    if not allowed_ip: return jsonify({'success': False, 'error': 'IP不能为空'})
    try:
        with get_conn() as conn:
            conn.execute("""
                INSERT INTO user_ip_whitelist(user_id, allowed_ip, note, created_by)
                VALUES(%s, %s, %s, %s)
                ON CONFLICT(user_id, allowed_ip) DO UPDATE SET is_active=1, note=EXCLUDED.note
            """, (user_id, allowed_ip, note, session['uid']))
        audit_write(session['uid'], session['uname'], 'ADD_IP_WHITELIST',
                    f'uid={user_id} ip={allowed_ip}', request.remote_addr, 'WARN', AuditCategory.ADMIN)
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@bp.route('/api/ip-whitelist/delete', methods=['POST'])
@login_required
@role_required(ROLE_DEPT)
def api_delete_ip():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403
    with get_conn() as conn:
        conn.execute("UPDATE user_ip_whitelist SET is_active=0 WHERE id=%s", (data.get('rule_id'),))
    return jsonify({'success': True})
