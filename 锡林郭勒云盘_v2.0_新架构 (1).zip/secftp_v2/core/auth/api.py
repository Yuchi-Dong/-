# -*- coding: utf-8 -*-
"""
core/auth/api.py — 认证 REST API

所有响应均为 JSON，不返回 HTML。

路由：
  POST /api/auth/login          登录，返回 JWT Cookie
  POST /api/auth/logout         注销，清除 Cookie
  POST /api/auth/refresh        刷新 Access Token
  GET  /api/auth/me             获取当前用户信息（含品牌配置）
  GET  /api/auth/csrf           获取 CSRF token（登录页用）
  POST /api/auth/verify-2fa     两步验证
  POST /api/auth/change-password 修改密码
"""
import hashlib
import secrets
import time
from datetime import datetime

from flask import Blueprint, request, jsonify, g, make_response, session

import config
from core.auth.jwt_auth import (
    create_tokens, set_auth_cookies, clear_auth_cookies,
    jwt_required, save_refresh_token, validate_refresh_token_db,
    revoke_refresh_token, decode_token, get_access_token
)
from core.auth.passwd import verify_password, hash_password, is_bcrypt_hash
from core.db import get_conn

bp = Blueprint("auth_api", __name__, url_prefix="/api/auth")

# 登录失败计数（内存，重启清零；生产可用 Redis）
_login_fails: dict = {}


def _check_rate_limit(ip: str, username: str) -> bool:
    """简单速率限制：5分钟内同IP+用户名失败超5次则拦截"""
    key  = f"{ip}:{username}"
    now  = time.time()
    data = _login_fails.get(key, {"count": 0, "reset_at": now + 300})
    if now > data["reset_at"]:
        data = {"count": 0, "reset_at": now + 300}
    return data["count"] < 5


def _record_fail(ip: str, username: str):
    key  = f"{ip}:{username}"
    now  = time.time()
    data = _login_fails.get(key, {"count": 0, "reset_at": now + 300})
    data["count"] += 1
    _login_fails[key] = data


def _clear_fail(ip: str, username: str):
    _login_fails.pop(f"{ip}:{username}", None)


@bp.route("/login", methods=["POST"])
def login():
    data     = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password", "")
    ip       = request.remote_addr

    if not username or not password:
        return jsonify({"error": "用户名和密码不能为空"}), 400

    # 速率限制
    if not _check_rate_limit(ip, username):
        return jsonify({"error": "登录尝试过于频繁，请5分钟后再试"}), 429

    # 查用户（同时支持 LDAP 账号）
    with get_conn() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE username=%s AND is_active=TRUE",
            (username,)
        ).fetchone()

    if not user:
        _record_fail(ip, username)
        return jsonify({"error": "用户名或密码错误"}), 401

    # 检查锁定
    if user.get("locked_until"):
        locked = user["locked_until"]
        if isinstance(locked, str):
            locked = datetime.fromisoformat(locked)
        if locked.replace(tzinfo=None) > datetime.now():
            mins = max(1, int((locked.replace(tzinfo=None) - datetime.now()).total_seconds() // 60))
            return jsonify({"error": f"账号已锁定，请 {mins} 分钟后重试"}), 401

    # LDAP 用户走 LDAP 验证
    if user.get("is_ldap_user"):
        try:
            from core.auth.ldap import ldap_authenticate
            ldap_user, ldap_err = ldap_authenticate(username, password)
            if not ldap_user:
                _record_fail(ip, username)
                return jsonify({"error": ldap_err or "LDAP 认证失败"}), 401
        except Exception:
            pass
    else:
        # 本地密码验证
        pw_hash = user.get("password_hash", "")
        pw_salt = user.get("password_salt", "")  # 旧版兼容

        # 优先 bcrypt
        if is_bcrypt_hash(pw_hash):
            if not verify_password(password, pw_hash):
                _record_fail(ip, username)
                _update_fail_count(user["id"])
                return jsonify({"error": "用户名或密码错误"}), 401
        elif pw_salt:
            # 旧版 PBKDF2 兼容
            import hashlib as _hl
            old_hash = _hl.pbkdf2_hmac("sha256", password.encode(), pw_salt.encode(), 100_000).hex()
            if not secrets.compare_digest(old_hash, pw_hash):
                _record_fail(ip, username)
                _update_fail_count(user["id"])
                return jsonify({"error": "用户名或密码错误"}), 401
            else:
                # 透明升级到 bcrypt
                _upgrade_to_bcrypt(user["id"], password)
        else:
            return jsonify({"error": "密码格式错误，请联系管理员重置"}), 401

    # 2FA 检查
    if user.get("totp_enabled"):
        # 暂存状态，要求前端验证码
        pending_token = secrets.token_hex(16)
        session["pending_2fa"] = {
            "uid":      user["id"],
            "token":    pending_token,
            "expires":  time.time() + 300,
        }
        return jsonify({"need_2fa": True, "pending_token": pending_token})

    return _do_login_success(user, ip)


@bp.route("/verify-2fa", methods=["POST"])
def verify_2fa():
    data = request.get_json(silent=True) or {}
    code = data.get("code", "").strip()
    pending = session.get("pending_2fa", {})

    if not pending or time.time() > pending.get("expires", 0):
        return jsonify({"error": "验证码已过期，请重新登录"}), 401

    uid = pending["uid"]
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=%s", (uid,)).fetchone()

    if not row:
        return jsonify({"error": "用户不存在"}), 401

    import pyotp
    totp = pyotp.TOTP(row["totp_secret"])
    if not totp.verify(code, valid_window=1):
        return jsonify({"error": "验证码错误"}), 401

    session.pop("pending_2fa", None)
    return _do_login_success(dict(row), request.remote_addr)


def _do_login_success(user: dict, ip: str):
    """登录成功的通用处理"""
    uid = user["id"]

    # 清除失败计数
    _clear_fail(ip, user["username"])

    # 更新登录记录
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET last_login=NOW(), fail_count=0, locked_until=NULL WHERE id=%s",
            (uid,)
        )

    # 生成 JWT
    access, refresh = create_tokens(user)

    # 保存 Refresh Token 到 DB
    ua = request.headers.get("User-Agent", "")
    save_refresh_token(uid, refresh, ip, ua)

    # 写审计日志
    try:
        from product.audit.log import write as audit_write, AuditCategory
        audit_write(uid, user["username"], "LOGIN_SUCCESS", f"ip={ip}",
                    ip, "INFO", AuditCategory.AUTH)
    except Exception:
        pass

    resp = make_response(jsonify({
        "success": True,
        "user":    _safe_user(user),
        "need_2fa": False,
    }))
    set_auth_cookies(resp, access, refresh)
    return resp


@bp.route("/logout", methods=["POST"])
def logout():
    refresh = request.cookies.get("refresh_token", "")
    if refresh:
        revoke_refresh_token(refresh)

    resp = make_response(jsonify({"success": True}))
    clear_auth_cookies(resp)
    return resp


@bp.route("/refresh", methods=["POST"])
def refresh():
    """用 Refresh Token 换取新 Access Token（Token Rotation）"""
    refresh_token = request.cookies.get("refresh_token", "")
    if not refresh_token:
        return jsonify({"error": "未登录"}), 401

    payload = validate_refresh_token_db(refresh_token)
    if not payload:
        resp = make_response(jsonify({"error": "Token 已过期，请重新登录"}), 401)
        clear_auth_cookies(resp)
        return resp

    uid = payload["uid"]
    with get_conn() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE id=%s AND is_active=TRUE", (uid,)
        ).fetchone()

    if not user:
        return jsonify({"error": "用户不存在或已被禁用"}), 401

    # Token Rotation：吊销旧 Refresh Token，颁发新的
    revoke_refresh_token(refresh_token)
    access, new_refresh = create_tokens(dict(user))
    save_refresh_token(uid, new_refresh, request.remote_addr,
                       request.headers.get("User-Agent", ""))

    resp = make_response(jsonify({"success": True}))
    set_auth_cookies(resp, access, new_refresh)
    return resp


@bp.route("/me")
@jwt_required
def me():
    """获取当前用户信息 + 品牌配置（登录后首次调用）"""
    with get_conn() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE id=%s", (g.uid,)
        ).fetchone()

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    # 计算已用空间
    used_mb = 0.0
    try:
        import os
        udir = os.path.join(config.FILE_ROOT, "users", user["username"])
        if os.path.isdir(udir):
            used_mb = sum(
                os.path.getsize(os.path.join(dp, fn))
                for dp, _, fns in os.walk(udir) for fn in fns
            ) / 1024 / 1024
    except Exception:
        pass

    # 品牌配置
    branding = {}
    try:
        with get_conn() as conn2:
            row = conn2.execute(
                "SELECT value FROM system_config WHERE key='branding'"
            ).fetchone()
        if row:
            branding = row["value"] if isinstance(row["value"], dict) else {}
    except Exception:
        pass

    return jsonify({
        "user":     {**_safe_user(dict(user)), "used_mb": round(used_mb, 2)},
        "branding": branding,
    })


@bp.route("/csrf")
def csrf():
    """
    登录页获取 CSRF token（品牌配置一并返回，减少请求次数）。
    CSRF 对于 Cookie+JWT 方案通过 SameSite=Lax 防护，
    此接口主要供老式表单兼容，以及给前端注入品牌配置。
    """
    csrf_token = secrets.token_hex(16)
    session["csrf_token"] = csrf_token

    branding = {}
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT value FROM system_config WHERE key='branding'"
            ).fetchone()
        if row:
            branding = row["value"] if isinstance(row["value"], dict) else {}
    except Exception:
        pass

    return jsonify({"csrf": csrf_token, "branding": branding})


@bp.route("/change-password", methods=["POST"])
@jwt_required
def change_password():
    data    = request.get_json(silent=True) or {}
    old_pw  = data.get("old_password", "")
    new_pw  = data.get("new_password", "")

    if len(new_pw) < 8:
        return jsonify({"error": "新密码至少 8 位"}), 400

    with get_conn() as conn:
        user = conn.execute(
            "SELECT password_hash, password_salt FROM users WHERE id=%s", (g.uid,)
        ).fetchone()

    if not user:
        return jsonify({"error": "用户不存在"}), 404

    pw_hash = user["password_hash"]
    pw_salt = user.get("password_salt", "")

    # 验证旧密码
    if is_bcrypt_hash(pw_hash):
        if not verify_password(old_pw, pw_hash):
            return jsonify({"error": "当前密码错误"}), 401
    elif pw_salt:
        import hashlib as _hl
        old_hash = _hl.pbkdf2_hmac("sha256", old_pw.encode(), pw_salt.encode(), 100_000).hex()
        if not secrets.compare_digest(old_hash, pw_hash):
            return jsonify({"error": "当前密码错误"}), 401
    else:
        return jsonify({"error": "密码格式错误"}), 400

    # 密码策略（简单版：8位以上，含字母数字）
    import re
    if not re.search(r'[A-Za-z]', new_pw) or not re.search(r'[0-9]', new_pw):
        return jsonify({"error": "新密码必须包含字母和数字"}), 400

    # 保存新密码（bcrypt）
    new_hash = hash_password(new_pw)
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET password_hash=%s, password_salt='', "
            "pw_changed_at=NOW(), force_pw_change=FALSE WHERE id=%s",
            (new_hash, g.uid)
        )

    # 吊销所有其他 token（改密后强制重新登录其他设备）
    from core.auth.jwt_auth import revoke_all_user_tokens
    revoke_all_user_tokens(g.uid)

    try:
        from product.audit.log import write as aw, AuditCategory
        aw(g.uid, g.username, "CHANGE_PASSWORD", "", request.remote_addr,
           "WARN", AuditCategory.AUTH)
    except Exception:
        pass

    return jsonify({"success": True, "message": "密码已修改，其他设备将被强制下线"})


# ── 辅助函数 ──────────────────────────────────────────
def _safe_user(u: dict) -> dict:
    """返回安全的用户字段（不含密码/salt/totp_secret）"""
    return {
        "id":           u.get("id"),
        "username":     u.get("username"),
        "display_name": u.get("display_name", ""),
        "email":        u.get("email", ""),
        "phone":        u.get("phone", ""),
        "bio":          u.get("bio", ""),
        "role":         u.get("role", 2),
        "org_id":       u.get("org_id"),
        "avatar_color": u.get("avatar_color", "#1560bd"),
        "avatar_path":  u.get("avatar_path", ""),
        "quota_mb":     u.get("quota_mb", 1048576),
        "is_active":    u.get("is_active", True),
        "totp_enabled": u.get("totp_enabled", False),
        "last_login":   str(u.get("last_login", ""))[:19],
        "created_at":   str(u.get("created_at", ""))[:10],
        "unread_shares": 0,  # 由专门接口提供
    }


def _update_fail_count(uid: int):
    """更新失败计数，超限锁定"""
    from datetime import timedelta
    with get_conn() as conn:
        row = conn.execute("SELECT fail_count FROM users WHERE id=%s", (uid,)).fetchone()
        new_count = (row["fail_count"] or 0) + 1
        lock_until = None
        if new_count >= config.MAX_LOGIN_FAIL:
            lock_until = (datetime.now() + timedelta(seconds=config.LOCKOUT_SECONDS)).isoformat()
        conn.execute(
            "UPDATE users SET fail_count=%s, locked_until=%s WHERE id=%s",
            (new_count, lock_until, uid)
        )


def _upgrade_to_bcrypt(uid: int, plain_password: str):
    """透明将旧 PBKDF2 hash 升级为 bcrypt"""
    new_hash = hash_password(plain_password)
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET password_hash=%s, password_salt='' WHERE id=%s",
            (new_hash, uid)
        )
