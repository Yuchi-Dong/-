# -*- coding: utf-8 -*-
"""
services/permission_service.py — 权限服务

融合两套权限体系，向后兼容：
  1. 组织驱动（新）：用户 → 组织链 → 组织权限（含继承）
  2. 路径授权（旧）：dir_perms + file_shares（兼容已有数据）

优先级：超管 > 组织权限 > 个人授权路径 > 分享
"""
from core.db import get_conn
from core.auth import org_dao
import config
import time
import threading

# ── 权限缓存（内存 LRU，TTL=120s）──────────────────────
_perm_cache: dict = {}
_perm_lock  = threading.Lock()
_PERM_TTL   = 120   # 秒


def _cache_get(key):
    with _perm_lock:
        item = _perm_cache.get(key)
        if item and time.time() < item[1]:
            return item[0]
        _perm_cache.pop(key, None)
    return None


def _cache_set(key, value):
    with _perm_lock:
        _perm_cache[key] = (value, time.time() + _PERM_TTL)
        # 限制缓存条目数（防内存无限增长）
        if len(_perm_cache) > 500:
            oldest = sorted(_perm_cache, key=lambda k: _perm_cache[k][1])
            for k in oldest[:100]:
                _perm_cache.pop(k, None)


def invalidate_perm_cache(user_id: int = None):
    """权限变更时主动失效缓存（管理员修改权限后调用）"""
    with _perm_lock:
        if user_id:
            to_del = [k for k in _perm_cache if k[0] == user_id]
        else:
            to_del = list(_perm_cache.keys())
        for k in to_del:
            _perm_cache.pop(k, None)


# ── 组织权限链（核心）──────────────────────────────────
def _get_ancestor_ids(org_id: int) -> list:
    """
    返回 org_id 自身及所有祖先的 id 列表。
    使用递归 CTE，单次查询替代循环查询。
    """
    if not org_id:
        return []
    rows = org_dao.get_ancestors(org_id)
    return [r['id'] for r in rows]


def _org_has_perm(org_id: int, rel_path: str, need_write: bool) -> bool:
    """
    检查组织（含祖先链）是否对 rel_path 有权限。
    继承规则：子组织自动继承父组织权限（inherit=1 时）。
    """
    if not org_id:
        return False
    ancestor_ids = _get_ancestor_ids(org_id)
    if not ancestor_ids:
        return False

    rel = rel_path.strip("/")
    # 使用 ANY(%s) 代替 IN 拼接，避免空列表问题且更安全
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT org_id, path, perm, inherit FROM org_permissions "
            "WHERE org_id = ANY(%s)",
            (ancestor_ids,)
        ).fetchall()

    for row in rows:
        ap = row['path'].strip("/")
        if rel == ap or rel.startswith(ap + "/") or ap == "":
            is_self = (row['org_id'] == org_id)
            if not is_self and not row['inherit']:
                continue
            if need_write:
                return row['perm'] == 'rw'
            return True
    return False


# ── 主权限入口 ──────────────────────────────────────
def get_authorized_paths(user_id: int, role: int, org_id) -> list:
    """
    返回当前用户的完整授权路径列表（供文件浏览用）。
    超管直接返回全局根目录。
    带 120 秒内存缓存，减少重复 DB 查询。
    """
    cache_key = (user_id, org_id, role)
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached
    paths = []

    # 个人空间（所有人都有）
    with get_conn() as conn:
        row = conn.execute("SELECT username FROM users WHERE id=%s", (user_id,)).fetchone()
    if row:
        import os, config as _cfg
        personal = f"users/{row['username']}"
        os.makedirs(os.path.join(_cfg.FILE_ROOT, personal), exist_ok=True)
        paths.append({"path": personal, "perm": "rw", "source": "personal", "label": "我的空间"})

    if role == config.ROLE_SUPER:
        paths.append({"path": "", "perm": "rw", "source": "superadmin", "label": "全局根目录"})
        return paths

    # 组织目录
    if org_id:
        with get_conn() as conn:
            org = conn.execute(
                "SELECT dir_path,name FROM organizations WHERE id=%s", (org_id,)
            ).fetchone()
        if org:
            org_perm = "rw" if role == config.ROLE_DEPT else "ro"
            paths.append({
                "path": org["dir_path"], "perm": org_perm,
                "source": "org", "label": org["name"]
            })

            # org_permissions 中额外授权的路径
            ancestor_ids = _get_ancestor_ids(org_id)
            if ancestor_ids:
                with get_conn() as conn:
                    rows = conn.execute(
                        "SELECT path, perm FROM org_permissions WHERE org_id = ANY(%s)",
                        (ancestor_ids,)
                    ).fetchall()
                for r in rows:
                    paths.append({
                        "path": r["path"], "perm": r["perm"],
                        "source": "org_perm", "label": f"组织授权：{r['path']}"
                    })

    # 公共资源
    with get_conn() as conn:
        pub = conn.execute("SELECT dir_path FROM organizations WHERE code='shared'").fetchone()
    if pub:
        paths.append({"path": pub["dir_path"], "perm": "ro", "source": "public", "label": "公共资源"})

    # dir_perms 个人授权
    with get_conn() as conn:
        for r in conn.execute("SELECT dir_path,perm FROM dir_perms WHERE user_id=%s", (user_id,)):
            paths.append({"path": r["dir_path"], "perm": r["perm"], "source": "granted", "label": r["dir_path"]})

    # 分享给我的
    with get_conn() as conn:
        shares = conn.execute("""
            SELECT fs.file_path, fs.perm, u.display_name as owner_name
            FROM file_shares fs LEFT JOIN users u ON u.id=fs.owner_id
            WHERE fs.is_active=1 AND fs.owner_id!=%s
              AND (fs.expires_at IS NULL OR fs.expires_at > NOW())
              AND ((fs.share_type='user' AND fs.target_id=%s)
                OR (fs.share_type='org'  AND fs.target_id=%s)
                OR  fs.share_type='public')
        """, (user_id, user_id, org_id)).fetchall()
    for s in shares:
        paths.append({
            "path": s["file_path"], "perm": s["perm"],
            "source": "shared", "label": f"来自 {s['owner_name']} 的共享"
        })

    _cache_set(cache_key, paths)
    return paths


def can_access(rel_path: str, user_id: int, role: int, org_id, need_write: bool = False) -> bool:
    """
    统一权限入口。
    双轨检查：组织权限（新）+ 路径权限（兼容旧）
    """
    if role == config.ROLE_SUPER:
        return True

    rel = rel_path.strip("/\\").replace("\\", "/")

    # 1. 组织驱动权限（新体系）
    if org_id and _org_has_perm(org_id, rel, need_write):
        return True

    # 2. 个人授权路径 + 分享（旧体系兼容）
    for ap in get_authorized_paths(user_id, role, org_id):
        ap_path = ap["path"].strip("/")
        if rel == ap_path or rel.startswith(ap_path + "/") or ap_path == "":
            if need_write:
                return ap["perm"] == "rw"
            return True

    return False
