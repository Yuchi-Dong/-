# -*- coding: utf-8 -*-
"""core/auth/avatar.py — 头像上传/删除/服务"""
import base64, hashlib, io, mimetypes, os, re
from flask import Blueprint, jsonify, request, g, send_file, abort
from core.auth.jwt_auth import jwt_required
from core.db import get_conn
import config

bp = Blueprint("avatar_api", __name__)

AVATAR_DIR = property(lambda self: os.path.join(config.FILE_ROOT, ".avatars"))


def _avatar_dir():
    d = os.path.join(config.FILE_ROOT, ".avatars")
    os.makedirs(d, exist_ok=True)
    return d


@bp.route("/avatar/<path:filename>")
def serve_avatar(filename):
    if not re.match(r'^[\w\-]{4,80}\.(jpg|jpeg|png|webp)$', filename, re.I):
        abort(403)
    d    = _avatar_dir()
    full = os.path.realpath(os.path.join(d, filename))
    if not full.startswith(os.path.realpath(d)):
        abort(403)
    if not os.path.isfile(full):
        abort(404)
    mime, _ = mimetypes.guess_type(full)
    resp = send_file(full, mimetype=mime or 'image/jpeg')
    resp.headers['Cache-Control'] = 'public, max-age=86400'
    return resp


@bp.route("/api/avatar/upload", methods=["POST"])
@jwt_required
def upload_avatar():
    b64 = request.form.get("image_data", "")
    if "," in b64:
        b64 = b64.split(",", 1)[1]
    if not b64:
        return jsonify({"error": "未收到图片数据"}), 400
    try:
        img_bytes = base64.b64decode(b64)
    except Exception:
        return jsonify({"error": "图片数据解析失败"}), 400

    max_b = getattr(config, "AVATAR_MAX_KB", 2048) * 1024
    if len(img_bytes) > max_b:
        return jsonify({"error": f"图片超过 {max_b//1024}KB"}), 400

    try:
        from PIL import Image
        img  = Image.open(io.BytesIO(img_bytes)).convert("RGBA")
        size = getattr(config, "AVATAR_SIZE", 200)
        w, h = img.size
        m    = min(w, h)
        img  = img.crop(((w-m)//2, (h-m)//2, (w+m)//2, (h+m)//2)).resize((size,size), Image.LANCZOS)
        bg   = Image.new("RGB", (size,size), (255,255,255))
        bg.paste(img, mask=img.split()[3] if img.mode=="RGBA" else None)
        out  = io.BytesIO()
        bg.save(out, "JPEG", quality=88, optimize=True)
        final = out.getvalue()
    except ImportError:
        final = img_bytes
    except Exception as e:
        return jsonify({"error": f"图片处理失败: {e}"}), 400

    d        = _avatar_dir()
    fhash    = hashlib.sha256(final).hexdigest()[:16]
    filename = f"{g.uid}_{fhash}.jpg"

    # 删旧
    with get_conn() as conn:
        old = conn.execute("SELECT avatar_path FROM users WHERE id=%s", (g.uid,)).fetchone()
    if old and old.get("avatar_path") and old["avatar_path"] != filename:
        try: os.remove(os.path.join(d, old["avatar_path"]))
        except Exception: pass

    with open(os.path.join(d, filename), "wb") as f:
        f.write(final)

    with get_conn() as conn:
        conn.execute("UPDATE users SET avatar_path=%s WHERE id=%s", (filename, g.uid))
    return jsonify({"success": True, "url": f"/avatar/{filename}"})


@bp.route("/api/avatar", methods=["DELETE"])
@jwt_required
def delete_avatar():
    with get_conn() as conn:
        row = conn.execute("SELECT avatar_path FROM users WHERE id=%s", (g.uid,)).fetchone()
    if row and row.get("avatar_path"):
        fp = os.path.join(_avatar_dir(), row["avatar_path"])
        try:
            if os.path.isfile(fp): os.remove(fp)
        except Exception: pass
    with get_conn() as conn:
        conn.execute("UPDATE users SET avatar_path='' WHERE id=%s", (g.uid,))
    return jsonify({"success": True})
