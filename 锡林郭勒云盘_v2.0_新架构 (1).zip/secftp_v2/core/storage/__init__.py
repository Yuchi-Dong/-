"""core/storage — 加密存储层"""
from core.storage.encrypted_local import EncryptedLocalStorage
from core.storage.registry import get_storage, init_storage

__all__ = ["EncryptedLocalStorage", "get_storage", "init_storage"]
