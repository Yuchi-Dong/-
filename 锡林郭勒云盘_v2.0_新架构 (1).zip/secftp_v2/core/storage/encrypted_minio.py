# -*- coding: utf-8 -*-
"""
core/storage/encrypted_minio.py — MinIO 加密存储后端

文件在加密后写入 MinIO：
  上传路径：明文 → AES-256-GCM 加密 → MinIO Object（key.enc）
  下载路径：MinIO Object → 内存解密 → 明文返回调用方

File Key 保护与本地版完全相同（vendor_enc + owner_enc 存 DB）。
"""
import io, os
from pathlib import Path
from core.crypto.engine import FileEncryptor
from core.crypto.key_service import is_encryption_available, protect_new_file_key, recover_file_key
from core.db import get_conn
import logging

log = logging.getLogger("storage.minio")


def _cfg(key, default=""):
    import config as _c
    return getattr(_c, key, None) or os.environ.get(key, default)


class EncryptedMinIOStorage:
    """MinIO + AES-256-GCM 透明加密存储"""

    def __init__(self):
        from minio import Minio
        self._S3Error = None
        try:
            from minio.error import S3Error
            self._S3Error = S3Error
        except Exception:
            pass

        endpoint   = _cfg("MINIO_ENDPOINT",   "127.0.0.1:9000")
        access_key = _cfg("MINIO_ACCESS_KEY",  "minioadmin")
        secret_key = _cfg("MINIO_SECRET_KEY",  "minioadmin")
        secure     = str(_cfg("MINIO_SECURE",  "false")).lower() in ("1","true","yes")
        self.bucket = _cfg("MINIO_BUCKET",     "secftp-files")

        self._client = Minio(endpoint, access_key=access_key,
                             secret_key=secret_key, secure=secure)
        self._ensure_bucket()
        log.info(f"MinIO 连接：{endpoint}  bucket={self.bucket}")

    def _ensure_bucket(self):
        if not self._client.bucket_exists(self.bucket):
            self._client.make_bucket(self.bucket)

    @staticmethod
    def _enc_key(key: str) -> str:
        """MinIO object name = key + .enc（对外透明）"""
        k = key.strip("/")
        return k + ".enc" if k else k

    # ── 写 ────────────────────────────────────────────
    def put(self, key: str, data, *, content_type: str = "") -> None:
        if isinstance(data, (bytes, bytearray)):
            stream = io.BytesIO(data)
        else:
            stream = data

        if is_encryption_available():
            ciphertext, file_key = FileEncryptor.encrypt_stream(stream)
            _, protected = _get_protected(file_key)
            obj_name = self._enc_key(key)
            self._client.put_object(
                self.bucket, obj_name,
                io.BytesIO(ciphertext), len(ciphertext),
                content_type="application/octet-stream",
            )
            # 保存 File Key 到 DB
            plaintext_size = len(ciphertext) - 36   # MAGIC+nonce+tag overhead
            with get_conn() as conn:
                conn.execute("""
                    INSERT INTO file_keys(file_path, vendor_enc, owner_enc, plaintext_size)
                    VALUES(%s,%s,%s,%s)
                    ON CONFLICT(file_path) DO UPDATE
                    SET vendor_enc=%s, owner_enc=%s, plaintext_size=%s, updated_at=NOW()
                """, (key, protected["vendor_enc"], protected.get("owner_enc",""), plaintext_size,
                      protected["vendor_enc"], protected.get("owner_enc",""), plaintext_size))
        else:
            log.warning(f"加密未启用，明文写入 MinIO: {key}")
            data_bytes = stream.read()
            self._client.put_object(
                self.bucket, key.lstrip("/"),
                io.BytesIO(data_bytes), len(data_bytes),
            )

    # ── 读 ────────────────────────────────────────────
    def get(self, key: str) -> bytes:
        obj_name = self._enc_key(key)
        try:
            resp  = self._client.get_object(self.bucket, obj_name)
            cipher= resp.read()
            resp.close(); resp.release_conn()
        except Exception:
            # 降级：尝试无加密 key
            try:
                resp  = self._client.get_object(self.bucket, key.lstrip("/"))
                data  = resp.read()
                resp.close(); resp.release_conn()
                return data
            except Exception:
                raise FileNotFoundError(key)

        return FileEncryptor.decrypt_bytes(cipher, self._get_file_key(key))

    def get_stream(self, key: str):
        data = self.get(key)
        return io.BytesIO(data)

    def _get_file_key(self, key: str) -> bytes:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT vendor_enc FROM file_keys WHERE file_path=%s", (key,)
            ).fetchone()
        if not row or not row.get("vendor_enc"):
            raise RuntimeError(f"File Key 未找到: {key}")
        return recover_file_key(row["vendor_enc"])

    # ── 删 ────────────────────────────────────────────
    def delete(self, key: str) -> None:
        for obj_name in [self._enc_key(key), key.lstrip("/")]:
            try: self._client.remove_object(self.bucket, obj_name)
            except Exception: pass
        # 递归删目录
        prefix = key.strip("/") + "/"
        for obj in self._client.list_objects(self.bucket, prefix=prefix, recursive=True):
            try: self._client.remove_object(self.bucket, obj.object_name)
            except Exception: pass
        # 清 DB
        try:
            with get_conn() as conn:
                conn.execute("DELETE FROM file_keys WHERE file_path=%s", (key,))
        except Exception: pass

    def copy(self, src: str, dst: str) -> None:
        """复制需要重新加密（File Key 独立）"""
        data = self.get(src)
        self.put(dst, data)

    def move(self, src: str, dst: str) -> None:
        self.copy(src, dst)
        self.delete(src)
        with get_conn() as conn:
            conn.execute(
                "UPDATE file_keys SET file_path=%s, updated_at=NOW() WHERE file_path=%s",
                (dst, src)
            )

    # ── 元数据 ────────────────────────────────────────
    def exists(self, key: str) -> bool:
        for obj_name in [self._enc_key(key), key.lstrip("/")]:
            try:
                self._client.stat_object(self.bucket, obj_name)
                return True
            except Exception:
                pass
        # 目录前缀
        prefix = key.strip("/") + "/"
        items  = list(self._client.list_objects(self.bucket, prefix=prefix, max_keys=1))
        return len(items) > 0

    def size(self, key: str) -> int:
        """返回明文大小（从 DB 取）"""
        try:
            with get_conn() as conn:
                row = conn.execute(
                    "SELECT plaintext_size FROM file_keys WHERE file_path=%s", (key,)
                ).fetchone()
            if row: return row["plaintext_size"]
        except Exception: pass
        return 0

    def makedirs(self, key: str) -> None:
        pass   # MinIO 无目录概念

    def listdir(self, prefix: str) -> list[dict]:
        pfx = (prefix.strip("/") + "/") if prefix else ""
        result = []
        seen   = set()
        for obj in self._client.list_objects(self.bucket, prefix=pfx, recursive=False):
            rel = obj.object_name[len(pfx):]
            if not rel: continue
            if obj.is_dir:
                name = rel.rstrip("/")
                if name and name not in seen:
                    seen.add(name)
                    result.append({"key": f"{prefix}/{name}".lstrip("/"),
                                   "name": name, "is_dir": True, "size": 0, "mtime": 0.0})
            else:
                # 去掉 .enc 后缀
                name = rel.rstrip("/")
                if name.endswith(".enc"): name = name[:-4]
                if "/" not in name and name not in seen:
                    seen.add(name)
                    sub_key = f"{prefix}/{name}".lstrip("/")
                    size = 0
                    try:
                        with get_conn() as conn:
                            row = conn.execute(
                                "SELECT plaintext_size FROM file_keys WHERE file_path=%s",
                                (sub_key,)
                            ).fetchone()
                        if row: size = row["plaintext_size"]
                    except Exception: size = obj.size or 0
                    result.append({
                        "key":    sub_key,
                        "name":   name,
                        "is_dir": False,
                        "size":   size,
                        "mtime":  obj.last_modified.timestamp() if obj.last_modified else 0.0,
                    })
        return sorted(result, key=lambda x: (not x["is_dir"], x["name"].lower()))


def _get_protected(file_key: bytes) -> tuple:
    from core.crypto.key_service import get_key_manager
    km = get_key_manager()
    return file_key, km.protect_file_key(file_key)
