#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
core/storage/migrate.py — 存储后端数据迁移工具

用法：
  # 从本地加密存储迁移到 MinIO
  python3 -m core.storage.migrate --from local --to minio

  # 从 MinIO 迁回本地（灾难恢复）
  python3 -m core.storage.migrate --from minio --to local

  # 仅列出文件（不迁移）
  python3 -m core.storage.migrate --list

迁移策略：
  - 读取源端文件（内存中解密）→ 写入目标端（重新加密）
  - File Key 在目标端重新生成，旧 File Key 记录在迁移完成后删除
  - 迁移过程中两端均可用（零停机窗口）
  - 支持断点续传：迁移日志记录已完成文件，重新运行跳过已完成
"""
import argparse
import json
import logging
import os
import sys
import time
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("migrate")


def main():
    parser = argparse.ArgumentParser(description="SecFTP 存储后端迁移工具")
    parser.add_argument("--from",   dest="src", choices=["local","minio"], default="local")
    parser.add_argument("--to",     dest="dst", choices=["local","minio"], default="minio")
    parser.add_argument("--list",   action="store_true", help="仅列出文件")
    parser.add_argument("--dry-run",action="store_true", help="模拟运行（不写目标）")
    parser.add_argument("--workers",type=int, default=4, help="并发线程数")
    parser.add_argument("--resume", action="store_true", help="跳过已迁移文件（读取 migrate_progress.json）")
    args = parser.parse_args()

    sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

    # 初始化
    import config
    from core.db import init_pool
    from core.crypto.key_service import init_key_service
    init_pool()
    init_key_service()

    src_storage = _make_storage(args.src)
    dst_storage = _make_storage(args.dst) if not args.list else None

    # 收集所有文件
    log.info(f"扫描源端（{args.src}）文件...")
    all_files = _collect_files(src_storage, args.src)
    log.info(f"共发现 {len(all_files)} 个文件")

    if args.list:
        for f in all_files:
            print(f["key"])
        return

    # 加载进度
    progress_file = "migrate_progress.json"
    done_keys = set()
    if args.resume and os.path.isfile(progress_file):
        with open(progress_file) as f:
            done_keys = set(json.load(f).get("done", []))
        log.info(f"续传：跳过已完成 {len(done_keys)} 个文件")

    # 并发迁移
    from concurrent.futures import ThreadPoolExecutor, as_completed
    import threading
    lock = threading.Lock()
    success_count = [0]
    error_count   = [0]
    done_list     = list(done_keys)

    def migrate_one(item):
        key = item["key"]
        if key in done_keys:
            return True, key, "skipped"
        try:
            data = src_storage.get(key)
            if not args.dry_run:
                dst_storage.put(key, data)
            with lock:
                done_list.append(key)
                success_count[0] += 1
                if success_count[0] % 50 == 0:
                    with open(progress_file, "w") as pf:
                        json.dump({"done": done_list}, pf)
                    log.info(f"进度：{success_count[0]}/{len(all_files)}  错误：{error_count[0]}")
            return True, key, None
        except Exception as e:
            with lock:
                error_count[0] += 1
            return False, key, str(e)

    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        futures = {ex.submit(migrate_one, item): item for item in all_files}
        for fut in as_completed(futures):
            ok, key, err = fut.result()
            if not ok:
                log.error(f"迁移失败：{key}  {err}")

    elapsed = time.perf_counter() - t0
    with open(progress_file, "w") as pf:
        json.dump({"done": done_list, "completed": True}, pf)

    log.info(f"迁移完成：成功 {success_count[0]}  失败 {error_count[0]}  耗时 {elapsed:.1f}s")
    if args.dry_run:
        log.info("（dry-run 模式，未实际写入目标端）")


def _make_storage(backend: str):
    if backend == "local":
        import config
        from core.storage.encrypted_local import EncryptedLocalStorage
        return EncryptedLocalStorage(getattr(config, "FILE_ROOT", "/data/secftp/files"))
    elif backend == "minio":
        from core.storage.encrypted_minio import EncryptedMinIOStorage
        return EncryptedMinIOStorage()


def _collect_files(storage, backend: str) -> list:
    """递归收集所有文件 key"""
    if backend == "local":
        import config
        root  = getattr(config, "FILE_ROOT", "/data/secftp/files")
        files = []
        for dirpath, _, fnames in os.walk(root):
            for fn in fnames:
                if fn.endswith(".enc"):
                    full = os.path.join(dirpath, fn)
                    rel  = os.path.relpath(full, root).replace("\\", "/")
                    key  = rel[:-4]   # 去掉 .enc
                    files.append({"key": key, "path": full})
        return files
    elif backend == "minio":
        result = []
        for obj in storage._client.list_objects(storage.bucket, recursive=True):
            name = obj.object_name
            if name.endswith(".enc"):
                result.append({"key": name[:-4], "size": obj.size})
        return result


if __name__ == "__main__":
    main()
