# -*- coding: utf-8 -*-
"""
core/storage/registry.py — 存储后端工厂（支持本地加密 + MinIO 热切换）

STORAGE_BACKEND 控制：
  "local"  → EncryptedLocalStorage（默认，单机）
  "minio"  → EncryptedMinIOStorage（对象存储，可分布式）

MinIO 模式下文件仍经过 AES-256-GCM 加密后才写入，MinIO 节点泄露不暴露明文。
"""
import logging, os, threading
log = logging.getLogger("storage")
_storage = None
_lock    = threading.Lock()

def init_storage(root=None):
    global _storage
    with _lock:
        if _storage is not None:
            return
        import config as _c
        backend = (os.environ.get("STORAGE_BACKEND","") or
                   getattr(_c,"STORAGE_BACKEND","local")).lower()
        if backend == "minio":
            _storage = _make_minio()
            log.info("存储后端：MinIO（加密）")
        else:
            root = root or getattr(_c,"FILE_ROOT","/data/secftp/files")
            from core.storage.encrypted_local import EncryptedLocalStorage
            _storage = EncryptedLocalStorage(root)
            log.info(f"存储后端：本地加密  root={root}")

def _make_minio():
    try:
        from core.storage.encrypted_minio import EncryptedMinIOStorage
        return EncryptedMinIOStorage()
    except ImportError:
        log.error("minio 未安装，退回本地存储")
        import config as _c
        from core.storage.encrypted_local import EncryptedLocalStorage
        return EncryptedLocalStorage(getattr(_c,"FILE_ROOT","/data/secftp/files"))

def get_storage():
    if _storage is None: init_storage()
    return _storage

def reset_storage():
    global _storage
    with _lock: _storage = None
