# -*- coding: utf-8 -*-
"""
core/storage/encrypted_local.py — 加密本地存储

职责：
  - 写文件：明文 → AES-256-GCM 加密 → 写磁盘 → File Key 存 DB
  - 读文件：读磁盘密文 → 从 DB 取 File Key → 内存解密 → 返回明文流
  - 文件元数据：大小返回明文大小（透明）

设计原则：
  - 对调用方（路由层）完全透明，接口与非加密版本相同
  - 加密失败时立即抛出，不降级为明文存储
  - File Key 操作通过 key_service 进行，不直接持有私钥
"""
import io
import logging
import os
import shutil
from pathlib import Path
from typing import Generator

from core.crypto.engine import FileEncryptor
from core.crypto.key_service import (
    is_encryption_available, protect_new_file_key, recover_file_key
)
from core.db import get_conn

log = logging.getLogger("storage")


class EncryptedLocalStorage:
    """
    加密本地文件存储。
    
    文件在磁盘上以 .enc 后缀存储（原始扩展名通过 file_keys 表还原）。
    路径对外透明，外部只使用原始相对路径。
    """

    def __init__(self, root: str):
        self.root = os.path.realpath(root)
        os.makedirs(self.root, exist_ok=True)
        log.info(f"存储根目录: {self.root}, 加密: {'启用' if is_encryption_available() else '禁用'}")

    # ── 路径转换 ─────────────────────────────────────────
    def _abs(self, key: str) -> str:
        """rel key → 绝对路径（防路径穿越）"""
        key = key.strip("/\\").replace("\\", "/")
        if not key:
            return self.root
        full = os.path.realpath(os.path.join(self.root, key))
        if not (full == self.root or full.startswith(self.root + os.sep)):
            raise PermissionError(f"路径穿越拦截: {key}")
        return full

    def _enc_path(self, key: str) -> str:
        """加密文件路径（在原路径加 .enc 后缀）"""
        return self._abs(key) + ".enc"

    def _resolve_path(self, key: str) -> tuple[str, bool]:
        """
        返回 (实际路径, 是否加密) 。
        优先检查加密版本，其次是明文版本（兼容旧数据）。
        """
        enc = self._enc_path(key)
        if os.path.isfile(enc):
            return enc, True
        plain = self._abs(key)
        if os.path.isfile(plain):
            return plain, False
        return enc, True  # 默认认为应该加密

    # ── 写文件 ─────────────────────────────────────────
    def put(self, key: str, data: bytes | io.IOBase, *,
            content_type: str = "") -> None:
        """写文件（自动加密）"""
        abs_path = self._abs(key)
        os.makedirs(os.path.dirname(abs_path), exist_ok=True)

        if isinstance(data, (bytes, bytearray)):
            stream = io.BytesIO(data)
        else:
            stream = data

        if is_encryption_available():
            self._write_encrypted(key, stream)
        else:
            # 加密未配置时降级明文（开发模式）
            log.warning(f"⚠ 加密未启用，明文写入: {key}")
            with open(abs_path, "wb") as f:
                shutil.copyfileobj(stream, f)

    def _write_encrypted(self, key: str, stream: io.IOBase) -> None:
        """加密写入并保存 File Key 到数据库"""
        # 1. 加密文件内容
        ciphertext, file_key = FileEncryptor.encrypt_stream(stream)
        plaintext_size = len(ciphertext) - 8 - 12 - 16  # 减去 overhead

        # 2. 保护 File Key
        from core.crypto.key_service import protect_new_file_key as _protect
        _, protected = _protect.__module__  # 取 file_key
        file_key2, protected = _get_protected_key(file_key)

        # 3. 写密文到磁盘
        enc_path = self._enc_path(key)
        os.makedirs(os.path.dirname(enc_path), exist_ok=True)
        with open(enc_path, "wb") as f:
            f.write(ciphertext)

        # 4. 删除同名明文文件（如果存在）
        plain = self._abs(key)
        if os.path.isfile(plain):
            os.remove(plain)

        # 5. 保存 File Key 到数据库
        with get_conn() as conn:
            conn.execute("""
                INSERT INTO file_keys(file_path, vendor_enc, owner_enc, plaintext_size)
                VALUES(%s, %s, %s, %s)
                ON CONFLICT(file_path) DO UPDATE
                SET vendor_enc=%s, owner_enc=%s, plaintext_size=%s, updated_at=NOW()
            """, (key, protected["vendor_enc"], protected.get("owner_enc",""),
                  plaintext_size,
                  protected["vendor_enc"], protected.get("owner_enc",""), plaintext_size))

    # ── 读文件 ─────────────────────────────────────────
    def get(self, key: str) -> bytes:
        """读文件（自动解密，返回明文字节）"""
        real_path, is_enc = self._resolve_path(key)
        if not os.path.isfile(real_path):
            raise FileNotFoundError(key)

        if is_enc:
            file_key = self._get_file_key(key)
            return FileEncryptor.decrypt_to_bytes(real_path, file_key)
        else:
            with open(real_path, "rb") as f:
                return f.read()

    def get_stream(self, key: str) -> Generator[bytes, None, None]:
        """流式读取（用于 HTTP 响应）"""
        real_path, is_enc = self._resolve_path(key)
        if not os.path.isfile(real_path):
            raise FileNotFoundError(key)

        if is_enc:
            file_key = self._get_file_key(key)
            yield from FileEncryptor.decrypt_to_stream(real_path, file_key)
        else:
            with open(real_path, "rb") as f:
                while True:
                    chunk = f.read(65536)
                    if not chunk:
                        break
                    yield chunk

    def _get_file_key(self, key: str) -> bytes:
        """从数据库取 vendor_enc，用 vendor 私钥恢复 File Key"""
        with get_conn() as conn:
            row = conn.execute(
                "SELECT vendor_enc FROM file_keys WHERE file_path=%s", (key,)
            ).fetchone()
        if not row or not row.get("vendor_enc"):
            raise RuntimeError(f"文件密钥未找到: {key}，无法解密")
        return recover_file_key(row["vendor_enc"])

    # ── 元数据 ─────────────────────────────────────────
    def exists(self, key: str) -> bool:
        enc   = self._enc_path(key)
        plain = self._abs(key)
        return os.path.isfile(enc) or os.path.isfile(plain) or os.path.isdir(plain)

    def size(self, key: str) -> int:
        """返回明文大小"""
        _, is_enc = self._resolve_path(key)
        if is_enc:
            with get_conn() as conn:
                row = conn.execute(
                    "SELECT plaintext_size FROM file_keys WHERE file_path=%s", (key,)
                ).fetchone()
            return row["plaintext_size"] if row else 0
        return os.path.getsize(self._abs(key))

    def delete(self, key: str) -> None:
        """删除文件（磁盘 + DB 文件密钥）"""
        enc   = self._enc_path(key)
        plain = self._abs(key)

        if os.path.isfile(enc):
            os.remove(enc)
        if os.path.isfile(plain):
            os.remove(plain)
        if os.path.isdir(plain):
            shutil.rmtree(plain, ignore_errors=True)

        # 清理数据库文件密钥
        try:
            with get_conn() as conn:
                conn.execute("DELETE FROM file_keys WHERE file_path=%s", (key,))
        except Exception as e:
            log.warning(f"删除 file_keys 记录失败: {e}")

    def move(self, src: str, dst: str) -> None:
        """移动文件（同时更新 DB 中的 file_path）"""
        src_enc = self._enc_path(src)
        dst_enc = self._enc_path(dst)
        os.makedirs(os.path.dirname(dst_enc), exist_ok=True)

        if os.path.isfile(src_enc):
            shutil.move(src_enc, dst_enc)
        elif os.path.isfile(self._abs(src)):
            shutil.move(self._abs(src), self._abs(dst))

        # 更新 DB
        with get_conn() as conn:
            conn.execute(
                "UPDATE file_keys SET file_path=%s, updated_at=NOW() WHERE file_path=%s",
                (dst, src)
            )

    def copy(self, src: str, dst: str) -> None:
        """复制文件（重新生成 File Key，独立加密副本）"""
        # 先解密原文件，再重新加密写入目标
        plaintext = self.get(src)
        self.put(dst, plaintext)

    def makedirs(self, key: str) -> None:
        os.makedirs(self._abs(key), exist_ok=True)

    def listdir(self, prefix: str) -> list[dict]:
        """列出目录内容（过滤 .enc 后缀）"""
        path = self._abs(prefix) if prefix else self.root
        if not os.path.isdir(path):
            return []
        result = []
        seen   = set()
        for entry in sorted(os.scandir(path),
                             key=lambda e: (not e.is_dir(), e.name.lower())):
            name = entry.name
            # 去掉 .enc 后缀，对外透明
            if name.endswith(".enc"):
                name = name[:-4]
            if name in seen:
                continue
            seen.add(name)

            sub_key = f"{prefix}/{name}".lstrip("/") if prefix else name
            st      = entry.stat()
            size    = 0
            if not entry.is_dir():
                # 尝试从 DB 取明文大小
                try:
                    with get_conn() as conn:
                        row = conn.execute(
                            "SELECT plaintext_size FROM file_keys WHERE file_path=%s",
                            (sub_key,)
                        ).fetchone()
                    size = row["plaintext_size"] if row else st.st_size
                except Exception:
                    size = st.st_size

            result.append({
                "key":    sub_key,
                "name":   name,
                "is_dir": entry.is_dir(),
                "size":   size,
                "mtime":  st.st_mtime,
            })
        return result

    def get_local_enc_path(self, key: str) -> str | None:
        """返回磁盘上的加密文件路径（供 OnlyOffice 等需要路径的模块使用）"""
        enc = self._enc_path(key)
        return enc if os.path.isfile(enc) else None


def _get_protected_key(file_key: bytes) -> tuple[bytes, dict]:
    """辅助：从 key_service 获取保护后的 File Key"""
    from core.crypto.key_service import get_key_manager
    km       = get_key_manager()
    protected = km.protect_file_key(file_key)
    return file_key, protected
