# -*- coding: utf-8 -*-
"""
core/crypto/engine.py — 加密引擎

对外接口：
  FileEncryptor.encrypt_stream(plain_stream) -> (ciphertext_bytes, file_key_b64)
  FileEncryptor.decrypt_to_bytes(ciphertext_path, file_key_b64) -> bytes
  FileEncryptor.decrypt_to_stream(ciphertext_path, file_key_b64) -> generator
  KeyManager.protect_file_key(file_key_b64) -> {vendor_enc, owner_enc}
  KeyManager.recover_file_key(vendor_enc_b64) -> file_key_b64
"""
import base64
import io
import os
import struct
from pathlib import Path
from typing import Generator

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding

# 常量
NONCE_SIZE    = 12    # GCM 标准 nonce 长度（字节）
TAG_SIZE      = 16    # GCM 认证 tag（字节）
FILE_KEY_SIZE = 32    # AES-256 密钥长度（字节）
CHUNK_SIZE    = 64 * 1024  # 流式解密块大小（64KB）

# 文件头魔数，用于识别加密文件格式
MAGIC = b"SECFTP\x02\x00"  # 8字节，版本号 2.0


class FileEncryptor:
    """
    文件加密/解密引擎。
    
    加密格式（磁盘布局）：
      [MAGIC 8B][nonce 12B][ciphertext ...][tag 16B]
    
    所有操作均在内存/流中完成，不写临时文件。
    """

    @staticmethod
    def generate_file_key() -> bytes:
        """生成一个随机的 256-bit 文件密钥"""
        return os.urandom(FILE_KEY_SIZE)

    @staticmethod
    def encrypt_stream(
        plain_stream: io.IOBase,
        file_key: bytes | None = None,
    ) -> tuple[bytes, bytes]:
        """
        加密文件流。
        
        Args:
            plain_stream: 可读的二进制流
            file_key: 可选，不传则自动生成
            
        Returns:
            (ciphertext_with_header: bytes, file_key: bytes)
            ciphertext 包含 MAGIC + nonce + ciphertext + tag
        """
        if file_key is None:
            file_key = FileEncryptor.generate_file_key()
        if len(file_key) != FILE_KEY_SIZE:
            raise ValueError(f"file_key 必须是 {FILE_KEY_SIZE} 字节")

        nonce     = os.urandom(NONCE_SIZE)
        aesgcm    = AESGCM(file_key)
        plaintext = plain_stream.read()

        # 关联数据（AAD）：用 MAGIC 作为绑定，防止密文被移植到其他系统
        ciphertext_with_tag = aesgcm.encrypt(nonce, plaintext, MAGIC)

        # 布局：MAGIC | nonce | ciphertext+tag
        result = MAGIC + nonce + ciphertext_with_tag
        return result, file_key

    @staticmethod
    def encrypt_file(src_path: str, dst_path: str, file_key: bytes | None = None) -> bytes:
        """
        加密磁盘文件，写入目标路径。
        Returns: file_key（字节）
        """
        if file_key is None:
            file_key = FileEncryptor.generate_file_key()

        with open(src_path, "rb") as f:
            ciphertext, file_key = FileEncryptor.encrypt_stream(f, file_key)

        os.makedirs(os.path.dirname(dst_path), exist_ok=True)
        with open(dst_path, "wb") as f:
            f.write(ciphertext)

        return file_key

    @staticmethod
    def decrypt_to_bytes(enc_path: str, file_key: bytes) -> bytes:
        """
        解密加密文件，返回明文字节。
        在内存中完成，不写临时文件。
        """
        with open(enc_path, "rb") as f:
            data = f.read()

        return FileEncryptor._decrypt_bytes(data, file_key)

    @staticmethod
    def decrypt_bytes(ciphertext: bytes, file_key: bytes) -> bytes:
        """解密字节串"""
        return FileEncryptor._decrypt_bytes(ciphertext, file_key)

    @staticmethod
    def _decrypt_bytes(data: bytes, file_key: bytes) -> bytes:
        if len(data) < len(MAGIC) + NONCE_SIZE + TAG_SIZE:
            raise ValueError("加密数据太短，可能已损坏")
        if data[:len(MAGIC)] != MAGIC:
            raise ValueError("文件头魔数不匹配，非加密格式或版本不兼容")

        offset    = len(MAGIC)
        nonce     = data[offset: offset + NONCE_SIZE]
        cipher_with_tag = data[offset + NONCE_SIZE:]

        aesgcm    = AESGCM(file_key)
        try:
            plaintext = aesgcm.decrypt(nonce, cipher_with_tag, MAGIC)
        except Exception:
            raise ValueError("解密失败：密钥错误或数据已被篡改")

        return plaintext

    @staticmethod
    def decrypt_to_stream(enc_path: str, file_key: bytes) -> Generator[bytes, None, None]:
        """
        流式解密（用于大文件 HTTP 响应，避免一次性读入内存）。
        注意：AES-GCM 必须全部解密后才能验证 tag，所以这里先解密
        再分块 yield，不是真正的流式解密，但避免了两次磁盘读取。
        """
        plaintext = FileEncryptor.decrypt_to_bytes(enc_path, file_key)
        for i in range(0, len(plaintext), CHUNK_SIZE):
            yield plaintext[i: i + CHUNK_SIZE]

    @staticmethod
    def is_encrypted(path: str) -> bool:
        """判断文件是否是本系统加密格式"""
        try:
            with open(path, "rb") as f:
                magic = f.read(len(MAGIC))
            return magic == MAGIC
        except Exception:
            return False

    @staticmethod
    def get_plaintext_size(enc_path: str, file_key: bytes) -> int:
        """
        获取解密后的明文大小（不完整解密，只需减去 overhead）。
        MAGIC(8) + nonce(12) + tag(16) = 36 字节 overhead
        """
        enc_size = os.path.getsize(enc_path)
        overhead = len(MAGIC) + NONCE_SIZE + TAG_SIZE
        return max(0, enc_size - overhead)


class KeyManager:
    """
    文件密钥管理器。
    
    负责：
    1. 用双 RSA 公钥保护 File Key（生成两份密文）
    2. 用 vendor 私钥恢复 File Key（运行时解密用）
    3. 密钥对生成（部署时一次性执行）
    """

    def __init__(self, vendor_private_key_pem: bytes | None = None,
                 vendor_public_key_pem: bytes | None = None,
                 owner_public_key_pem: bytes | None = None):
        """
        Args:
            vendor_private_key_pem: 我方私钥（PEM格式），运行时解密用
            vendor_public_key_pem:  我方公钥（PEM格式），加密 File Key 用
            owner_public_key_pem:   甲方公钥（PEM格式），加密 File Key 用
        """
        self._vendor_priv = None
        self._vendor_pub  = None
        self._owner_pub   = None

        if vendor_private_key_pem:
            self._vendor_priv = serialization.load_pem_private_key(
                vendor_private_key_pem, password=None
            )
        if vendor_public_key_pem:
            self._vendor_pub = serialization.load_pem_public_key(vendor_public_key_pem)
        if owner_public_key_pem:
            self._owner_pub = serialization.load_pem_public_key(owner_public_key_pem)

    @staticmethod
    def generate_key_pair(key_size: int = 4096) -> tuple[bytes, bytes]:
        """
        生成 RSA 密钥对。
        Returns: (private_key_pem, public_key_pem)
        部署时调用一次，私钥由各方安全保存，公钥写入配置。
        """
        private_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=key_size,
        )
        priv_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        pub_pem = private_key.public_key().public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        return priv_pem, pub_pem

    @staticmethod
    def _rsa_encrypt(public_key, data: bytes) -> bytes:
        """RSA-OAEP-SHA256 加密"""
        return public_key.encrypt(
            data,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )

    @staticmethod
    def _rsa_decrypt(private_key, ciphertext: bytes) -> bytes:
        """RSA-OAEP-SHA256 解密"""
        return private_key.decrypt(
            ciphertext,
            asym_padding.OAEP(
                mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None,
            ),
        )

    def protect_file_key(self, file_key: bytes) -> dict[str, str]:
        """
        用双公钥保护 File Key，返回两份加密后的密文（base64 编码）。
        
        Returns:
            {
                "vendor_enc": "base64...",   # 我方公钥加密的版本
                "owner_enc":  "base64...",   # 甲方公钥加密的版本（若无甲方公钥则为空）
            }
        """
        result = {"vendor_enc": "", "owner_enc": ""}

        if self._vendor_pub:
            enc = KeyManager._rsa_encrypt(self._vendor_pub, file_key)
            result["vendor_enc"] = base64.b64encode(enc).decode()

        if self._owner_pub:
            enc = KeyManager._rsa_encrypt(self._owner_pub, file_key)
            result["owner_enc"] = base64.b64encode(enc).decode()

        if not result["vendor_enc"] and not result["owner_enc"]:
            raise RuntimeError("至少需要一个公钥才能保护 File Key")

        return result

    def recover_file_key_vendor(self, vendor_enc_b64: str) -> bytes:
        """
        用 vendor 私钥恢复 File Key（运行时服务端调用）。
        """
        if not self._vendor_priv:
            raise RuntimeError("vendor 私钥未加载，无法解密 File Key")
        ciphertext = base64.b64decode(vendor_enc_b64)
        return KeyManager._rsa_decrypt(self._vendor_priv, ciphertext)

    def recover_file_key_owner(self, owner_enc_b64: str) -> bytes:
        """
        用 owner 私钥恢复 File Key（解密工具调用）。
        """
        if not self._owner_priv:
            raise RuntimeError("owner 私钥未加载")
        ciphertext = base64.b64decode(owner_enc_b64)
        return KeyManager._rsa_decrypt(self._owner_priv, ciphertext)
