# -*- coding: utf-8 -*-
"""
core/crypto/key_service.py — 运行时密钥服务

单例模式，应用启动时初始化一次。
持有 vendor 私钥用于运行时文件解密，私钥只存内存不落磁盘。

安全说明：
  - vendor 私钥通过环境变量 SECFTP_VENDOR_PRIVATE_KEY 传入（PEM base64 编码）
  - 或通过文件路径 SECFTP_VENDOR_KEY_FILE 指向私钥文件（文件权限应为 600）
  - vendor 公钥和 owner 公钥写入配置文件，不敏感
  - 私钥从不写入数据库或日志
"""
import base64
import logging
import os
from functools import lru_cache

from core.crypto.engine import FileEncryptor, KeyManager

log = logging.getLogger("key_service")

_key_manager: KeyManager | None = None


def init_key_service(
    vendor_private_key_pem: bytes | None = None,
    vendor_public_key_pem: bytes | None = None,
    owner_public_key_pem: bytes | None = None,
) -> KeyManager:
    """
    初始化密钥服务。在 app factory 里调用一次。
    
    如果不传参数，从环境变量自动读取。
    """
    global _key_manager

    # 优先用传入的参数
    if vendor_private_key_pem is None:
        # 从环境变量读取（base64 编码的 PEM）
        env_key = os.environ.get("SECFTP_VENDOR_PRIVATE_KEY", "")
        if env_key:
            try:
                vendor_private_key_pem = base64.b64decode(env_key)
            except Exception:
                log.warning("SECFTP_VENDOR_PRIVATE_KEY 格式错误，尝试直接使用")
                vendor_private_key_pem = env_key.encode()

        # 或从文件路径读取
        key_file = os.environ.get("SECFTP_VENDOR_KEY_FILE", "")
        if key_file and os.path.isfile(key_file):
            with open(key_file, "rb") as f:
                vendor_private_key_pem = f.read()
            log.info(f"从文件加载 vendor 私钥: {key_file}")

    if vendor_public_key_pem is None:
        pub_str = os.environ.get("SECFTP_VENDOR_PUBLIC_KEY", "")
        if pub_str:
            vendor_public_key_pem = pub_str.encode() if not pub_str.startswith("-----") \
                else pub_str.encode()
        # 或从文件
        pub_file = os.environ.get("SECFTP_VENDOR_PUBKEY_FILE", "")
        if pub_file and os.path.isfile(pub_file):
            with open(pub_file, "rb") as f:
                vendor_public_key_pem = f.read()

    if owner_public_key_pem is None:
        owner_str = os.environ.get("SECFTP_OWNER_PUBLIC_KEY", "")
        if owner_str:
            owner_public_key_pem = owner_str.encode() if owner_str.startswith("-----") \
                else base64.b64decode(owner_str)
        owner_file = os.environ.get("SECFTP_OWNER_PUBKEY_FILE", "")
        if owner_file and os.path.isfile(owner_file):
            with open(owner_file, "rb") as f:
                owner_public_key_pem = f.read()

    _key_manager = KeyManager(
        vendor_private_key_pem=vendor_private_key_pem,
        vendor_public_key_pem=vendor_public_key_pem,
        owner_public_key_pem=owner_public_key_pem,
    )

    has_priv = vendor_private_key_pem is not None
    has_vpub = vendor_public_key_pem is not None
    has_opub = owner_public_key_pem is not None

    log.info(
        f"密钥服务初始化: vendor_priv={'✓' if has_priv else '✗'} "
        f"vendor_pub={'✓' if has_vpub else '✗'} "
        f"owner_pub={'✓' if has_opub else '✗'}"
    )

    if not has_vpub and not has_opub:
        log.warning(
            "⚠ 未配置任何公钥！文件加密将被禁用。\n"
            "  生产环境请设置 SECFTP_VENDOR_PUBLIC_KEY 和 SECFTP_OWNER_PUBLIC_KEY"
        )

    return _key_manager


def get_key_manager() -> KeyManager:
    """获取已初始化的 KeyManager，未初始化时抛出错误"""
    if _key_manager is None:
        raise RuntimeError("密钥服务未初始化，请先调用 init_key_service()")
    return _key_manager


def is_encryption_available() -> bool:
    """检查加密功能是否可用（至少有一个公钥）"""
    if _key_manager is None:
        return False
    return (
        _key_manager._vendor_pub is not None
        or _key_manager._owner_pub is not None
    )


def can_decrypt() -> bool:
    """检查运行时解密是否可用（需要 vendor 私钥）"""
    if _key_manager is None:
        return False
    return _key_manager._vendor_priv is not None


def protect_new_file_key() -> tuple[bytes, dict]:
    """
    生成新文件密钥并用双公钥保护。
    Returns: (file_key_bytes, {vendor_enc, owner_enc})
    """
    km = get_key_manager()
    file_key = FileEncryptor.generate_file_key()
    protected = km.protect_file_key(file_key)
    return file_key, protected


def recover_file_key(vendor_enc_b64: str) -> bytes:
    """用 vendor 私钥恢复文件密钥（运行时服务端调用）"""
    km = get_key_manager()
    return km.recover_file_key_vendor(vendor_enc_b64)
