"""
core/crypto — 文件加密核心模块

加密架构：
  每个文件 → 随机 AES-256-GCM File Key（32字节）
  File Key  → 双 RSA-4096 公钥分别加密存入 DB（vendor_key + owner_key）
  磁盘文件  → AES-256-GCM 密文（带 12字节 nonce + 16字节 tag）

解密路径（任一即可）：
  路径A：vendor 私钥 → 解出 File Key → 解密文件
  路径B：owner  私钥 → 解出 File Key → 解密文件

威胁防护：
  ✓ 管理员拷走磁盘文件无法打开（无 File Key）
  ✓ 数据库泄露不暴露文件内容（File Key 密文需私钥才能还原）
  ✓ 运行时内存解密（不落临时文件）
  ✗ 不防止：服务进程运行时内存 dump（已知限制，文档说明）
"""
from core.crypto.engine import FileEncryptor, KeyManager

__all__ = ["FileEncryptor", "KeyManager"]
