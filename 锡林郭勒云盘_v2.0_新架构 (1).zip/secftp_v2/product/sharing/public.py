# -*- coding: utf-8 -*-
"""product/sharing/public.py — 公开链接访问（无需登录）"""
import mimetypes, os
from pathlib import Path
from flask import Blueprint, jsonify, request, send_file, abort, make_response
from core.db import get_conn
from core.storage import get_storage
import config

bp = Blueprint("public_share", __name__)


@bp.route("/api/s/<token>", methods=["GET", "POST"])
def public_link(token):
    with get_conn() as conn:
        link = conn.execute(
            "SELECT * FROM public_links WHERE token=%s AND is_active=TRUE", (token,)
        ).fetchone()

    if not link:
        return jsonify({"error": "链接不存在或已失效"}), 404

    from datetime import datetime
    if link.get("expires_at"):
        exp = link["expires_at"]
        if isinstance(exp, str):
            exp = datetime.fromisoformat(exp)
        if exp.replace(tzinfo=None) < datetime.now():
            return jsonify({"error": "链接已过期"}), 410

    if link["max_views"] > 0 and link["view_count"] >= link["max_views"]:
        return jsonify({"error": "链接下载次数已达上限"}), 410

    # 密码验证
    if link["password"]:
        if request.method == "GET":
            return jsonify({"need_password": True, "token": token})
        data = request.get_json(silent=True) or {}
        if data.get("password") != link["password"]:
            return jsonify({"error": "提取码错误"}), 401

    # 返回文件信息或下载
    file_path = link["file_path"]
    storage   = get_storage()

    if not storage.exists(file_path):
        return jsonify({"error": "文件不存在"}), 404

    # 更新访问次数
    with get_conn() as conn:
        conn.execute(
            "UPDATE public_links SET view_count=view_count+1 WHERE token=%s", (token,)
        )

    # 下载
    if request.args.get("dl") == "1" or request.method == "POST":
        name = Path(file_path).name
        mime, _ = mimetypes.guess_type(file_path)
        mime = mime or "application/octet-stream"
        data = storage.get(file_path)
        resp = make_response(data)
        resp.headers["Content-Type"] = mime
        resp.headers["Content-Disposition"] = f'attachment; filename="{name}"'
        return resp

    # 返回文件元信息（供前端展示）
    from product.files.api import _classify, _fmt_size, FTYPE_META
    ext  = Path(file_path).suffix
    ft   = _classify(ext)
    meta = FTYPE_META.get(ft, FTYPE_META["other"])
    return jsonify({
        "token":      token,
        "filename":   Path(file_path).name,
        "ftype":      ft,
        "icon":       meta["icon"],
        "size_str":   _fmt_size(storage.size(file_path)),
        "need_password": False,
        "download_url": f"/api/s/{token}?dl=1",
        "expires_at": str(link.get("expires_at",""))[:16],
        "max_views":  link["max_views"],
        "view_count": link["view_count"] + 1,
    })


@bp.route("/s/<token>")
def public_page(token):
    """公开链接页面（SPA 处理）"""
    index = os.path.join(os.path.dirname(__file__), "..", "..", "static", "index.html")
    if os.path.isfile(index):
        return send_file(index)
    return f"<html><body><h2>链接: {token}</h2><a href='/api/s/{token}?dl=1'>下载文件</a></body></html>"
