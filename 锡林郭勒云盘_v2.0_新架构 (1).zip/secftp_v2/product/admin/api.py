# -*- coding: utf-8 -*-
"""product/admin/api.py — 管理员 REST API"""
import os, secrets
from flask import Blueprint, jsonify, request, g
from core.auth.jwt_auth import jwt_required, admin_required, super_required
from core.auth.passwd import hash_password
from core.db import get_conn
import config

bp = Blueprint("admin_api", __name__, url_prefix="/api/admin")


# ══ 用户管理 ══════════════════════════════════════════════
@bp.route("/users")
@admin_required
def list_users():
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT u.id, u.username, u.display_name, u.email, u.phone,
                   u.role, u.org_id, u.is_active, u.quota_mb, u.avatar_color,
                   u.avatar_path, u.created_at, u.last_login, u.fail_count,
                   o.name as org_name
            FROM users u LEFT JOIN organizations o ON o.id=u.org_id
            ORDER BY u.role, u.username
        """).fetchall()
    return jsonify({"users": [dict(r) for r in rows]})


@bp.route("/users", methods=["POST"])
@admin_required
def create_user():
    data    = request.get_json(silent=True) or {}
    uname   = (data.get("username") or "").strip()
    pw      = data.get("password", "")
    role    = int(data.get("role", 2))
    org_id  = data.get("org_id")
    dn      = (data.get("display_name") or uname).strip()
    email   = (data.get("email") or "").strip()
    quota   = int(data.get("quota_mb", 1048576))

    if not uname or not pw:
        return jsonify({"error": "用户名和密码不能为空"}), 400
    if role < g.role:
        return jsonify({"error": "不能创建比自身权限更高的账号"}), 403
    if len(pw) < 8:
        return jsonify({"error": "密码至少8位"}), 400

    pw_hash = hash_password(pw)
    try:
        with get_conn() as conn:
            row = conn.execute(
                "INSERT INTO users(username,password_hash,password_salt,role,org_id,"
                "display_name,email,quota_mb,created_by) "
                "VALUES(%s,%s,'',%s,%s,%s,%s,%s,%s) RETURNING id",
                (uname, pw_hash, role, org_id, dn, email, quota, g.uid)
            ).fetchone()
        # 创建个人目录
        udir = os.path.join(config.FILE_ROOT, "users", uname)
        os.makedirs(udir, exist_ok=True)
        return jsonify({"success": True, "id": row[0]})
    except Exception as e:
        if "unique" in str(e).lower():
            return jsonify({"error": "用户名已存在"}), 400
        return jsonify({"error": str(e)}), 500


@bp.route("/users", methods=["PUT"])
@admin_required
def update_user():
    data   = request.get_json(silent=True) or {}
    uid    = data.get("id")
    if not uid:
        return jsonify({"error": "缺少用户ID"}), 400

    fields, params = [], []
    for k, col in [("display_name","display_name"),("email","email"),
                   ("phone","phone"),("org_id","org_id"),("quota_mb","quota_mb")]:
        if k in data:
            fields.append(f"{col}=%s"); params.append(data[k])
    if "role" in data:
        if int(data["role"]) < g.role:
            return jsonify({"error": "权限不足"}), 403
        fields.append("role=%s"); params.append(data["role"])

    if not fields:
        return jsonify({"error": "没有要更新的字段"}), 400

    params.append(uid)
    # 白名单字段已在上方验证，此处 f-string 拼接字段名均来自硬编码白名单
    # 不含用户输入，SQL 注入风险极低
    sql = "UPDATE users SET " + ", ".join(fields) + " WHERE id=%s"  # noqa: S608
    with get_conn() as conn:
        conn.execute(sql, params)
    return jsonify({"success": True})


@bp.route("/users/<int:uid>", methods=["DELETE"])
@super_required
def delete_user(uid):
    if uid == g.uid:
        return jsonify({"error": "不能删除自己"}), 400
    with get_conn() as conn:
        conn.execute("UPDATE users SET is_active=FALSE WHERE id=%s", (uid,))
    return jsonify({"success": True})


@bp.route("/users/toggle", methods=["POST"])
@admin_required
def toggle_user():
    data   = request.get_json(silent=True) or {}
    uid    = data.get("id")
    active = data.get("is_active", True)
    if uid == g.uid:
        return jsonify({"error": "不能禁用自己"}), 400
    with get_conn() as conn:
        conn.execute("UPDATE users SET is_active=%s WHERE id=%s", (active, uid))
    return jsonify({"success": True})


@bp.route("/users/reset-password", methods=["POST"])
@admin_required
def reset_password():
    data    = request.get_json(silent=True) or {}
    uid     = data.get("id")
    new_pw  = data.get("password", secrets.token_urlsafe(10))
    if not uid:
        return jsonify({"error": "缺少用户ID"}), 400
    pw_hash = hash_password(new_pw)
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET password_hash=%s, password_salt='', "
            "force_pw_change=TRUE WHERE id=%s",
            (pw_hash, uid)
        )
    from core.auth.jwt_auth import revoke_all_user_tokens
    revoke_all_user_tokens(uid)
    return jsonify({"success": True, "new_password": new_pw})


# ══ 组织管理 ══════════════════════════════════════════════
@bp.route("/orgs")
@admin_required
def list_orgs():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, name, code, parent_id, org_level, dir_path, description "
            "FROM organizations ORDER BY org_level, name"
        ).fetchall()
    return jsonify({"orgs": [dict(r) for r in rows]})


@bp.route("/orgs", methods=["POST"])
@super_required
def create_org():
    data = request.get_json(silent=True) or {}
    name = (data.get("name") or "").strip()
    code = (data.get("code") or "").strip()
    if not name or not code:
        return jsonify({"error": "名称和编码不能为空"}), 400
    dir_path = data.get("dir_path") or code
    try:
        with get_conn() as conn:
            row = conn.execute(
                "INSERT INTO organizations(name,code,parent_id,org_level,dir_path,description) "
                "VALUES(%s,%s,%s,%s,%s,%s) RETURNING id",
                (name, code, data.get("parent_id"),
                 int(data.get("org_level",1)), dir_path,
                 data.get("description",""))
            ).fetchone()
        os.makedirs(os.path.join(config.FILE_ROOT, dir_path), exist_ok=True)
        return jsonify({"success": True, "id": row[0]})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@bp.route("/orgs", methods=["PUT"])
@super_required
def update_org():
    data = request.get_json(silent=True) or {}
    oid  = data.get("id")
    if not oid: return jsonify({"error": "缺少ID"}), 400
    fields, params = [], []
    for k in ("name","description","org_level"):
        if k in data: fields.append(f"{k}=%s"); params.append(data[k])
    if not fields: return jsonify({"error": "无更新字段"}), 400
    params.append(oid)
    sql = "UPDATE organizations SET " + ", ".join(fields) + " WHERE id=%s"  # noqa: S608
    with get_conn() as conn:
        conn.execute(sql, params)
    return jsonify({"success": True})


@bp.route("/orgs/<int:oid>", methods=["DELETE"])
@super_required
def delete_org(oid):
    with get_conn() as conn:
        users = conn.execute("SELECT COUNT(*) as c FROM users WHERE org_id=%s", (oid,)).fetchone()
        if users["c"] > 0:
            return jsonify({"error": f"组织下还有 {users['c']} 个用户，不能删除"}), 400
        conn.execute("DELETE FROM organizations WHERE id=%s", (oid,))
    return jsonify({"success": True})


# ══ 存储统计 ══════════════════════════════════════════════
@bp.route("/storage/stats")
@admin_required
def storage_stats():
    with get_conn() as conn:
        total_files = conn.execute("SELECT COUNT(*) as c FROM file_index").fetchone()["c"]
        total_bytes = conn.execute("SELECT COALESCE(SUM(file_size),0) as s FROM file_index").fetchone()["s"]
        by_type     = conn.execute("""
            SELECT ftype, COUNT(*) as cnt, COALESCE(SUM(file_size),0) as bytes
            FROM file_index GROUP BY ftype ORDER BY bytes DESC
        """).fetchall()
        user_quota  = conn.execute("""
            SELECT u.username, u.quota_mb,
                   COALESCE(fi.used_bytes,0) as used_bytes
            FROM users u
            LEFT JOIN (
                SELECT SUBSTRING(file_path FROM 'users/([^/]+)') as uname,
                       SUM(file_size) as used_bytes
                FROM file_index WHERE file_path LIKE 'users/%'
                GROUP BY uname
            ) fi ON fi.uname = u.username
            WHERE u.is_active=TRUE ORDER BY used_bytes DESC LIMIT 20
        """).fetchall()
    return jsonify({
        "total_files": total_files,
        "total_bytes": total_bytes,
        "by_type": [dict(r) for r in by_type],
        "user_quota": [dict(r) for r in user_quota],
    })


# ══ 账号申请管理 ══════════════════════════════════════════
@bp.route("/register-requests")
@admin_required
def list_register_requests():
    status = request.args.get("status", "pending")
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM register_requests WHERE status=%s ORDER BY created_at DESC",
            (status,)
        ).fetchall()
    return jsonify({"requests": [dict(r) for r in rows]})


@bp.route("/register-requests/approve", methods=["POST"])
@admin_required
def approve_request():
    data  = request.get_json(silent=True) or {}
    rid   = data.get("id")
    note  = data.get("note", "")
    if not rid: return jsonify({"error": "缺少ID"}), 400
    with get_conn() as conn:
        req = conn.execute("SELECT * FROM register_requests WHERE id=%s", (rid,)).fetchone()
        if not req: return jsonify({"error": "申请不存在"}), 404
        # 创建用户
        pw = secrets.token_urlsafe(10)
        conn.execute(
            "INSERT INTO users(username,password_hash,password_salt,role,display_name,email,phone) "
            "VALUES(%s,%s,'',2,%s,%s,%s) ON CONFLICT DO NOTHING",
            (req["username"], hash_password(pw), req["realname"], req["email"], req["phone"])
        )
        conn.execute(
            "UPDATE register_requests SET status='approved',reviewer_id=%s,"
            "review_note=%s,reviewed_at=NOW() WHERE id=%s",
            (g.uid, note, rid)
        )
    return jsonify({"success": True, "temp_password": pw})


@bp.route("/register-requests/reject", methods=["POST"])
@admin_required
def reject_request():
    data = request.get_json(silent=True) or {}
    rid  = data.get("id")
    note = data.get("note", "")
    with get_conn() as conn:
        conn.execute(
            "UPDATE register_requests SET status='rejected',reviewer_id=%s,"
            "review_note=%s,reviewed_at=NOW() WHERE id=%s",
            (g.uid, note, rid)
        )
    return jsonify({"success": True})


# ══ 审计日志 ══════════════════════════════════════════════
@bp.route("/audit/logs")
@admin_required
def audit_logs():
    page    = int(request.args.get("page", 1))
    per_page= min(int(request.args.get("per_page", 50)), 200)
    action  = request.args.get("action", "")
    uname   = request.args.get("username", "")
    offset  = (page - 1) * per_page

    where, params = [], []
    if action: where.append("action=%s"); params.append(action)
    if uname:  where.append("username ILIKE %s"); params.append(f"%{uname}%")
    clause = ("WHERE " + " AND ".join(where)) if where else ""

    # WHERE clause 由内部白名单条件构建，非用户直接输入字段名
    count_sql = "SELECT COUNT(*) as c FROM audit_log" + (" " + clause if clause else "")
    rows_sql  = ("SELECT id,ts,username,action,detail,ip,level FROM audit_log"
                 + (" " + clause if clause else "")
                 + " ORDER BY id DESC LIMIT %s OFFSET %s")
    with get_conn() as conn:
        total = conn.execute(count_sql, params).fetchone()["c"]
        rows  = conn.execute(rows_sql, params + [per_page, offset]).fetchall()
    return jsonify({
        "logs":  [dict(r) for r in rows],
        "total": total,
        "page":  page,
        "pages": (total + per_page - 1) // per_page,
    })


# ══ 品牌配置 ══════════════════════════════════════════════
@bp.route("/branding")
@jwt_required
def get_branding():
    with get_conn() as conn:
        row = conn.execute("SELECT value FROM system_config WHERE key='branding'").fetchone()
    return jsonify({"branding": row["value"] if row else {}})


@bp.route("/branding", methods=["POST"])
@super_required
def save_branding():
    import re
    data = request.get_json(silent=True) or {}
    cfg  = {k: data.get(k, v) for k, v in {
        "system_name": config.SYSTEM_NAME, "system_name_en": "Xilingol Cloud Drive",
        "system_org": config.SYSTEM_ORG, "system_short": config.SYSTEM_SHORT,
        "primary_color": "#1560bd", "login_desc": "", "allow_register": False,
    }.items()}
    if not re.match(r'^#[0-9a-fA-F]{6}$', cfg.get("primary_color","")):
        cfg["primary_color"] = "#1560bd"
    import json
    val = json.dumps(cfg, ensure_ascii=False)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO system_config(key,value) VALUES('branding',%s::jsonb) "
            "ON CONFLICT(key) DO UPDATE SET value=%s::jsonb, updated_at=NOW()",
            (val, val)
        )
    return jsonify({"success": True})
