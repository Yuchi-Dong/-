# -*- coding: utf-8 -*-
"""product/dashboard/api.py — 仪表盘 JSON API"""
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request, g
from core.auth.jwt_auth import jwt_required, admin_required
from core.db import get_conn
import config, os

bp = Blueprint("dashboard_api", __name__, url_prefix="/api/dashboard")


@bp.route("/stats")
@jwt_required
def stats():
    uid, role, org_id = g.uid, g.role, g.org_id
    with get_conn() as conn:
        if role == 0:
            fc  = conn.execute("SELECT COUNT(*) as c, COALESCE(SUM(file_size),0) as s FROM file_index").fetchone()
            uc  = conn.execute("SELECT COUNT(*) as c FROM users WHERE is_active=TRUE").fetchone()["c"]
        else:
            fc  = conn.execute(
                "SELECT COUNT(*) as c, COALESCE(SUM(file_size),0) as s FROM file_index "
                "WHERE file_path LIKE %s", (f"users/{g.username}/%",)
            ).fetchone()
            uc  = 1

        sc  = conn.execute(
            "SELECT COUNT(*) as c FROM file_shares WHERE is_active=TRUE" +
            ("" if role == 0 else " AND owner_id=%s"), () if role == 0 else (uid,)
        ).fetchone()["c"]

        today = datetime.now().strftime("%Y-%m-%d")
        ops   = conn.execute("SELECT COUNT(*) as c FROM audit_log WHERE ts::date=%s::date", (today,)).fetchone()["c"]
        active= conn.execute(
            "SELECT COUNT(DISTINCT user_id) as c FROM active_sessions "
            "WHERE is_active=TRUE AND last_active > NOW() - INTERVAL '30 minutes'"
        ).fetchone()["c"]
        pending = 0
        if role <= 1:
            pending = conn.execute("SELECT COUNT(*) as c FROM register_requests WHERE status='pending'").fetchone()["c"]

    gb = round((fc["s"] or 0) / 1024**3, 2)
    return jsonify({
        "file_count":  fc["c"] or 0,
        "total_gb":    gb,
        "total_mb":    round((fc["s"] or 0) / 1024**2, 1),
        "user_count":  uc,
        "share_count": sc,
        "today_ops":   ops,
        "active_now":  active,
        "pending_reg": pending,
    })


@bp.route("/trend")
@jwt_required
def trend():
    days = min(int(request.args.get("days", 30)), 90)
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT ts::date as day,
                   COUNT(*) as ops,
                   COUNT(*) FILTER(WHERE action='UPLOAD') as uploads
            FROM audit_log WHERE ts::date >= %s::date
            GROUP BY ts::date ORDER BY ts::date
        """, (since,)).fetchall()
    return jsonify([{"day": str(r["day"]), "ops": r["ops"], "uploads": r["uploads"]} for r in rows])


@bp.route("/filetype")
@jwt_required
def filetype():
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT ftype, COUNT(*) as cnt, COALESCE(SUM(file_size),0) as bytes
            FROM file_index WHERE ftype IS NOT NULL
            GROUP BY ftype ORDER BY bytes DESC
        """).fetchall()
    colors = {"image":"#3b82f6","pdf":"#ef4444","video":"#8b5cf6","audio":"#ec4899",
              "word":"#2563eb","excel":"#16a34a","ppt":"#f59e0b","zip":"#64748b",
              "text":"#06b6d4","code":"#0d9488","other":"#9ca3af"}
    labels = {"image":"图片","pdf":"PDF","video":"视频","audio":"音频","word":"Word",
              "excel":"Excel","ppt":"PPT","zip":"压缩包","text":"文本","code":"代码","other":"其他"}
    return jsonify([{
        "ftype": r["ftype"], "label": labels.get(r["ftype"], r["ftype"]),
        "count": r["cnt"], "bytes": r["bytes"], "color": colors.get(r["ftype"],"#9ca3af"),
    } for r in rows if r["cnt"] > 0])


@bp.route("/activity")
@jwt_required
def activity():
    since = (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT EXTRACT(DOW FROM ts)::int as dow,
                   EXTRACT(HOUR FROM ts)::int as hour,
                   COUNT(*) as cnt
            FROM audit_log WHERE ts::date >= %s::date
            GROUP BY dow, hour
        """, (since,)).fetchall()
    matrix = [[0]*24 for _ in range(7)]
    for r in rows:
        d, h = int(r["dow"]), int(r["hour"])
        if 0 <= d < 7 and 0 <= h < 24:
            matrix[d][h] = int(r["cnt"])
    return jsonify(matrix)


@bp.route("/topusers")
@admin_required
def topusers():
    since = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT username, COUNT(*) as ops FROM audit_log
            WHERE ts::date >= %s::date AND action IN('UPLOAD','DOWNLOAD','EDIT_SAVE')
            GROUP BY username ORDER BY ops DESC LIMIT 10
        """, (since,)).fetchall()
    return jsonify([{"rank": i+1, "username": r["username"], "ops": r["ops"]} for i,r in enumerate(rows)])


@bp.route("/recent")
@jwt_required
def recent():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT username, action, detail, ts, level FROM audit_log ORDER BY id DESC LIMIT 10"
        ).fetchall()
    ico = {"UPLOAD":"📤","DOWNLOAD":"📥","LOGIN_SUCCESS":"🔐","DELETE_TO_TRASH":"🗑️",
           "MKDIR":"📁","SHARE_CREATE":"🔗","EDIT_SAVE":"✏️","CHANGE_PASSWORD":"🔑"}
    return jsonify([{
        "icon": ico.get(r["action"],"•"), "username": r["username"] or "系统",
        "action": r["action"], "detail": (r["detail"] or "")[:40],
        "ts": str(r["ts"])[:16], "level": r["level"] or "INFO",
    } for r in rows])
