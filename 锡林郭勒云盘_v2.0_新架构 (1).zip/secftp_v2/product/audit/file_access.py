# -*- coding: utf-8 -*-
"""
product/audit/file_access.py — 文件访问审计报告 API

解决"企业客户会问：谁看了这个文件？"

提供接口：
  GET /api/audit/file-access?path=xx  文件访问记录
  GET /api/audit/user-files?uid=xx    用户访问记录
  GET /api/audit/stats                全局审计统计
"""
from datetime import datetime, timedelta
from flask import Blueprint, request, jsonify, g
from core.auth.jwt_auth import jwt_required, admin_required
from core.db import get_conn

bp = Blueprint("file_access_audit", __name__, url_prefix="/api/audit")


@bp.route("/file-access")
@jwt_required
def file_access():
    """
    查询文件的访问记录：谁在何时访问了这个文件？
    普通用户只能查自己有权限的文件；管理员可查所有文件。
    """
    path     = request.args.get("path", "").strip("/")
    page     = max(1, int(request.args.get("page", 1)))
    per_page = min(100, int(request.args.get("per_page", 50)))
    days     = min(365, int(request.args.get("days", 90)))
    action   = request.args.get("action", "")   # 空 = 所有操作

    if not path:
        return jsonify({"error": "path 不能为空"}), 400

    # 权限检查：非管理员只能查自己文件的访问记录
    if g.role > 1:
        if not (path.startswith(f"users/{g.username}/") or
                path == f"users/{g.username}"):
            return jsonify({"error": "无权限查询该文件的访问记录"}), 403

    since  = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    offset = (page - 1) * per_page

    # action 白名单过滤
    action_filter = ""
    params = [path, f"%{path}%", since]
    if action and action in ("DOWNLOAD","PREVIEW","UPLOAD","DELETE_TO_TRASH","SHARE_CREATE"):
        action_filter = " AND action=%s"
        params.insert(-1, action)

    with get_conn() as conn:
        total_row = conn.execute(
            "SELECT COUNT(*) as c FROM audit_log "
            "WHERE (resource=%s OR detail LIKE %s) AND ts::date >= %s::date" + action_filter,
            params
        ).fetchone()
        total = total_row["c"] if total_row else 0

        rows = conn.execute(
            "SELECT al.id, al.ts, al.username, al.action, al.detail, al.ip, al.result, "
            "       u.display_name, u.org_id, o.name as org_name "
            "FROM audit_log al "
            "LEFT JOIN users u ON u.username=al.username "
            "LEFT JOIN organizations o ON o.id=u.org_id "
            "WHERE (al.resource=%s OR al.detail LIKE %s) AND al.ts::date >= %s::date"
            + action_filter +
            " ORDER BY al.ts DESC LIMIT %s OFFSET %s",
            params + [per_page, offset]
        ).fetchall()

    # 聚合统计
    stats = {}
    for r in rows:
        uname = r["username"] or "anonymous"
        if uname not in stats:
            stats[uname] = {"count": 0, "last_at": str(r["ts"])[:16],
                            "display_name": r.get("display_name",""), "org_name": r.get("org_name","")}
        stats[uname]["count"] += 1

    return jsonify({
        "path":    path,
        "total":   total,
        "page":    page,
        "pages":   (total + per_page - 1) // per_page,
        "days":    days,
        "records": [dict(r) for r in rows],
        "summary": list(stats.values()),   # 聚合：每个用户访问次数
    })


@bp.route("/user-files")
@admin_required
def user_files():
    """管理员查询某用户的文件操作记录"""
    uid      = request.args.get("uid") or request.args.get("username")
    days     = min(365, int(request.args.get("days", 30)))
    page     = max(1, int(request.args.get("page", 1)))
    per_page = min(100, int(request.args.get("per_page", 50)))
    since    = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    offset   = (page - 1) * per_page

    if not uid:
        return jsonify({"error": "uid 或 username 不能为空"}), 400

    # 支持按 user_id 或 username 查询
    where = "user_id=%s" if uid.isdigit() else "username=%s"
    with get_conn() as conn:
        total = conn.execute(
            f"SELECT COUNT(*) as c FROM audit_log WHERE {where} AND ts::date >= %s::date",
            (uid, since)
        ).fetchone()["c"]
        rows  = conn.execute(
            f"SELECT id, ts, action, resource, detail, ip, result "
            f"FROM audit_log WHERE {where} AND ts::date >= %s::date "
            f"ORDER BY ts DESC LIMIT %s OFFSET %s",
            (uid, since, per_page, offset)
        ).fetchall()

    return jsonify({
        "uid":     uid,
        "total":   total,
        "page":    page,
        "pages":   (total + per_page - 1) // per_page,
        "records": [dict(r) for r in rows],
    })


@bp.route("/stats")
@admin_required
def audit_stats():
    """全局审计统计"""
    days  = min(365, int(request.args.get("days", 30)))
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

    with get_conn() as conn:
        # 操作类型分布
        actions = conn.execute(
            "SELECT action, COUNT(*) as cnt FROM audit_log "
            "WHERE ts::date >= %s::date GROUP BY action ORDER BY cnt DESC LIMIT 20",
            (since,)
        ).fetchall()

        # 用户活跃度 Top10
        top_users = conn.execute(
            "SELECT username, COUNT(*) as cnt FROM audit_log "
            "WHERE ts::date >= %s::date AND username IS NOT NULL "
            "GROUP BY username ORDER BY cnt DESC LIMIT 10",
            (since,)
        ).fetchall()

        # 风险事件（WARN/ERROR 级别）
        risk_events = conn.execute(
            "SELECT ts, username, action, detail, ip, level "
            "FROM audit_log "
            "WHERE level IN ('WARN','ERROR') AND ts::date >= %s::date "
            "ORDER BY ts DESC LIMIT 20",
            (since,)
        ).fetchall()

        # 文件下载热点 Top10（最多人下载的文件）
        hot_files = conn.execute(
            "SELECT resource, COUNT(*) as cnt, COUNT(DISTINCT username) as uv "
            "FROM audit_log "
            "WHERE action='DOWNLOAD' AND ts::date >= %s::date AND resource != '' "
            "GROUP BY resource ORDER BY cnt DESC LIMIT 10",
            (since,)
        ).fetchall()

        # 每天操作数趋势
        trend = conn.execute(
            "SELECT ts::date as day, COUNT(*) as cnt FROM audit_log "
            "WHERE ts::date >= %s::date GROUP BY ts::date ORDER BY ts::date",
            (since,)
        ).fetchall()

    return jsonify({
        "days":        days,
        "actions":     [dict(r) for r in actions],
        "top_users":   [dict(r) for r in top_users],
        "risk_events": [dict(r) for r in risk_events],
        "hot_files":   [dict(r) for r in hot_files],
        "trend":       [{"day": str(r["day"]), "cnt": r["cnt"]} for r in trend],
    })


@bp.route("/export")
@admin_required
def export_audit():
    """导出审计日志为 CSV（监管合规用）"""
    days  = min(365, int(request.args.get("days", 30)))
    since = (datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d")

    with get_conn() as conn:
        rows = conn.execute(
            "SELECT ts, username, action, resource, detail, ip, level "
            "FROM audit_log WHERE ts::date >= %s::date ORDER BY ts",
            (since,)
        ).fetchall()

    import io, csv
    buf = io.StringIO()
    w   = csv.writer(buf)
    w.writerow(["时间","用户","操作","资源","详情","IP","级别"])
    for r in rows:
        w.writerow([str(r["ts"])[:19], r["username"]or"", r["action"]or"",
                    r["resource"]or"", r["detail"]or"", r["ip"]or"", r["level"]or""])

    from flask import Response
    return Response(
        "\ufeff" + buf.getvalue(),   # BOM，确保 Excel 正确显示中文
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename=audit_{days}days.csv"}
    )
