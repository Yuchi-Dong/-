# -*- coding: utf-8 -*-
"""
compliance/alert.py — 异常登录告警

支持：
  1. 邮件告警（SMTP，兼容企业邮箱）
  2. 企业微信 Webhook（Markdown 消息）
  3. 钉钉 Webhook
  4. 自定义 HTTP Webhook

告警触发条件：
  - 异地 IP 首次登录
  - 登录失败次数超过阈值
  - 账号被锁定
  - 非工作时间登录（可选）

配置方式：在 config.py 或环境变量中设置
"""
import json
import logging
import smtplib
import threading
import urllib.request
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

import config

log = logging.getLogger('alert')


def _cfg(key, default=None):
    return getattr(config, key, None) or default


# ── 发送入口（异步，不阻断登录流程）─────────────────────
def send_alert(event_type: str, user: dict, ip: str, detail: str = ''):
    """
    发送安全告警（后台线程执行，不影响响应速度）

    event_type: LOGIN_ANOMALY / ACCOUNT_LOCKED / LOGIN_FAIL_FLOOD
    """
    t = threading.Thread(
        target=_dispatch,
        args=(event_type, user, ip, detail),
        daemon=True
    )
    t.start()


def _dispatch(event_type, user, ip, detail):
    payload = _build_payload(event_type, user, ip, detail)
    errors  = []

    # 企业微信 Webhook
    wx_url = _cfg('ALERT_WECOM_WEBHOOK')
    if wx_url:
        try: _send_wecom(wx_url, payload)
        except Exception as e: errors.append(f'企业微信: {e}')

    # 钉钉 Webhook
    dd_url = _cfg('ALERT_DINGTALK_WEBHOOK')
    if dd_url:
        try: _send_dingtalk(dd_url, payload)
        except Exception as e: errors.append(f'钉钉: {e}')

    # 邮件
    smtp_host = _cfg('ALERT_SMTP_HOST')
    if smtp_host:
        try: _send_email(payload)
        except Exception as e: errors.append(f'邮件: {e}')

    # 自定义 Webhook
    custom_url = _cfg('ALERT_WEBHOOK_URL')
    if custom_url:
        try: _send_webhook(custom_url, payload)
        except Exception as e: errors.append(f'自定义Webhook: {e}')

    if errors:
        log.warning(f'告警发送部分失败: {errors}')
    else:
        if any([wx_url, dd_url, smtp_host, custom_url]):
            log.info(f'安全告警已发送: {event_type} user={user.get("username")} ip={ip}')


def _build_payload(event_type, user, ip, detail):
    ts       = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    username = user.get('username', '未知用户')
    display  = user.get('display_name', '') or username
    system   = _cfg('SYSTEM_NAME', '锡林郭勒云盘')

    titles = {
        'LOGIN_ANOMALY':    '⚠ 异常登录告警',
        'ACCOUNT_LOCKED':   '🔒 账号锁定告警',
        'LOGIN_FAIL_FLOOD': '🚨 高频登录失败告警',
    }
    title = titles.get(event_type, f'🔔 安全事件：{event_type}')

    descs = {
        'LOGIN_ANOMALY':    f'用户 **{display}** 从未知IP首次登录系统',
        'ACCOUNT_LOCKED':   f'用户 **{display}** 多次登录失败，账号已自动锁定',
        'LOGIN_FAIL_FLOOD': f'IP **{ip}** 对账号 **{display}** 发起高频登录尝试',
    }
    desc = descs.get(event_type, detail)

    return {
        'title':    title,
        'desc':     desc,
        'username': username,
        'display':  display,
        'ip':       ip,
        'ts':       ts,
        'system':   system,
        'detail':   detail,
        'event':    event_type,
    }


# ── 企业微信 Webhook ─────────────────────────────────────
def _send_wecom(url, p):
    content = (
        f"## {p['title']}\n"
        f"> **系统**：{p['system']}\n"
        f"> **时间**：{p['ts']}\n"
        f"> **用户**：{p['display']}（{p['username']}）\n"
        f"> **IP**：<font color='warning'>{p['ip']}</font>\n"
        f"> **说明**：{p['desc']}\n"
    )
    if p.get('detail'):
        content += f"> **详情**：{p['detail']}\n"

    data = json.dumps({
        'msgtype': 'markdown',
        'markdown': {'content': content}
    }).encode('utf-8')

    req = urllib.request.Request(
        url, data=data,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    with urllib.request.urlopen(req, timeout=8) as resp:
        result = json.loads(resp.read())
        if result.get('errcode', 0) != 0:
            raise RuntimeError(f"企业微信返回错误: {result}")


# ── 钉钉 Webhook ─────────────────────────────────────────
def _send_dingtalk(url, p):
    content = (
        f"**{p['title']}**\n\n"
        f"- 系统：{p['system']}\n"
        f"- 时间：{p['ts']}\n"
        f"- 用户：{p['display']}（{p['username']}）\n"
        f"- IP：{p['ip']}\n"
        f"- 说明：{p['desc']}\n"
    )
    data = json.dumps({
        'msgtype': 'markdown',
        'markdown': {'title': p['title'], 'text': content},
        'at': {'isAtAll': False}
    }).encode('utf-8')

    req = urllib.request.Request(
        url, data=data,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    with urllib.request.urlopen(req, timeout=8) as resp:
        result = json.loads(resp.read())
        if result.get('errcode', 0) != 0:
            raise RuntimeError(f"钉钉返回错误: {result}")


# ── 邮件 ─────────────────────────────────────────────────
def _send_email(p):
    smtp_host = _cfg('ALERT_SMTP_HOST', '')
    smtp_port = int(_cfg('ALERT_SMTP_PORT', 465))
    smtp_user = _cfg('ALERT_SMTP_USER', '')
    smtp_pass = _cfg('ALERT_SMTP_PASS', '')
    recipients = _cfg('ALERT_EMAIL_TO', '').split(',')
    recipients = [r.strip() for r in recipients if r.strip()]
    if not recipients or not smtp_host or not smtp_user:
        return

    msg = MIMEMultipart('alternative')
    msg['Subject'] = f"[{p['system']}] {p['title']}"
    msg['From']    = smtp_user
    msg['To']      = ', '.join(recipients)

    html = f"""
    <html><body style="font-family:'Microsoft YaHei',sans-serif;font-size:14px;color:#1a1f2e">
    <div style="max-width:560px;margin:0 auto;border:1px solid #e2e8f0;border-radius:8px;overflow:hidden">
      <div style="background:#1560bd;padding:16px 20px">
        <h2 style="color:#fff;margin:0;font-size:16px">{p['title']}</h2>
      </div>
      <div style="padding:20px">
        <table style="width:100%;border-collapse:collapse">
          <tr><td style="padding:7px 0;color:#64748b;width:80px">系统</td>
              <td style="padding:7px 0;font-weight:600">{p['system']}</td></tr>
          <tr><td style="padding:7px 0;color:#64748b">时间</td>
              <td style="padding:7px 0">{p['ts']}</td></tr>
          <tr><td style="padding:7px 0;color:#64748b">用户</td>
              <td style="padding:7px 0">{p['display']}（{p['username']}）</td></tr>
          <tr><td style="padding:7px 0;color:#64748b">登录IP</td>
              <td style="padding:7px 0;color:#c62828;font-weight:600">{p['ip']}</td></tr>
          <tr><td style="padding:7px 0;color:#64748b">说明</td>
              <td style="padding:7px 0">{p['desc']}</td></tr>
        </table>
        <p style="margin-top:16px;font-size:12px;color:#94a3b8">
          此邮件由系统自动发送，请勿回复。如有疑问请联系系统管理员。
        </p>
      </div>
    </div>
    </body></html>
    """
    msg.attach(MIMEText(html, 'html', 'utf-8'))

    if smtp_port == 465:
        server = smtplib.SMTP_SSL(smtp_host, smtp_port, timeout=10)
    else:
        server = smtplib.SMTP(smtp_host, smtp_port, timeout=10)
        server.starttls()

    server.login(smtp_user, smtp_pass)
    server.sendmail(smtp_user, recipients, msg.as_bytes())
    server.quit()


# ── 自定义 Webhook ───────────────────────────────────────
def _send_webhook(url, p):
    data = json.dumps(p, ensure_ascii=False).encode('utf-8')
    req  = urllib.request.Request(
        url, data=data,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    urllib.request.urlopen(req, timeout=8)
