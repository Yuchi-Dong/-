# -*- coding: utf-8 -*-
"""
routes/upload_routes.py — 分片上传与断点续传

协议设计（兼容主流前端分片库）：

  POST /api/upload/init
    body: {path, filename, file_size, file_hash(md5), total_chunks, csrf_token}
    返回: {upload_id, uploaded_chunks: [...已完成的分片序号...]}
    作用：创建上传会话，已有则返回已完成的分片（实现断点续传）

  POST /api/upload/chunk
    form: {upload_id, chunk_index, total_chunks, chunk(file)}
    返回: {done: false, chunk_index} 或 {done: true, file_path}
    作用：上传单个分片，全部完成后自动合并

  POST /api/upload/cancel
    body: {upload_id, csrf_token}
    返回: {success: true}
    作用：取消上传，清理临时文件

  GET  /api/upload/status/<upload_id>
    返回: {uploaded_chunks, total_chunks, filename}
    作用：查询上传进度

分片大小：前端建议 5MB，服务端不限制单片大小（受 MAX_UPLOAD_MB 约束）
临时目录：FILE_ROOT/../.upload_tmp/{upload_id}/
"""
import os
import hashlib
import secrets
import shutil
import threading
from pathlib import Path
from datetime import datetime, timedelta

from flask import Blueprint, session, request, jsonify

import config
from core.storage import get_storage
from auth import login_required, safe_join, csrf_ok, secure_filename
from core.auth.permission import can_access
from core.db import get_conn
from product.files.dao import log_action, save_version
from product.files.indexer import async_index

bp = Blueprint("upload_chunked", __name__)

# 上传临时目录
def _tmp_root():
    d = os.path.join(os.path.dirname(config.FILE_ROOT), ".upload_tmp")
    os.makedirs(d, exist_ok=True)
    return d

# 过期时间：24 小时未活动的上传会话自动清理
_UPLOAD_EXPIRE_HOURS = 24
_cleanup_lock = threading.Lock()


# ── 数据库：upload_sessions 表 ────────────────────────
def _ensure_table():
    """确保 upload_sessions 表存在（首次启动时建表）"""
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS upload_sessions (
                id            TEXT PRIMARY KEY,
                user_id       INTEGER NOT NULL,
                filename      TEXT NOT NULL,
                rel_path      TEXT NOT NULL,
                file_size     BIGINT DEFAULT 0,
                file_hash     TEXT DEFAULT '',
                total_chunks  INTEGER NOT NULL,
                done_chunks   TEXT DEFAULT '[]',
                status        TEXT DEFAULT 'active',
                created_at    TIMESTAMPTZ DEFAULT NOW(),
                updated_at    TIMESTAMPTZ DEFAULT NOW()
            )
        """)


# ── 工具函数 ──────────────────────────────────────────
def _chunk_path(upload_id: str, chunk_index: int) -> str:
    d = os.path.join(_tmp_root(), upload_id)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, f"{chunk_index:06d}.chunk")


def _get_session(upload_id: str, user_id: int = None) -> dict | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM upload_sessions WHERE id=%s" +
            (" AND user_id=%s" if user_id else ""),
            (upload_id, user_id) if user_id else (upload_id,)
        ).fetchone()
    return dict(row) if row else None


def _update_done_chunks(upload_id: str, chunk_index: int):
    import json
    with get_conn() as conn:
        row = conn.execute(
            "SELECT done_chunks FROM upload_sessions WHERE id=%s", (upload_id,)
        ).fetchone()
        done = json.loads(row["done_chunks"] or "[]") if row else []
        if chunk_index not in done:
            done.append(chunk_index)
        conn.execute(
            "UPDATE upload_sessions SET done_chunks=%s, updated_at=NOW() WHERE id=%s",
            (json.dumps(done), upload_id)
        )
    return done


def _merge_chunks(upload_id: str, total_chunks: int, dest_path: str) -> bool:
    """将所有分片按序合并到目标路径"""
    tmp_dir = os.path.join(_tmp_root(), upload_id)
    try:
        with open(dest_path, "wb") as out:
            for i in range(total_chunks):
                chunk_file = os.path.join(tmp_dir, f"{i:06d}.chunk")
                if not os.path.isfile(chunk_file):
                    return False
                with open(chunk_file, "rb") as f:
                    shutil.copyfileobj(f, out)
        return True
    except Exception:
        return False
    finally:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


def _cleanup_expired():
    """清理超时的上传会话（定期调用）"""
    if not _cleanup_lock.acquire(blocking=False):
        return
    try:
        with get_conn() as conn:
            expired = conn.execute(
                "SELECT id FROM upload_sessions WHERE status='active' "
                "AND updated_at < NOW() - INTERVAL '%s hours'",
                (_UPLOAD_EXPIRE_HOURS,)
            ).fetchall()
            for row in expired:
                uid = row["id"]
                tmp_dir = os.path.join(_tmp_root(), uid)
                shutil.rmtree(tmp_dir, ignore_errors=True)
            conn.execute(
                "DELETE FROM upload_sessions WHERE status='active' "
                "AND updated_at < NOW() - INTERVAL '%s hours'",
                (_UPLOAD_EXPIRE_HOURS,)
            )
    except Exception:
        pass
    finally:
        _cleanup_lock.release()


def _can_write(rel_path: str) -> bool:
    role   = session.get("role", 2)
    uid    = session.get("uid")
    org_id = session.get("org_id")
    if role == 0:  # ROLE_SUPER
        return True
    return can_access(rel_path, uid, role, org_id, need_write=True)


# ── API：初始化上传会话 ───────────────────────────────
@bp.route("/api/upload/init", methods=["POST"])
@login_required
def upload_init():
    """
    初始化分片上传会话。
    如果同一用户已有相同文件名+路径的活跃会话，返回已完成的分片（续传）。
    """
    _cleanup_expired()  # 顺带清理过期会话

    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"error": "CSRF"}), 403

    rel_path     = (data.get("path", "") or "").strip("/") or f"users/{session['uname']}"
    filename     = data.get("filename", "").strip()
    file_size    = int(data.get("file_size", 0))
    file_hash    = data.get("file_hash", "").strip().lower()
    total_chunks = int(data.get("total_chunks", 1))

    if not filename:
        return jsonify({"error": "文件名不能为空"}), 400

    # 权限检查
    if not _can_write(rel_path):
        return jsonify({"error": "无写入权限"}), 403

    # 扩展名白名单
    ext = Path(filename).suffix.lower()
    if ext not in config.UPLOAD_WHITELIST:
        return jsonify({"error": f"不允许上传 {ext or '无扩展名'} 类型文件"}), 400

    # 文件名安全化
    safe_name = secure_filename(filename) or filename.replace("/", "_")

    # 检查是否已有活跃会话（断点续传）
    import json
    with get_conn() as conn:
        existing = conn.execute(
            "SELECT * FROM upload_sessions "
            "WHERE user_id=%s AND filename=%s AND rel_path=%s AND status='active' "
            "ORDER BY created_at DESC LIMIT 1",
            (session["uid"], safe_name, rel_path)
        ).fetchone()

    if existing:
        done = json.loads(existing["done_chunks"] or "[]")
        return jsonify({
            "upload_id":       existing["id"],
            "uploaded_chunks": done,
            "filename":        safe_name,
            "resuming":        True,
        })

    # 新建会话
    upload_id = secrets.token_hex(16)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO upload_sessions(id,user_id,filename,rel_path,"
            "file_size,file_hash,total_chunks,done_chunks,status) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s,'[]','active')",
            (upload_id, session["uid"], safe_name, rel_path,
             file_size, file_hash, total_chunks)
        )

    return jsonify({
        "upload_id":       upload_id,
        "uploaded_chunks": [],
        "filename":        safe_name,
        "resuming":        False,
    })


# ── API：上传单个分片 ─────────────────────────────────
@bp.route("/api/upload/chunk", methods=["POST"])
@login_required
def upload_chunk():
    upload_id   = request.form.get("upload_id", "")
    chunk_index = int(request.form.get("chunk_index", 0))
    chunk_file  = request.files.get("chunk")

    if not upload_id or chunk_file is None:
        return jsonify({"error": "参数缺失"}), 400

    sess = _get_session(upload_id, session["uid"])
    if not sess:
        return jsonify({"error": "上传会话不存在或已过期，请重新初始化"}), 404

    if sess["status"] != "active":
        return jsonify({"error": f"上传会话状态异常: {sess['status']}"}), 400

    total_chunks = sess["total_chunks"]
    if chunk_index < 0 or chunk_index >= total_chunks:
        return jsonify({"error": f"分片序号越界: {chunk_index}/{total_chunks}"}), 400

    # 保存分片
    cp = _chunk_path(upload_id, chunk_index)
    chunk_file.save(cp)

    done_chunks = _update_done_chunks(upload_id, chunk_index)

    # 判断是否全部完成
    if len(done_chunks) < total_chunks:
        return jsonify({
            "done":        False,
            "chunk_index": chunk_index,
            "progress":    len(done_chunks) / total_chunks,
        })

    # ── 全部分片已到，合并文件 ──────────────────────
    rel_path  = sess["rel_path"]
    filename  = sess["filename"]
    dest_dir  = safe_join(config.FILE_ROOT, rel_path)
    os.makedirs(dest_dir, exist_ok=True)
    dest_path = os.path.join(dest_dir, filename)

    # 覆盖时先备份旧版本
    if os.path.isfile(dest_path):
        save_version(f"{rel_path}/{filename}", dest_path,
                     session["uid"], "分片上传覆盖前自动备份")

    # 先合并到临时位置（本地）
    _tmp_merged = dest_path + ".merging"
    if not _merge_chunks(upload_id, total_chunks, _tmp_merged):
        return jsonify({"error": "文件合并失败，请重试"}), 500

    # 写入存储后端
    _storage = get_storage()
    if hasattr(_storage, 'get_local_path'):
        # 本地存储：直接重命名到目标位置
        import shutil as _sh
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)
        _sh.move(_tmp_merged, dest_path)
    else:
        # 对象存储：上传后删除本地临时文件
        try:
            _storage.put_file(f"{sess['rel_path']}/{sess['filename']}", _tmp_merged)
        finally:
            try: os.remove(_tmp_merged)
            except Exception: pass

    # 服务端哈希校验（MD5/SHA-256 均支持，客户端提供哈希值时验证）
    file_hash = (sess.get("file_hash") or "").strip().lower()
    if file_hash:
        hasher = hashlib.sha256() if len(file_hash) == 64 else hashlib.md5()
        with open(dest_path, "rb") as _fh:
            for _chunk in iter(lambda: _fh.read(65536), b""):
                hasher.update(_chunk)
        actual_hash = hasher.hexdigest()
        if actual_hash != file_hash:
            os.remove(dest_path)
            log.warning(f"上传哈希校验失败: 预期={file_hash[:16]}… 实际={actual_hash[:16]}… 文件={full_path}")
            return jsonify({"error": "文件校验失败（哈希不匹配），文件可能损坏，请重新上传"}), 500

    # 标记会话完成
    with get_conn() as conn:
        conn.execute(
            "UPDATE upload_sessions SET status='done', updated_at=NOW() WHERE id=%s",
            (upload_id,)
        )

    # 记录审计日志 + 触发全文索引
    full_path = f"{rel_path}/{filename}"
    log_action(session["uid"], session["uname"], "UPLOAD_CHUNKED",
               f"{full_path} ({sess['file_size']} bytes)", request.remote_addr)
    async_index(dest_path, full_path)

    return jsonify({
        "done":      True,
        "file_path": full_path,
        "filename":  filename,
    })


# ── API：取消上传 ─────────────────────────────────────
@bp.route("/api/upload/cancel", methods=["POST"])
@login_required
def upload_cancel():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"error": "CSRF"}), 403

    upload_id = data.get("upload_id", "")
    if not upload_id:
        return jsonify({"success": False, "error": "upload_id 不能为空"}), 400

    with get_conn() as conn:
        conn.execute(
            "UPDATE upload_sessions SET status='cancelled', updated_at=NOW() "
            "WHERE id=%s AND user_id=%s",
            (upload_id, session["uid"])
        )

    # 清理临时分片目录
    tmp_dir = os.path.join(_tmp_root(), upload_id)
    shutil.rmtree(tmp_dir, ignore_errors=True)

    return jsonify({"success": True})


# ── API：查询上传进度 ─────────────────────────────────
@bp.route("/api/upload/status/<upload_id>")
@login_required
def upload_status(upload_id):
    import json
    sess = _get_session(upload_id, session["uid"])
    if not sess:
        return jsonify({"error": "会话不存在"}), 404
    done = json.loads(sess["done_chunks"] or "[]")
    return jsonify({
        "upload_id":       upload_id,
        "filename":        sess["filename"],
        "total_chunks":    sess["total_chunks"],
        "uploaded_chunks": done,
        "progress":        len(done) / max(1, sess["total_chunks"]),
        "status":          sess["status"],
    })
