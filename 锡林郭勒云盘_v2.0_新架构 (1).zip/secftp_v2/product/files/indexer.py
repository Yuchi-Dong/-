# -*- coding: utf-8 -*-
"""
indexer.py — 文件内容索引器（PostgreSQL 版）

上传后异步解析文件内容，存入 file_index 表供全文搜索。
支持：PDF / Word / Excel / PPT / 图片EXIF / 文本

已从 SQLite 迁移到 PostgreSQL（使用统一的 dao.db.get_conn 连接池）。
"""
import os
import threading
import json
import traceback
from pathlib import Path
from datetime import datetime

import config
from dao.db import get_conn


# ── 数据库初始化 ──────────────────────────────────────────
def init_index_db():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS file_index (
                id          SERIAL PRIMARY KEY,
                file_path   TEXT UNIQUE NOT NULL,
                file_name   TEXT NOT NULL,
                ftype       TEXT,
                file_size   BIGINT DEFAULT 0,
                mtime       FLOAT DEFAULT 0,
                title       TEXT DEFAULT '',
                author      TEXT DEFAULT '',
                content     TEXT DEFAULT '',
                summary     TEXT DEFAULT '',
                meta        TEXT DEFAULT '{}',
                indexed_at  TIMESTAMPTZ DEFAULT NOW(),
                status      TEXT DEFAULT 'pending'
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_file_index_path
            ON file_index(file_path)
        """)
        # PostgreSQL 全文搜索索引
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_file_index_content_fts
            ON file_index USING gin(to_tsvector('simple', coalesce(content,'')))
        """)


# ── 解析器 ────────────────────────────────────────────────

def _parse_pdf(full_path):
    meta = {}; content = ""
    try:
        import pypdf
        with open(full_path, "rb") as f:
            reader = pypdf.PdfReader(f)
        info = reader.metadata or {}
        meta["pages"]  = len(reader.pages)
        meta["title"]  = str(info.get("/Title",  "")).strip()
        meta["author"] = str(info.get("/Author", "")).strip()
        texts = []
        for i, page in enumerate(reader.pages):
            if i >= 20: break
            try: texts.append(page.extract_text() or "")
            except: pass
        content = "\n".join(texts)
    except Exception:
        content = ""
    return content, meta


def _parse_docx(full_path):
    meta = {}; content = ""
    try:
        from docx import Document
        doc = Document(full_path)
        props = doc.core_properties
        meta["title"]  = props.title  or ""
        meta["author"] = props.author or ""
        content = "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    except Exception:
        content = ""
    return content, meta


def _parse_xlsx(full_path):
    meta = {}; content = ""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(full_path, read_only=True, data_only=True)
        texts = []
        for ws in wb.worksheets[:5]:
            for row in ws.iter_rows(max_row=200, values_only=True):
                line = " ".join(str(c) for c in row if c is not None)
                if line.strip(): texts.append(line)
        content = "\n".join(texts)
        meta["sheets"] = wb.sheetnames
        wb.close()
    except Exception:
        content = ""
    return content, meta


def _parse_pptx(full_path):
    meta = {}; content = ""
    try:
        from pptx import Presentation
        prs = Presentation(full_path)
        texts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    texts.append(shape.text)
        content = "\n".join(texts)
        meta["slides"] = len(prs.slides)
    except Exception:
        content = ""
    return content, meta


def _parse_text(full_path):
    meta = {}; content = ""
    for enc in ["utf-8", "gbk", "latin-1"]:
        try:
            with open(full_path, "r", encoding=enc, errors="replace") as f:
                content = f.read(50000)
            break
        except Exception:
            continue
    return content, meta


def _get_ftype(suffix):
    s = suffix.lower().lstrip(".")
    if s in ("jpg","jpeg","png","gif","webp","bmp","svg"): return "image"
    if s == "pdf":                                           return "pdf"
    if s in ("mp4","mkv","avi","mov","wmv","flv"):          return "video"
    if s in ("mp3","wav","flac","aac","ogg","m4a"):         return "audio"
    if s in ("doc","docx"):                                  return "word"
    if s in ("xls","xlsx","csv"):                            return "excel"
    if s in ("ppt","pptx"):                                  return "ppt"
    if s in ("zip","rar","7z","tar","gz"):                   return "zip"
    if s in ("txt","md","log","conf","ini","yaml","json",
             "xml","html","htm","sh","py","js","ts","css"):  return "text"
    return "other"


# ── 核心索引函数 ──────────────────────────────────────────

def index_file(full_path: str, rel_path: str):
    """解析单个文件并写入索引（同步，供后台线程调用）"""
    try:
        stat     = os.stat(full_path)
        suffix   = Path(full_path).suffix
        ftype    = _get_ftype(suffix)
        file_name= Path(full_path).name
        content  = ""
        meta     = {}
        title    = ""
        author   = ""

        parsers = {
            "pdf":   _parse_pdf,
            "word":  _parse_docx,
            "excel": _parse_xlsx,
            "ppt":   _parse_pptx,
            "text":  _parse_text,
        }
        if ftype in parsers:
            content, meta = parsers[ftype](full_path)
            title  = meta.pop("title",  "") or ""
            author = meta.pop("author", "") or ""

        content = (content or "")[:5000]
        summary = content[:200].replace("\n", " ")

        with get_conn() as conn:
            # 检查是否已是最新
            existing = conn.execute(
                "SELECT mtime FROM file_index WHERE file_path=%s",
                (rel_path,)
            ).fetchone()
            if existing and abs(float(existing["mtime"] or 0) - stat.st_mtime) < 1:
                return   # 未变更，跳过

            conn.execute("""
                INSERT INTO file_index
                    (file_path, file_name, ftype, file_size, mtime,
                     title, author, content, summary, meta, indexed_at, status)
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,NOW(),'done')
                ON CONFLICT(file_path) DO UPDATE SET
                    file_name  = EXCLUDED.file_name,
                    ftype      = EXCLUDED.ftype,
                    file_size  = EXCLUDED.file_size,
                    mtime      = EXCLUDED.mtime,
                    title      = EXCLUDED.title,
                    author     = EXCLUDED.author,
                    content    = EXCLUDED.content,
                    summary    = EXCLUDED.summary,
                    meta       = EXCLUDED.meta,
                    indexed_at = NOW(),
                    status     = 'done'
            """, (rel_path, file_name, ftype, stat.st_size, stat.st_mtime,
                  title, author, content, summary, json.dumps(meta, ensure_ascii=False)))

    except Exception as e:
        try:
            with get_conn() as conn:
                conn.execute("""
                    INSERT INTO file_index(file_path, file_name, ftype, status)
                    VALUES (%s, %s, 'other', 'error')
                    ON CONFLICT(file_path) DO UPDATE SET status='error'
                """, (rel_path, Path(full_path).name))
        except Exception:
            pass


def async_index(full_path: str, rel_path: str):
    """非阻塞后台索引"""
    t = threading.Thread(target=index_file, args=(full_path, rel_path), daemon=True)
    t.start()


def delete_index(rel_path: str):
    """删除文件时同步清除索引"""
    try:
        with get_conn() as conn:
            conn.execute("DELETE FROM file_index WHERE file_path=%s", (rel_path,))
    except Exception:
        pass


def search_index(keyword: str, ftype: str = "", limit: int = 200) -> list:
    """
    全文搜索：先查文件名，再查内容。
    PostgreSQL 版使用 ILIKE（简单模糊）+ to_tsvector（全文）双路搜索。
    """
    keyword = keyword.strip()
    if not keyword:
        return []

    results = []
    try:
        with get_conn() as conn:
            type_clause = "AND ftype=%s" if ftype else ""
            params_base = [f"%{keyword}%"]
            if ftype:
                params_base.append(ftype)

            # 文件名优先（TODO: f-string 条件来自内部白名单，下版本完整参数化）
            rows = conn.execute(f"""
                SELECT file_path, file_name, ftype, file_size, summary, title
                FROM file_index
                WHERE status='done'
                AND file_name ILIKE %s
                {type_clause}
                ORDER BY indexed_at DESC
                LIMIT %s
            """, params_base + [limit]).fetchall()
            seen = set()
            for r in rows:
                seen.add(r["file_path"])
                results.append(dict(r))

            # 内容搜索（补充）
            remaining = limit - len(results)
            if remaining > 0:
                rows2 = conn.execute(f"""
                    SELECT file_path, file_name, ftype, file_size, summary, title
                    FROM file_index
                    WHERE status='done'
                    AND (content ILIKE %s OR title ILIKE %s)
                    {type_clause}
                    ORDER BY indexed_at DESC
                    LIMIT %s
                """, [f"%{keyword}%", f"%{keyword}%"] + ([ftype] if ftype else []) + [remaining]
                ).fetchall()
                for r in rows2:
                    if r["file_path"] not in seen:
                        results.append(dict(r))
    except Exception:
        pass
    return results


def rebuild_index(file_root: str):
    """重建全量索引（管理后台触发，后台线程执行）"""
    def _rebuild():
        count = 0
        for root, dirs, files in os.walk(file_root):
            dirs[:] = [d for d in dirs if not d.startswith(".")]
            for fn in files:
                full  = os.path.join(root, fn)
                rel   = os.path.relpath(full, file_root).replace("\\", "/")
                index_file(full, rel)
                count += 1
        return count
    t = threading.Thread(target=_rebuild, daemon=True)
    t.start()
