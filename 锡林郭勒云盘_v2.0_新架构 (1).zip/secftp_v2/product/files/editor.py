# -*- coding: utf-8 -*-
"""
routes/editor_routes.py — OnlyOffice 在线编辑集成

工作流程：
  1. 用户点击「在线编辑」→ GET /edit/<filepath> → 返回内嵌 OnlyOffice 编辑器的页面
  2. OnlyOffice Document Server 通过 document.url 拉取文件（GET /api/editor/download/<token>）
  3. 用户编辑保存时，OnlyOffice 回调 callbackUrl（POST /api/editor/callback/<token>）
  4. 服务端收到回调后，从 OnlyOffice 下载最新版本，写入存储，触发索引

token 机制：
  - 每次打开编辑器生成一个一次性 token（有效期 12 小时）
  - token 绑定：用户 ID + 文件路径 + 权限
  - 防止 OnlyOffice 回调时伪造文件路径

支持的文件格式：
  - Word: .docx .doc .odt .rtf
  - Excel: .xlsx .xls .ods .csv
  - PPT: .pptx .ppt .odp

配置项（config.py）：
  ONLYOFFICE_SERVER   - OnlyOffice Document Server 地址，如 http://192.168.1.50:8888
  ONLYOFFICE_JWT_KEY  - JWT 密钥（OnlyOffice 后台配置保持一致）
  ONLYOFFICE_ENABLED  - 是否启用（默认 False）
"""
import hashlib
import json
import logging
import mimetypes
import os
import secrets
import urllib.request
from datetime import datetime, timedelta
from pathlib import Path

from flask import Blueprint, session, request, jsonify, abort, redirect

import config
from auth import login_required, safe_join, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER
from core.auth.permission import can_access
from core.db import get_conn
from product.files.dao import log_action, save_version
from product.files.indexer import async_index
from infra.templates import layout

bp  = Blueprint("editor", __name__)
log = logging.getLogger("editor")


# ── 支持格式 ─────────────────────────────────────────
EDITABLE_EXTS = {
    ".docx": "word",   ".doc":  "word",   ".odt": "word",  ".rtf":  "word",
    ".xlsx": "cell",   ".xls":  "cell",   ".ods": "cell",  ".csv":  "cell",
    ".pptx": "slide",  ".ppt":  "slide",  ".odp": "slide",
}

DOC_TYPE_MAP = {
    "word":  "text",
    "cell":  "spreadsheet",
    "slide": "presentation",
}

# ── 工具函数 ──────────────────────────────────────────
def _cfg(key, default=""):
    return getattr(config, key, None) or os.environ.get(key, default)


def is_editor_enabled() -> bool:
    return str(_cfg("ONLYOFFICE_ENABLED", "false")).lower() in ("1", "true", "yes")


def _ensure_table():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS editor_sessions (
                token       TEXT PRIMARY KEY,
                user_id     INTEGER NOT NULL,
                username    TEXT NOT NULL,
                file_path   TEXT NOT NULL,
                can_write   BOOLEAN DEFAULT FALSE,
                expires_at  TIMESTAMPTZ NOT NULL,
                created_at  TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_editor_expires
            ON editor_sessions(expires_at)
        """)


def _make_token(user_id: int, username: str, file_path: str, can_write: bool) -> str:
    token = secrets.token_urlsafe(24)
    expires_at = datetime.now() + timedelta(hours=12)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO editor_sessions(token,user_id,username,file_path,can_write,expires_at) "
            "VALUES(%s,%s,%s,%s,%s,%s)",
            (token, user_id, username, file_path, can_write, expires_at.isoformat())
        )
    return token


def _get_token_info(token: str) -> dict | None:
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM editor_sessions WHERE token=%s", (token,)
        ).fetchone()
    if not row:
        return None
    expires = row["expires_at"]
    if isinstance(expires, str):
        expires = datetime.fromisoformat(expires)
    if hasattr(expires, "tzinfo") and expires.tzinfo:
        from datetime import timezone
        if datetime.now(timezone.utc) > expires:
            return None
    else:
        if datetime.now() > expires.replace(tzinfo=None):
            return None
    return dict(row)


def _make_jwt(payload: dict) -> str:
    """生成 OnlyOffice 需要的 JWT（仅在 jwt_key 配置时使用）"""
    jwt_key = _cfg("ONLYOFFICE_JWT_KEY", "")
    if not jwt_key:
        return ""
    try:
        import base64, hmac, hashlib as hl
        header  = base64.urlsafe_b64encode(json.dumps({"alg":"HS256","typ":"JWT"}).encode()).rstrip(b"=")
        body    = base64.urlsafe_b64encode(json.dumps(payload).encode()).rstrip(b"=")
        sig_inp = header + b"." + body
        sig     = hmac.new(jwt_key.encode(), sig_inp, hl.sha256).digest()
        sig_b64 = base64.urlsafe_b64encode(sig).rstrip(b"=")
        return (sig_inp + b"." + sig_b64).decode()
    except Exception as e:
        log.warning(f"JWT 生成失败: {e}")
        return ""


def _server_url() -> str:
    url = _cfg("ONLYOFFICE_SERVER", "https://onlinedocs.onlyoffice.com").rstrip("/")
    return url


def _base_url() -> str:
    """当前系统的对外访问地址（OnlyOffice 需要能访问到这个地址拉取文件）"""
    return _cfg("SECFTP_PUBLIC_URL", f"http://{request.host}").rstrip("/")


# ── 编辑器页面 ────────────────────────────────────────
@bp.route("/edit/<path:filepath>")
@login_required
def edit_file(filepath):
    if not is_editor_enabled():
        return "<h2>在线编辑未启用，请联系管理员配置 OnlyOffice</h2>", 503

    full = safe_join(config.FILE_ROOT, filepath)
    if not os.path.isfile(full):
        abort(404)

    ext = Path(filepath).suffix.lower()
    if ext not in EDITABLE_EXTS:
        return f"<h2>不支持在线编辑 {ext} 格式</h2>", 400

    uid    = session["uid"]
    role   = session["role"]
    org_id = session.get("org_id")
    uname  = session["uname"]

    # 权限检查
    if role != ROLE_SUPER and not can_access(filepath, uid, role, org_id):
        abort(403)
    can_write = (role == ROLE_SUPER or can_access(filepath, uid, role, org_id, True))

    token    = _make_token(uid, uname, filepath, can_write)
    doc_key  = hashlib.md5(f"{filepath}{os.path.getmtime(full)}".encode()).hexdigest()[:20]
    filename = Path(filepath).name
    editor_type = EDITABLE_EXTS[ext]
    doc_type    = DOC_TYPE_MAP[editor_type]
    base_url    = _base_url()
    server_url  = _server_url()

    doc_config = {
        "type":          "desktop",
        "documentType":  doc_type,
        "document": {
            "title":       filename,
            "url":         f"{base_url}/api/editor/download/{token}",
            "fileType":    ext.lstrip("."),
            "key":         doc_key,
            "permissions": {
                "download": True,
                "edit":     can_write,
                "print":    True,
                "review":   True,
            },
        },
        "editorConfig": {
            "mode":          "edit" if can_write else "view",
            "lang":          "zh-CN",
            "callbackUrl":   f"{base_url}/api/editor/callback/{token}",
            "user": {
                "id":   str(uid),
                "name": session.get("display_name") or uname,
            },
            "customization": {
                "autosave":        True,
                "forcesave":       False,
                "logo":            {"visible": False},
                "customer":        {"visible": False},
                "feedback":        {"visible": False},
                "help":            False,
                "toolbarNoTabs":   True,
            },
        },
    }

    # JWT 签名（可选）
    jwt_token = _make_jwt(doc_config)
    if jwt_token:
        doc_config["token"] = jwt_token

    doc_config_json = json.dumps(doc_config, ensure_ascii=False)

    log_action(uid, uname, "EDIT_OPEN", filepath, request.remote_addr)

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    # CSP 需要放行 OnlyOffice 服务器
    oo_host = _server_url().split("//")[-1].split("/")[0]

    content = f"""
<div class="view show" style="padding:0;height:100%;display:flex;flex-direction:column">
  <div style="display:flex;align-items:center;justify-content:space-between;
    padding:8px 16px;background:var(--white);border-bottom:1px solid var(--border);
    flex-shrink:0">
    <div style="display:flex;align-items:center;gap:10px">
      <a href="javascript:history.back()" class="btn btn-outline btn-sm">← 返回</a>
      <span style="font-size:13px;font-weight:600">{filename}</span>
      <span class="badge {'badge-blue' if can_write else 'badge-gray'}">
        {'✏ 编辑' if can_write else '👁 只读'}</span>
    </div>
    <div style="font-size:11px;color:var(--text3)">
      OnlyOffice 在线编辑 · 自动保存已启用
    </div>
  </div>
  <div id="onlyoffice-container" style="flex:1;min-height:0"></div>
</div>
<script src="{server_url}/web-apps/apps/api/documents/api.js"></script>
<script>
(function() {{
  const config = {doc_config_json};
  try {{
    window._editor = new DocsAPI.DocEditor("onlyoffice-container", config);
  }} catch(e) {{
    document.getElementById('onlyoffice-container').innerHTML =
      '<div style="padding:40px;text-align:center;color:#c62828">' +
      '<h3>OnlyOffice 加载失败</h3>' +
      '<p>请确认 OnlyOffice Document Server 已正常运行：{server_url}</p>' +
      '<p style="font-size:12px;color:#64748b">错误：' + e.message + '</p>' +
      '</div>';
  }}
}})();
</script>"""

    # 编辑器页面需要放宽 CSP（允许加载 OnlyOffice 资源）
    from flask import make_response
    resp = make_response(layout(content, f"编辑 - {filename}", "browse",
                                csrf_token=csrf, **_ctx_data()))
    resp.headers["Content-Security-Policy"] = (
        f"default-src 'self' {oo_host}; "
        f"script-src 'self' 'unsafe-inline' 'unsafe-eval' {oo_host}; "
        f"style-src 'self' 'unsafe-inline' {oo_host}; "
        f"frame-src 'self' {oo_host}; "
        f"img-src 'self' data: blob: {oo_host}; "
        f"connect-src 'self' {oo_host}; "
        f"font-src 'self' data: {oo_host};"
    )
    return resp


def _ctx_data():
    """提取 layout 所需的 user/role 等上下文"""
    from core.auth.user_dao import get_by_id
    try:
        user = get_by_id(session["uid"])
        return {
            "user":       user,
            "role":       session.get("role", 2),
            "csrf_token": session.get("csrf_token", ""),
            "av_color":   (user or {}).get("avatar_color", "#1560bd"),
        }
    except Exception:
        return {"role": 2, "csrf_token": ""}


# ── 文件下载（OnlyOffice 拉取文件用）─────────────────
@bp.route("/api/editor/download/<token>")
def editor_download(token):
    """OnlyOffice 通过此端点拉取原始文件内容"""
    info = _get_token_info(token)
    if not info:
        abort(403)

    full = safe_join(config.FILE_ROOT, info["file_path"])
    if not os.path.isfile(full):
        abort(404)

    mime, _ = mimetypes.guess_type(full)
    from flask import send_file
    return send_file(full, mimetype=mime or "application/octet-stream")


# ── 回调（OnlyOffice 保存文件用）─────────────────────
@bp.route("/api/editor/callback/<token>", methods=["POST"])
def editor_callback(token):
    """
    OnlyOffice 在用户保存时回调此端点。
    状态码含义：
      2 - 文档已就绪，可下载（forcesave 或关闭编辑器时触发）
      6 - 文档正在编辑（心跳，无需处理）
    """
    info = _get_token_info(token)
    if not info:
        return jsonify({"error": 1})  # OnlyOffice 要求返回 {"error": 0} 表示成功

    try:
        data = request.get_json(force=True) or {}
    except Exception:
        return jsonify({"error": 0})

    status = data.get("status", 0)

    # 状态 6：正在编辑，心跳，直接回复 OK
    if status == 6:
        return jsonify({"error": 0})

    # 状态 2 或 3：文档保存完成，需要下载最新版本
    if status in (2, 3):
        download_url = data.get("url", "")
        if not download_url:
            log.error(f"OnlyOffice callback: 状态{status}但无 url, token={token}")
            return jsonify({"error": 0})

        file_path = info["file_path"]
        full_path = safe_join(config.FILE_ROOT, file_path)

        try:
            # 先备份旧版本
            if os.path.isfile(full_path):
                save_version(file_path, full_path, info["user_id"], "OnlyOffice 在线编辑保存前备份")

            # 从 OnlyOffice 下载新版本
            req = urllib.request.urlopen(download_url, timeout=60)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)
            # 通过加密存储层写入（保证文件静态加密）
            import io as _io
            _buf = _io.BytesIO()
            while True:
                chunk = req.read(65536)
                if not chunk: break
                _buf.write(chunk)
            _buf.seek(0)
            from core.storage import get_storage
            get_storage().put(file_path, _buf)

            log.info(f"OnlyOffice 保存成功: {file_path} by {info['username']}")
            log_action(info["user_id"], info["username"], "EDIT_SAVE",
                       file_path, request.remote_addr)
            async_index(full_path, file_path)

        except Exception as e:
            log.error(f"OnlyOffice 保存失败: {e}")

    return jsonify({"error": 0})


# ── 文件评论 API ──────────────────────────────────────
def _ensure_comments_table():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS file_comments (
                id          SERIAL PRIMARY KEY,
                file_path   TEXT NOT NULL,
                user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                parent_id   INTEGER REFERENCES file_comments(id) ON DELETE CASCADE,
                content     TEXT NOT NULL,
                created_at  TIMESTAMPTZ DEFAULT NOW(),
                updated_at  TIMESTAMPTZ DEFAULT NOW(),
                is_deleted  BOOLEAN DEFAULT FALSE
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_fc_path
            ON file_comments(file_path)
        """)


@bp.route("/api/comments/<path:filepath>")
@login_required
def get_comments(filepath):
    """获取文件评论列表"""
    if not can_access(filepath, session["uid"], session["role"], session.get("org_id")):
        abort(403)

    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fc.id, fc.parent_id, fc.content, fc.created_at, fc.updated_at,
                   u.display_name, u.username, u.avatar_color
            FROM file_comments fc
            JOIN users u ON u.id = fc.user_id
            WHERE fc.file_path=%s AND fc.is_deleted=FALSE
            ORDER BY fc.created_at ASC
        """, (filepath,)).fetchall()

    comments = []
    for r in rows:
        comments.append({
            "id":           r["id"],
            "parent_id":    r["parent_id"],
            "content":      r["content"],
            "created_at":   str(r["created_at"])[:16],
            "display_name": r["display_name"] or r["username"],
            "username":     r["username"],
            "avatar_color": r["avatar_color"] or "#1560bd",
            "is_mine":      r["username"] == session["uname"],
        })
    return jsonify({"comments": comments})


@bp.route("/api/comments/<path:filepath>", methods=["POST"])
@login_required
def post_comment(filepath):
    """发布评论"""
    if not can_access(filepath, session["uid"], session["role"], session.get("org_id")):
        abort(403)

    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"error": "CSRF"}), 403

    content   = (data.get("content") or "").strip()
    parent_id = data.get("parent_id")

    if not content:
        return jsonify({"error": "评论内容不能为空"}), 400
    if len(content) > 2000:
        return jsonify({"error": "评论内容不能超过2000字"}), 400

    with get_conn() as conn:
        cid = conn.execute(
            "INSERT INTO file_comments(file_path,user_id,parent_id,content) "
            "VALUES(%s,%s,%s,%s) RETURNING id",
            (filepath, session["uid"], parent_id or None, content)
        ).fetchone()[0]

    return jsonify({"success": True, "comment_id": cid})


@bp.route("/api/comments/delete/<int:comment_id>", methods=["POST"])
@login_required
def delete_comment(comment_id):
    """删除评论（本人或超管）"""
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"error": "CSRF"}), 403

    with get_conn() as conn:
        row = conn.execute(
            "SELECT user_id FROM file_comments WHERE id=%s", (comment_id,)
        ).fetchone()
        if not row:
            return jsonify({"error": "评论不存在"}), 404
        if row["user_id"] != session["uid"] and session.get("role", 2) != ROLE_SUPER:
            return jsonify({"error": "无权删除"}), 403
        conn.execute(
            "UPDATE file_comments SET is_deleted=TRUE, updated_at=NOW() WHERE id=%s",
            (comment_id,)
        )
    return jsonify({"success": True})


# ── OnlyOffice 配置 API ───────────────────────────────
@bp.route("/admin/editor")
@login_required
def admin_editor():
    from auth import role_required as _rr
    if session.get("role", 2) != ROLE_SUPER:
        abort(403)

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    oo_server  = _cfg("ONLYOFFICE_SERVER", "")
    oo_enabled = is_editor_enabled()
    oo_jwt     = _cfg("ONLYOFFICE_JWT_KEY", "")
    pub_url    = _cfg("SECFTP_PUBLIC_URL", "")

    status_badge = '<span class="badge badge-green">● 已启用</span>' if oo_enabled else '<span class="badge badge-gray">○ 未启用</span>'

    content = f"""
<div class="view show" style="max-width:700px">
  <div class="page-title"><span class="pt-icon">📝</span>OnlyOffice 在线编辑配置</div>

  <div class="card" style="padding:16px 20px;margin-bottom:12px">
    <div style="display:flex;align-items:center;gap:12px">
      <span style="font-size:13px;font-weight:600">当前状态：</span>{status_badge}
    </div>
  </div>

  <div class="card" style="padding:20px 24px">
    <div class="fg">
      <label style="display:flex;align-items:center;gap:8px">
        <input type="checkbox" id="oo-enabled" {"checked" if oo_enabled else ""}
          style="width:16px;height:16px">
        <span style="font-weight:600">启用 OnlyOffice 在线编辑</span>
      </label>
    </div>

    <div class="fg">
      <label>OnlyOffice Document Server 地址 <span style="color:var(--danger)">*</span></label>
      <input class="inp" id="oo-server" value="{oo_server}"
        placeholder="http://192.168.1.50:8888">
      <div style="font-size:11px;color:var(--text3);margin-top:3px">
        Document Server 需要能访问到本系统的 /api/editor/download 和 /api/editor/callback 端点
      </div>
    </div>

    <div class="fg">
      <label>本系统对外访问地址（供 OnlyOffice 回调）</label>
      <input class="inp" id="oo-pub-url" value="{pub_url}"
        placeholder="http://192.168.1.100:8080">
      <div style="font-size:11px;color:var(--text3);margin-top:3px">
        OnlyOffice 需要通过此地址拉取文件和发送回调，不能是 127.0.0.1
      </div>
    </div>

    <div class="fg">
      <label>JWT 密钥（可选，与 OnlyOffice 配置一致）</label>
      <input class="inp" id="oo-jwt" value="{oo_jwt}" type="password"
        placeholder="留空则不启用 JWT 签名">
    </div>

    <div class="fg">
      <div style="font-size:12px;color:var(--text2);background:var(--gray50);
        border-radius:6px;padding:12px 14px;line-height:1.8">
        <div style="font-weight:600;margin-bottom:4px">Docker 快速部署命令</div>
        <code style="font-size:11px;color:var(--text)">
          docker run -d --name onlyoffice -p 8888:80<br>
          &nbsp;&nbsp;-e JWT_ENABLED=true<br>
          &nbsp;&nbsp;-e JWT_SECRET=your_secret_key<br>
          &nbsp;&nbsp;onlyoffice/documentserver
        </code>
      </div>
    </div>

    <div style="display:flex;gap:10px;margin-top:16px">
      <button class="btn btn-outline" onclick="testEditor()">🔌 测试连接</button>
      <span style="flex:1"></span>
      <button class="btn btn-primary" onclick="saveEditor()">💾 保存</button>
    </div>
  </div>
  <div id="editor-result" style="display:none;margin-top:12px"></div>
</div>

<script>
async function saveEditor() {{
  const r = await fetch('/api/admin/editor/save', {{
    method:'POST', headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify({{
      enabled:    document.getElementById('oo-enabled').checked,
      server:     document.getElementById('oo-server').value.trim(),
      public_url: document.getElementById('oo-pub-url').value.trim(),
      jwt_key:    document.getElementById('oo-jwt').value,
      csrf_token: window._csrf
    }})
  }});
  const d = await r.json();
  if (d.success) toast('配置已保存', 'ok');
  else toast('保存失败：' + d.error, 'err');
}}

async function testEditor() {{
  const server = document.getElementById('oo-server').value.trim();
  if (!server) {{ toast('请先填写服务器地址', 'err'); return; }}
  document.getElementById('editor-result').style.display='';
  document.getElementById('editor-result').innerHTML = '<div class="card" style="padding:12px">⏳ 测试中...</div>';
  try {{
    const r = await fetch(server + '/hosting/discovery', {{mode:'no-cors'}});
    document.getElementById('editor-result').innerHTML = '<div class="toast ok" style="padding:12px">✅ 服务器可访问（状态: ' + r.status + '）</div>';
  }} catch(e) {{
    document.getElementById('editor-result').innerHTML = '<div class="toast err" style="padding:12px">❌ 无法访问：' + e.message + '（注意：跨域限制可能导致误报，以实际编辑测试为准）</div>';
  }}
}}
</script>"""

    from core.auth.context import ctx
    return layout(content, "OnlyOffice 配置", "editor", **ctx())


@bp.route("/api/admin/editor/save", methods=["POST"])
@login_required
def api_editor_save():
    if session.get("role", 2) != ROLE_SUPER:
        abort(403)
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    import config as _c
    _c.ONLYOFFICE_ENABLED = bool(data.get("enabled"))
    _c.ONLYOFFICE_SERVER  = data.get("server", "").rstrip("/")
    _c.SECFTP_PUBLIC_URL  = data.get("public_url", "").rstrip("/")
    if data.get("jwt_key"):
        _c.ONLYOFFICE_JWT_KEY = data["jwt_key"]

    # 持久化到 onlyoffice_config.json
    cfg_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "onlyoffice_config.json")
    try:
        with open(cfg_path, "w", encoding="utf-8") as f:
            json.dump({
                "enabled":    _c.ONLYOFFICE_ENABLED,
                "server":     _c.ONLYOFFICE_SERVER,
                "public_url": _c.SECFTP_PUBLIC_URL,
                "jwt_key":    getattr(_c, "ONLYOFFICE_JWT_KEY", ""),
            }, f, ensure_ascii=False, indent=2)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
