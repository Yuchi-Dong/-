# -*- coding: utf-8 -*-
"""
dao/file_dao.py — 文件相关数据访问层
涵盖：分享、版本、回收站、外链、锁、密级
"""
import os
import secrets
import hashlib
import shutil
from datetime import datetime, timedelta
from core.db import get_conn
import config


# ── 审计日志 ────────────────────────────────────────
def log_action(user_id, username, action, detail="", ip="", level="INFO"):
    """
    统一审计日志入口：转发到哈希链审计日志（audit_log_secure）。
    旧 audit_log 表保留但不再写入（维持历史数据查询能力）。
    """
    try:
        from product.audit.log import write as _aw, AuditCategory
        _aw(user_id, username, action, detail, ip, level,
            category=AuditCategory.FILE)
    except Exception as _e:
        import logging
        logging.getLogger("file_dao").warning(f"log_action 失败: {_e}")


def get_audit_logs(limit=200, user_id=None):
    with get_conn() as conn:
        if user_id:
            rows = conn.execute(
                "SELECT * FROM audit_log WHERE user_id=%s ORDER BY id DESC LIMIT %s",
                (user_id, limit)
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM audit_log ORDER BY id DESC LIMIT %s", (limit,)
            ).fetchall()
    return [dict(r) for r in rows]


# ── 文件分享 ────────────────────────────────────────
def create_share(owner_id, file_path, is_dir, share_type, target_id, perm, note, expires_at):
    with get_conn() as conn:
        return conn.execute(
            "INSERT INTO file_shares(owner_id,file_path,is_dir,share_type,target_id,perm,note,expires_at) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id",
            (owner_id, file_path, 1 if is_dir else 0, share_type, target_id, perm, note, expires_at)
        ).fetchone()[0]


def get_shares_received(user_id, org_id):
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fs.*, u.display_name as owner_name, u.username as owner_username,
                   tu.display_name as target_user_name, o.name as target_org_name
            FROM file_shares fs
            LEFT JOIN users u  ON u.id=fs.owner_id
            LEFT JOIN users tu ON tu.id=fs.target_id AND fs.share_type='user'
            LEFT JOIN organizations o ON o.id=fs.target_id AND fs.share_type='org'
            WHERE fs.is_active=1 AND fs.owner_id!=%s
              AND (fs.expires_at IS NULL OR fs.expires_at > NOW())
              AND ((fs.share_type='user' AND fs.target_id=%s)
                OR (fs.share_type='org'  AND fs.target_id=%s)
                OR  fs.share_type='public')
            ORDER BY fs.created_at DESC
        """, (user_id, user_id, org_id)).fetchall()
    return [dict(r) for r in rows]


def get_shares_sent(owner_id):
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fs.*, tu.display_name as target_user_name, o.name as target_org_name
            FROM file_shares fs
            LEFT JOIN users tu ON tu.id=fs.target_id AND fs.share_type='user'
            LEFT JOIN organizations o ON o.id=fs.target_id AND fs.share_type='org'
            WHERE fs.owner_id=%s AND fs.is_active=1
            ORDER BY fs.created_at DESC
        """, (owner_id,)).fetchall()
    return [dict(r) for r in rows]


def get_share_detail(owner_id, file_path):
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fs.id, fs.share_type, fs.perm, fs.note, fs.expires_at,
                   tu.display_name as target_user_name, tu.username as target_username,
                   o.name as target_org_name
            FROM file_shares fs
            LEFT JOIN users tu ON tu.id=fs.target_id AND fs.share_type='user'
            LEFT JOIN organizations o ON o.id=fs.target_id AND fs.share_type='org'
            WHERE fs.owner_id=%s AND fs.file_path=%s AND fs.is_active=1
              AND (fs.expires_at IS NULL OR fs.expires_at > NOW())
            ORDER BY fs.created_at DESC
        """, (owner_id, file_path)).fetchall()
    return [dict(r) for r in rows]


def revoke_share(share_id, owner_id):
    with get_conn() as conn:
        conn.execute(
            "UPDATE file_shares SET is_active=0 WHERE id=%s AND owner_id=%s", (share_id, owner_id)
        )


def check_shared_to(file_path, user_id, org_id) -> bool:
    """检查文件是否被分享给当前用户（单次 SQL）"""
    fp = file_path.strip("/")
    with get_conn() as conn:
        row = conn.execute("""
            SELECT id FROM file_shares
            WHERE is_active=1
              AND (expires_at IS NULL OR expires_at > NOW())
              AND (file_path=%s OR (%s LIKE file_path||'/' || '%%'))
              AND (
                  share_type='public'
                  OR (share_type='user' AND target_id=%s)
                  OR (share_type='org'  AND target_id=%s)
              )
            LIMIT 1
        """, (fp, fp, user_id or -1, org_id or -1)).fetchone()
    return row is not None


# ── 文件版本 ────────────────────────────────────────
def _versions_dir():
    d = os.path.join(os.path.dirname(config.FILE_ROOT), '.versions')
    os.makedirs(d, exist_ok=True)
    return d


def save_version(file_path, full_path, user_id, comment=''):
    if not os.path.isfile(full_path):
        return
    with get_conn() as conn:
        last = conn.execute(
            "SELECT COALESCE(MAX(version_no),0) FROM file_versions WHERE file_path=%s",
            (file_path,)
        ).fetchone()[0]
        ver_no = last + 1
        h = hashlib.sha256(file_path.encode()).hexdigest()[:8]
        backup_name = f"{h}_v{ver_no}_{os.path.basename(file_path)}"
        backup_path = os.path.join(_versions_dir(), backup_name)
        shutil.copy2(full_path, backup_path)
        size = os.path.getsize(full_path)
        conn.execute(
            "INSERT INTO file_versions(file_path,version_no,file_size,backup_path,created_by,comment) "
            "VALUES(%s,%s,%s,%s,%s,%s)",
            (file_path, ver_no, size, backup_path, user_id, comment)
        )
        # 清理超出版本上限的旧版本（上限由 config.MAX_FILE_VERSIONS 控制，默认 10）
        max_v = getattr(config, 'MAX_FILE_VERSIONS', 10)
        old = conn.execute(
            "SELECT id,backup_path FROM file_versions WHERE file_path=%s "
            "ORDER BY version_no DESC OFFSET %s",
            (file_path, max_v)
        ).fetchall()
        for row in old:
            try:
                if os.path.isfile(row['backup_path']):
                    os.remove(row['backup_path'])
            except Exception:
                pass
            conn.execute("DELETE FROM file_versions WHERE id=%s", (row['id'],))


def get_versions(file_path):
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fv.*, u.display_name, u.username FROM file_versions fv
            LEFT JOIN users u ON u.id=fv.created_by
            WHERE fv.file_path=%s ORDER BY fv.version_no DESC
        """, (file_path,)).fetchall()
    return [dict(r) for r in rows]


def get_version_by_id(version_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM file_versions WHERE id=%s", (version_id,)).fetchone()
    return dict(row) if row else None


def restore_version(version_id, full_path):
    row = get_version_by_id(version_id)
    if not row or not os.path.isfile(row['backup_path']):
        return False, "版本文件不存在"
    shutil.copy2(row['backup_path'], full_path)
    return True, ""


# ── 回收站 ──────────────────────────────────────────
def move_to_trash(file_path, full_path, user_id):
    import time
    is_dir = os.path.isdir(full_path)
    size   = 0 if is_dir else os.path.getsize(full_path)
    trash_base = os.path.join(os.path.dirname(config.FILE_ROOT), '.trash')
    os.makedirs(trash_base, exist_ok=True)
    trash_name = f"{int(time.time())}_{os.path.basename(full_path)}"
    trash_path = os.path.join(trash_base, trash_name)
    shutil.move(full_path, trash_path)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO trash(orig_path,trash_path,is_dir,file_size,deleted_by) VALUES(%s,%s,%s,%s,%s)",
            (file_path, trash_path, 1 if is_dir else 0, size, user_id)
        )


def get_trash(user_id, is_super=False):
    with get_conn() as conn:
        if is_super:
            rows = conn.execute("""
                SELECT t.*, u.display_name, u.username FROM trash t
                LEFT JOIN users u ON u.id=t.deleted_by
                ORDER BY t.deleted_at DESC LIMIT 200
            """).fetchall()
        else:
            rows = conn.execute("""
                SELECT t.*, u.display_name, u.username FROM trash t
                LEFT JOIN users u ON u.id=t.deleted_by
                WHERE t.deleted_by=%s ORDER BY t.deleted_at DESC LIMIT 100
            """, (user_id,)).fetchall()
    return [dict(r) for r in rows]


def restore_from_trash(trash_id, user_id, is_super=False):
    with get_conn() as conn:
        if is_super:
            row = conn.execute("SELECT * FROM trash WHERE id=%s", (trash_id,)).fetchone()
        else:
            row = conn.execute("SELECT * FROM trash WHERE id=%s AND deleted_by=%s",
                               (trash_id, user_id)).fetchone()
        if not row:
            return False, "记录不存在"
        if not os.path.exists(row['trash_path']):
            return False, "回收站文件已丢失"
        orig_full = os.path.join(config.FILE_ROOT, row['orig_path'])
        if os.path.exists(orig_full):
            return False, "原路径已存在文件，请先重命名"
        os.makedirs(os.path.dirname(orig_full), exist_ok=True)
        shutil.move(row['trash_path'], orig_full)
        conn.execute("DELETE FROM trash WHERE id=%s", (trash_id,))
    return True, ""


def empty_trash_item(trash_id, user_id, is_super=False):
    with get_conn() as conn:
        if is_super:
            row = conn.execute("SELECT * FROM trash WHERE id=%s", (trash_id,)).fetchone()
        else:
            row = conn.execute("SELECT * FROM trash WHERE id=%s AND deleted_by=%s",
                               (trash_id, user_id)).fetchone()
        if not row:
            return False
        try:
            if os.path.isdir(row['trash_path']):  shutil.rmtree(row['trash_path'])
            elif os.path.isfile(row['trash_path']): os.remove(row['trash_path'])
        except Exception:
            pass
        conn.execute("DELETE FROM trash WHERE id=%s", (trash_id,))
    return True


# ── 公开外链 ────────────────────────────────────────
def _hash_pw(salt, password):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()


def create_public_link(file_path, is_dir, perm, password, expires_at, user_id):
    token   = secrets.token_urlsafe(16)
    pw_hash = ""
    pw_salt = ""
    if password:
        pw_salt = secrets.token_hex(16)
        pw_hash = _hash_pw(pw_salt, password)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO public_links(token,file_path,is_dir,perm,pw_hash,pw_salt,expires_at,created_by) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s,%s)",
            (token, file_path, 1 if is_dir else 0, perm, pw_hash, pw_salt, expires_at or None, user_id)
        )
    return token


def get_public_link(token):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM public_links WHERE token=%s AND is_active=1", (token,)
        ).fetchone()
    return dict(row) if row else None


def verify_link_password(link, password):
    if not link.get('pw_hash'):
        return True
    pw_salt = link.get('pw_salt', '')
    expected = _hash_pw(pw_salt, password) if pw_salt else hashlib.sha256(password.encode()).hexdigest()
    return secrets.compare_digest(expected, link['pw_hash'])


def increment_link_views(token):
    with get_conn() as conn:
        conn.execute(
            "UPDATE public_links SET view_count=view_count+1 WHERE token=%s", (token,)
        )


def get_my_links(user_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM public_links WHERE created_by=%s AND is_active=1 ORDER BY created_at DESC",
            (user_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def revoke_public_link(link_id, user_id):
    with get_conn() as conn:
        conn.execute(
            "UPDATE public_links SET is_active=0 WHERE id=%s AND created_by=%s", (link_id, user_id)
        )


# ── 文件锁 ──────────────────────────────────────────
def lock_file(file_path, user_id, hours=8):
    expires = (datetime.now() + timedelta(hours=hours)).strftime('%Y-%m-%d %H:%M:%S')
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO file_locks(file_path,locked_by,locked_at,expires_at) "
            "VALUES(%s,%s,NOW(),%s) ON CONFLICT(file_path) DO UPDATE "
            "SET locked_by=EXCLUDED.locked_by, locked_at=NOW(), expires_at=EXCLUDED.expires_at",
            (file_path, user_id, expires)
        )


def unlock_file(file_path, user_id, is_super=False):
    with get_conn() as conn:
        if is_super:
            conn.execute("DELETE FROM file_locks WHERE file_path=%s", (file_path,))
        else:
            conn.execute(
                "DELETE FROM file_locks WHERE file_path=%s AND locked_by=%s", (file_path, user_id)
            )


def get_lock_info(file_path):
    with get_conn() as conn:
        row = conn.execute("""
            SELECT fl.*, u.display_name, u.username FROM file_locks fl
            LEFT JOIN users u ON u.id=fl.locked_by
            WHERE fl.file_path=%s
              AND (fl.expires_at IS NULL OR fl.expires_at > NOW())
        """, (file_path,)).fetchone()
    return dict(row) if row else None


# ── 密级标签 ────────────────────────────────────────
LABELS = {
    'public':       {'name': '公开',  'color': '#1a7a40', 'bg': '#e6f5ec'},
    'internal':     {'name': '内部',  'color': '#1560bd', 'bg': '#eaf2ff'},
    'confidential': {'name': '机密',  'color': '#b8860b', 'bg': '#fef9e7'},
    'secret':       {'name': '绝密',  'color': '#c62828', 'bg': '#fff0f0'},
}


def set_label(file_path, label, user_id):
    if label not in LABELS:
        return
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO file_labels(file_path,label,set_by) VALUES(%s,%s,%s) "
            "ON CONFLICT(file_path) DO UPDATE SET label=EXCLUDED.label, set_by=EXCLUDED.set_by",
            (file_path, label, user_id)
        )


def get_label(file_path):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT label FROM file_labels WHERE file_path=%s", (file_path,)
        ).fetchone()
    return row['label'] if row else None


def get_labels_for_dir(dir_path):
    with get_conn() as conn:
        dp = dir_path.rstrip('/') + '/'
        rows = conn.execute(
            "SELECT file_path, label FROM file_labels WHERE file_path LIKE %s OR file_path=%s",
            (dp + '%', dir_path)
        ).fetchall()
    return {r['file_path']: r['label'] for r in rows}
