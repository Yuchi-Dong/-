# -*- coding: utf-8 -*-
"""
compliance/watermark.py — 文件水印（政务版）

对下载/预览的文件叠加水印：
  - PDF：使用 pypdf 叠加透明文字水印
  - 图片：使用 Pillow 叠加文字水印
  - Office：下载时提示水印说明（完整水印需 LibreOffice 转 PDF 后叠加）

水印内容：单位名称 + 姓名 + 时间 + IP
"""
import os
import io
import hashlib
import tempfile
from datetime import datetime
from pathlib import Path


def _make_watermark_text(username: str, display_name: str,
                          org_name: str = '', ip: str = '') -> str:
    ts = datetime.now().strftime('%Y-%m-%d %H:%M')
    name = display_name or username
    parts = [org_name, name, ts]
    if ip:
        parts.append(ip)
    return '  '.join(p for p in parts if p)


def apply_pdf_watermark(src_path: str, username: str, display_name: str,
                         org_name: str = '', ip: str = '') -> bytes:
    """
    给 PDF 叠加半透明对角水印，返回带水印的 PDF 字节流。
    """
    try:
        from pypdf import PdfReader, PdfWriter
        from pypdf.generic import (
            ArrayObject, DecodedStreamObject, NameObject, NumberObject,
            ByteStringObject
        )
    except ImportError:
        # pypdf 不可用，返回原文件
        with open(src_path, 'rb') as f:
            return f.read()

    try:
        import reportlab
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas as rl_canvas
        from reportlab.lib.colors import Color

        wm_text = _make_watermark_text(username, display_name, org_name, ip)

        # 生成水印页
        packet = io.BytesIO()
        w, h   = A4
        c      = rl_canvas.Canvas(packet, pagesize=A4)
        c.setFont('Helvetica', 28)
        c.setFillColor(Color(0.6, 0.6, 0.6, alpha=0.25))
        c.saveState()
        c.translate(w / 2, h / 2)
        c.rotate(45)
        c.drawCentredString(0, 0, wm_text)
        c.restoreState()
        c.save()
        packet.seek(0)
        wm_pdf = PdfReader(packet)
        wm_page = wm_pdf.pages[0]

        reader = PdfReader(src_path)
        writer = PdfWriter()
        for page in reader.pages:
            page.merge_page(wm_page)
            writer.add_page(page)

        out = io.BytesIO()
        writer.write(out)
        return out.getvalue()

    except Exception:
        # 水印失败静默降级，返回原文件
        with open(src_path, 'rb') as f:
            return f.read()


def apply_image_watermark(src_path: str, username: str, display_name: str,
                           org_name: str = '', ip: str = '') -> bytes:
    """
    给图片叠加水印，返回带水印的图片字节流（保持原格式）。
    """
    try:
        from PIL import Image, ImageDraw, ImageFont
        import math

        wm_text = _make_watermark_text(username, display_name, org_name, ip)
        img     = Image.open(src_path).convert('RGBA')
        w, h    = img.size

        # 水印层（透明）
        wm_layer = Image.new('RGBA', (w, h), (0, 0, 0, 0))
        draw     = ImageDraw.Draw(wm_layer)

        # 字体大小按图片宽度自适应
        font_size = max(20, w // 40)
        try:
            font = ImageFont.truetype('arial.ttf', font_size)
        except Exception:
            font = ImageFont.load_default()

        # 计算文字尺寸
        bbox    = draw.textbbox((0, 0), wm_text, font=font)
        tw, th  = bbox[2] - bbox[0], bbox[3] - bbox[1]

        # 平铺水印（45度倾斜，间距适中）
        step_x = tw + 80
        step_y = th + 60
        for y in range(-h, h * 2, step_y):
            for x in range(-w, w * 2, step_x):
                # 旋转每个水印块
                tmp = Image.new('RGBA', (tw + 20, th + 20), (0, 0, 0, 0))
                d   = ImageDraw.Draw(tmp)
                d.text((10, 10), wm_text, fill=(100, 100, 100, 60), font=font)
                rotated = tmp.rotate(30, expand=True)
                wm_layer.paste(rotated, (x, y), rotated)

        # 合并
        out_img = Image.alpha_composite(img, wm_layer)
        out     = io.BytesIO()
        fmt     = Path(src_path).suffix.lstrip('.').upper()
        fmt     = fmt if fmt in ('JPEG', 'JPG', 'PNG', 'WEBP') else 'PNG'
        if fmt == 'JPG': fmt = 'JPEG'
        out_img.convert('RGB' if fmt == 'JPEG' else 'RGBA').save(out, format=fmt)
        return out.getvalue()

    except Exception:
        with open(src_path, 'rb') as f:
            return f.read()


def needs_watermark(filepath: str) -> bool:
    """判断文件是否需要叠加水印"""
    ext = Path(filepath).suffix.lower()
    return ext in ('.pdf', '.jpg', '.jpeg', '.png', '.webp', '.bmp')


def get_watermarked_response(src_path: str, username: str, display_name: str,
                              org_name: str = '', ip: str = ''):
    """
    返回带水印的文件内容（bytes）。
    调用方负责设置正确的 Content-Type。
    """
    ext = Path(src_path).suffix.lower()
    if ext == '.pdf':
        return apply_pdf_watermark(src_path, username, display_name, org_name, ip)
    elif ext in ('.jpg', '.jpeg', '.png', '.webp', '.bmp'):
        return apply_image_watermark(src_path, username, display_name, org_name, ip)
    else:
        with open(src_path, 'rb') as f:
            return f.read()
