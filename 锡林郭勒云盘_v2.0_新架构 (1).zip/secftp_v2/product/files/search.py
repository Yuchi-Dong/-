"""
SecFTP Pro — 文件搜索引擎
支持: 文件名模糊搜索 / 类型过滤 / 按权限范围搜索
"""
import os
from pathlib import Path
from datetime import datetime
import config


# ── 文件类型分类 ────────────────────────────────────
EXT_MAP = {
    "image":  {".jpg",".jpeg",".png",".gif",".bmp",".webp",".svg",".tiff",".heic",".heif",".avif"},
    "pdf":    {".pdf"},
    "ofd":    {".ofd"},
    "text":   {".txt",".md",".csv",".log",".json",".xml",".yaml",".yml",".ini",
               ".conf",".toml",".sh",".bat",".ps1",".py",".js",".ts",".css",
               ".html",".htm",".sql",".env"},
    "office": {".doc",".docx",".xls",".xlsx",".ppt",".pptx",".wps",".et",".dps",
               ".odt",".ods",".odp",".rtf"},
    "zip":    {".zip",".rar",".7z",".tar",".gz",".bz2",".xz",".tar.gz"},
    "video":  {".mp4",".avi",".mkv",".mov",".wmv",".flv",".webm",".m4v",
               ".mpg",".mpeg",".3gp",".ts",".mts",".m2ts",".vob",".ogv",".rm",".rmvb"},
    "audio":  {".mp3",".wav",".flac",".aac",".ogg",".wma",".m4a",".opus",
               ".ape",".aiff",".au",".mid",".midi"},
}

def classify(ext: str) -> str:
    ext = ext.lower()
    for ftype, exts in EXT_MAP.items():
        if ext in exts: return ftype
    return "other"


def fmt_size(n: float) -> str:
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024: return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} TB"


# ── 核心搜索 ────────────────────────────────────────
def search_files(uid, role, org_id, query: str,
                 file_type: str = None, max_results: int = 100) -> list:
    """
    在当前用户有权限的路径范围内搜索文件。
    - query: 文件名关键词（大小写不敏感）
    - file_type: image / pdf / text / office / zip / other (None=不过滤)
    - 返回: 文件信息列表，按匹配精度排序
    """
    from models import get_authorized_paths

    query = query.strip().lower()
    if not query:
        return []

    root = os.path.realpath(config.FILE_ROOT)
    auth = get_authorized_paths(uid, role, org_id)

    # 确定搜索根目录集合（去重、归并）
    search_roots = set()
    for ap in auth:
        p = ap["path"].strip("/")
        if p == "" and role == 0:
            search_roots.add(root); break
        full = os.path.realpath(os.path.join(root, p))
        if os.path.exists(full):
            search_roots.add(full)

    results = []
    seen    = set()

    for sr in search_roots:
        for dirpath, dirnames, filenames in os.walk(sr, topdown=True):
            # 跳过隐藏目录
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]

            for fname in filenames:
                if fname.startswith("."): continue
                if query not in fname.lower(): continue

                full_path = os.path.join(dirpath, fname)
                if full_path in seen: continue
                seen.add(full_path)

                ext   = Path(fname).suffix
                ftype = classify(ext)
                if file_type and ftype != file_type: continue

                try:
                    rel = os.path.relpath(full_path, root).replace("\\", "/")
                except ValueError:
                    continue

                stat = os.stat(full_path)

                # 确定权限
                perm = "ro"
                for ap in auth:
                    ap_p = ap["path"].strip("/")
                    if ap_p == "" or rel.startswith(ap_p + "/") or rel == ap_p:
                        perm = ap["perm"]; break
                if role == 0:
                    perm = "rw"

                # 匹配精度评分（0=完全匹配，1=前缀，2=包含）
                name_lower = fname.lower()
                if name_lower == query:              score = 0
                elif name_lower.startswith(query):   score = 1
                else:                                score = 2

                results.append({
                    "name":      fname,
                    "rel_path":  rel,
                    "dir":       os.path.dirname(rel).replace("\\", "/"),
                    "ftype":     ftype,
                    "ext":       ext.lower(),
                    "size_str":  fmt_size(stat.st_size),
                    "mtime":     datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                    "perm":      perm,
                    "file_url":  f"/file/{rel}",
                    "score":     score,
                })

                if len(results) >= max_results:
                    results.sort(key=lambda r: (r["score"], r["name"]))
                    return results

    results.sort(key=lambda r: (r["score"], r["name"].lower()))
    return results
