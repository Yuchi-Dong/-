# -*- coding: utf-8 -*-
"""
product/files/search_pg.py — PostgreSQL 全文搜索

方案：PostgreSQL tsvector + 中文字符级分词（无需 pg_jieba 插件）
对于政务场景（内网无法装额外插件），使用"字符级 n-gram"分词：
  每2个汉字提取一个 token，覆盖中文词语边界
  例如："审计日志" → "审计" "计日" "日志"

效果：
  - 支持 2 字以上任意中文词语搜索
  - 支持英文单词全文搜索
  - 搜索速度：文件名 + 标签索引后 < 5ms（百万级）
  - 内容搜索：PDF/Word 提取文本后索引（可选，加密文件跳过）

如果服务器可以安装 pg_jieba，在 search_pg.py 顶部设置 USE_JIEBA=True，
自动切换到词级分词，搜索精度更高。
"""
from core.db import get_conn
import logging
import re

log = logging.getLogger("search")

USE_JIEBA = False   # 设为 True 并安装 pg_jieba 后启用词级分词


def _ngram_tokenize(text: str, n: int = 2) -> str:
    """
    中文字符级 n-gram 分词，用于 tsvector。
    英文按空格切词，中文每 n 个字符一个 token。
    """
    tokens = []
    # 英文数字直接按空格切
    en_parts = re.sub(r'[\u4e00-\u9fff]+', ' ', text)
    for word in en_parts.lower().split():
        if len(word) >= 2:
            tokens.append(word)
    # 中文 n-gram
    chinese = re.findall(r'[\u4e00-\u9fff]+', text)
    for seg in chinese:
        for i in range(len(seg) - n + 1):
            tokens.append(seg[i:i+n])
        if len(seg) < n:
            tokens.append(seg)
    return " ".join(dict.fromkeys(tokens))   # 去重保序


def update_file_index(file_path: str, file_name: str, ftype: str,
                       file_size: int, file_hash: str = "",
                       tags: str = "", summary: str = "",
                       content_text: str = "") -> None:
    """
    写入/更新文件索引（上传时调用）。
    content_text：从 PDF/Word 提取的文本内容（加密文件为空）
    """
    # 构建全文搜索向量
    search_text = f"{file_name} {tags} {summary}"
    if content_text:
        # 最多索引前 50000 字符（防止大文件占满内存）
        search_text += " " + content_text[:50000]

    tokens  = _ngram_tokenize(search_text)

    # 根据配置选择 tsvector 函数（固定常量，无 f-string 风险）
    tsv_jieba  = "to_tsvector('jieba',  %s)"
    tsv_simple = "to_tsvector('simple', %s)"

    if USE_JIEBA:
        insert_sql = (
            "INSERT INTO file_index "
            "  (file_path, file_name, ftype, file_size, file_hash, "
            "   tags, summary, is_encrypted, search_vector) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, FALSE, " + tsv_jieba + ") "
            "ON CONFLICT(file_path) DO UPDATE SET "
            "  file_name=%s, ftype=%s, file_size=%s, file_hash=%s, "
            "  tags=%s, summary=%s, "
            "  search_vector=" + tsv_jieba + ", indexed_at=NOW()"
        )
    else:
        insert_sql = (
            "INSERT INTO file_index "
            "  (file_path, file_name, ftype, file_size, file_hash, "
            "   tags, summary, is_encrypted, search_vector) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s, FALSE, " + tsv_simple + ") "
            "ON CONFLICT(file_path) DO UPDATE SET "
            "  file_name=%s, ftype=%s, file_size=%s, file_hash=%s, "
            "  tags=%s, summary=%s, "
            "  search_vector=" + tsv_simple + ", indexed_at=NOW()"
        )

    with get_conn() as conn:
        conn.execute(insert_sql, (
            file_path, file_name, ftype, file_size, file_hash, tags, summary,
            tokens,      # INSERT search_vector
            file_name, ftype, file_size, file_hash, tags, summary,
            tokens,      # UPDATE search_vector
        ))


def search_files(query: str, ftype: str = "", limit: int = 50,
                 user_paths: list = None) -> list[dict]:
    """
    全文搜索文件。
    query:      搜索关键词
    ftype:      文件类型过滤（空=所有）
    user_paths: 权限过滤，仅搜索指定前缀（None=所有，管理员用）
    """
    if not query.strip():
        return []

    # 构建搜索 token
    tokens = _ngram_tokenize(query)
    if not tokens:
        return []

    # tsquery：所有 token AND 连接
    tsquery_tokens = " & ".join(f"{t}:*" for t in tokens.split()[:10])

    # 权限过滤子句
    path_clauses = []
    path_params  = []
    if user_paths:
        for p in user_paths:
            path_clauses.append("file_path LIKE %s")
            path_params.append(f"{p}/%")

    type_clause  = "AND ftype=%s" if ftype else ""
    path_clause  = ("AND (" + " OR ".join(path_clauses) + ")") if path_clauses else ""

    params = [tsquery_tokens] + path_params
    if ftype:
        params.append(ftype)
    params.append(limit)

    with get_conn() as conn:
        # 先尝试 tsvector 搜索
        try:
            # 构建 WHERE 子句（白名单条件，非用户输入字段名）
            where_parts = ["search_vector @@ to_tsquery('simple', %s)"]
            q_params    = [tsquery_tokens]
            if ftype:
                where_parts.append("ftype=%s"); q_params.append(ftype)
            for pc in path_clauses:
                where_parts.append(pc)
            q_params.extend(path_params)
            q_params.append(limit)

            where_sql = " AND ".join(where_parts)
            search_sql = (
                "SELECT file_path, file_name, ftype, file_size, tags, summary, "
                "       ts_rank(search_vector, to_tsquery('simple', %s)) as rank "
                "FROM file_index WHERE " + where_sql + " "
                "ORDER BY rank DESC, indexed_at DESC LIMIT %s"
            )
            rows = conn.execute(search_sql, [tsquery_tokens] + q_params).fetchall()
        except Exception:
            # 降级：ILIKE 搜索
            rows = _fallback_ilike(conn, query, ftype, path_clauses, path_params, limit)

    return [dict(r) for r in rows]


def _fallback_ilike(conn, query, ftype, path_clauses, path_params, limit):
    """降级到 ILIKE 搜索（不依赖 tsvector）"""
    type_clause = "AND ftype=%s" if ftype else ""
    path_clause = ("AND (" + " OR ".join(path_clauses) + ")") if path_clauses else ""
    params = [f"%{query}%", f"%{query}%"]
    if ftype: params.append(ftype)
    params.extend(path_params)
    params.append(limit)
    where_parts = ["(file_name ILIKE %s OR tags ILIKE %s)"]
    if ftype: where_parts.append("ftype=%s")
    for pc in path_clauses: where_parts.append(pc)
    fb_sql = (
        "SELECT file_path, file_name, ftype, file_size, tags, summary, 1.0 as rank "
        "FROM file_index WHERE " + " AND ".join(where_parts) + " "
        "ORDER BY indexed_at DESC LIMIT %s"
    )
    return conn.execute(fb_sql, params).fetchall()


def ensure_search_index() -> None:
    """
    确保 file_index 表有 search_vector 列和 GIN 索引。
    首次部署时调用，或在 models.py init_db() 之后调用。
    """
    with get_conn() as conn:
        # 补充 search_vector 列
        conn.execute("""
            ALTER TABLE file_index
            ADD COLUMN IF NOT EXISTS search_vector tsvector
        """)
        # GIN 索引（全文搜索必需，百万行下 < 5ms）
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_fi_search
            ON file_index USING gin(search_vector)
        """)
        # 补全现有行的 search_vector（全量重建索引）
        conn.execute("""
            UPDATE file_index
            SET search_vector = to_tsvector('simple',
                COALESCE(file_name,'') || ' ' || COALESCE(tags,'') || ' ' || COALESCE(summary,''))
            WHERE search_vector IS NULL
        """)
    log.info("✓ search_vector 列和 GIN 索引已就绪")
