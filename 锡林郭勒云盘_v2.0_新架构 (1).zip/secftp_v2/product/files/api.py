# -*- coding: utf-8 -*-
"""
product/files/api.py — 文件管理 REST API

路由：
  GET    /api/files/list          列出目录
  POST   /api/files/upload        普通上传
  POST   /api/files/mkdir         新建文件夹
  POST   /api/files/delete        删除（移入回收站）
  POST   /api/files/rename        重命名
  POST   /api/files/move          移动
  POST   /api/files/copy          复制
  POST   /api/files/batch         批量操作
  GET    /api/files/download      下载（重定向）
  GET    /api/files/preview       预览信息（URL+类型）
  GET    /api/files/search        搜索

  # 分片上传（断点续传 + 秒传）
  POST   /api/upload/init         初始化上传会话（含秒传检查）
  POST   /api/upload/chunk        上传分片
  POST   /api/upload/complete     完成合并
  GET    /api/upload/status/<id>  查询进度
  POST   /api/upload/cancel       取消上传

  # 分享
  GET    /api/shares              我的分享列表
  POST   /api/shares              创建分享
  DELETE /api/shares/<id>         取消分享
  GET    /api/shares/received     收到的分享

  # 回收站
  GET    /api/trash               回收站列表
  POST   /api/trash/restore       恢复
  DELETE /api/trash/<id>          彻底删除
  POST   /api/trash/empty         清空回收站

  # 评论
  GET    /api/files/comments      文件评论
  POST   /api/files/comments      发表评论
  DELETE /api/files/comments/<id> 删除评论
"""
import hashlib
import json
import mimetypes
import os
import shutil
import time
from datetime import datetime, timedelta
from pathlib import Path

from flask import Blueprint, request, jsonify, g, send_file, abort

import config
from core.auth.jwt_auth import jwt_required
from core.db import get_conn
from core.storage import get_storage

bp = Blueprint("files_api", __name__, url_prefix="/api")

# 文件类型图标和颜色映射
FTYPE_META = {
    "dir":   {"icon": "📁", "color": "#f59e0b", "bg": "#fef3c7"},
    "image": {"icon": "🖼️", "color": "#3b82f6", "bg": "#dbeafe"},
    "video": {"icon": "🎬", "color": "#8b5cf6", "bg": "#ede9fe"},
    "audio": {"icon": "🎵", "color": "#ec4899", "bg": "#fce7f3"},
    "pdf":   {"icon": "📄", "color": "#ef4444", "bg": "#fee2e2"},
    "word":  {"icon": "📝", "color": "#2563eb", "bg": "#dbeafe"},
    "excel": {"icon": "📊", "color": "#16a34a", "bg": "#dcfce7"},
    "ppt":   {"icon": "📈", "color": "#f59e0b", "bg": "#fef3c7"},
    "zip":   {"icon": "🗜️", "color": "#64748b", "bg": "#f1f5f9"},
    "text":  {"icon": "📃", "color": "#06b6d4", "bg": "#cffafe"},
    "code":  {"icon": "💻", "color": "#0d9488", "bg": "#ccfbf1"},
    "other": {"icon": "📦", "color": "#9ca3af", "bg": "#f3f4f6"},
}

def _classify(ext: str) -> str:
    e = ext.lower().lstrip(".")
    if e in ("jpg","jpeg","png","gif","webp","bmp","svg","tiff"): return "image"
    if e == "pdf":                                                 return "pdf"
    if e in ("mp4","mkv","avi","mov","wmv","flv","m4v"):          return "video"
    if e in ("mp3","wav","flac","aac","ogg","m4a"):               return "audio"
    if e in ("doc","docx","odt","wps"):                           return "word"
    if e in ("xls","xlsx","ods","csv","et"):                      return "excel"
    if e in ("ppt","pptx","odp","dps"):                           return "ppt"
    if e in ("zip","rar","7z","tar","gz","bz2"):                  return "zip"
    if e in ("txt","md","log","conf","ini","yaml","yml","toml"):  return "text"
    if e in ("py","js","ts","vue","html","css","json","xml",
             "sh","bash","c","cpp","java","go","rs","php"):       return "code"
    return "other"


def _fmt_size(n: int) -> str:
    for u in ("B","KB","MB","GB","TB"):
        if n < 1024: return f"{n:.1f} {u}" if n != int(n) else f"{int(n)} {u}"
        n /= 1024
    return f"{n:.1f} TB"


def _can(path: str, need_write: bool = False) -> bool:
    """权限检查（包装 permission 模块）"""
    if g.role == 0:
        return True
    try:
        from core.auth.permission import can_access
        return can_access(path, g.uid, g.role, g.org_id, need_write)
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════
#  目录列表
# ══════════════════════════════════════════════════════════════
@bp.route("/files/list")
@jwt_required
def list_dir():
    path     = request.args.get("path", "").strip("/")
    full     = os.path.join(config.FILE_ROOT, path) if path else config.FILE_ROOT

    if not os.path.isdir(full):
        return jsonify({"error": "目录不存在"}), 404

    if path and not _can(path):
        return jsonify({"error": "无访问权限"}), 403

    items = []
    try:
        for entry in sorted(os.scandir(full), key=lambda e: (not e.is_dir(), e.name.lower())):
            name = entry.name
            # 过滤隐藏文件和系统目录
            if name.startswith("."):
                continue
            # 过滤 .enc 加密文件（透明化）
            if name.endswith(".enc"):
                name = name[:-4]
                # 避免重复（原始名已存在）
                plain = os.path.join(full, name)
                if os.path.exists(plain):
                    continue

            rel  = f"{path}/{name}".lstrip("/") if path else name
            stat = entry.stat()
            ext  = Path(name).suffix if not entry.is_dir() else ""
            ft   = "dir" if entry.is_dir() else _classify(ext)
            meta = FTYPE_META.get(ft, FTYPE_META["other"])

            # 文件大小（加密文件用 DB 中的明文大小）
            size = 0
            if not entry.is_dir():
                try:
                    with get_conn() as conn:
                        row = conn.execute(
                            "SELECT plaintext_size FROM file_keys WHERE file_path=%s", (rel,)
                        ).fetchone()
                    size = row["plaintext_size"] if row else stat.st_size
                except Exception:
                    size = stat.st_size

            items.append({
                "rel":       rel,
                "name":      name,
                "is_dir":    entry.is_dir(),
                "ftype":     ft,
                "icon":      meta["icon"],
                "color":     meta["color"],
                "bg":        meta["bg"],
                "size":      size,
                "size_str":  "—" if entry.is_dir() else _fmt_size(size),
                "mtime":     datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                "mtime_ts":  int(stat.st_mtime),
                "can_write": _can(rel, True),
                "is_encrypted": _is_encrypted(rel),
                "is_shared": False,   # 由分享接口单独提供
            })
    except PermissionError:
        pass

    return jsonify({
        "path":   path,
        "items":  items,
        "count":  len(items),
    })


def _is_encrypted(rel_path: str) -> bool:
    """判断文件是否已加密（检查 file_keys 表）"""
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT id FROM file_keys WHERE file_path=%s", (rel_path,)
            ).fetchone()
        return row is not None
    except Exception:
        return False


# ══════════════════════════════════════════════════════════════
#  新建文件夹
# ══════════════════════════════════════════════════════════════
@bp.route("/files/mkdir", methods=["POST"])
@jwt_required
def mkdir():
    data   = request.get_json(silent=True) or {}
    parent = (data.get("parent") or "").strip("/")
    name   = (data.get("name") or "").strip()

    if not name:
        return jsonify({"error": "文件夹名不能为空"}), 400

    # 安全检查
    if any(c in name for c in r'\/:*?"<>|'):
        return jsonify({"error": "文件夹名包含非法字符"}), 400

    rel  = f"{parent}/{name}".lstrip("/") if parent else name
    full = os.path.join(config.FILE_ROOT, rel)

    if not _can(parent or "", True):
        return jsonify({"error": "无写入权限"}), 403

    if os.path.exists(full):
        return jsonify({"error": "同名文件或文件夹已存在"}), 400

    os.makedirs(full)
    _audit("MKDIR", rel)
    return jsonify({"success": True, "path": rel})


# ══════════════════════════════════════════════════════════════
#  普通上传（小文件，< 100MB）
# ══════════════════════════════════════════════════════════════
@bp.route("/files/upload", methods=["POST"])
@jwt_required
def upload():
    path      = (request.form.get("path") or f"users/{g.username}").strip("/")
    upload_dir = os.path.join(config.FILE_ROOT, path)

    if not _can(path, True):
        return jsonify({"error": "无写入权限"}), 403

    if not request.files:
        return jsonify({"error": "没有上传文件"}), 400

    os.makedirs(upload_dir, exist_ok=True)
    saved = []
    errors = []

    for f in request.files.getlist("files"):
        if not f.filename:
            continue
        from core.auth.guards import secure_filename
        safe_name = secure_filename(f.filename)
        if not safe_name:
            errors.append(f.filename)
            continue

        ext = Path(safe_name).suffix.lower()
        if ext not in config.UPLOAD_WHITELIST:
            errors.append(f"{safe_name}（不允许的文件类型）")
            continue

        dest_key = f"{path}/{safe_name}"
        try:
            f.seek(0)
            get_storage().put(dest_key, f.stream)
            saved.append(safe_name)
            _audit("UPLOAD", dest_key)
            # 触发索引
            try:
                from product.files.indexer import async_index
                dest_full = os.path.join(upload_dir, safe_name)
                async_index(dest_full, dest_key)
            except Exception:
                pass
        except Exception as e:
            errors.append(f"{safe_name}: {e}")

    if not saved:
        return jsonify({"error": "上传失败", "details": errors}), 500

    return jsonify({"success": True, "saved": saved, "errors": errors})


# ══════════════════════════════════════════════════════════════
#  分片上传（断点续传 + 秒传）
# ══════════════════════════════════════════════════════════════
@bp.route("/upload/init", methods=["POST"])
@jwt_required
def upload_init():
    """
    初始化上传会话。
    秒传：如果文件 hash 已存在，直接返回 {instant: true, file_path}。
    断点续传：如果已有未完成会话，返回 uploaded_chunks。
    """
    data         = request.get_json(silent=True) or {}
    filename     = (data.get("filename") or "").strip()
    file_size    = int(data.get("size", 0))
    file_hash    = (data.get("hash") or "").strip().lower()
    total_chunks = int(data.get("total_chunks", 1))
    path         = (data.get("path") or f"users/{g.username}").strip("/")

    if not filename:
        return jsonify({"error": "文件名不能为空"}), 400

    if not _can(path, True):
        return jsonify({"error": "无写入权限"}), 403

    from core.auth.guards import secure_filename
    safe_name = secure_filename(filename) or filename.replace("/", "_")
    ext = Path(safe_name).suffix.lower()
    if ext not in config.UPLOAD_WHITELIST:
        return jsonify({"error": f"不允许上传 {ext} 类型文件"}), 400

    # ── 秒传检查 ──────────────────────────────────────
    if file_hash and len(file_hash) in (32, 64):
        with get_conn() as conn:
            # 在 file_index 里查 hash
            existing = conn.execute(
                "SELECT file_path FROM file_index WHERE file_hash=%s LIMIT 1",
                (file_hash,)
            ).fetchone()
        if existing:
            _audit("UPLOAD_INSTANT", f"{path}/{safe_name} (秒传)")
            return jsonify({
                "instant":   True,
                "file_path": existing["file_path"],
                "filename":  safe_name,
                "message":   "秒传成功（文件已存在）",
            })

    # ── 断点续传：查已有会话 ───────────────────────────
    with get_conn() as conn:
        existing_session = conn.execute(
            "SELECT * FROM upload_sessions "
            "WHERE user_id=%s AND filename=%s AND rel_path=%s AND status='active' "
            "ORDER BY created_at DESC LIMIT 1",
            (g.uid, safe_name, path)
        ).fetchone()

    if existing_session:
        done = existing_session["done_chunks"]
        if isinstance(done, str):
            done = json.loads(done)
        return jsonify({
            "instant":         False,
            "upload_id":       existing_session["id"],
            "uploaded_chunks": done,
            "filename":        safe_name,
            "resuming":        True,
        })

    # ── 新建会话 ──────────────────────────────────────
    import secrets
    upload_id = secrets.token_hex(16)
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO upload_sessions(id,user_id,filename,rel_path,"
            "file_size,file_hash,total_chunks,done_chunks,status) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s,'[]'::jsonb,'active')",
            (upload_id, g.uid, safe_name, path, file_size, file_hash, total_chunks)
        )

    return jsonify({
        "instant":         False,
        "upload_id":       upload_id,
        "uploaded_chunks": [],
        "filename":        safe_name,
        "resuming":        False,
    })


@bp.route("/upload/chunk", methods=["POST"])
@jwt_required
def upload_chunk():
    """接收单个分片，支持并发上传"""
    upload_id   = request.form.get("upload_id", "")
    chunk_index = int(request.form.get("chunk_index", 0))
    chunk_file  = request.files.get("chunk")

    if not upload_id or chunk_file is None:
        return jsonify({"error": "参数缺失"}), 400

    with get_conn() as conn:
        sess = conn.execute(
            "SELECT * FROM upload_sessions WHERE id=%s AND user_id=%s",
            (upload_id, g.uid)
        ).fetchone()

    if not sess:
        return jsonify({"error": "上传会话不存在或已过期"}), 404

    total_chunks = sess["total_chunks"]

    # 保存分片到临时目录
    tmp_dir = os.path.join(os.path.dirname(config.FILE_ROOT), ".upload_tmp", upload_id)
    os.makedirs(tmp_dir, exist_ok=True)
    chunk_path = os.path.join(tmp_dir, f"{chunk_index:06d}.chunk")
    chunk_file.save(chunk_path)

    # 更新已完成分片列表（原子操作）
    with get_conn() as conn:
        conn.execute(
            "UPDATE upload_sessions SET "
            "done_chunks = done_chunks || %s::jsonb, updated_at=NOW() "
            "WHERE id=%s",
            (json.dumps([chunk_index]), upload_id)
        )
        updated = conn.execute(
            "SELECT done_chunks, total_chunks FROM upload_sessions WHERE id=%s",
            (upload_id,)
        ).fetchone()

    done = updated["done_chunks"]
    if isinstance(done, str):
        done = json.loads(done)
    done_set = set(done)

    # 检查是否全部完成
    if len(done_set) < total_chunks:
        return jsonify({
            "done":        False,
            "chunk_index": chunk_index,
            "progress":    len(done_set) / total_chunks,
            "done_chunks": list(done_set),
        })

    # ── 所有分片完成，合并 ─────────────────────────────
    return _merge_chunks(upload_id, sess)


def _merge_chunks(upload_id: str, sess) -> tuple:
    """合并所有分片，写入加密存储"""
    total_chunks = sess["total_chunks"]
    path         = sess["rel_path"]
    filename     = sess["filename"]
    file_hash    = sess.get("file_hash", "")

    dest_key = f"{path}/{filename}"
    tmp_dir  = os.path.join(os.path.dirname(config.FILE_ROOT), ".upload_tmp", upload_id)

    # 合并到临时文件
    import tempfile
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tmp") as tf:
        tmp_merged = tf.name
        for i in range(total_chunks):
            chunk_path = os.path.join(tmp_dir, f"{i:06d}.chunk")
            if not os.path.isfile(chunk_path):
                return jsonify({"error": f"分片 {i} 缺失，请重新上传"}), 500
            with open(chunk_path, "rb") as cf:
                tf.write(cf.read())

    # Hash 校验
    if file_hash and len(file_hash) in (32, 64):
        hasher = hashlib.sha256() if len(file_hash) == 64 else hashlib.md5()
        with open(tmp_merged, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                hasher.update(chunk)
        if hasher.hexdigest() != file_hash:
            os.unlink(tmp_merged)
            return jsonify({"error": "文件校验失败（Hash 不匹配），请重新上传"}), 500

    # 写入加密存储
    try:
        import io
        with open(tmp_merged, "rb") as f:
            get_storage().put(dest_key, f)
    finally:
        try:
            os.unlink(tmp_merged)
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

    # 更新会话状态
    with get_conn() as conn:
        conn.execute(
            "UPDATE upload_sessions SET status='done', updated_at=NOW() WHERE id=%s",
            (upload_id,)
        )
        # 更新 file_index 的 hash（支持秒传）
        if file_hash:
            conn.execute(
                "INSERT INTO file_index(file_path, file_name, ftype, file_size, file_hash) "
                "VALUES(%s,%s,%s,%s,%s) "
                "ON CONFLICT(file_path) DO UPDATE "
                "SET file_hash=%s, indexed_at=NOW()",
                (dest_key, filename, _classify(Path(filename).suffix),
                 sess.get("file_size", 0), file_hash, file_hash)
            )

    _audit("UPLOAD_CHUNKED", dest_key)
    return jsonify({
        "done":      True,
        "file_path": dest_key,
        "filename":  filename,
    })


@bp.route("/upload/complete", methods=["POST"])
@jwt_required
def upload_complete():
    """手动触发合并（前端确认所有分片上传后调用）"""
    data      = request.get_json(silent=True) or {}
    upload_id = data.get("upload_id", "")
    with get_conn() as conn:
        sess = conn.execute(
            "SELECT * FROM upload_sessions WHERE id=%s AND user_id=%s",
            (upload_id, g.uid)
        ).fetchone()
    if not sess:
        return jsonify({"error": "会话不存在"}), 404
    return _merge_chunks(upload_id, sess)


@bp.route("/upload/status/<upload_id>")
@jwt_required
def upload_status(upload_id):
    with get_conn() as conn:
        sess = conn.execute(
            "SELECT done_chunks, total_chunks, filename, status FROM upload_sessions "
            "WHERE id=%s AND user_id=%s",
            (upload_id, g.uid)
        ).fetchone()
    if not sess:
        return jsonify({"error": "会话不存在"}), 404
    done = sess["done_chunks"]
    if isinstance(done, str):
        done = json.loads(done)
    return jsonify({
        "upload_id":       upload_id,
        "filename":        sess["filename"],
        "total_chunks":    sess["total_chunks"],
        "uploaded_chunks": list(set(done)),
        "progress":        len(set(done)) / max(1, sess["total_chunks"]),
        "status":          sess["status"],
    })


@bp.route("/upload/cancel", methods=["POST"])
@jwt_required
def upload_cancel():
    data      = request.get_json(silent=True) or {}
    upload_id = data.get("upload_id", "")
    with get_conn() as conn:
        conn.execute(
            "UPDATE upload_sessions SET status='cancelled' WHERE id=%s AND user_id=%s",
            (upload_id, g.uid)
        )
    tmp_dir = os.path.join(os.path.dirname(config.FILE_ROOT), ".upload_tmp", upload_id)
    shutil.rmtree(tmp_dir, ignore_errors=True)
    return jsonify({"success": True})


# ══════════════════════════════════════════════════════════════
#  文件操作（重命名/移动/复制/删除/批量）
# ══════════════════════════════════════════════════════════════
@bp.route("/files/rename", methods=["POST"])
@jwt_required
def rename():
    data    = request.get_json(silent=True) or {}
    path    = (data.get("path") or "").strip("/")
    new_name= (data.get("new_name") or "").strip()

    if not path or not new_name:
        return jsonify({"error": "参数缺失"}), 400
    if any(c in new_name for c in r'\/:*?"<>|'):
        return jsonify({"error": "名称包含非法字符"}), 400
    if not _can(path, True):
        return jsonify({"error": "无权限"}), 403

    parent   = str(Path(path).parent)
    new_path = f"{parent}/{new_name}".lstrip("/")
    src_full = os.path.join(config.FILE_ROOT, path)
    dst_full = os.path.join(config.FILE_ROOT, new_path)

    if os.path.exists(dst_full):
        return jsonify({"error": "同名文件已存在"}), 400
    if not os.path.exists(src_full):
        return jsonify({"error": "文件不存在"}), 404

    os.rename(src_full, dst_full)
    # 更新 file_keys 表
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE file_keys SET file_path=%s WHERE file_path=%s",
                (new_path, path)
            )
    except Exception:
        pass
    _audit("RENAME", f"{path} → {new_path}")
    return jsonify({"success": True, "new_path": new_path})


@bp.route("/files/move", methods=["POST"])
@jwt_required
def move():
    data     = request.get_json(silent=True) or {}
    src      = (data.get("src") or "").strip("/")
    dst_dir  = (data.get("dst_dir") or "").strip("/")

    if not src:
        return jsonify({"error": "源路径不能为空"}), 400
    if not _can(src, True) or not _can(dst_dir, True):
        return jsonify({"error": "无权限"}), 403

    name     = Path(src).name
    dst      = f"{dst_dir}/{name}".lstrip("/")
    src_full = os.path.join(config.FILE_ROOT, src)
    dst_full = os.path.join(config.FILE_ROOT, dst)

    if not os.path.exists(src_full):
        return jsonify({"error": "源文件不存在"}), 404
    if os.path.exists(dst_full):
        return jsonify({"error": "目标位置已有同名文件"}), 400

    os.makedirs(os.path.dirname(dst_full), exist_ok=True)
    shutil.move(src_full, dst_full)
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE file_keys SET file_path=%s WHERE file_path=%s", (dst, src)
            )
    except Exception:
        pass
    _audit("MOVE", f"{src} → {dst}")
    return jsonify({"success": True, "new_path": dst})


@bp.route("/files/copy", methods=["POST"])
@jwt_required
def copy():
    data    = request.get_json(silent=True) or {}
    src     = (data.get("src") or "").strip("/")
    dst_dir = (data.get("dst_dir") or "").strip("/")

    if not src:
        return jsonify({"error": "源路径不能为空"}), 400
    if not _can(src) or not _can(dst_dir, True):
        return jsonify({"error": "无权限"}), 403

    name     = Path(src).name
    dst      = f"{dst_dir}/{name}".lstrip("/")
    src_full = os.path.join(config.FILE_ROOT, src)
    dst_full = os.path.join(config.FILE_ROOT, dst)

    if not os.path.exists(src_full):
        return jsonify({"error": "源文件不存在"}), 404

    # 复制需要重新加密
    try:
        get_storage().copy(src, dst)
    except Exception:
        shutil.copy2(src_full, dst_full)

    _audit("COPY", f"{src} → {dst}")
    return jsonify({"success": True, "new_path": dst})


@bp.route("/files/delete", methods=["POST"])
@jwt_required
def delete():
    data = request.get_json(silent=True) or {}
    path = (data.get("path") or "").strip("/")

    if not path:
        return jsonify({"error": "路径不能为空"}), 400
    if not _can(path, True):
        return jsonify({"error": "无权限"}), 403

    full = os.path.join(config.FILE_ROOT, path)
    if not os.path.exists(full):
        return jsonify({"error": "文件不存在"}), 404

    # 移入回收站
    is_dir   = os.path.isdir(full)
    size     = 0 if is_dir else os.path.getsize(full)
    trash_dir= os.path.join(os.path.dirname(config.FILE_ROOT), ".trash")
    os.makedirs(trash_dir, exist_ok=True)
    trash_name = f"{int(time.time())}_{os.path.basename(full)}"
    trash_path = os.path.join(trash_dir, trash_name)
    shutil.move(full, trash_path)

    with get_conn() as conn:
        conn.execute(
            "INSERT INTO trash_items(user_id, orig_path, trash_path, is_dir, file_size) "
            "VALUES(%s,%s,%s,%s,%s)",
            (g.uid, path, trash_path, is_dir, size)
        )

    _audit("DELETE_TO_TRASH", path)
    return jsonify({"success": True})


@bp.route("/files/batch", methods=["POST"])
@jwt_required
def batch():
    """批量操作：delete / move"""
    data   = request.get_json(silent=True) or {}
    action = data.get("action", "")
    paths  = data.get("paths", [])

    if not paths:
        return jsonify({"error": "未选择文件"}), 400

    results = {"success": [], "error": []}
    for path in paths:
        path = path.strip("/")
        if action == "delete":
            if _can(path, True):
                full = os.path.join(config.FILE_ROOT, path)
                if os.path.exists(full):
                    trash_dir  = os.path.join(os.path.dirname(config.FILE_ROOT), ".trash")
                    os.makedirs(trash_dir, exist_ok=True)
                    trash_name = f"{int(time.time())}_{os.path.basename(full)}"
                    trash_path = os.path.join(trash_dir, trash_name)
                    shutil.move(full, trash_path)
                    with get_conn() as conn:
                        conn.execute(
                            "INSERT INTO trash_items(user_id,orig_path,trash_path,is_dir) "
                            "VALUES(%s,%s,%s,%s)",
                            (g.uid, path, trash_path, os.path.isdir(trash_path))
                        )
                    results["success"].append(path)
                else:
                    results["error"].append(path)
        else:
            results["error"].append(path)

    return jsonify({"success": True, "results": results})


# ══════════════════════════════════════════════════════════════
#  文件下载（服务端解密 + 流式返回）
# ══════════════════════════════════════════════════════════════
@bp.route("/file/<path:filepath>")
@jwt_required
def download(filepath):
    filepath = filepath.strip("/")
    if not _can(filepath):
        return jsonify({"error": "无权限"}), 403

    storage = get_storage()
    if not storage.exists(filepath):
        return jsonify({"error": "文件不存在"}), 404

    as_dl = request.args.get("dl") == "1"

    # 本地存储直接用 send_file
    if hasattr(storage, "get_local_path"):
        local = storage.get_local_path(filepath)
        if not os.path.isfile(local):
            # 检查加密版本
            enc = local + ".enc"
            if os.path.isfile(enc):
                data = storage.get(filepath)
                from flask import Response
                mime, _ = mimetypes.guess_type(filepath)
                mime = mime or "application/octet-stream"
                from urllib.parse import quote
                fn = Path(filepath).name
                cd = f'{"attachment" if as_dl else "inline"}; filename="{quote(fn)}"'
                return Response(data, mimetype=mime, headers={"Content-Disposition": cd})
            abort(404)
        if as_dl:
            _audit("DOWNLOAD", filepath)
        return send_file(local, as_attachment=as_dl, download_name=Path(filepath).name)

    # 对象存储：流式返回
    from flask import Response, stream_with_context
    if as_dl:
        _audit("DOWNLOAD", filepath)
    data   = storage.get(filepath)
    mime, _= mimetypes.guess_type(filepath)
    mime   = mime or "application/octet-stream"
    return Response(data, mimetype=mime)


# ══════════════════════════════════════════════════════════════
#  预览信息（返回预览所需的 URL 和元数据）
# ══════════════════════════════════════════════════════════════
@bp.route("/files/preview")
@jwt_required
def preview_info():
    path = request.args.get("path", "").strip("/")
    if not path or not _can(path):
        return jsonify({"error": "无权限"}), 403

    ext   = Path(path).suffix.lower()
    ftype = _classify(ext)
    full  = os.path.join(config.FILE_ROOT, path)

    # 文件 URL（直接用下载路由）
    file_url = f"/api/file/{path}"

    preview_data = {
        "path":     path,
        "name":     Path(path).name,
        "ftype":    ftype,
        "ext":      ext,
        "file_url": file_url,
        "can_preview": ftype in ("image","video","audio","pdf","text","code"),
    }

    # 文本/代码：读取内容
    if ftype in ("text", "code"):
        try:
            content = get_storage().get(path)
            # 尝试 UTF-8 解码
            preview_data["content"] = content.decode("utf-8", errors="replace")[:50000]  # 最多 50KB
            preview_data["encoding"] = "utf-8"
        except Exception as e:
            preview_data["content"] = f"读取失败：{e}"

    # 图片：直接返回 URL
    elif ftype == "image":
        preview_data["thumbnail_url"] = file_url

    # 视频/音频：MIME type
    elif ftype in ("video", "audio"):
        mime, _ = mimetypes.guess_type(path)
        preview_data["mime_type"] = mime or "application/octet-stream"

    return jsonify(preview_data)


# ══════════════════════════════════════════════════════════════
#  搜索
# ══════════════════════════════════════════════════════════════
@bp.route("/files/search")
@jwt_required
def search():
    q     = request.args.get("q", "").strip()
    ftype = request.args.get("type", "")
    if not q:
        return jsonify({"items": []})

    try:
        from product.files.indexer import search_index
        results = search_index(q, ftype, limit=100)
    except Exception:
        results = []

    # 过滤权限
    items = []
    for r in results:
        fp = r.get("file_path", "")
        if _can(fp):
            ft   = r.get("ftype", "other")
            meta = FTYPE_META.get(ft, FTYPE_META["other"])
            items.append({
                **r,
                "icon":  meta["icon"],
                "color": meta["color"],
                "bg":    meta["bg"],
            })
    return jsonify({"items": items, "count": len(items)})


# ══════════════════════════════════════════════════════════════
#  分享
# ══════════════════════════════════════════════════════════════
@bp.route("/shares", methods=["GET"])
@jwt_required
def list_shares():
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fs.*, u.username as target_username, u.display_name as target_name,
                   o.name as target_org
            FROM file_shares fs
            LEFT JOIN users u ON u.id = fs.target_id AND fs.share_type='user'
            LEFT JOIN organizations o ON o.id = fs.target_id AND fs.share_type='org'
            WHERE fs.owner_id=%s AND fs.is_active=TRUE
            ORDER BY fs.created_at DESC
        """, (g.uid,)).fetchall()
    return jsonify({"shares": [dict(r) for r in rows]})


@bp.route("/shares", methods=["POST"])
@jwt_required
def create_share():
    data       = request.get_json(silent=True) or {}
    file_path  = (data.get("path") or "").strip("/")
    share_type = data.get("type", "user")   # user / org / public
    target_id  = data.get("target_id")
    perm       = data.get("perm", "ro")
    expires_days = int(data.get("expires_days", 0))

    if not file_path:
        return jsonify({"error": "文件路径不能为空"}), 400
    if not _can(file_path):
        return jsonify({"error": "无权限"}), 403

    expires_at = None
    if expires_days > 0:
        expires_at = (datetime.now() + timedelta(days=expires_days)).isoformat()

    with get_conn() as conn:
        row = conn.execute(
            "INSERT INTO file_shares(owner_id, file_path, is_dir, share_type, target_id, perm, expires_at) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING id",
            (g.uid, file_path, os.path.isdir(os.path.join(config.FILE_ROOT, file_path)),
             share_type, target_id, perm, expires_at)
        ).fetchone()

    _audit("SHARE_CREATE", file_path)
    return jsonify({"success": True, "share_id": row[0]})


@bp.route("/shares/<int:share_id>", methods=["DELETE"])
@jwt_required
def revoke_share(share_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT owner_id FROM file_shares WHERE id=%s", (share_id,)
        ).fetchone()
    if not row or (row["owner_id"] != g.uid and g.role != 0):
        return jsonify({"error": "无权限"}), 403
    with get_conn() as conn:
        conn.execute("UPDATE file_shares SET is_active=FALSE WHERE id=%s", (share_id,))
    return jsonify({"success": True})


@bp.route("/shares/received")
@jwt_required
def received_shares():
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fs.*, u.username as owner_username, u.display_name as owner_name
            FROM file_shares fs
            LEFT JOIN users u ON u.id = fs.owner_id
            WHERE fs.is_active=TRUE
              AND (fs.expires_at IS NULL OR fs.expires_at > NOW())
              AND (
                (fs.share_type='user' AND fs.target_id=%s)
                OR (fs.share_type='org' AND fs.target_id=%s)
                OR fs.share_type='public'
              )
              AND fs.owner_id != %s
            ORDER BY fs.created_at DESC
        """, (g.uid, g.org_id, g.uid)).fetchall()
    return jsonify({"shares": [dict(r) for r in rows]})


@bp.route("/shares/targets")
@jwt_required
def share_targets():
    q = request.args.get("q", "").strip()
    with get_conn() as conn:
        users = conn.execute(
            "SELECT id, username, display_name FROM users "
            "WHERE is_active=TRUE AND id!=%s "
            "AND (username ILIKE %s OR display_name ILIKE %s) LIMIT 20",
            (g.uid, f"%{q}%", f"%{q}%")
        ).fetchall()
        orgs = conn.execute(
            "SELECT id, name FROM organizations "
            "WHERE name ILIKE %s LIMIT 10",
            (f"%{q}%",)
        ).fetchall()
    return jsonify({
        "users": [{"id": r["id"], "label": r["display_name"] or r["username"], "type": "user"} for r in users],
        "orgs":  [{"id": r["id"], "label": r["name"], "type": "org"} for r in orgs],
    })


# ══════════════════════════════════════════════════════════════
#  公开分享链接
# ══════════════════════════════════════════════════════════════
@bp.route("/links", methods=["POST"])
@jwt_required
def create_link():
    import secrets as _sec
    data       = request.get_json(silent=True) or {}
    file_path  = (data.get("path") or "").strip("/")
    password   = data.get("password", "")
    expires_days = int(data.get("expires_days", 7))
    max_views  = int(data.get("max_views", 0))

    if not file_path or not _can(file_path):
        return jsonify({"error": "无权限"}), 403

    token      = _sec.token_urlsafe(12)
    expires_at = (datetime.now() + timedelta(days=expires_days)).isoformat()

    with get_conn() as conn:
        conn.execute(
            "INSERT INTO public_links(owner_id, file_path, token, password, expires_at, max_views) "
            "VALUES(%s,%s,%s,%s,%s,%s)",
            (g.uid, file_path, token, password, expires_at, max_views)
        )

    return jsonify({"success": True, "token": token, "url": f"/s/{token}"})


@bp.route("/links/my")
@jwt_required
def my_links():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, file_path, token, expires_at, max_views, view_count, is_active "
            "FROM public_links WHERE owner_id=%s ORDER BY created_at DESC",
            (g.uid,)
        ).fetchall()
    return jsonify({"links": [dict(r) for r in rows]})


@bp.route("/links/<int:link_id>", methods=["DELETE"])
@jwt_required
def revoke_link(link_id):
    with get_conn() as conn:
        conn.execute(
            "UPDATE public_links SET is_active=FALSE WHERE id=%s AND owner_id=%s",
            (link_id, g.uid)
        )
    return jsonify({"success": True})


# ══════════════════════════════════════════════════════════════
#  回收站
# ══════════════════════════════════════════════════════════════
@bp.route("/trash")
@jwt_required
def list_trash():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, orig_path, is_dir, file_size, deleted_at "
            "FROM trash_items WHERE user_id=%s ORDER BY deleted_at DESC",
            (g.uid,)
        ).fetchall()
    items = []
    for r in rows:
        ft   = "dir" if r["is_dir"] else _classify(Path(r["orig_path"]).suffix)
        meta = FTYPE_META.get(ft, FTYPE_META["other"])
        items.append({
            "id":         r["id"],
            "name":       Path(r["orig_path"]).name,
            "orig_path":  r["orig_path"],
            "is_dir":     r["is_dir"],
            "size_str":   "—" if r["is_dir"] else _fmt_size(r["file_size"] or 0),
            "deleted_at": str(r["deleted_at"])[:16],
            "icon":       meta["icon"],
            "ftype":      ft,
        })
    return jsonify({"items": items})


@bp.route("/trash/restore", methods=["POST"])
@jwt_required
def restore_trash():
    data = request.get_json(silent=True) or {}
    ids  = data.get("ids", [])
    if not ids:
        return jsonify({"error": "未选择文件"}), 400

    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM trash_items WHERE id = ANY(%s) AND user_id=%s",
            (ids, g.uid)
        ).fetchall()

    restored = []
    for row in rows:
        orig_full  = os.path.join(config.FILE_ROOT, row["orig_path"])
        trash_path = row["trash_path"]
        if os.path.exists(trash_path):
            os.makedirs(os.path.dirname(orig_full), exist_ok=True)
            if not os.path.exists(orig_full):
                shutil.move(trash_path, orig_full)
                with get_conn() as conn:
                    conn.execute("DELETE FROM trash_items WHERE id=%s", (row["id"],))
                restored.append(row["orig_path"])

    return jsonify({"success": True, "restored": restored})


@bp.route("/trash/<int:item_id>", methods=["DELETE"])
@jwt_required
def delete_trash(item_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT trash_path FROM trash_items WHERE id=%s AND user_id=%s",
            (item_id, g.uid)
        ).fetchone()

    if not row:
        return jsonify({"error": "文件不存在"}), 404

    tp = row["trash_path"]
    if os.path.isfile(tp):   os.remove(tp)
    elif os.path.isdir(tp):  shutil.rmtree(tp, ignore_errors=True)

    with get_conn() as conn:
        conn.execute("DELETE FROM trash_items WHERE id=%s", (item_id,))

    return jsonify({"success": True})


@bp.route("/trash/empty", methods=["POST"])
@jwt_required
def empty_trash():
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT trash_path FROM trash_items WHERE user_id=%s", (g.uid,)
        ).fetchall()
        for row in rows:
            tp = row["trash_path"]
            if os.path.isfile(tp):   os.remove(tp)
            elif os.path.isdir(tp):  shutil.rmtree(tp, ignore_errors=True)
        conn.execute("DELETE FROM trash_items WHERE user_id=%s", (g.uid,))
    return jsonify({"success": True})


# ══════════════════════════════════════════════════════════════
#  评论
# ══════════════════════════════════════════════════════════════
@bp.route("/files/comments")
@jwt_required
def get_comments():
    path = request.args.get("path", "").strip("/")
    if not path or not _can(path):
        return jsonify({"error": "无权限"}), 403
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fc.id, fc.parent_id, fc.content, fc.created_at,
                   u.username, u.display_name, u.avatar_color
            FROM file_comments fc JOIN users u ON u.id=fc.user_id
            WHERE fc.file_path=%s AND fc.is_deleted=FALSE
            ORDER BY fc.created_at
        """, (path,)).fetchall()
    return jsonify({"comments": [dict(r) for r in rows]})


@bp.route("/files/comments", methods=["POST"])
@jwt_required
def post_comment():
    data    = request.get_json(silent=True) or {}
    path    = (data.get("path") or "").strip("/")
    content = (data.get("content") or "").strip()
    parent  = data.get("parent_id")
    if not path or not content or not _can(path):
        return jsonify({"error": "参数错误或无权限"}), 400
    with get_conn() as conn:
        cid = conn.execute(
            "INSERT INTO file_comments(file_path,user_id,parent_id,content) "
            "VALUES(%s,%s,%s,%s) RETURNING id",
            (path, g.uid, parent, content[:2000])
        ).fetchone()[0]
    return jsonify({"success": True, "id": cid})


@bp.route("/files/comments/<int:cid>", methods=["DELETE"])
@jwt_required
def delete_comment(cid):
    with get_conn() as conn:
        row = conn.execute("SELECT user_id FROM file_comments WHERE id=%s", (cid,)).fetchone()
        if not row or (row["user_id"] != g.uid and g.role != 0):
            return jsonify({"error": "无权限"}), 403
        conn.execute("UPDATE file_comments SET is_deleted=TRUE WHERE id=%s", (cid,))
    return jsonify({"success": True})


# ── 审计日志辅助 ──────────────────────────────────────
def _audit(action: str, detail: str = ""):
    try:
        from product.audit.log import write as aw, AuditCategory
        aw(g.uid, g.username, action, detail, request.remote_addr, "INFO", AuditCategory.FILE)
    except Exception:
        pass
