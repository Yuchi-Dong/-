# -*- coding: utf-8 -*-
"""
webdav/handler.py — WebDAV 接口

支持 Windows 资源管理器挂载（Basic Auth）
挂载地址：http://服务器IP:8080/webdav
"""
import os
import base64
from pathlib import Path

from flask import Blueprint, request, abort, Response

import config
from auth import safe_join, ROLE_SUPER, ROLE_DEPT
from license.middleware import feature_required
from services.permission_service import can_access
from services.user_service import verify_password
from dao.file_dao import move_to_trash, save_version
from indexer import async_index

bp = Blueprint("webdav", __name__)


def _safe_send(full_path):
    import mimetypes
    from urllib.parse import quote
    from flask import send_file
    mime, _ = mimetypes.guess_type(full_path)
    mime = mime or "application/octet-stream"
    fname         = Path(full_path).name
    fname_encoded = quote(fname.encode("utf-8"), safe="")
    fname_ascii   = "".join(c for c in fname if ord(c) < 128) or "file"
    cd = f'inline; filename="{fname_ascii}"; filename*=UTF-8\'\'{fname_encoded}'
    response = send_file(full_path, mimetype=mime)
    response.headers["Content-Disposition"] = cd
    return response


# WebDAV 认证缓存（减少 PBKDF2 CPU 消耗）
# key: (username, pw_hash_prefix) → (user_dict, expire_ts)
import threading as _thr, time as _time, hashlib as _hl
_webdav_auth_cache: dict = {}
_webdav_auth_lock  = _thr.Lock()
_WEBDAV_AUTH_TTL   = 60   # 秒


def _authenticate():
    """
    解析 Basic Auth，返回 user dict 或 None。
    PBKDF2 验证结果缓存 60 秒，减少 CPU 占用。
    ⚠ 仅在 HTTPS 环境下部署，HTTP 下密码明文传输。
    """
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Basic "):
        return None
    try:
        decoded = base64.b64decode(auth[6:]).decode("utf-8", "replace")
        uname, pw = decoded.split(":", 1)
    except Exception:
        return None

    # 缓存 key：用户名 + 密码的 SHA-256 前 32 位（不存明文密码）
    pw_hint    = _hl.sha256(pw.encode()).hexdigest()[:32]
    cache_key  = (uname, pw_hint)
    now        = _time.time()

    with _webdav_auth_lock:
        cached = _webdav_auth_cache.get(cache_key)
        if cached and now < cached[1]:
            return cached[0]

    # 缓存未命中，执行完整 PBKDF2 验证
    try:
        user, _ = verify_password(uname, pw)
    except Exception:
        user = None

    with _webdav_auth_lock:
        if user:
            _webdav_auth_cache[cache_key] = (user, now + _WEBDAV_AUTH_TTL)
        else:
            _webdav_auth_cache.pop(cache_key, None)
        # 清理过期条目
        expired = [k for k, v in _webdav_auth_cache.items() if now >= v[1]]
        for k in expired:
            _webdav_auth_cache.pop(k, None)

    return user


def _unauth():
    return Response("Unauthorized", 401, {"WWW-Authenticate": 'Basic realm="SecFTP Pro"'})


@bp.route("/webdav", defaults={"path": ""}, methods=["GET", "HEAD", "OPTIONS",
    "PROPFIND", "MKCOL", "PUT", "DELETE", "COPY", "MOVE", "LOCK", "UNLOCK"])
@bp.route("/webdav/<path:path>", methods=["GET", "HEAD", "OPTIONS",
    "PROPFIND", "MKCOL", "PUT", "DELETE", "COPY", "MOVE", "LOCK", "UNLOCK"])
@feature_required("webdav")
def webdav(path):
    user = _authenticate()
    if not user:
        return _unauth()

    uid   = user["id"]
    urole = user.get("role", 2)
    uorg  = user.get("org_id")
    rel   = path.strip("/")
    full  = safe_join(config.FILE_ROOT, rel) if rel else config.FILE_ROOT
    method = request.method.upper()

    def _can(p, need_write=False):
        return can_access(p, uid, urole, uorg, need_write)

    if method == "OPTIONS":
        return Response("", 200, {
            "DAV": "1,2",
            "Allow": "GET,HEAD,PUT,DELETE,MKCOL,PROPFIND,OPTIONS",
            "MS-Author-Via": "DAV"
        })

    if method == "PROPFIND":
        from email.utils import formatdate
        import time
        depth = request.headers.get("Depth", "1")

        def _prop(p, is_dir, sz=0, mtime=None):
            mt   = formatdate(mtime or time.time()) if mtime else formatdate()
            ct   = "httpd/unix-directory" if is_dir else "application/octet-stream"
            href = f"/webdav/{p}" if p else "/webdav/"
            return (f"<D:response><D:href>{href}</D:href><D:propstat>"
                    f"<D:prop><D:resourcetype>{'<D:collection/>' if is_dir else ''}</D:resourcetype>"
                    f"<D:getcontenttype>{ct}</D:getcontenttype>"
                    f"<D:getcontentlength>{sz}</D:getcontentlength>"
                    f"<D:getlastmodified>{mt}</D:getlastmodified></D:prop>"
                    f"<D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>")

        entries = []
        if os.path.isfile(full):
            st = os.stat(full)
            entries.append(_prop(rel, False, st.st_size, st.st_mtime))
        elif os.path.isdir(full):
            st = os.stat(full)
            entries.append(_prop(rel, True, 0, st.st_mtime))
            if depth != "0":
                for entry in os.scandir(full):
                    child_rel = (rel + "/" + entry.name).lstrip("/")
                    cst = entry.stat()
                    entries.append(_prop(child_rel, entry.is_dir(),
                                         0 if entry.is_dir() else cst.st_size, cst.st_mtime))
        xml = ('<?xml version="1.0" encoding="utf-8"?>'
               '<D:multistatus xmlns:D="DAV:">' + "".join(entries) + '</D:multistatus>')
        return Response(xml, 207, {"Content-Type": "application/xml; charset=utf-8"})

    if method in ("GET", "HEAD"):
        if not os.path.isfile(full): abort(404)
        return _safe_send(full)

    if method == "PUT":
        if urole > ROLE_DEPT and not _can(rel, True):
            abort(403)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        save_version(rel, full, uid, "WebDAV 覆盖前备份")
        # 流式写入，避免大文件全量读入内存
        # 通过加密存储层写入（保证文件静态加密）
        import io as _io
        _buf = _io.BytesIO()
        while True:
            chunk = request.stream.read(65536)
            if not chunk: break
            _buf.write(chunk)
        _buf.seek(0)
        from core.storage import get_storage
        get_storage().put(rel, _buf)
        async_index(full, rel)
        return Response("", 204)

    if method == "MKCOL":
        if os.path.exists(full): abort(405)
        os.makedirs(full, exist_ok=True)
        return Response("", 201)

    if method == "DELETE":
        if not os.path.exists(full): abort(404)
        move_to_trash(rel, full, uid)
        return Response("", 204)

    if method == "MOVE":
        dest     = request.headers.get("Destination", "")
        dest_rel = dest.split("/webdav/", 1)[-1].strip("/") if "/webdav/" in dest else ""
        if dest_rel:
            dest_full = safe_join(config.FILE_ROOT, dest_rel)
            if os.path.exists(full):
                os.makedirs(os.path.dirname(dest_full), exist_ok=True)
                import shutil
                shutil.move(full, dest_full)
        return Response("", 201)

    return Response("", 200)
