# -*- coding: utf-8 -*-
"""
dao/user_dao.py — 用户数据访问层
只做：SQL 查询，不含任何业务判断
"""
from dao.db import get_conn

# 允许返回给上层的用户字段（排除 password、salt、totp_secret）
_SAFE_FIELDS = frozenset({
    'id','username','display_name','email','phone','bio',
    'role','org_id','is_active','is_locked',
    'created_at','last_login','created_by',
    'fail_count','locked_until',
    'quota_mb','avatar_color',
    'totp_enabled','force_pw_change','pw_changed_at',
    # 联表字段
    'org_name','org_level','org_level_label',
    'target_user_name','target_username','target_org_name',
    'owner_name','owner_username','display_name',
})

def _safe(row: dict) -> dict:
    """过滤敏感字段，仅返回 _SAFE_FIELDS 中声明的字段"""
    return {k: v for k, v in row.items() if k in _SAFE_FIELDS}


def get_by_id(user_id: int):
    """返回安全用户信息（不含 password/salt/totp_secret）"""
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=%s", (user_id,)).fetchone()
    return _safe(dict(row)) if row else None


def get_by_id_raw(user_id: int):
    """返回完整用户信息（含敏感字段），仅供认证模块使用"""
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=%s", (user_id,)).fetchone()
    return dict(row) if row else None


def get_by_username(username: str):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE username=%s AND is_active=1", (username,)
        ).fetchone()
    return dict(row) if row else None


def get_all(caller_role, caller_org_id):
    import config
    with get_conn() as conn:
        if caller_role == config.ROLE_SUPER:
            rows = conn.execute("""
                SELECT u.*, o.name as org_name, o.org_level
                FROM users u LEFT JOIN organizations o ON o.id=u.org_id
                ORDER BY u.role, u.username
            """).fetchall()
        else:
            rows = conn.execute("""
                SELECT u.*, o.name as org_name, o.org_level
                FROM users u LEFT JOIN organizations o ON o.id=u.org_id
                WHERE u.org_id=%s AND u.role>=1
                ORDER BY u.role, u.username
            """, (caller_org_id,)).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        d.setdefault("phone", "")
        d.setdefault("email", "")
        d.setdefault("org_id", None)
        d.setdefault("org_name", "—")
        d.setdefault("quota_mb", 1024000)
        d.setdefault("last_login", None)
        result.append(d)
    return result


def create(username, pw_hash, salt, role, org_id, display_name, email, quota_mb, created_by):
    import os, config
    with get_conn() as conn:
        uid = conn.execute(
            "INSERT INTO users(username,password,salt,role,org_id,display_name,"
            "email,quota_mb,created_by) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id",
            (username, pw_hash, salt, role, org_id, display_name, email, quota_mb, created_by)
        ).fetchone()[0]
    os.makedirs(os.path.join(config.FILE_ROOT, "users", username), exist_ok=True)
    return uid


def update_profile(user_id, display_name, email, phone):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET display_name=%s,email=%s,phone=%s WHERE id=%s",
            (display_name, email, phone, user_id)
        )


def update_avatar(user_id, color):
    with get_conn() as conn:
        conn.execute("UPDATE users SET avatar_color=%s WHERE id=%s", (color, user_id))


def update_password(user_id, pw_hash, salt):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET password=%s,salt=%s,fail_count=0,locked_until=NULL WHERE id=%s",
            (pw_hash, salt, user_id)
        )


def update_avatar_image(user_id, avatar_path: str):
    """保存头像图片路径（upload 后调用）"""
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET avatar_path=%s WHERE id=%s", (avatar_path, user_id)
        )


def update_bio(user_id, bio: str, location: str = '', department_title: str = ''):
    """更新个人签名/位置/职位"""
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET bio=%s, location=%s, department_title=%s WHERE id=%s",
            (bio[:200], location[:50], department_title[:50], user_id)
        )


def get_stats(user_id: int) -> dict:
    """获取用户活动统计（文件数、分享数、下载数）"""
    try:
        from dao.db import get_conn as _gc
        with _gc() as conn:
            files = conn.execute(
                """SELECT COUNT(*) FROM audit_log
                   WHERE user_id=%s AND action='UPLOAD'""",
                (user_id,)
            ).fetchone()[0] or 0
            shares = conn.execute(
                """SELECT COUNT(*) FROM file_shares
                   WHERE owner_id=%s AND is_active=1""",
                (user_id,)
            ).fetchone()[0] or 0
            downloads = conn.execute(
                """SELECT COUNT(*) FROM audit_log
                   WHERE user_id=%s AND action='DOWNLOAD'""",
                (user_id,)
            ).fetchone()[0] or 0
            last_ops = conn.execute(
                """SELECT action, detail, ts FROM audit_log
                   WHERE user_id=%s ORDER BY id DESC LIMIT 5""",
                (user_id,)
            ).fetchall()
        return {
            "uploads":   files,
            "shares":    shares,
            "downloads": downloads,
            "last_ops":  [dict(r) for r in last_ops],
        }
    except Exception:
        return {"uploads": 0, "shares": 0, "downloads": 0, "last_ops": []}


def update_info(user_id, display_name, email, phone, role, org_id, quota_mb):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET display_name=%s,email=%s,phone=%s,role=%s,org_id=%s,quota_mb=%s WHERE id=%s",
            (display_name, email, phone, role, org_id, quota_mb, user_id)
        )


def set_active(user_id, is_active: bool):
    with get_conn() as conn:
        conn.execute("UPDATE users SET is_active=%s WHERE id=%s", (1 if is_active else 0, user_id))


def record_login_success(user_id):
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET fail_count=0,locked_until=NULL,last_login=NOW() WHERE id=%s",
            (user_id,)
        )
        return dict(conn.execute("SELECT * FROM users WHERE id=%s", (user_id,)).fetchone())


def record_login_fail(user_id, new_fail, lock_until=None):
    with get_conn() as conn:
        if lock_until:
            conn.execute(
                "UPDATE users SET fail_count=%s,locked_until=%s WHERE id=%s",
                (new_fail, lock_until, user_id)
            )
        else:
            conn.execute("UPDATE users SET fail_count=%s WHERE id=%s", (new_fail, user_id))


def get_share_targets(exclude_uid, org_id=None, is_super=False):
    """
    返回可分享的用户列表。
    - 超管（is_super=True）：返回全部活跃用户
    - 普通用户：只返回同组织成员（org_id 相同）
    - 无组织用户：返回空列表
    """
    with get_conn() as conn:
        if is_super:
            rows = conn.execute(
                "SELECT id,username,display_name,org_id FROM users "
                "WHERE is_active=1 AND id!=%s ORDER BY display_name",
                (exclude_uid,)
            ).fetchall()
        elif org_id:
            rows = conn.execute(
                "SELECT id,username,display_name,org_id FROM users "
                "WHERE is_active=1 AND id!=%s AND org_id=%s ORDER BY display_name",
                (exclude_uid, org_id)
            ).fetchall()
        else:
            rows = []
    return [dict(r) for r in rows]


def search_users_by_name(query: str, exclude_uid, org_id=None, is_super=False):
    """按姓名或用户名搜索可分享的用户（支持 @ 搜索）"""
    q = "%" + query.strip("@ ") + "%"
    with get_conn() as conn:
        if is_super:
            rows = conn.execute(
                "SELECT id,username,display_name,org_id FROM users "
                "WHERE is_active=1 AND id!=%s "
                "AND (username ILIKE %s OR display_name ILIKE %s) "
                "ORDER BY display_name LIMIT 20",
                (exclude_uid, q, q)
            ).fetchall()
        elif org_id:
            rows = conn.execute(
                "SELECT id,username,display_name,org_id FROM users "
                "WHERE is_active=1 AND id!=%s AND org_id=%s "
                "AND (username ILIKE %s OR display_name ILIKE %s) "
                "ORDER BY display_name LIMIT 20",
                (exclude_uid, org_id, q, q)
            ).fetchall()
        else:
            rows = []
    return [dict(r) for r in rows]
