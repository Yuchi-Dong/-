# -*- coding: utf-8 -*-
"""
dao/org_dao.py — 组织数据访问层
"""
import os
import config
from dao.db import get_conn


def get_all():
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT o.*, COUNT(u.id) as member_count
            FROM organizations o LEFT JOIN users u ON u.org_id=o.id
            GROUP BY o.id ORDER BY o.org_level, o.id
        """).fetchall()
    return [dict(r) for r in rows]


def get_by_id(org_id):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM organizations WHERE id=%s", (org_id,)).fetchone()
    return dict(row) if row else None


def get_by_code(code):
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM organizations WHERE code=%s", (code,)).fetchone()
    return dict(row) if row else None


def get_children(parent_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM organizations WHERE parent_id=%s ORDER BY org_level, id",
            (parent_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def get_ancestors(org_id) -> list:
    """
    返回从当前节点到根节点的祖先链（含自身）。
    PostgreSQL 递归 CTE。
    """
    with get_conn() as conn:
        rows = conn.execute("""
            WITH RECURSIVE ancestors(id, name, parent_id, org_level, dir_path) AS (
                SELECT id, name, parent_id, org_level, dir_path
                FROM organizations WHERE id=%s
                UNION ALL
                SELECT o.id, o.name, o.parent_id, o.org_level, o.dir_path
                FROM organizations o
                JOIN ancestors a ON o.id = a.parent_id
            )
            SELECT * FROM ancestors
        """, (org_id,)).fetchall()
    return [dict(r) for r in rows]


def create(name, code, dir_path, desc, parent_id, org_level, level_label, created_by):
    with get_conn() as conn:
        oid = conn.execute(
            'INSERT INTO organizations(name,code,dir_path,"desc",parent_id,org_level,level_label,created_by) '
            "VALUES(%s,%s,%s,%s,%s,%s,%s,%s) RETURNING id",
            (name, code, dir_path, desc, parent_id or None, org_level, level_label or "", created_by)
        ).fetchone()[0]
    os.makedirs(os.path.join(config.FILE_ROOT, dir_path), exist_ok=True)
    return oid


def update(org_id, name, desc, level_label=None):
    with get_conn() as conn:
        if level_label is not None:
            conn.execute(
                'UPDATE organizations SET name=%s,"desc"=%s,level_label=%s WHERE id=%s',
                (name, desc, level_label, org_id)
            )
        else:
            conn.execute('UPDATE organizations SET name=%s,"desc"=%s WHERE id=%s',
                         (name, desc, org_id))


def delete(org_id):
    with get_conn() as conn:
        conn.execute("DELETE FROM organizations WHERE id=%s", (org_id,))


def count_children(org_id):
    with get_conn() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM organizations WHERE parent_id=%s", (org_id,)
        ).fetchone()[0]


def count_members(org_id):
    with get_conn() as conn:
        return conn.execute(
            "SELECT COUNT(*) FROM users WHERE org_id=%s", (org_id,)
        ).fetchone()[0]


# ── 组织权限表 ───────────────────────────────────────
def get_org_perms(org_id):
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM org_permissions WHERE org_id=%s", (org_id,)
        ).fetchall()
    return [dict(r) for r in rows]


def set_org_perm(org_id, path, perm, inherit, granted_by):
    with get_conn() as conn:
        conn.execute("""
            INSERT INTO org_permissions(org_id, path, perm, inherit, granted_by)
            VALUES(%s,%s,%s,%s,%s)
            ON CONFLICT(org_id,path) DO UPDATE
            SET perm=EXCLUDED.perm, inherit=EXCLUDED.inherit, granted_by=EXCLUDED.granted_by
        """, (org_id, path, perm, 1 if inherit else 0, granted_by))


def delete_org_perm(org_id, path):
    with get_conn() as conn:
        conn.execute(
            "DELETE FROM org_permissions WHERE org_id=%s AND path=%s", (org_id, path)
        )
