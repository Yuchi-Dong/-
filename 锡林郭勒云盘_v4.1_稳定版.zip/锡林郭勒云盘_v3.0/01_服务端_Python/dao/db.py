# -*- coding: utf-8 -*-
"""
dao/db.py — PostgreSQL 连接层（替换原 SQLite）

使用 psycopg2 ThreadedConnectionPool，兼容原 get_conn() 上下文接口。
上层 DAO 代码只需把占位符 ? → %s，其余接口不变。

连接优先级：
  1. 环境变量 DATABASE_URL
  2. config.py 中的 DB_HOST / DB_PORT / DB_NAME / DB_USER / DB_PASS
"""
import contextlib
import logging
import os

import psycopg2
import psycopg2.extras
import psycopg2.pool

import config

log = logging.getLogger('db')

_pool = None   # ThreadedConnectionPool 单例


def _dsn():
    env = os.environ.get('DATABASE_URL', '')
    if env:
        return env
    host = getattr(config, 'DB_HOST', '127.0.0.1')
    port = getattr(config, 'DB_PORT', 5432)
    name = getattr(config, 'DB_NAME', 'secftp')
    user = getattr(config, 'DB_USER', 'secftp')
    pwd  = getattr(config, 'DB_PASS', 'secftp_pass')
    return f"host={host} port={port} dbname={name} user={user} password={pwd} connect_timeout=10"


def _get_pool():
    global _pool
    if _pool is None:
        dsn     = _dsn()
        min_c   = getattr(config, 'DB_POOL_MIN', 4)
        max_c   = getattr(config, 'DB_POOL_MAX', 32)
        _pool   = psycopg2.pool.ThreadedConnectionPool(min_c, max_c, dsn)
        log.info(f"PostgreSQL pool: {min_c}~{max_c} | {dsn.split('dbname=')[-1].split()[0]}")
    return _pool


def close_pool():
    global _pool
    if _pool:
        _pool.closeall()
        _pool = None


# ── RealDictRow 兼容 sqlite3.Row ─────────────────────
class _Row(dict):
    """psycopg2 RealDictRow → 支持 row['key'] 和 row[index] 两种访问"""
    def __init__(self, data, keys):
        super().__init__(data)
        self._keys = list(keys)

    def __getitem__(self, key):
        if isinstance(key, int):
            return super().__getitem__(self._keys[key])
        return super().__getitem__(key)

    def keys(self):
        return self._keys

    def get(self, key, default=None):
        return super().get(key, default)


def _wrap(row):
    if row is None:
        return None
    if isinstance(row, dict):
        return _Row(row, list(row.keys()))
    return row


# ── SQL 方言转换 ──────────────────────────────────────
def _pg(sql):
    """SQLite → PostgreSQL SQL 方言自动转换"""
    sql = sql.replace('?', '%s')
    sql = sql.replace("datetime('now','localtime')", 'NOW()')
    sql = sql.replace("datetime('now')",             'NOW()')
    return sql


# ── Cursor / Connection 包装 ─────────────────────────
class _Cursor:
    def __init__(self, cur):
        self._c = cur

    @property
    def rowcount(self):
        return self._c.rowcount

    def execute(self, sql, params=None):
        self._c.execute(_pg(sql), params)
        return self

    def fetchone(self):
        return _wrap(self._c.fetchone())

    def fetchall(self):
        rows = self._c.fetchall()
        return [_wrap(r) for r in rows] if rows else []

    def __iter__(self):
        for r in self._c:
            yield _wrap(r)


class _Conn:
    def __init__(self, raw):
        self._raw = raw
        self._cur = None   # 懒创建

    def _get_cur(self):
        if self._cur is None:
            self._cur = _Cursor(
                self._raw.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            )
        return self._cur

    def execute(self, sql, params=None):
        return self._get_cur().execute(sql, params)

    def cursor(self):
        return _Cursor(
            self._raw.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        )

    def commit(self):   self._raw.commit()
    def rollback(self): self._raw.rollback()

    def __enter__(self):  return self
    def __exit__(self, *_): pass


@contextlib.contextmanager
def get_conn():
    """
    从连接池取连接，自动提交/回滚/归还。
    接口与 SQLite 版本完全相同。
    """
    pool = _get_pool()
    raw  = pool.getconn()
    raw.autocommit = False
    conn = _Conn(raw)
    try:
        yield conn
        raw.commit()
    except Exception:
        raw.rollback()
        raise
    finally:
        pool.putconn(raw)
