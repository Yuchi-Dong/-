@echo off
:: ============================================================
:: setup_postgres.bat — 锡林郭勒云盘 PostgreSQL 一键初始化脚本
:: 必须以管理员身份运行
:: 已安装 PostgreSQL 15+ 的情况下执行
:: ============================================================
chcp 65001 >nul
setlocal

echo.
echo ╔══════════════════════════════════════════════════════╗
echo ║        锡林郭勒云盘 — PostgreSQL 初始化脚本          ║
echo ╚══════════════════════════════════════════════════════╝
echo.

:: ── 配置项（按需修改）────────────────────────────────────
set DB_NAME=secftp
set DB_USER=secftp
set DB_PASS=Secftp@2025!
set PG_PORT=5432
:: PostgreSQL bin 目录（根据实际安装路径修改）
set PG_BIN=C:\Program Files\PostgreSQL\15\bin
set PSQL=%PG_BIN%\psql.exe

:: ── 检查 PostgreSQL ──────────────────────────────────────
if not exist "%PSQL%" (
    echo [错误] 未找到 psql.exe: %PSQL%
    echo 请先安装 PostgreSQL 15，下载地址: https://www.postgresql.org/download/windows/
    echo 或修改此脚本中的 PG_BIN 变量为实际安装路径
    pause & exit /b 1
)

echo [1/4] 创建数据库用户...
"%PSQL%" -U postgres -p %PG_PORT% -c "CREATE USER %DB_USER% WITH PASSWORD '%DB_PASS%';" 2>nul
"%PSQL%" -U postgres -p %PG_PORT% -c "ALTER USER %DB_USER% CREATEDB;" 2>nul
echo      用户 %DB_USER% 已就绪

echo [2/4] 创建数据库...
"%PSQL%" -U postgres -p %PG_PORT% -c "CREATE DATABASE %DB_NAME% OWNER %DB_USER% ENCODING 'UTF8' LC_COLLATE 'Chinese (Simplified)_China.936' LC_CTYPE 'Chinese (Simplified)_China.936';" 2>nul
if errorlevel 1 (
    :: 如果中文 locale 失败，用默认 locale
    "%PSQL%" -U postgres -p %PG_PORT% -c "CREATE DATABASE %DB_NAME% OWNER %DB_USER% ENCODING 'UTF8';" 2>nul
)
echo      数据库 %DB_NAME% 已就绪

echo [3/4] 授权...
"%PSQL%" -U postgres -p %PG_PORT% -d %DB_NAME% -c "GRANT ALL PRIVILEGES ON DATABASE %DB_NAME% TO %DB_USER%;" 2>nul
"%PSQL%" -U postgres -p %PG_PORT% -d %DB_NAME% -c "GRANT ALL ON SCHEMA public TO %DB_USER%;" 2>nul
echo      授权完成

echo [4/4] 写入环境变量...
setx DB_HOST "127.0.0.1" /M >nul 2>&1
setx DB_PORT "%PG_PORT%"  /M >nul 2>&1
setx DB_NAME "%DB_NAME%"  /M >nul 2>&1
setx DB_USER "%DB_USER%"  /M >nul 2>&1
setx DB_PASS "%DB_PASS%"  /M >nul 2>&1
echo      环境变量已写入系统（需重启 PowerShell 生效）

echo.
echo ══════════════════════════════════════════════════════
echo  PostgreSQL 初始化完成！
echo.
echo  连接信息：
echo    主机: 127.0.0.1:%PG_PORT%
echo    数据库: %DB_NAME%
echo    用户名: %DB_USER%
echo    密码: %DB_PASS%
echo.
echo  下一步：
echo    1. 安装 psycopg2:
echo       cd C:\SecFTP\secftp_pro
echo       venv\Scripts\activate
echo       pip install psycopg2-binary
echo.
echo    2. 初始化应用数据库表:
echo       python -c "from models import init_db; init_db(); print('OK')"
echo.
echo    3. 启动服务:
echo       C:\SecFTP\nssm\nssm.exe restart SecFTPWeb
echo ══════════════════════════════════════════════════════
echo.
pause
