# -*- coding: utf-8 -*-
"""
routes/admin_routes.py — 组织管理 / 用户管理 / 审计日志 / 索引重建
"""
import os
import re
import json
import secrets
import threading

from flask import Blueprint, session, request, jsonify

import config
from auth import login_required, role_required, generate_csrf_token, csrf_ok, ROLE_SUPER, ROLE_DEPT
from services.org_service import (create_organization, update_organization,
                                   delete_organization, get_org_tree, get_level_label)
from services.user_service import create_user, change_password
from dao.org_dao import get_all as get_all_orgs
from dao.user_dao import get_all as get_all_users, update_info, set_active
from dao.file_dao import log_action, get_audit_logs
from dao.db import get_conn
from templates import layout

bp = Blueprint("admin", __name__)


# ── 组织管理 ─────────────────────────────────────────
@bp.route("/admin/orgs")
@login_required
@role_required(ROLE_SUPER)
def admin_orgs():
    all_orgs = get_all_orgs()
    org_tree = get_org_tree()
    csrf     = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    lvl_default = config.ORG_LEVEL_NAMES
    lvl1_name   = lvl_default.get(1, "委办局")
    lvl2_name   = lvl_default.get(2, "业务科室")
    lvl3_name   = lvl_default.get(3, "工作小组")

    def _lvl_icon(level):
        return {1: "🏛", 2: "🏢", 3: "👥"}.get(level, "📁")

    def _lvl_badge(level):
        return {1: "badge-super", 2: "badge-blue", 3: "badge-gray"}.get(level, "badge-gray")

    def render_node(o, indent=0):
        oid      = o["id"]; oname = o["name"]; odirpath = o["dir_path"]
        level    = o.get("org_level", 1)
        lname    = o.get("level_label") or lvl_default.get(level, "组织")
        mc       = o.get("member_count", 0)
        children = o.get("children", [])
        indent_px = indent * 24

        toggle_btn = ""; child_wrap = ""
        if children:
            nid = "ch_" + str(oid)
            toggle_btn = (f'<button class="org-toggle" onclick="toggleChildren(\'{nid}\')"'
                          f' id="tb_{oid}">▼</button>')
            child_wrap = (f'<div class="org-children" id="{nid}">'
                          + "".join(render_node(c, indent+1) for c in children) + '</div>')

        add_child_btn = ""
        if level < 3:
            cl    = level + 1
            clname = lvl_default.get(cl, "子组织")
            add_child_btn = (f'<button class="btn btn-xs btn-outline" '
                             f'onclick="openCreateOrg({oid},{cl},\'{clname}\')">➕ 新建{clname}</button>')

        sn = oname.replace('"', '&quot;').replace("'", "\\'")
        sd = (o.get("desc", "") or "").replace('"', '&quot;').replace("'", "\\'")
        sl = (o.get("level_label", "") or "").replace('"', '&quot;').replace("'", "\\'")
        edit_btn   = (f'<button class="btn btn-xs btn-outline" onclick="openEditOrg({oid},\'{sn}\',\'{sd}\',\'{sl}\')">'
                      f'编辑</button>')
        browse_btn = f'<a class="btn btn-xs btn-outline" href="/browse/{odirpath}">浏览</a>'
        del_btn    = f'<button class="btn btn-xs btn-danger" onclick="deleteOrg({oid},\'{sn}\')">删除</button>'

        return f"""
<div class="org-node" style="margin-left:{indent_px}px">
  <div class="org-row">
    <div class="org-row-left">
      {toggle_btn}
      <span class="org-icon">{_lvl_icon(level)}</span>
      <span class="org-name">{oname}</span>
      <span class="badge {_lvl_badge(level)}" style="font-size:10px">{lname}</span>
      <span class="org-code">/{odirpath}</span>
    </div>
    <div class="org-row-right">
      <span style="font-size:11px;color:var(--text3)">👥 {mc} 人</span>
      {add_child_btn} {edit_btn} {browse_btn} {del_btn}
    </div>
  </div>
  {child_wrap}
</div>"""

    tree_html = "".join(render_node(root) for root in org_tree) or \
        '<div class="empty-state"><div class="es-icon">🏢</div><p>暂无组织，点击右上角新建</p></div>'

    l1_opts = json.dumps([{"id": o["id"], "name": o["name"]} for o in all_orgs if o.get("org_level", 1) == 1], ensure_ascii=False)
    l2_opts = json.dumps([{"id": o["id"], "name": o["name"], "parent_id": o.get("parent_id")} for o in all_orgs if o.get("org_level", 1) == 2], ensure_ascii=False)

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div class="page-title"><span class="pt-icon">🏛</span>组织架构管理</div>
    <button class="btn btn-primary" onclick="openCreateOrg(null,1,'{lvl1_name}')">➕ 新建{lvl1_name}</button>
  </div>
  <div class="card" style="padding:10px 16px;flex-shrink:0">
    <div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
      <span style="font-size:12px;color:var(--text3)">层级结构：</span>
      <span class="badge badge-super">🏛 {lvl1_name}（一级）</span>
      <span style="color:var(--text3)">→</span>
      <span class="badge badge-blue">🏢 {lvl2_name}（二级）</span>
      <span style="color:var(--text3)">→</span>
      <span class="badge badge-gray">👥 {lvl3_name}（三级）</span>
    </div>
  </div>
  <div class="card" style="flex:1;overflow-y:auto">
    <div style="padding:12px 16px">{tree_html}</div>
  </div>
</div>

<div class="overlay" id="m-create-org" onclick="if(event.target===this)hideModal('m-create-org')">
  <div class="modal" style="max-width:480px">
    <div class="modal-hdr"><h3 id="co-title">新建组织</h3>
      <button class="modal-close" onclick="hideModal('m-create-org')">✕</button></div>
    <input type="hidden" id="co-level" value="1">
    <div class="fg" id="co-parent-wrap" style="display:none">
      <label id="co-parent-label">上级组织</label>
      <select class="inp inp-sel" id="co-parent"><option value="">请选择</option></select>
    </div>
    <div class="fg"><label>名称</label><input class="inp" id="co-name" placeholder="例如：综合办公室"></div>
    <div class="fg"><label>代码（英文/数字/下划线）</label><input class="inp" id="co-code" placeholder="例如：dept_zzb"></div>
    <div class="fg"><label>层级显示名（可选）</label><input class="inp" id="co-level-label" placeholder="如：处室、股室"></div>
    <div class="fg"><label>描述（可选）</label><input class="inp" id="co-desc"></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-create-org')">取消</button>
      <button class="btn btn-primary" onclick="submitCreateOrg()">创建</button>
    </div>
  </div>
</div>

<div class="overlay" id="m-edit-org" onclick="if(event.target===this)hideModal('m-edit-org')">
  <div class="modal" style="max-width:480px">
    <div class="modal-hdr"><h3>✏️ 编辑组织</h3>
      <button class="modal-close" onclick="hideModal('m-edit-org')">✕</button></div>
    <input type="hidden" id="eo-id">
    <div class="fg"><label>名称</label><input class="inp" id="eo-name"></div>
    <div class="fg"><label>层级显示名（可选）</label><input class="inp" id="eo-level-label"></div>
    <div class="fg"><label>描述</label><input class="inp" id="eo-desc"></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-edit-org')">取消</button>
      <button class="btn btn-primary" onclick="submitEditOrg()">保存</button>
    </div>
  </div>
</div>

<style>
.org-node{{margin-bottom:2px}}
.org-row{{display:flex;align-items:center;justify-content:space-between;padding:8px 12px;
  border:1px solid var(--border);border-radius:var(--radius);background:var(--white);
  transition:background .12s;gap:8px;flex-wrap:wrap}}
.org-row:hover{{background:var(--primary-xlt)}}
.org-row-left{{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-width:0}}
.org-row-right{{display:flex;align-items:center;gap:6px;flex-shrink:0;flex-wrap:wrap}}
.org-icon{{font-size:16px;flex-shrink:0}}
.org-name{{font-weight:600;font-size:13px;color:var(--text)}}
.org-code{{font-size:11px;color:var(--text3);font-family:var(--font-mono)}}
.org-toggle{{background:none;border:none;cursor:pointer;font-size:11px;color:var(--text3);
  width:18px;height:18px;display:flex;align-items:center;justify-content:center;
  border-radius:3px;flex-shrink:0;transition:transform .15s}}
.org-children{{margin-top:4px;padding-left:8px;border-left:2px solid var(--border);margin-left:8px}}
</style>

<script>
const _l1opts={l1_opts};
const _l2opts={l2_opts};
const _lvlNames={json.dumps(lvl_default, ensure_ascii=False)};

function toggleChildren(id){{
  const el=document.getElementById(id);
  if(!el) return;
  el.style.display=el.style.display==='none'?'':'none';
}}
function openCreateOrg(parentId,level,lvlName){{
  document.getElementById('co-level').value=level;
  document.getElementById('co-title').textContent='新建'+lvlName;
  document.getElementById('co-name').value='';
  document.getElementById('co-code').value='';
  document.getElementById('co-desc').value='';
  document.getElementById('co-level-label').value='';
  const pw=document.getElementById('co-parent-wrap');
  const sel=document.getElementById('co-parent');
  if(level>1){{
    pw.style.display='';
    const opts=level===2?_l1opts:_l2opts;
    sel.innerHTML='<option value="">请选择</option>'+opts.map(o=>`<option value="${{o.id}}">${{o.name}}</option>`).join('');
    if(parentId) sel.value=String(parentId);
  }}else pw.style.display='none';
  showModal('m-create-org');
}}
async function submitCreateOrg(){{
  const level=parseInt(document.getElementById('co-level').value)||1;
  const name=document.getElementById('co-name').value.trim();
  const code=document.getElementById('co-code').value.trim();
  const desc=document.getElementById('co-desc').value.trim();
  const lvlLabel=document.getElementById('co-level-label').value.trim();
  const parentId=document.getElementById('co-parent').value||null;
  if(!name){{toast('名称不能为空','err');return;}}
  if(!code){{toast('代码不能为空','err');return;}}
  if(level>1&&!parentId){{toast('请选择上级组织','err');return;}}
  const r=await fetch('/api/admin/org/create',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{name,code,desc,org_level:level,level_label:lvlLabel,
      parent_id:parentId?parseInt(parentId):null,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{hideModal('m-create-org');toast('创建成功','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
function openEditOrg(id,name,desc,lvlLabel){{
  document.getElementById('eo-id').value=id;
  document.getElementById('eo-name').value=name;
  document.getElementById('eo-desc').value=desc;
  document.getElementById('eo-level-label').value=lvlLabel;
  showModal('m-edit-org');
}}
async function submitEditOrg(){{
  const id=document.getElementById('eo-id').value;
  const name=document.getElementById('eo-name').value.trim();
  const desc=document.getElementById('eo-desc').value.trim();
  const lvlLabel=document.getElementById('eo-level-label').value.trim();
  if(!name){{toast('名称不能为空','err');return;}}
  const r=await fetch('/api/admin/org/update',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{org_id:parseInt(id),name,desc,level_label:lvlLabel,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{hideModal('m-edit-org');toast('已更新','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
async function deleteOrg(id,name){{
  if(!confirm('确认删除「'+name+'」？')) return;
  const r=await fetch('/api/admin/org/delete',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{org_id:id,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('已删除','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "组织管理", "orgs", **ctx())


@bp.route("/api/admin/org/create", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_org_create():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    oid, err = create_organization(
        data.get("name", ""), data.get("code", ""), data.get("desc", ""),
        data.get("parent_id"), int(data.get("org_level", 1)),
        data.get("level_label", ""), session["uid"]
    )
    if err: return jsonify({"success": False, "error": err})
    log_action(session["uid"], session["uname"], "CREATE_ORG", data.get("name", ""), request.remote_addr)
    return jsonify({"success": True, "org_id": oid})


@bp.route("/api/admin/org/update", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_org_update():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    ok, err = update_organization(data.get("org_id"), data.get("name", ""),
                                   data.get("desc", ""), data.get("level_label"))
    if ok: log_action(session["uid"], session["uname"], "UPDATE_ORG", str(data.get("org_id")), request.remote_addr)
    return jsonify({"success": ok, "error": err})


@bp.route("/api/admin/org/delete", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_org_delete():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    ok, err = delete_organization(data.get("org_id"))
    if ok: log_action(session["uid"], session["uname"], "DELETE_ORG", str(data.get("org_id")), request.remote_addr, "WARN")
    return jsonify({"success": ok, "error": err})


# ── 用户管理 ─────────────────────────────────────────
@bp.route("/admin/users")
@login_required
@role_required(ROLE_DEPT)
def admin_users():
    users     = get_all_users(session["role"], session.get("org_id"))
    all_orgs  = get_all_orgs()
    csrf      = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    role_labels = {0: "超级管理员", 1: "组织管理员", 2: "普通用户"}
    av_cls  = {0: "uav-s", 1: "uav-d", 2: "uav-u"}
    rb_cls  = {0: "badge-super", 1: "badge-blue", 2: "badge-gray"}

    cards = ""
    for u in users:
        av  = (u.get("display_name") or u["username"])[0].upper()
        uid = u["id"]
        dn  = (u.get("display_name") or u["username"]).replace('"', '').replace("'", "")
        em  = (u.get("email") or "").replace('"', '').replace("'", "")
        ph  = (u.get("phone") or "").replace('"', '').replace("'", "")
        cards += f"""
        <div class="ucard {'udisabled' if not u['is_active'] else ''}">
          <div class="uav {av_cls.get(u['role'], 'uav-u')}">{av}</div>
          <h3>{u.get('display_name') or u['username']}</h3>
          <div class="uname">@{u['username']}</div>
          <div style="text-align:center;margin-top:6px">
            <span class="badge {rb_cls.get(u['role'], 'badge-gray')}">{role_labels.get(u['role'], '用户')}</span>
          </div>
          <div class="uinfo">
            <div>组织：{u.get('org_name') or '—'}</div>
            <div>配额：{u.get('quota_mb', 1024000)//1024} GB</div>
            <div>状态：<span style="color:{'var(--success)' if u['is_active'] else 'var(--danger)'}">
              {'✓ 正常' if u['is_active'] else '✗ 禁用'}</span></div>
            <div>最近登录：{u.get('last_login', '从未') or '从未'}</div>
          </div>
          <div class="ucard-acts" style="flex-wrap:wrap">
            <button class="btn btn-xs btn-primary" style="flex:1"
              onclick='openEditUser({uid},"{dn}","{em}","{ph}",{u["role"]},{u.get("org_id") or "null"},{u.get("quota_mb") or 1024000})'>编辑</button>
            <button class="btn btn-xs btn-outline" style="flex:1"
              onclick='openResetPw({uid},"{u["username"]}")'>重置密码</button>
            <button class="btn btn-xs {'btn-danger' if u['is_active'] else 'btn-success'}" style="width:100%"
              onclick="toggleUser({uid})">{'禁用' if u['is_active'] else '启用'}</button>
          </div>
        </div>"""

    # 两级组织联动数据
    l1_orgs = [{"id": o["id"], "name": o["name"]} for o in all_orgs if o.get("org_level", 1) == 1]
    l2_orgs = [{"id": o["id"], "name": o["name"], "parent_id": o.get("parent_id")} for o in all_orgs if o.get("org_level", 1) == 2]
    all_orgs_flat = [{"id": o["id"], "name": o["name"], "level": o.get("org_level", 1), "parent_id": o.get("parent_id")} for o in all_orgs]
    lvl1_name = config.ORG_LEVEL_NAMES.get(1, "委办局")
    lvl2_name = config.ORG_LEVEL_NAMES.get(2, "业务科室")

    super_opt = f'<option value="0">超级管理员</option>' if session["role"] == 0 else ""

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between">
    <div class="page-title"><span class="pt-icon">👥</span>用户管理</div>
    <button class="btn btn-primary" onclick="showModal('m-create-user')">➕ 新建用户</button>
  </div>
  <div class="card" style="flex:1;overflow-y:auto">
    <div class="user-grid">{cards}</div>
  </div>
</div>

<div class="overlay" id="m-create-user" onclick="if(event.target===this)hideModal('m-create-user')">
  <div class="modal">
    <div class="modal-hdr"><h3>➕ 新建用户</h3>
      <button class="modal-close" onclick="hideModal('m-create-user')">✕</button></div>
    <div class="fg"><label>用户名</label><input class="inp" id="nu-user" placeholder="英文字母开头，3-20位"></div>
    <div class="fg"><label>姓名</label><input class="inp" id="nu-name" placeholder="真实姓名"></div>
    <div class="fg"><label>初始密码</label><input class="inp" type="password" id="nu-pw" placeholder="至少8位"></div>
    <div class="fg"><label>角色</label>
      <select class="inp inp-sel" id="nu-role">
        <option value="2">普通用户</option><option value="1">组织管理员</option>{super_opt}
      </select></div>
    <div class="fg"><label>所属{lvl1_name}</label>
      <select class="inp inp-sel" id="nu-dept" onchange="nuDeptChange(this.value)">
        <option value="">（不归属{lvl1_name}）</option></select></div>
    <div class="fg" id="nu-section-wrap" style="display:none"><label>所属{lvl2_name}（可选）</label>
      <select class="inp inp-sel" id="nu-org">
        <option value="">（直属{lvl1_name}）</option></select></div>
    <div class="fg"><label>存储配额</label>
      <select class="inp inp-sel" id="nu-quota">
        <option value="10240">10 GB</option><option value="51200">50 GB</option>
        <option value="102400">100 GB</option><option value="512000">500 GB</option>
        <option value="1024000" selected>1000 GB</option><option value="5120000">5000 GB</option>
      </select></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-create-user')">取消</button>
      <button class="btn btn-primary" onclick="submitCreateUser()">创建用户</button>
    </div>
  </div>
</div>

<div class="overlay" id="m-reset-pw" onclick="if(event.target===this)hideModal('m-reset-pw')">
  <div class="modal">
    <div class="modal-hdr"><h3>🔑 重置密码</h3>
      <button class="modal-close" onclick="hideModal('m-reset-pw')">✕</button></div>
    <p style="font-size:13px;color:var(--text2);margin-bottom:14px">为 <strong id="rp-uname" style="color:var(--primary)"></strong> 设置新密码</p>
    <input type="hidden" id="rp-uid">
    <div class="fg"><label>新密码（至少8位）</label><input class="inp" type="password" id="rp-pw"></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-reset-pw')">取消</button>
      <button class="btn btn-primary" onclick="submitResetPw()">确认重置</button>
    </div>
  </div>
</div>

<div class="overlay" id="m-edit-user" onclick="if(event.target===this)hideModal('m-edit-user')">
  <div class="modal">
    <div class="modal-hdr"><h3>✏️ 编辑用户信息</h3>
      <button class="modal-close" onclick="hideModal('m-edit-user')">✕</button></div>
    <input type="hidden" id="eu-id">
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
      <div class="fg" style="margin:0"><label>姓名</label><input class="inp" id="eu-name"></div>
      <div class="fg" style="margin:0"><label>邮箱</label><input class="inp" id="eu-email" type="email"></div>
      <div class="fg" style="margin:0"><label>手机号</label><input class="inp" id="eu-phone"></div>
      <div class="fg" style="margin:0"><label>角色</label>
        <select class="inp inp-sel" id="eu-role">
          <option value="2">普通用户</option><option value="1">组织管理员</option>{super_opt}
        </select></div>
    </div>
    <div class="fg" style="margin-top:12px"><label>所属{lvl1_name}</label>
      <select class="inp inp-sel" id="eu-dept" onchange="euDeptChange(this.value)">
        <option value="">（不归属{lvl1_name}）</option></select></div>
    <div class="fg" id="eu-section-wrap" style="display:none"><label>所属{lvl2_name}（可选）</label>
      <select class="inp inp-sel" id="eu-org">
        <option value="">（直属{lvl1_name}）</option></select></div>
    <div class="fg"><label>存储配额</label>
      <select class="inp inp-sel" id="eu-quota">
        <option value="10240">10 GB</option><option value="51200">50 GB</option>
        <option value="102400">100 GB</option><option value="512000">500 GB</option>
        <option value="1024000">1000 GB</option><option value="5120000">5000 GB</option>
      </select></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-edit-user')">取消</button>
      <button class="btn btn-primary" onclick="submitEditUser()">保存修改</button>
    </div>
  </div>
</div>

<script>
const _l1orgs={json.dumps(l1_orgs, ensure_ascii=False)};
const _l2orgs={json.dumps(l2_orgs, ensure_ascii=False)};
const _allOrgs={json.dumps(all_orgs_flat, ensure_ascii=False)};
const _l1name="{lvl1_name}"; const _l2name="{lvl2_name}";

function _populateSelect(sel,items,emptyLabel){{
  const prev=sel.value;
  sel.innerHTML='<option value="">'+emptyLabel+'</option>';
  items.forEach(o=>{{const opt=document.createElement('option');opt.value=String(o.id);opt.textContent=o.name;sel.appendChild(opt);}});
  if(prev) sel.value=prev;
}}
function _getSelectedOrg(prefix){{
  const dv=document.getElementById(prefix+'-dept').value;
  const ov=document.getElementById(prefix+'-org').value;
  return ov||dv||null;
}}
function nuDeptChange(deptId){{
  const wrap=document.getElementById('nu-section-wrap');
  const sel=document.getElementById('nu-org');
  if(!deptId){{wrap.style.display='none';sel.value='';return;}}
  const ch=_l2orgs.filter(o=>String(o.parent_id)===String(deptId));
  if(!ch.length){{wrap.style.display='none';sel.value='';return;}}
  _populateSelect(sel,ch,'（直属'+_l1name+'）');
  wrap.style.display='';sel.value='';
}}
function euDeptChange(deptId){{
  const wrap=document.getElementById('eu-section-wrap');
  const sel=document.getElementById('eu-org');
  if(!deptId){{wrap.style.display='none';sel.value='';return;}}
  const ch=_l2orgs.filter(o=>String(o.parent_id)===String(deptId));
  if(!ch.length){{wrap.style.display='none';sel.value='';return;}}
  _populateSelect(sel,ch,'（直属'+_l1name+'）');
  wrap.style.display='';sel.value='';
}}
function _fillEuOrg(orgId){{
  const deptSel=document.getElementById('eu-dept');
  const orgSel=document.getElementById('eu-org');
  const wrap=document.getElementById('eu-section-wrap');
  _populateSelect(deptSel,_l1orgs,'（不归属'+_l1name+'）');
  if(!orgId){{deptSel.value='';wrap.style.display='none';orgSel.value='';return;}}
  const rec=_allOrgs.find(o=>o.id===orgId);
  if(!rec){{deptSel.value='';wrap.style.display='none';return;}}
  if(rec.level===1){{deptSel.value=String(orgId);wrap.style.display='none';orgSel.value='';}}
  else{{
    deptSel.value=String(rec.parent_id||'');
    euDeptChange(String(rec.parent_id||''));
    orgSel.value=String(orgId);
  }}
}}
function openResetPw(id,uname){{
  document.getElementById('rp-uid').value=id;
  document.getElementById('rp-uname').textContent=uname;
  document.getElementById('rp-pw').value='';
  showModal('m-reset-pw');
}}
function openEditUser(id,name,email,phone,role,orgId,quota){{
  document.getElementById('eu-id').value=id;
  document.getElementById('eu-name').value=name;
  document.getElementById('eu-email').value=email;
  document.getElementById('eu-phone').value=phone;
  document.getElementById('eu-role').value=String(role);
  document.getElementById('eu-quota').value=String(quota);
  _fillEuOrg(orgId===null?null:parseInt(orgId));
  showModal('m-edit-user');
}}
async function submitCreateUser(){{
  const data={{username:document.getElementById('nu-user').value.trim(),
    display_name:document.getElementById('nu-name').value.trim(),
    password:document.getElementById('nu-pw').value,
    role:parseInt(document.getElementById('nu-role').value),
    org_id:_getSelectedOrg('nu'),
    quota_mb:parseInt(document.getElementById('nu-quota').value),
    csrf_token:'{csrf}'}};
  if(!data.username||data.username.length<3){{toast('用户名至少3位','err');return;}}
  if(!data.display_name){{toast('请填写姓名','err');return;}}
  if(data.password.length<8){{toast('密码至少8位','err');return;}}
  const r=await fetch('/api/admin/user/create',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},body:JSON.stringify(data)}});
  const d=await r.json();
  if(d.success){{hideModal('m-create-user');toast('用户创建成功','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
async function submitResetPw(){{
  const id=document.getElementById('rp-uid').value;
  const pw=document.getElementById('rp-pw').value;
  if(pw.length<8){{toast('密码至少8位','err');return;}}
  const r=await fetch('/api/admin/user/reset-pw',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{user_id:id,password:pw,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{hideModal('m-reset-pw');toast('密码已重置','ok');}}
  else toast('失败：'+d.error,'err');
}}
async function toggleUser(id){{
  const r=await fetch('/api/admin/user/toggle',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{user_id:id,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success) location.reload();
  else toast('操作失败：'+d.error,'err');
}}
async function submitEditUser(){{
  const id=document.getElementById('eu-id').value;
  const data={{user_id:id,
    display_name:document.getElementById('eu-name').value.trim(),
    email:document.getElementById('eu-email').value.trim(),
    phone:document.getElementById('eu-phone').value.trim(),
    role:parseInt(document.getElementById('eu-role').value),
    org_id:_getSelectedOrg('eu'),
    quota_mb:parseInt(document.getElementById('eu-quota').value),
    csrf_token:'{csrf}'}};
  if(!data.display_name){{toast('姓名不能为空','err');return;}}
  const r=await fetch('/api/admin/user/update',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},body:JSON.stringify(data)}});
  const d=await r.json();
  if(d.success){{hideModal('m-edit-user');toast('已更新','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
(function(){{
  _populateSelect(document.getElementById('nu-dept'),_l1orgs,'（不归属'+_l1name+'）');
  _populateSelect(document.getElementById('eu-dept'),_l1orgs,'（不归属'+_l1name+'）');
}})();
</script>"""
    from routes._ctx import ctx
    return layout(content, "用户管理", "users", **ctx())


@bp.route("/api/admin/user/create", methods=["POST"])
@login_required
@role_required(ROLE_DEPT)
def api_user_create():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    uid, err = create_user(data.get("username", ""), data.get("password", ""),
                           int(data.get("role", 2)), data.get("org_id"),
                           data.get("display_name", ""), data.get("email", ""),
                           int(data.get("quota_mb", 1024000)), session["uid"])
    if err: return jsonify({"success": False, "error": err})
    log_action(session["uid"], session["uname"], "CREATE_USER", data.get("username", ""), request.remote_addr)
    return jsonify({"success": True, "user_id": uid})


@bp.route("/api/admin/user/update", methods=["POST"])
@login_required
@role_required(ROLE_DEPT)
def api_user_update():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    user_id = data.get("user_id")
    if not user_id: return jsonify({"success": False, "error": "缺少用户ID"})
    if session["role"] != ROLE_SUPER:
        with get_conn() as conn:
            target = conn.execute("SELECT org_id,role FROM users WHERE id=%s", (user_id,)).fetchone()
        if not target or target["org_id"] != session.get("org_id"):
            return jsonify({"success": False, "error": "无权限修改此用户"}), 403
        if int(data.get("role", 2)) < ROLE_DEPT:
            return jsonify({"success": False, "error": "无权限设置此角色"}), 403
    try:
        update_info(user_id, data.get("display_name", ""), data.get("email", ""),
                    data.get("phone", ""), int(data.get("role", 2)),
                    data.get("org_id") or None, int(data.get("quota_mb", 1024000)))
        log_action(session["uid"], session["uname"], "UPDATE_USER",
                   f"uid={user_id}", request.remote_addr)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@bp.route("/api/admin/user/reset-pw", methods=["POST"])
@login_required
@role_required(ROLE_DEPT)
def api_user_reset_pw():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    pw = data.get("password", "")
    if len(pw) < 8: return jsonify({"success": False, "error": "密码至少8位"})
    change_password(int(data.get("user_id")), pw)
    log_action(session["uid"], session["uname"], "RESET_PW", str(data.get("user_id")), request.remote_addr, "WARN")
    return jsonify({"success": True})


@bp.route("/api/admin/user/toggle", methods=["POST"])
@login_required
@role_required(ROLE_DEPT)
def api_user_toggle():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    with get_conn() as conn:
        row = conn.execute("SELECT is_active FROM users WHERE id=%s", (data.get("user_id"),)).fetchone()
    new_state = 0 if row and row["is_active"] else 1
    set_active(data.get("user_id"), bool(new_state))
    log_action(session["uid"], session["uname"],
               "ENABLE_USER" if new_state else "DISABLE_USER",
               str(data.get("user_id")), request.remote_addr, "WARN")
    return jsonify({"success": True, "new_state": new_state})


# ── 索引重建 ─────────────────────────────────────────
@bp.route("/admin/reindex")
@login_required
@role_required(ROLE_SUPER)
def admin_reindex():
    from indexer import rebuild_index
    t = threading.Thread(target=rebuild_index, args=(config.FILE_ROOT,), daemon=True)
    t.start()
    return jsonify({"success": True, "message": "索引重建已在后台启动"})


# ── 审计日志 ─────────────────────────────────────────
@bp.route("/admin/audit")
@login_required
@role_required(ROLE_SUPER)
def admin_audit():
    logs      = get_audit_logs(limit=300)
    level_cls = {"INFO": "badge-blue", "WARN": "badge-yellow", "ERROR": "badge-red"}
    rows = "".join(f"""<tr>
        <td class="fdate">{r["ts"]}</td>
        <td style="font-size:12px">{r.get("username", "")}</td>
        <td><span class="badge {level_cls.get(r['level'], 'badge-gray')}">{r['level']}</span></td>
        <td style="font-family:var(--font-mono);font-size:12px">{r['action']}</td>
        <td style="font-size:12px;color:var(--text2)">{r.get('detail', '')}</td>
        <td class="fdate">{r.get('ip', '')}</td>
      </tr>""" for r in logs) or \
        '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">📋</div><p>暂无日志</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">📋</span>审计日志</div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>操作记录</h2>
      <span class="badge badge-gray">{len(logs)} 条</span></div>
    <div class="card-body"><table class="tbl"><thead><tr>
      <th style="width:150px">时间</th><th>用户</th><th>级别</th>
      <th>操作</th><th>详情</th><th>IP</th>
    </tr></thead><tbody>{rows}</tbody></table></div>
  </div>
</div>"""
    from routes._ctx import ctx
    return layout(content, "审计日志", "audit", **ctx())
