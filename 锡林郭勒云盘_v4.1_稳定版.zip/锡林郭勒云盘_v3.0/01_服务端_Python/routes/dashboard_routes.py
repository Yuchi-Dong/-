# -*- coding: utf-8 -*-
"""
routes/dashboard_routes.py — 运营仪表盘 & 存储分析

路由：
  GET  /dashboard               管理员/普通用户仪表盘主页
  GET  /api/dashboard/stats     仪表盘核心统计数据（JSON）
  GET  /api/dashboard/trend     30天存储趋势（JSON）
  GET  /api/dashboard/filetype  文件类型分布（JSON）
  GET  /api/dashboard/activity  近24小时操作热力数据（JSON）
  GET  /api/dashboard/topusers  用量排行榜（JSON，管理员）
  GET  /admin/storage-analytics 存储分析页（管理员专属）
"""
import os
from datetime import datetime, timedelta
from flask import Blueprint, session, jsonify, request, abort
import config
from auth import login_required, ROLE_SUPER, ROLE_DEPT
from dao.db import get_conn
from templates import layout

bp = Blueprint("dashboard", __name__)


# ════════════════════════════════════════════════════
#  数据聚合函数
# ════════════════════════════════════════════════════

def _get_core_stats(uid: int, role: int, org_id) -> dict:
    """核心统计数字：总文件数、存储量、用户数、分享数、在线活跃"""
    with get_conn() as conn:
        # 文件数 & 总存储（file_index）
        if role == ROLE_SUPER:
            fi = conn.execute(
                "SELECT COUNT(*) as cnt, COALESCE(SUM(file_size),0) as sz FROM file_index"
            ).fetchone()
        else:
            fi = conn.execute(
                "SELECT COUNT(*) as cnt, COALESCE(SUM(file_size),0) as sz "
                "FROM file_index WHERE file_path LIKE %s OR file_path LIKE %s",
                (f"users/{session.get('uname','')}/%", f"{org_id or 'x'}/%")
            ).fetchone()

        file_count  = fi["cnt"] if fi else 0
        total_bytes = fi["sz"]  if fi else 0

        # 用户数（管理员可见全部，普通用户看同组织）
        if role == ROLE_SUPER:
            uc = conn.execute("SELECT COUNT(*) FROM users WHERE is_active=1").fetchone()[0]
        elif org_id:
            uc = conn.execute(
                "SELECT COUNT(*) FROM users WHERE is_active=1 AND org_id=%s", (org_id,)
            ).fetchone()[0]
        else:
            uc = 1

        # 活跃分享数
        share_c = conn.execute(
            "SELECT COUNT(*) FROM file_shares WHERE is_active=1 "
            + ("" if role == ROLE_SUPER else "AND owner_id=%s"),
            () if role == ROLE_SUPER else (uid,)
        ).fetchone()[0]

        # 今日操作数
        today_ops = conn.execute(
            "SELECT COUNT(*) FROM audit_log_secure WHERE ts >= %s",
            (datetime.now().strftime("%Y-%m-%d 00:00:00"),)
        ).fetchone()[0]

        # 近30分钟活跃 session（有 last_active 记录）
        active_now = conn.execute(
            "SELECT COUNT(DISTINCT user_id) FROM active_sessions "
            "WHERE is_active=1 AND last_active >= NOW() - INTERVAL '30 minutes'"
        ).fetchone()[0]

        # 待审批申请（管理员）
        pending_reg = 0
        if role <= ROLE_DEPT:
            pending_reg = conn.execute(
                "SELECT COUNT(*) FROM register_requests WHERE status='pending'"
            ).fetchone()[0]

    return {
        "file_count":   file_count,
        "total_gb":     round(total_bytes / 1024**3, 2),
        "total_mb":     round(total_bytes / 1024**2, 1),
        "user_count":   uc,
        "share_count":  share_c,
        "today_ops":    today_ops,
        "active_now":   active_now,
        "pending_reg":  pending_reg,
    }


def _get_trend(days: int = 30) -> list:
    """近 N 天每日新增文件数和存储量"""
    rows = []
    with get_conn() as conn:
        result = conn.execute("""
            SELECT DATE(ts::timestamp) as day,
                   COUNT(*) as ops,
                   COUNT(*) FILTER (WHERE action='UPLOAD') as uploads
            FROM audit_log_secure
            WHERE ts >= %s
            GROUP BY day ORDER BY day ASC
        """, ((datetime.now() - timedelta(days=days)).strftime("%Y-%m-%d"),)).fetchall()
    return [{"day": str(r["day"]), "ops": r["ops"], "uploads": r["uploads"]} for r in result]


def _get_filetype_dist() -> list:
    """文件类型分布"""
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT ftype,
                   COUNT(*) as cnt,
                   COALESCE(SUM(file_size),0) as bytes
            FROM file_index
            WHERE ftype IS NOT NULL
            GROUP BY ftype ORDER BY bytes DESC
        """).fetchall()
    type_labels = {
        "image": "图片", "pdf": "PDF", "video": "视频",
        "audio": "音频", "word": "Word", "excel": "Excel",
        "ppt": "PPT", "zip": "压缩包", "text": "文本", "other": "其他",
    }
    colors = {
        "image": "#3b82f6", "pdf": "#ef4444", "video": "#8b5cf6",
        "audio": "#ec4899", "word": "#2563eb", "excel": "#16a34a",
        "ppt": "#f59e0b", "zip": "#64748b", "text": "#06b6d4", "other": "#9ca3af",
    }
    return [
        {
            "ftype": r["ftype"],
            "label": type_labels.get(r["ftype"], r["ftype"]),
            "count": r["cnt"],
            "bytes": r["bytes"],
            "color": colors.get(r["ftype"], "#9ca3af"),
        }
        for r in rows if r["cnt"] > 0
    ]


def _get_activity_heatmap() -> list:
    """近7天每小时操作量（热力图数据，7×24 矩阵）"""
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT
                EXTRACT(DOW  FROM ts::timestamp)::int AS dow,
                EXTRACT(HOUR FROM ts::timestamp)::int AS hour,
                COUNT(*) AS cnt
            FROM audit_log_secure
            WHERE ts >= %s
            GROUP BY dow, hour
        """, ((datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),)).fetchall()

    matrix = [[0]*24 for _ in range(7)]
    for r in rows:
        d, h, c = int(r["dow"]), int(r["hour"]), int(r["cnt"])
        if 0 <= d < 7 and 0 <= h < 24:
            matrix[d][h] = c
    return matrix


def _get_top_users(limit: int = 10) -> list:
    """存储用量 Top N 用户"""
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT u.id, u.username, u.display_name, u.quota_mb, u.org_id,
                   COALESCE(fi.used_mb, 0) as used_mb,
                   o.name as org_name
            FROM users u
            LEFT JOIN (
                SELECT file_path, SUM(file_size)/1048576.0 as used_mb
                FROM file_index
                WHERE file_path LIKE 'users/%'
                GROUP BY SUBSTRING(file_path FROM 'users/([^/]+)/')
            ) fi ON fi.file_path LIKE 'users/' || u.username || '/%'
            LEFT JOIN organizations o ON o.id = u.org_id
            WHERE u.is_active = 1
            ORDER BY used_mb DESC
            LIMIT %s
        """, (limit,)).fetchall()

        # 简化版：直接按 audit 操作量排行
        active_rows = conn.execute("""
            SELECT username, COUNT(*) as ops
            FROM audit_log_secure
            WHERE ts >= %s AND action IN ('UPLOAD','DOWNLOAD','EDIT_SAVE')
            GROUP BY username ORDER BY ops DESC LIMIT %s
        """, ((datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"), limit)).fetchall()

    top = []
    for i, r in enumerate(active_rows):
        top.append({
            "rank":     i + 1,
            "username": r["username"],
            "ops":      r["ops"],
        })
    return top


def _get_recent_activities(limit: int = 8) -> list:
    """最近操作记录（仪表盘动态流）"""
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT username, action, detail, ts, level
            FROM audit_log_secure
            ORDER BY id DESC LIMIT %s
        """, (limit,)).fetchall()
    op_ico = {
        "UPLOAD": "📤", "DOWNLOAD": "📥", "LOGIN": "🔐",
        "DELETE_TO_TRASH": "🗑️", "MKDIR": "📁", "SHARE_CREATE": "🔗",
        "EDIT_SAVE": "✏️", "CHANGE_PASSWORD": "🔑", "UPDATE_PROFILE": "👤",
        "REGISTER_APPROVED": "✅", "LOGIN_FAIL": "⚠️",
    }
    result = []
    for r in rows:
        result.append({
            "icon":     op_ico.get(r["action"], "•"),
            "username": r["username"] or "系统",
            "action":   r["action"],
            "detail":   (r["detail"] or "")[:40],
            "ts":       str(r["ts"])[:16],
            "level":    r["level"] or "INFO",
        })
    return result


# ════════════════════════════════════════════════════
#  JSON API
# ════════════════════════════════════════════════════
@bp.route("/api/dashboard/stats")
@login_required
def api_stats():
    uid, role, org_id = session["uid"], session.get("role",2), session.get("org_id")
    return jsonify(_get_core_stats(uid, role, org_id))


@bp.route("/api/dashboard/trend")
@login_required
def api_trend():
    days = min(int(request.args.get("days", 30)), 90)
    return jsonify(_get_trend(days))


@bp.route("/api/dashboard/filetype")
@login_required
def api_filetype():
    return jsonify(_get_filetype_dist())


@bp.route("/api/dashboard/activity")
@login_required
def api_activity():
    return jsonify(_get_activity_heatmap())


@bp.route("/api/dashboard/topusers")
@login_required
def api_topusers():
    if session.get("role", 2) > ROLE_DEPT:
        abort(403)
    return jsonify(_get_top_users())


@bp.route("/api/dashboard/recent")
@login_required
def api_recent():
    return jsonify(_get_recent_activities())


# ════════════════════════════════════════════════════
#  仪表盘主页
# ════════════════════════════════════════════════════
@bp.route("/dashboard")
@login_required
def dashboard():
    from routes._ctx import ctx
    uid   = session["uid"]
    role  = session.get("role", 2)
    uname = session.get("display_name") or session.get("uname", "")

    greeting_hour = datetime.now().hour
    if greeting_hour < 6:    greeting = "夜深了"
    elif greeting_hour < 12: greeting = "早上好"
    elif greeting_hour < 18: greeting = "下午好"
    else:                    greeting = "晚上好"

    is_admin = role <= ROLE_DEPT

    # 先同步获取核心数字用于首屏渲染（避免白屏）
    try:
        stats = _get_core_stats(uid, role, session.get("org_id"))
    except Exception:
        stats = {"file_count":0,"total_gb":0,"user_count":0,
                 "share_count":0,"today_ops":0,"active_now":0,"pending_reg":0}

    def _fmt_size(gb):
        if gb >= 1024: return f"{gb/1024:.1f} TB"
        if gb >= 1:    return f"{gb:.2f} GB"
        return f"{stats['total_mb']:.0f} MB"

    size_str = _fmt_size(stats["total_gb"])

    # 管理员卡片 or 普通用户卡片
    admin_cards = ""
    if is_admin:
        admin_cards = (
            '<div class="dash-card" onclick="location.href=\'/admin/users\'">'
            '<div class="dc-icon" style="background:#dbeafe">👥</div>'
            '<div class="dc-body"><div class="dc-num" id="stat-users">' + str(stats["user_count"]) + '</div>'
            '<div class="dc-label">注册用户</div></div></div>'

            '<div class="dash-card" onclick="location.href=\'/admin/register-requests\'">'
            + ('<div class="dc-icon" style="background:#fef3c7">📝</div>' if stats["pending_reg"] else '<div class="dc-icon" style="background:#dcfce7">📝</div>')
            + '<div class="dc-body"><div class="dc-num" id="stat-pending">' + str(stats["pending_reg"]) + '</div>'
            '<div class="dc-label">待审批申请</div></div></div>'
        )

    content = """
<div class="view show" style="gap:16px;overflow-y:auto">

  <!-- 欢迎栏 -->
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div>
      <div style="font-size:20px;font-weight:700;color:var(--text)">""" + greeting + """，""" + uname + """ 👋</div>
      <div style="font-size:12px;color:var(--text3);margin-top:3px">""" + datetime.now().strftime("%Y年%m月%d日 %A") + """  &nbsp;|&nbsp; 数据每30秒自动刷新</div>
    </div>
    <div style="display:flex;gap:8px">
      <a href="/browse" class="btn btn-outline btn-sm">📂 文件管理</a>
      """ + ('<a href="/admin/storage-analytics" class="btn btn-outline btn-sm">📊 存储分析</a>' if is_admin else '') + """
    </div>
  </div>

  <!-- 核心指标卡片 -->
  <div class="dash-grid">
    <div class="dash-card" onclick="location.href='/browse'">
      <div class="dc-icon" style="background:#dbeafe">📁</div>
      <div class="dc-body">
        <div class="dc-num" id="stat-files">""" + str(stats["file_count"]) + """</div>
        <div class="dc-label">文件总数</div>
      </div>
    </div>
    <div class="dash-card">
      <div class="dc-icon" style="background:#dcfce7">💾</div>
      <div class="dc-body">
        <div class="dc-num" id="stat-size">""" + size_str + """</div>
        <div class="dc-label">存储总量</div>
      </div>
    </div>
    <div class="dash-card" onclick="location.href='/shared'">
      <div class="dc-icon" style="background:#fce7f3">🔗</div>
      <div class="dc-body">
        <div class="dc-num" id="stat-shares">""" + str(stats["share_count"]) + """</div>
        <div class="dc-label">活跃分享</div>
      </div>
    </div>
    <div class="dash-card">
      <div class="dc-icon" style="background:#fff7ed">⚡</div>
      <div class="dc-body">
        <div class="dc-num" id="stat-ops">""" + str(stats["today_ops"]) + """</div>
        <div class="dc-label">今日操作</div>
      </div>
    </div>
    <div class="dash-card">
      <div class="dc-icon" style="background:#f0fdf4">🟢</div>
      <div class="dc-body">
        <div class="dc-num" id="stat-active">""" + str(stats["active_now"]) + """</div>
        <div class="dc-label">在线用户</div>
      </div>
    </div>
    """ + admin_cards + """
  </div>

  <!-- 图表区：双列 -->
  <div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;min-height:260px">

    <!-- 操作趋势折线图 -->
    <div class="card" style="padding:18px 20px">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px">
        <div style="font-size:13px;font-weight:600;color:var(--text)">📈 操作趋势（近30天）</div>
        <div style="display:flex;gap:10px;font-size:11px;color:var(--text3)">
          <span><span style="color:#3b82f6">●</span> 总操作</span>
          <span><span style="color:#10b981">●</span> 上传</span>
        </div>
      </div>
      <canvas id="trend-chart" height="160"></canvas>
    </div>

    <!-- 文件类型饼图 -->
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:14px">📊 文件类型分布</div>
      <canvas id="pie-chart" height="130"></canvas>
      <div id="pie-legend" style="margin-top:10px;display:flex;flex-wrap:wrap;gap:6px"></div>
    </div>
  </div>

  <!-- 下方双列：热力图 + 最近动态 -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">

    <!-- 活动热力图 -->
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:12px">🔥 访问热力图（近7天）</div>
      <div id="heatmap-wrap" style="overflow-x:auto">
        <div id="heatmap" style="display:inline-grid;gap:2px"></div>
        <div style="display:flex;justify-content:space-between;margin-top:6px;font-size:10px;color:var(--text3)">
          <span>0:00</span><span>6:00</span><span>12:00</span><span>18:00</span><span>23:00</span>
        </div>
      </div>
    </div>

    <!-- 最近活动流 -->
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:12px">📋 最近操作</div>
      <div id="activity-feed"></div>
    </div>
  </div>

  """ + ("""
  <!-- 用量排行（仅管理员） -->
  <div class="card" style="padding:18px 20px">
    <div style="font-size:13px;font-weight:600;color:var(--text);margin-bottom:12px">🏆 近30天活跃用户排行</div>
    <div id="top-users-wrap"></div>
  </div>
  """ if is_admin else "") + """

</div>

<style>
.dash-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
.dash-card{background:var(--white);border:1px solid var(--border);border-radius:8px;
  padding:14px 16px;display:flex;align-items:center;gap:12px;cursor:pointer;
  transition:box-shadow .2s,transform .15s}
.dash-card:hover{box-shadow:var(--shadow-md);transform:translateY(-1px)}
.dc-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;
  justify-content:center;font-size:20px;flex-shrink:0}
.dc-num{font-size:22px;font-weight:700;color:var(--text);line-height:1.1}
.dc-label{font-size:11px;color:var(--text3);margin-top:2px}
</style>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
Chart.defaults.font.family = "'Microsoft YaHei', sans-serif";
Chart.defaults.color = '#64748b';

var trendChart, pieChart;

// ── 趋势折线 ────────────────────────────────────────
async function loadTrend() {
  const d = await (await fetch('/api/dashboard/trend')).json();
  const labels = d.map(r => r.day.slice(5));
  const ops    = d.map(r => r.ops);
  const ups    = d.map(r => r.uploads);
  const ctx    = document.getElementById('trend-chart');
  if (trendChart) trendChart.destroy();
  trendChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [
        { label:'总操作', data:ops, borderColor:'#3b82f6', backgroundColor:'rgba(59,130,246,.1)',
          fill:true, tension:.4, pointRadius:2 },
        { label:'上传', data:ups, borderColor:'#10b981', backgroundColor:'rgba(16,185,129,.08)',
          fill:true, tension:.4, pointRadius:2 },
      ]
    },
    options: {
      responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{ display:false } },
      scales:{
        x:{ grid:{ color:'rgba(0,0,0,.04)' }, ticks:{ maxTicksLimit:10 } },
        y:{ grid:{ color:'rgba(0,0,0,.04)' }, beginAtZero:true }
      }
    }
  });
}

// ── 文件类型饼图 ────────────────────────────────────
async function loadPie() {
  const d = await (await fetch('/api/dashboard/filetype')).json();
  if (!d.length) return;
  const ctx = document.getElementById('pie-chart');
  if (pieChart) pieChart.destroy();
  pieChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: d.map(r => r.label),
      datasets: [{ data: d.map(r => r.count), backgroundColor: d.map(r => r.color),
                   borderWidth:2, borderColor:'#fff' }]
    },
    options: {
      responsive:true, maintainAspectRatio:false, cutout:'65%',
      plugins:{ legend:{ display:false }, tooltip:{
        callbacks:{ label: ctx => ' ' + ctx.label + ': ' + ctx.parsed + ' 个' }
      }}
    }
  });
  const leg = document.getElementById('pie-legend');
  leg.innerHTML = d.slice(0,6).map(r =>
    '<span style="font-size:10px;color:var(--text2);display:flex;align-items:center;gap:3px">'
    + '<span style="width:8px;height:8px;border-radius:2px;background:' + r.color + ';flex-shrink:0"></span>'
    + r.label + '</span>'
  ).join('');
}

// ── 热力图 ──────────────────────────────────────────
async function loadHeatmap() {
  const matrix = await (await fetch('/api/dashboard/activity')).json();
  const days = ['日','一','二','三','四','五','六'];
  const maxVal = Math.max(...matrix.flat(), 1);
  const wrap = document.getElementById('heatmap');
  // 24列 7行
  wrap.style.gridTemplateColumns = 'repeat(24, 14px)';
  wrap.innerHTML = '';
  for (let d = 0; d < 7; d++) {
    for (let h = 0; h < 24; h++) {
      const v    = matrix[d][h] || 0;
      const intensity = Math.round((v / maxVal) * 255);
      const alpha = 0.08 + (v / maxVal) * 0.88;
      const cell = document.createElement('div');
      cell.title = days[d] + '曜 ' + h + ':00  ' + v + '次操作';
      cell.style.cssText = 'width:14px;height:14px;border-radius:3px;cursor:default;background:rgba(59,130,246,' + alpha.toFixed(2) + ')';
      wrap.appendChild(cell);
    }
  }
  // 行标签（叠加显示）
}

// ── 最近活动 ────────────────────────────────────────
async function loadActivity() {
  const items = await (await fetch('/api/dashboard/recent')).json();
  const lv_color = { WARN:'#f59e0b', ERROR:'#ef4444', INFO:'transparent' };
  const feed = document.getElementById('activity-feed');
  feed.innerHTML = items.map(it =>
    '<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--border);font-size:12px">'
    + '<span style="font-size:14px;flex-shrink:0">' + it.icon + '</span>'
    + '<div style="flex:1;min-width:0">'
    + '<span style="font-weight:600;color:var(--text)">' + it.username + '</span>'
    + '<span style="color:var(--text3);margin-left:4px">' + it.detail + '</span>'
    + '</div>'
    + '<span style="color:var(--text3);white-space:nowrap">' + it.ts.slice(11) + '</span>'
    + '</div>'
  ).join('');
}

// ── 用户排行 ────────────────────────────────────────
async function loadTopUsers() {
  const wrap = document.getElementById('top-users-wrap');
  if (!wrap) return;
  const users = await (await fetch('/api/dashboard/topusers')).json();
  const maxOps = Math.max(...users.map(u => u.ops), 1);
  wrap.innerHTML = users.map(u =>
    '<div style="display:flex;align-items:center;gap:10px;padding:6px 0;font-size:12px">'
    + '<span style="min-width:20px;text-align:center;color:' + (u.rank<=3?'#f59e0b':'var(--text3)') + ';font-weight:700">'
    + (u.rank <= 3 ? ['🥇','🥈','🥉'][u.rank-1] : u.rank) + '</span>'
    + '<span style="min-width:80px;font-weight:500;color:var(--text)">' + u.username + '</span>'
    + '<div style="flex:1;height:6px;background:var(--gray100);border-radius:3px;overflow:hidden">'
    + '<div style="height:100%;width:' + Math.round(u.ops/maxOps*100) + '%;background:var(--primary);border-radius:3px;transition:width .4s"></div>'
    + '</div>'
    + '<span style="min-width:50px;text-align:right;color:var(--text3)">' + u.ops + '次</span>'
    + '</div>'
  ).join('');
}

// ── 统计数字更新 ────────────────────────────────────
async function refreshStats() {
  try {
    const s = await (await fetch('/api/dashboard/stats')).json();
    var el;
    if ((el=document.getElementById('stat-files')))  el.textContent = s.file_count;
    if ((el=document.getElementById('stat-shares'))) el.textContent = s.share_count;
    if ((el=document.getElementById('stat-ops')))    el.textContent = s.today_ops;
    if ((el=document.getElementById('stat-active'))) el.textContent = s.active_now;
    if ((el=document.getElementById('stat-users')))  el.textContent = s.user_count;
    if ((el=document.getElementById('stat-pending')))el.textContent = s.pending_reg;
    var gb = s.total_gb;
    var sz = gb >= 1024 ? (gb/1024).toFixed(1)+' TB' : gb >= 1 ? gb.toFixed(2)+' GB' : s.total_mb+' MB';
    if ((el=document.getElementById('stat-size')))   el.textContent = sz;
  } catch(e) {}
}

// 初始加载
Promise.all([loadTrend(), loadPie(), loadHeatmap(), loadActivity(), loadTopUsers()]);
// 30s 自动刷新统计数字
setInterval(refreshStats, 30000);
</script>
"""

    from routes._ctx import ctx
    return layout(content, "数据仪表盘", "dashboard", **ctx())


# ════════════════════════════════════════════════════
#  存储分析页（管理员专属）
# ════════════════════════════════════════════════════
@bp.route("/admin/storage-analytics")
@login_required
def storage_analytics():
    if session.get("role", 2) > ROLE_DEPT:
        abort(403)

    from routes._ctx import ctx

    content = """
<div class="view show" style="gap:16px;overflow-y:auto">
  <div style="display:flex;align-items:center;justify-content:space-between">
    <div class="page-title"><span class="pt-icon">📊</span>存储分析</div>
    <div style="display:flex;gap:8px">
      <select id="range-sel" class="inp inp-sel" style="width:120px;padding:5px 10px"
        onchange="loadAll()">
        <option value="7">近7天</option>
        <option value="30" selected>近30天</option>
        <option value="90">近90天</option>
      </select>
    </div>
  </div>

  <!-- Top 卡片 -->
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px">
    <div class="card" style="padding:16px 18px">
      <div style="font-size:11px;color:var(--text3);margin-bottom:6px">文件总数</div>
      <div id="sa-files" style="font-size:26px;font-weight:700;color:var(--text)">—</div>
    </div>
    <div class="card" style="padding:16px 18px">
      <div style="font-size:11px;color:var(--text3);margin-bottom:6px">存储总量</div>
      <div id="sa-size" style="font-size:26px;font-weight:700;color:var(--text)">—</div>
    </div>
    <div class="card" style="padding:16px 18px">
      <div style="font-size:11px;color:var(--text3);margin-bottom:6px">活跃用户</div>
      <div id="sa-users" style="font-size:26px;font-weight:700;color:var(--text)">—</div>
    </div>
    <div class="card" style="padding:16px 18px">
      <div style="font-size:11px;color:var(--text3);margin-bottom:6px">期间操作</div>
      <div id="sa-ops" style="font-size:26px;font-weight:700;color:var(--text)">—</div>
    </div>
  </div>

  <!-- 趋势 + 饼图 -->
  <div style="display:grid;grid-template-columns:3fr 2fr;gap:16px">
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;margin-bottom:14px">操作量趋势</div>
      <canvas id="sa-trend" height="180"></canvas>
    </div>
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;margin-bottom:14px">文件类型占比（按大小）</div>
      <canvas id="sa-pie" height="180"></canvas>
      <div id="sa-pie-leg" style="margin-top:10px;display:grid;grid-template-columns:1fr 1fr;gap:4px"></div>
    </div>
  </div>

  <!-- 用量排行 + 文件类型明细 -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;margin-bottom:12px">🏆 活跃用户排行</div>
      <div id="sa-topusers"></div>
    </div>
    <div class="card" style="padding:18px 20px">
      <div style="font-size:13px;font-weight:600;margin-bottom:12px">📂 文件类型明细</div>
      <table style="width:100%;border-collapse:collapse;font-size:12px">
        <thead>
          <tr style="color:var(--text3);border-bottom:1px solid var(--border)">
            <th style="padding:6px 0;text-align:left;font-weight:500">类型</th>
            <th style="padding:6px 0;text-align:right;font-weight:500">文件数</th>
            <th style="padding:6px 0;text-align:right;font-weight:500">大小</th>
            <th style="padding:6px 0;text-align:right;font-weight:500">占比</th>
          </tr>
        </thead>
        <tbody id="sa-typetable"></tbody>
      </table>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
Chart.defaults.font.family = "'Microsoft YaHei', sans-serif";
Chart.defaults.color = '#64748b';
var _saCharts = {};

function fmtBytes(b) {
  if (b >= 1073741824) return (b/1073741824).toFixed(2)+' GB';
  if (b >= 1048576)    return (b/1048576).toFixed(1)+' MB';
  if (b >= 1024)       return (b/1024).toFixed(1)+' KB';
  return b+' B';
}

async function loadAll() {
  const days = document.getElementById('range-sel').value;
  const [stats, trend, types, topUsers] = await Promise.all([
    fetch('/api/dashboard/stats').then(r=>r.json()),
    fetch('/api/dashboard/trend?days='+days).then(r=>r.json()),
    fetch('/api/dashboard/filetype').then(r=>r.json()),
    fetch('/api/dashboard/topusers').then(r=>r.json()),
  ]);

  // Top 卡片
  document.getElementById('sa-files').textContent = stats.file_count.toLocaleString();
  var gb = stats.total_gb;
  document.getElementById('sa-size').textContent = gb>=1024?(gb/1024).toFixed(1)+' TB':gb.toFixed(2)+' GB';
  document.getElementById('sa-users').textContent = stats.user_count;
  var totalOps = trend.reduce((s,r)=>s+r.ops,0);
  document.getElementById('sa-ops').textContent = totalOps.toLocaleString();

  // 趋势图
  if (_saCharts.trend) _saCharts.trend.destroy();
  _saCharts.trend = new Chart(document.getElementById('sa-trend'), {
    type:'bar',
    data:{
      labels: trend.map(r=>r.day.slice(5)),
      datasets:[
        { label:'上传', data:trend.map(r=>r.uploads), backgroundColor:'rgba(16,185,129,.7)', stack:'s' },
        { label:'其他', data:trend.map(r=>r.ops-r.uploads), backgroundColor:'rgba(59,130,246,.55)', stack:'s' },
      ]
    },
    options:{
      responsive:true, maintainAspectRatio:false,
      plugins:{ legend:{ position:'bottom', labels:{ boxWidth:12, padding:10 } } },
      scales:{
        x:{ grid:{ display:false }, stacked:true, ticks:{maxTicksLimit:12} },
        y:{ stacked:true, grid:{ color:'rgba(0,0,0,.04)' }, beginAtZero:true }
      }
    }
  });

  // 饼图（按字节数）
  if (_saCharts.pie) _saCharts.pie.destroy();
  var totalBytes = types.reduce((s,t)=>s+t.bytes,0)||1;
  _saCharts.pie = new Chart(document.getElementById('sa-pie'), {
    type:'doughnut',
    data:{
      labels: types.map(t=>t.label),
      datasets:[{ data:types.map(t=>t.bytes), backgroundColor:types.map(t=>t.color), borderWidth:2, borderColor:'#fff' }]
    },
    options:{
      responsive:true, maintainAspectRatio:false, cutout:'60%',
      plugins:{ legend:{display:false}, tooltip:{
        callbacks:{ label: c => ' '+c.label+': '+fmtBytes(c.parsed) }
      }}
    }
  });
  document.getElementById('sa-pie-leg').innerHTML = types.map(t=>
    '<div style="display:flex;align-items:center;gap:4px;font-size:11px;color:var(--text2)">'
    +'<span style="width:8px;height:8px;border-radius:2px;background:'+t.color+';flex-shrink:0"></span>'
    +t.label+' <span style="color:var(--text3)">'+(t.bytes/totalBytes*100).toFixed(1)+'%</span></div>'
  ).join('');

  // 类型明细表
  document.getElementById('sa-typetable').innerHTML = types.map(t=>
    '<tr style="border-bottom:1px solid var(--border)">'
    +'<td style="padding:7px 0;display:flex;align-items:center;gap:6px">'
    +'<span style="width:8px;height:8px;border-radius:2px;background:'+t.color+';flex-shrink:0"></span>'
    +t.label+'</td>'
    +'<td style="padding:7px 0;text-align:right;color:var(--text2)">'+t.count.toLocaleString()+'</td>'
    +'<td style="padding:7px 0;text-align:right;color:var(--text2)">'+fmtBytes(t.bytes)+'</td>'
    +'<td style="padding:7px 0;text-align:right;color:var(--text3)">'+(t.bytes/totalBytes*100).toFixed(1)+'%</td>'
    +'</tr>'
  ).join('');

  // 用户排行
  var maxOps = Math.max(...topUsers.map(u=>u.ops),1);
  document.getElementById('sa-topusers').innerHTML = topUsers.map(u=>
    '<div style="display:flex;align-items:center;gap:10px;padding:6px 0;font-size:12px">'
    +'<span style="min-width:22px;text-align:center;font-weight:700;color:'+(u.rank<=3?'#f59e0b':'var(--text3)')+';">'
    +(u.rank<=3?['🥇','🥈','🥉'][u.rank-1]:u.rank)+'</span>'
    +'<span style="min-width:80px;font-weight:500;color:var(--text)">'+u.username+'</span>'
    +'<div style="flex:1;height:5px;background:var(--gray100);border-radius:3px;overflow:hidden">'
    +'<div style="height:100%;width:'+Math.round(u.ops/maxOps*100)+'%;background:var(--primary);border-radius:3px"></div>'
    +'</div>'
    +'<span style="min-width:44px;text-align:right;color:var(--text3)">'+u.ops+'</span>'
    +'</div>'
  ).join('');
}

loadAll();
</script>
"""
    return layout(content, "存储分析", "analytics", **ctx())
