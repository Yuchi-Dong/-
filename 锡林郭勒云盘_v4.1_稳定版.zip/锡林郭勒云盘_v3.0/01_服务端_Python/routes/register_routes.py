# -*- coding: utf-8 -*-
"""
routes/register_routes.py — 账号申请与审批

流程：
  1. 访客在登录页点「申请账号」→ GET /register
  2. 填写申请表单 → POST /api/register/apply
  3. 管理员在 /admin/register-requests 审批
  4. 批准时自动创建账号，发送通知（如配置了邮件）
  5. 拒绝时记录理由

申请表单字段：
  - 姓名（真实姓名）
  - 期望用户名
  - 邮箱（用于通知）
  - 手机号
  - 所属部门/单位
  - 申请原因（必填，至少 10 字）
  - 验证码（防机器人）— 简单数学题
"""
import hashlib
import json
import os
import random
import secrets
import time
from flask import Blueprint, session, request, jsonify, abort

import config
from auth import login_required, role_required, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER, ROLE_DEPT
from dao.db import get_conn
from compliance.audit_log import write as audit_write, AuditCategory
from templates import layout

bp = Blueprint("register", __name__)


def _is_register_open() -> bool:
    return getattr(config, "ALLOW_REGISTER", False)


def _ensure_table():
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS register_requests (
                id           SERIAL PRIMARY KEY,
                realname     TEXT NOT NULL,
                username     TEXT NOT NULL,
                email        TEXT DEFAULT '',
                phone        TEXT DEFAULT '',
                department   TEXT DEFAULT '',
                reason       TEXT NOT NULL,
                status       TEXT DEFAULT 'pending',
                reviewer_id  INTEGER REFERENCES users(id),
                review_note  TEXT DEFAULT '',
                created_at   TIMESTAMPTZ DEFAULT NOW(),
                reviewed_at  TIMESTAMPTZ,
                ip           TEXT DEFAULT ''
            )
        """)
        conn.execute("""
            CREATE INDEX IF NOT EXISTS idx_rr_status ON register_requests(status)
        """)


# ── 访客申请页 ────────────────────────────────────
@bp.route("/register")
def register_page():
    if not _is_register_open():
        return "<h2>本系统暂不开放账号申请</h2>", 403

    csrf = generate_csrf_token()
    session["csrf_token"] = csrf

    # 生成简单数学验证码
    a, b = random.randint(1, 9), random.randint(1, 9)
    answer = a + b
    session["captcha_answer"] = answer

    from routes.branding_routes import load_branding
    cfg = load_branding()
    sys_name = cfg.get("system_name", "政务云盘")
    reg_note = cfg.get("register_note", "申请通过后，管理员将在1个工作日内审核并开通账号。")

    # 加载组织列表供选择
    try:
        with get_conn() as conn:
            orgs = conn.execute(
                "SELECT id, name FROM organizations ORDER BY org_level, id"
            ).fetchall()
        org_opts = "".join(
            f'<option value="{o["name"]}">{o["name"]}</option>'
            for o in orgs
        )
    except Exception:
        org_opts = ""

    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>申请账号 — {sys_name}</title>
<style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{font-family:'Microsoft YaHei',sans-serif;background:#f4f7fb;min-height:100vh;
  display:flex;align-items:center;justify-content:center;padding:20px}}
.wrap{{background:#fff;border-radius:8px;padding:32px 36px;max-width:520px;width:100%;
  box-shadow:0 4px 20px rgba(0,0,0,.1)}}
.header{{text-align:center;margin-bottom:24px}}
.header h1{{font-size:18px;color:#1a1f2e;margin-bottom:6px}}
.header p{{font-size:12px;color:#64748b;line-height:1.6}}
.fg{{margin-bottom:14px}}
label{{display:block;font-size:12px;font-weight:600;color:#374151;margin-bottom:5px}}
.inp{{width:100%;padding:9px 12px;border:1.5px solid #e2e8f0;border-radius:5px;
  font-size:13px;font-family:inherit;transition:border-color .15s}}
.inp:focus{{outline:none;border-color:#1560bd}}
.grid2{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}
.btn{{width:100%;padding:11px;background:#1560bd;color:#fff;border:none;border-radius:5px;
  font-size:14px;font-weight:600;cursor:pointer;letter-spacing:1px;margin-top:4px}}
.btn:hover{{background:#0e4a9a}}
.note{{background:#eaf2ff;border-radius:5px;padding:12px 14px;
  font-size:11px;color:#1560bd;line-height:1.8;margin-bottom:18px}}
.err{{background:#fff0f0;border:1px solid #f5a0a0;color:#c62828;padding:8px 12px;
  border-radius:5px;font-size:12px;margin-bottom:12px;display:none}}
.foot{{text-align:center;margin-top:16px;font-size:12px;color:#94a3b8}}
.captcha-wrap{{display:flex;align-items:center;gap:10px}}
.captcha-question{{background:#f1f4f8;border-radius:5px;padding:8px 14px;
  font-size:16px;font-weight:700;color:#1a1f2e;letter-spacing:2px;white-space:nowrap}}
</style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h1>☁ 申请 {sys_name} 账号</h1>
    <p>{reg_note}</p>
  </div>
  <div class="note">
    ℹ 请使用真实信息填写，以便管理员审核。账号一经批准将发送通知。
  </div>
  <div class="err" id="err"></div>
  <form id="reg-form">
    <input type="hidden" name="csrf_token" value="{csrf}">
    <div class="grid2">
      <div class="fg" style="margin:0">
        <label>真实姓名 *</label>
        <input class="inp" name="realname" required placeholder="请填写真实姓名">
      </div>
      <div class="fg" style="margin:0">
        <label>期望用户名 *</label>
        <input class="inp" name="username" required placeholder="英文字母开头，3-20位"
          pattern="[a-zA-Z][a-zA-Z0-9_]{{2,19}}">
      </div>
    </div>
    <div style="height:14px"></div>
    <div class="grid2">
      <div class="fg" style="margin:0">
        <label>联系邮箱</label>
        <input class="inp" name="email" type="email" placeholder="用于接收审核通知">
      </div>
      <div class="fg" style="margin:0">
        <label>手机号码</label>
        <input class="inp" name="phone" placeholder="可选">
      </div>
    </div>
    <div style="height:14px"></div>
    <div class="fg">
      <label>所属部门 *</label>
      <select class="inp" name="department" required>
        <option value="">请选择所属部门</option>
        {org_opts}
        <option value="其他">其他</option>
      </select>
    </div>
    <div class="fg">
      <label>申请原因 * （至少10字）</label>
      <textarea class="inp" name="reason" required rows="3"
        placeholder="请简要说明申请账号的用途和原因..."
        style="resize:vertical;min-height:80px"></textarea>
    </div>
    <div class="fg">
      <label>验证码：请计算下方结果</label>
      <div class="captcha-wrap">
        <div class="captcha-question">{a} + {b} = ?</div>
        <input class="inp" name="captcha" type="number" required
          placeholder="填写计算结果" style="flex:1;max-width:120px">
      </div>
    </div>
    <button type="button" class="btn" onclick="submitApply()">提交申请</button>
  </form>
  <div class="foot">
    已有账号？<a href="/login" style="color:#1560bd">返回登录</a>
  </div>
</div>
<script>
async function submitApply() {{
  const form = document.getElementById('reg-form');
  const data = Object.fromEntries(new FormData(form));
  const errEl = document.getElementById('err');
  errEl.style.display = 'none';

  if (!data.realname?.trim()) {{ showErr('请填写真实姓名'); return; }}
  if (!/^[a-zA-Z][a-zA-Z0-9_]{{2,19}}$/.test(data.username)) {{
    showErr('用户名格式错误：字母开头，3-20位字母数字下划线'); return;
  }}
  if (!data.department) {{ showErr('请选择所属部门'); return; }}
  if ((data.reason||'').trim().length < 10) {{ showErr('申请原因至少10个字'); return; }}
  if (!data.captcha) {{ showErr('请填写验证码'); return; }}

  const r = await fetch('/api/register/apply', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify(data)
  }});
  const d = await r.json();
  if (d.success) {{
    document.getElementById('reg-form').innerHTML =
      '<div style="text-align:center;padding:30px 0">' +
      '<div style="font-size:48px;margin-bottom:16px">✅</div>' +
      '<h3 style="color:#1a7a40;margin-bottom:8px">申请已提交</h3>' +
      '<p style="font-size:13px;color:#64748b">我们将在1个工作日内完成审核</p>' +
      '<p style="font-size:12px;color:#94a3b8;margin-top:16px">申请编号：' + d.request_id + '</p>' +
      '<a href="/login" style="display:inline-block;margin-top:20px;color:#1560bd;font-size:13px">← 返回登录</a>' +
      '</div>';
  }} else showErr(d.error || '提交失败，请稍后重试');
}}

function showErr(msg) {{
  const el = document.getElementById('err');
  el.textContent = '⚠ ' + msg;
  el.style.display = 'block';
}}
</script>
</body></html>"""
    return html


# ── 提交申请 API ──────────────────────────────────
@bp.route("/api/register/apply", methods=["POST"])
def api_register_apply():
    if not _is_register_open():
        return jsonify({"success": False, "error": "账号申请功能未开放"}), 403

    data = request.get_json() or {}

    # 验证 CSRF
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "页面已过期，请刷新重试"}), 403

    # 验证码
    captcha = str(data.get("captcha", "")).strip()
    expected = session.get("captcha_answer")
    if not expected or str(expected) != captcha:
        return jsonify({"success": False, "error": "验证码错误"}), 400

    realname   = (data.get("realname") or "").strip()
    username   = (data.get("username") or "").strip()
    email      = (data.get("email") or "").strip()
    phone      = (data.get("phone") or "").strip()
    department = (data.get("department") or "").strip()
    reason     = (data.get("reason") or "").strip()

    import re
    if not realname:
        return jsonify({"success": False, "error": "姓名不能为空"}), 400
    if not re.match(r'^[a-zA-Z][a-zA-Z0-9_]{2,19}$', username):
        return jsonify({"success": False, "error": "用户名格式错误"}), 400
    if len(reason) < 10:
        return jsonify({"success": False, "error": "申请原因至少10个字"}), 400
    if not department:
        return jsonify({"success": False, "error": "请选择所属部门"}), 400

    # 检查用户名是否已存在
    with get_conn() as conn:
        if conn.execute("SELECT id FROM users WHERE username=%s", (username,)).fetchone():
            return jsonify({"success": False, "error": "用户名已被使用，请更换"}), 400
        # 检查是否已有待审核申请
        if conn.execute(
            "SELECT id FROM register_requests WHERE username=%s AND status='pending'",
            (username,)
        ).fetchone():
            return jsonify({"success": False, "error": "该用户名已有待审核的申请"}), 400

        rid = conn.execute(
            "INSERT INTO register_requests(realname,username,email,phone,department,reason,ip) "
            "VALUES(%s,%s,%s,%s,%s,%s,%s) RETURNING id",
            (realname, username, email, phone, department, reason, request.remote_addr)
        ).fetchone()[0]

    # 清空验证码（防重放）
    session.pop("captcha_answer", None)
    return jsonify({"success": True, "request_id": rid})


# ── 管理员审批页 ──────────────────────────────────
@bp.route("/admin/register-requests")
@login_required
@role_required(ROLE_DEPT)
def admin_register_requests():
    _ensure_table()
    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    status_filter = request.args.get("status", "pending")

    with get_conn() as conn:
        rows = conn.execute("""
            SELECT rr.*, u.display_name as reviewer_name
            FROM register_requests rr
            LEFT JOIN users u ON u.id = rr.reviewer_id
            WHERE rr.status = %s
            ORDER BY rr.created_at DESC
            LIMIT 100
        """, (status_filter,)).fetchall()
        pending_count = conn.execute(
            "SELECT COUNT(*) FROM register_requests WHERE status='pending'"
        ).fetchone()[0]

    status_opts = [
        ("pending",  f"待审批 ({pending_count})", "badge-yellow"),
        ("approved", "已批准", "badge-green"),
        ("rejected", "已拒绝", "badge-red"),
    ]
    tab_html = "".join(
        f'<a href="/admin/register-requests?status={s}" '
        f'class="btn btn-{"primary" if s==status_filter else "outline"} btn-sm">'
        f'{l}</a>'
        for s, l, _ in status_opts
    )

    rows_html = ""
    for r in rows:
        rows_html += f"""<tr>
          <td class="fdate" style="font-size:11px">{str(r['created_at'])[:16]}</td>
          <td><strong>{r['realname']}</strong><br>
              <span style="font-size:11px;color:var(--text3)">@{r['username']}</span></td>
          <td style="font-size:12px">{r.get('department','')}</td>
          <td style="font-size:12px;color:var(--text2)">{r.get('email','')}</td>
          <td style="font-size:12px;max-width:200px">{(r.get('reason','') or '')[:60]}...</td>
          <td style="font-size:11px;color:var(--text3)">{r.get('ip','')}</td>
          <td style="text-align:right;white-space:nowrap">
            {'<button class="btn btn-xs btn-primary" onclick="approve('+str(r['id'])+',' + repr(r['username']) + ',' + repr(r.get('department','')) + ')">✓ 批准</button> <button class="btn btn-xs btn-danger" onclick="reject('+str(r['id'])+')">✗ 拒绝</button>'
             if r['status']=='pending' else
             f'<span class="badge badge-{"green" if r["status"]=="approved" else "red"}">'
             f'{"已批准" if r["status"]=="approved" else "已拒绝"}</span><br>'
             f'<span style="font-size:10px;color:var(--text3)">{(r.get("review_note","") or "")[:20]}</span>'}
          </td>
        </tr>"""

    if not rows_html:
        rows_html = f'<tr><td colspan="7"><div class="empty-state"><div class="es-icon">📋</div><p>暂无{dict(status_opts)[status_filter][0] if status_filter in dict(s for s,l,_ in status_opts) else ""}申请</p></div></td></tr>'

    # 组织列表供分配
    with get_conn() as conn:
        orgs = conn.execute(
            "SELECT id,name FROM organizations ORDER BY org_level,id"
        ).fetchall()
    org_opts = "".join(
        f'<option value="{o["id"]}">{o["name"]}</option>' for o in orgs
    )

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div class="page-title"><span class="pt-icon">📝</span>账号申请审批
      {f'<span class="badge badge-yellow" style="font-size:11px">{pending_count} 待审</span>' if pending_count else ''}
    </div>
    <div style="display:flex;gap:6px">{tab_html}</div>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th>申请时间</th><th>姓名/用户名</th><th>部门</th>
        <th>邮箱</th><th>申请原因</th><th>IP</th>
        <th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>

<div class="overlay" id="m-approve" onclick="if(event.target===this)hideModal('m-approve')">
  <div class="modal">
    <div class="modal-hdr"><h3>✓ 批准申请</h3>
      <button class="modal-close" onclick="hideModal('m-approve')">✕</button></div>
    <input type="hidden" id="ap-id">
    <div class="fg">
      <label>用户名（只读）</label>
      <input class="inp" id="ap-uname" readonly style="background:var(--gray50)">
    </div>
    <div class="fg">
      <label>初始密码 <span style="color:var(--danger)">*</span>（将发送给用户）</label>
      <input class="inp" id="ap-pw" type="password" placeholder="至少8位，含大小写+数字+符号">
      <button type="button" class="btn btn-outline btn-sm" style="margin-top:6px"
        onclick="genPw()">🎲 随机生成</button>
      <span id="ap-pw-show" style="font-size:12px;color:var(--text3);margin-left:8px"></span>
    </div>
    <div class="fg">
      <label>分配组织</label>
      <select class="inp inp-sel" id="ap-org">
        <option value="">不分配</option>{org_opts}
      </select>
    </div>
    <div class="fg">
      <label>角色</label>
      <select class="inp inp-sel" id="ap-role">
        <option value="2">普通用户</option>
        <option value="1">组织管理员</option>
      </select>
    </div>
    <div class="fg">
      <label>备注（可选）</label>
      <input class="inp" id="ap-note" placeholder="如：已核实身份，已通知本人">
    </div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-approve')">取消</button>
      <button class="btn btn-primary" onclick="submitApprove()">确认批准</button>
    </div>
  </div>
</div>

<div class="overlay" id="m-reject" onclick="if(event.target===this)hideModal('m-reject')">
  <div class="modal">
    <div class="modal-hdr"><h3>✗ 拒绝申请</h3>
      <button class="modal-close" onclick="hideModal('m-reject')">✕</button></div>
    <input type="hidden" id="rj-id">
    <div class="fg">
      <label>拒绝原因 <span style="color:var(--danger)">*</span></label>
      <textarea class="inp" id="rj-note" rows="3"
        placeholder="请说明拒绝原因，将展示给申请人..."></textarea>
    </div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-reject')">取消</button>
      <button class="btn btn-danger" onclick="submitReject()">确认拒绝</button>
    </div>
  </div>
</div>

<script>
function approve(id, uname, dept) {{
  document.getElementById('ap-id').value = id;
  document.getElementById('ap-uname').value = uname;
  document.getElementById('ap-note').value = '';
  document.getElementById('ap-pw').value = '';
  document.getElementById('ap-pw-show').textContent = '';
  // 尝试匹配部门
  const sel = document.getElementById('ap-org');
  for (let opt of sel.options) {{
    if (opt.textContent === dept) {{ sel.value = opt.value; break; }}
  }}
  showModal('m-approve');
}}

function reject(id) {{
  document.getElementById('rj-id').value = id;
  document.getElementById('rj-note').value = '';
  showModal('m-reject');
}}

function genPw() {{
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789!@#$%';
  let pw = '';
  // 确保包含各类字符
  pw += 'ABCDEFGHJKMNPQRSTUVWXYZ'[Math.floor(Math.random()*23)];
  pw += 'abcdefghjkmnpqrstuvwxyz'[Math.floor(Math.random()*23)];
  pw += '23456789'[Math.floor(Math.random()*8)];
  pw += '!@#$%'[Math.floor(Math.random()*5)];
  for (let i=0;i<6;i++) pw += chars[Math.floor(Math.random()*chars.length)];
  pw = pw.split('').sort(()=>Math.random()-.5).join('');
  document.getElementById('ap-pw').value = pw;
  document.getElementById('ap-pw-show').textContent = '密码：' + pw;
}}

async function submitApprove() {{
  const id   = document.getElementById('ap-id').value;
  const pw   = document.getElementById('ap-pw').value;
  const org  = document.getElementById('ap-org').value;
  const role = document.getElementById('ap-role').value;
  const note = document.getElementById('ap-note').value.trim();
  if (pw.length < 8) {{ toast('密码至少8位', 'err'); return; }}
  const r = await fetch('/api/register/approve', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{request_id:id, password:pw, org_id:org||null,
      role:parseInt(role), note:note, csrf_token:window._csrf}})
  }});
  const d = await r.json();
  if (d.success) {{ hideModal('m-approve'); toast('已批准，账号已创建', 'ok'); location.reload(); }}
  else toast('操作失败：' + d.error, 'err');
}}

async function submitReject() {{
  const id   = document.getElementById('rj-id').value;
  const note = document.getElementById('rj-note').value.trim();
  if (!note) {{ toast('请填写拒绝原因', 'err'); return; }}
  const r = await fetch('/api/register/reject', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify({{request_id:id, note:note, csrf_token:window._csrf}})
  }});
  const d = await r.json();
  if (d.success) {{ hideModal('m-reject'); toast('已拒绝', 'ok'); location.reload(); }}
  else toast(d.error, 'err');
}}
</script>"""

    from routes._ctx import ctx
    return layout(content, "账号申请审批", "register", **ctx())


# ── 审批 API ──────────────────────────────────────
@bp.route("/api/register/approve", methods=["POST"])
@login_required
@role_required(ROLE_DEPT)
def api_approve():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    req_id   = data.get("request_id")
    password = data.get("password", "")
    org_id   = data.get("org_id") or None
    role     = int(data.get("role", 2))
    note     = data.get("note", "")

    if len(password) < 8:
        return jsonify({"success": False, "error": "密码至少8位"}), 400

    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM register_requests WHERE id=%s AND status='pending'",
            (req_id,)
        ).fetchone()
        if not row:
            return jsonify({"success": False, "error": "申请不存在或已处理"}), 404

    # 创建账号
    from services.user_service import create_user
    uid, err = create_user(
        row["username"], password, role,
        int(org_id) if org_id else None,
        row["realname"], row.get("email", ""),
        1024000, session["uid"]
    )
    if err:
        return jsonify({"success": False, "error": err})

    # 更新申请状态
    with get_conn() as conn:
        conn.execute("""
            UPDATE register_requests
            SET status='approved', reviewer_id=%s, review_note=%s, reviewed_at=NOW()
            WHERE id=%s
        """, (session["uid"], note, req_id))

    audit_write(session["uid"], session["uname"], "REGISTER_APPROVED",
                f"username={row['username']} uid={uid}",
                request.remote_addr, "INFO", AuditCategory.ADMIN)
    return jsonify({"success": True, "user_id": uid})


@bp.route("/api/register/reject", methods=["POST"])
@login_required
@role_required(ROLE_DEPT)
def api_reject():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    req_id = data.get("request_id")
    note   = (data.get("note") or "").strip()
    if not note:
        return jsonify({"success": False, "error": "请填写拒绝原因"}), 400

    with get_conn() as conn:
        row = conn.execute(
            "SELECT id FROM register_requests WHERE id=%s AND status='pending'", (req_id,)
        ).fetchone()
        if not row:
            return jsonify({"success": False, "error": "申请不存在或已处理"}), 404
        conn.execute("""
            UPDATE register_requests
            SET status='rejected', reviewer_id=%s, review_note=%s, reviewed_at=NOW()
            WHERE id=%s
        """, (session["uid"], note, req_id))

    audit_write(session["uid"], session["uname"], "REGISTER_REJECTED",
                f"req_id={req_id}", request.remote_addr, "INFO", AuditCategory.ADMIN)
    return jsonify({"success": True})
