# -*- coding: utf-8 -*-
"""
routes/browse_routes.py — 文件浏览 / 上传 / 下载 / 预览 / 搜索 / 我的空间
"""
import os
import re
import json
import secrets
import hashlib
import mimetypes
import subprocess
from pathlib import Path
from datetime import datetime

from flask import (Blueprint, session, request, redirect, abort,
                   jsonify, send_file, make_response)

import config
from storage import get_storage
from auth import login_required, safe_join, generate_csrf_token, csrf_ok, secure_filename, ROLE_SUPER, ROLE_DEPT
from services.permission_service import can_access, get_authorized_paths
from dao.file_dao import (log_action, move_to_trash, save_version,
                          check_shared_to, get_shares_sent)
from dao.db import get_conn
from search import search_files, classify, fmt_size
from indexer import async_index, delete_index, search_index
from templates import layout

bp = Blueprint("browse", __name__)

# 可在线编辑的扩展名
ONLINE_EDITABLE = {".docx",".doc",".odt",".rtf",".xlsx",".xls",".ods",".csv",".pptx",".ppt",".odp"}


# ── 工具函数 ─────────────────────────────────────────
def _ftype_icon(ftype):
    return {"image": "🖼", "pdf": "📄", "text": "📝", "office": "📊",
            "zip": "🗜", "dir": "📁", "ofd": "📋",
            "video": "🎬", "audio": "🎵"}.get(ftype, "📦")


def safe_send(full_path, mime=None, inline=True, dl_name=None):
    from urllib.parse import quote
    if not mime:
        mime, _ = mimetypes.guess_type(full_path)
        mime = mime or "application/octet-stream"
    fname         = dl_name or Path(full_path).name
    fname_encoded = quote(fname.encode("utf-8"), safe="")
    fname_ascii   = "".join(c for c in fname if ord(c) < 128) or "file"
    disposition   = "inline" if inline else "attachment"
    cd = f'{disposition}; filename="{fname_ascii}"; filename*=UTF-8\'\'{fname_encoded}'
    response = send_file(full_path, mimetype=mime)
    response.headers["Content-Disposition"] = cd
    response.headers["Cache-Control"] = "no-cache, private"
    return response


def _is_shared_to_me(filepath):
    return check_shared_to(filepath, session.get("uid"), session.get("org_id"))


def _can(rel, need_write=False):
    return can_access(rel, session["uid"], session["role"], session.get("org_id"), need_write)


def _js(s):
    import json
    return json.dumps(str(s))


# ── 文件浏览 ─────────────────────────────────────────
@bp.route("/browse", defaults={"subpath": ""})
@bp.route("/browse/<path:subpath>")
@login_required
def browse(subpath):
    role   = session["role"]
    uid    = session["uid"]
    org_id = session.get("org_id")
    uname  = session["uname"]

    auth_paths = get_authorized_paths(uid, role, org_id)

    if role != ROLE_SUPER and subpath:
        sp = subpath.strip("/")
        allowed = any(
            ap["path"].strip("/") == "" or sp == ap["path"].strip("/")
            or sp.startswith(ap["path"].strip("/") + "/")
            or ap["path"].strip("/").startswith(sp + "/")
            for ap in auth_paths
        )
        if not allowed:
            log_action(uid, uname, "ACCESS_DENIED", subpath, request.remote_addr, "ERROR")
            abort(403)

    full_path = safe_join(config.FILE_ROOT, subpath) if subpath else config.FILE_ROOT
    if not os.path.isdir(full_path):
        abort(404)

    _auth_set = [ap["path"].strip("/") for ap in auth_paths]

    def _is_visible(rel):
        if role == ROLE_SUPER:
            return True
        rel_norm = rel.strip("/")
        for ap_path in _auth_set:
            if ap_path == "":
                return True
            if rel_norm == ap_path or rel_norm.startswith(ap_path + "/"):
                return True
            if ap_path.startswith(rel_norm + "/"):
                if rel_norm == "users":
                    if ap_path.startswith(f"users/{uname}"):
                        return True
                    continue
                return True
        return False

    # 加载当前目录的分享标记
    _shared_rels = set()
    _share_info  = {}
    try:
        for sr in get_shares_sent(uid):
            fp = sr["file_path"].strip("/")
            _shared_rels.add(fp)
            info = _share_info.setdefault(fp, [])
            if sr["share_type"] == "public":  tname = "全员公开"
            elif sr["share_type"] == "org":   tname = sr.get("target_org_name") or "组织"
            else:                              tname = sr.get("target_user_name") or "用户"
            info.append({"type": sr["share_type"], "target": tname, "perm": sr["perm"]})
    except Exception:
        pass

    def _share_badge(rel):
        if rel not in _shared_rels:
            return ""
        infos    = _share_info.get(rel, [])
        tip      = "；".join(f"{'全员' if i['type']=='public' else i['target']} ({'只读' if i['perm']=='ro' else '读写'})" for i in infos)
        info_json = json.dumps(infos, ensure_ascii=False).replace("'", "\\'")
        return (f'<span class="share-badge" title="已分享：{tip}" '
                f'onclick="event.stopPropagation();showShareInfo({json.dumps(rel)},{info_json})">'
                f'🔗 已分享</span>')

    items = []
    try:
        for entry in sorted(os.scandir(full_path), key=lambda e: (not e.is_dir(), e.name.lower())):
            try:
                stat = entry.stat()
                rel  = (subpath + "/" + entry.name).lstrip("/") if subpath else entry.name
                if not _is_visible(rel):
                    continue
                if entry.is_dir():
                    items.append({"name": entry.name, "is_dir": True, "size_str": "—",
                        "mtime": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        "icon": "📁", "ftype": "dir", "browse_url": f"/browse/{rel}", "rel": rel,
                        "can_write": role == ROLE_SUPER or _can(rel, True)})
                else:
                    ext   = Path(entry.name).suffix.lower()
                    ftype = classify(ext)
                    items.append({"name": entry.name, "is_dir": False,
                        "size_str": fmt_size(stat.st_size),
                        "mtime": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                        "icon": _ftype_icon(ftype), "ftype": ftype,
                        "file_url": f"/file/{rel}", "browse_url": "", "rel": rel,
                        "can_write": role == ROLE_SUPER or _can(rel, True)})
            except Exception:
                continue
    except PermissionError:
        abort(403)

    can_upload = role == ROLE_SUPER or _can(subpath or f"users/{uname}", True)
    can_mkdir  = can_upload

    # 面包屑
    bc = ['<a href="/browse" class="bc">🏠 根目录</a>']
    if subpath:
        parts = subpath.split("/")
        for i, p in enumerate(parts):
            partial = "/".join(parts[:i+1])
            if i < len(parts) - 1:
                bc.append(f'<span class="sep">/</span><a href="/browse/{partial}" class="bc">{p}</a>')
            else:
                bc.append(f'<span class="sep">/</span><span class="bc-current">{p}</span>')
    bc_html = "".join(bc)

    # 视图渲染辅助
    PREV_EXTS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"}

    def _row(it):
        _rel = it["rel"]; _fu = it.get("file_url", ""); _ft = it["ftype"]
        ext  = Path(_rel).suffix.lower() if not it["is_dir"] else ""  
        _fn_js = _js(it["name"]); _fu_js = _js(_fu); _rel_js = _js(_rel)
        perm  = '<span class="perm-rw">读写</span>' if it["can_write"] else '<span class="perm-ro">只读</span>'
        sb    = _share_badge(_rel); q = "'"
        burl  = it.get("browse_url", "")
        if it["is_dir"]:
            nc  = f'<a href="{burl}" class="fname" style="text-decoration:none;color:inherit"><span class="ficon">{it["icon"]}</span>{it["name"]}</a> {sb}'
            ops = f'<button class="btn btn-xs btn-outline" onclick="openShare({q}{_rel_js}{q})">分享</button>'
            if it["can_write"]:
                ops += f' <button class="btn btn-xs btn-danger" onclick="deleteFile({q}{_rel_js}{q})">删除</button>'
        else:
            pv  = f'previewFile({q}{_fu_js}{q},{q}{_fn_js}{q},{q}{_ft}{q})'
            nc  = f'<span class="fname file-click" onclick="{pv}"><span class="ficon">{it["icon"]}</span>{it["name"]}</span> {sb}'
            edit_btn = ""
            if ext in ONLINE_EDITABLE:
                import config as _cfg2
                if getattr(_cfg2, 'ONLYOFFICE_ENABLED', False):
                    edit_btn = f' <a class="btn btn-xs btn-primary" href="/edit/{_rel}">编辑</a>'
            ops = (f'<a class="btn btn-xs btn-outline" href="{_fu}?dl=1">下载</a>'
                   f' <button class="btn btn-xs btn-outline" onclick="{pv}">预览</button>'
                   + edit_btn +
                   f' <button class="btn btn-xs btn-outline" onclick="openShare({q}{_rel_js}{q})">分享</button>')
            if it["can_write"]:
                ops += f' <button class="btn btn-xs btn-danger" onclick="deleteFile({q}{_rel_js}{q})">删除</button>'
        return (f'<tr><td>{nc}</td>'
                f'<td><span class="badge badge-gray" style="font-size:10px">{_ft.upper()}</span></td>'
                f'<td class="fsize">{it["size_str"]}</td><td class="fdate">{it["mtime"]}</td>'
                f'<td>{perm}</td><td style="text-align:right;white-space:nowrap">{ops}</td></tr>')


    # ── 卡片网格渲染 ─────────────────────────────────
    FTYPE_COLORS = {
        "dir":   "#fbbf24", "image": "#3b82f6", "video": "#8b5cf6",
        "audio": "#ec4899", "pdf":   "#ef4444", "word":  "#2563eb",
        "excel": "#16a34a", "ppt":   "#f59e0b", "zip":   "#64748b",
        "text":  "#06b6d4", "other": "#9ca3af",
    }
    FTYPE_BG = {
        "dir":   "#fef3c7", "image": "#dbeafe", "video": "#ede9fe",
        "audio": "#fce7f3", "pdf":   "#fee2e2", "word":  "#dbeafe",
        "excel": "#dcfce7", "ppt":   "#fef3c7", "zip":   "#f1f5f9",
        "text":  "#cffafe", "other": "#f3f4f6",
    }

    def _card(it):
        _rel = it["rel"]; _fu = it.get("file_url", ""); _ft = it["ftype"]
        ext   = Path(_rel).suffix.lower() if not it["is_dir"] else ""
        _rel_js = _js(_rel); _fu_js = _js(_fu); _fn_js = _js(it["name"])
        col   = FTYPE_COLORS.get(_ft, "#9ca3af")
        bg    = FTYPE_BG.get(_ft, "#f3f4f6")
        sb    = "🔗 " if _rel in _shared_rels else ""
        q     = "'"

        # 缩略图（图片类型）
        if _ft == "image" and not it["is_dir"]:
            thumb = (
                '<div class="fc-thumb" style="background:#e2e8f0;overflow:hidden">'
                '<img src="' + _fu + '" loading="lazy" '
                'style="width:100%;height:100%;object-fit:cover" '
                'onerror="this.parentElement.style.background='' + bg + '';this.remove()">'
                '</div>'
            )
        elif _ft == "video" and not it["is_dir"]:
            thumb = (
                '<div class="fc-thumb" style="background:' + bg + ';position:relative">'
                '<div style="font-size:32px;display:flex;align-items:center;justify-content:center;height:100%">' + it["icon"] + '</div>'
                '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center">'
                '<span style="width:32px;height:32px;background:rgba(0,0,0,.5);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:14px">▶</span>'
                '</div></div>'
            )
        else:
            thumb = (
                '<div class="fc-thumb" style="background:' + bg + ';display:flex;align-items:center;justify-content:center;font-size:36px">'
                + it["icon"] + '</div>'
            )

        # 点击事件
        if it["is_dir"]:
            click_action = 'location.href=' + _js(it.get("browse_url","")) + ''
        else:
            pv = 'previewFile(' + q + _fu_js + q + ',' + q + _fn_js + q + ',' + q + _ft + q + ')'
            click_action = pv

        # 操作浮层
        ops_items = []
        if not it["is_dir"]:
            ops_items.append('<a href="' + _fu + '?dl=1" class="fc-op-btn" onclick="event.stopPropagation()">⬇ 下载</a>')
        ext_ok = ext in ONLINE_EDITABLE and getattr(__import__("config"), "ONLYOFFICE_ENABLED", False)
        if ext_ok:
            ops_items.append('<a href="/edit/' + _rel + '" class="fc-op-btn" onclick="event.stopPropagation()">✏️ 编辑</a>')
        ops_items.append('<button class="fc-op-btn" onclick="event.stopPropagation();openShare(' + q + _rel_js + q + ')">🔗 分享</button>')
        if it["can_write"]:
            ops_items.append('<button class="fc-op-btn fc-op-del" onclick="event.stopPropagation();deleteFile(' + q + _rel_js + q + ')">🗑 删除</button>')
        ops_html = "".join(ops_items)

        type_tag = (
            '<span style="font-size:10px;font-weight:600;color:' + col + ';'
            'background:' + bg + ';padding:1px 5px;border-radius:3px">'
            + _ft.upper() + '</span>'
        )
        
        return (
            '<div class="fc" onclick="' + click_action + '">'
            + thumb
            + '<div class="fc-info">'
            + '<div class="fc-name" title="' + it["name"] + '">' + sb + it["name"] + '</div>'
            + '<div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px">'
            + type_tag
            + '<span style="font-size:10px;color:var(--text3)">' + it["size_str"] + '</span>'
            + '</div>'
            + '</div>'
            + '<div class="fc-ops">' + ops_html + '</div>'
            + '</div>'
        )

        rows_html  = "".join(_row(it) for it in items) or '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">📭</div><p>此目录为空</p></div></td></tr>'

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf
    upload_path_val = subpath or f"users/{uname}"

    upload_zone = ""
    if can_upload:
        upload_zone = f"""
        <div class="upload-zone" id="dropzone"
          ondragover="event.preventDefault();this.classList.add('drag')"
          ondragleave="this.classList.remove('drag')"
          ondrop="handleDrop(event)">
          <div class="uz-icon">☁️</div>
          <p>拖拽文件到此处，或 <label style="cursor:pointer">
            <input type="file" id="file-input" multiple style="display:none"
              onchange="uploadFiles(this.files,'{upload_path_val}')">
            <strong>点击选择文件</strong></label> 上传</p>
          <p style="font-size:11px;color:var(--text3);margin-top:4px">单次最大 {config.MAX_UPLOAD_MB}MB</p>
          <div class="progress" id="upload-progress"><div class="progress-bar" id="upload-bar"></div></div>
        </div>"""

    mkdir_btn = f'<button class="btn btn-outline btn-sm" onclick="doMkdir(\'{subpath}\')">📁 新建文件夹</button>' if can_mkdir else ""

    content = f"""
<div class="view show" style="gap:12px">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div class="bc" id="bc">{bc_html}</div>
    <div style="display:flex;gap:6px">
      {mkdir_btn}
      <a href="/search" class="btn btn-outline btn-sm">🔍 搜索文件</a>
    </div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap">
    {"".join('<a class="qpath" href="/browse/'+ap["path"]+'">'+ap.get("label","")+'</a>' for ap in auth_paths if ap["path"])}
  </div>
  {upload_zone}
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr">
      <h2>📁 文件列表</h2>
      <div style="display:flex;align-items:center;gap:10px">
        <span style="font-size:12px;color:var(--text3)">{len(items)} 项</span>
        <div class="view-switcher">
          <button class="vs-btn active" id="vs-list" onclick="switchView('list')" title="列表">☰</button>
          <button class="vs-btn" id="vs-grid" onclick="switchView('grid')" title="网格">⊞</button>
        </div>
      </div>
    </div>
    <div class="card-body" id="pane-list">
      <table class="tbl">
        <thead><tr>
          <th style="width:38%">文件名</th><th>类型</th><th>大小</th>
          <th>修改时间</th><th>权限</th><th style="text-align:right">操作</th>
        </tr></thead>
        <tbody>{rows_html}</tbody>
      </table>
    </div>
    <div id="pane-grid" style="display:none">
      <div class="fc-grid">{''.join(_card(it) for it in items) or '<div style="padding:40px;text-align:center;color:var(--text3)">此目录为空</div>'}</div>
    </div>
  </div>
</div>
<script>
async function uploadFiles(files,path){{
  if(!files.length) return;
  const bar=document.getElementById('upload-bar');
  const prog=document.getElementById('upload-progress');
  prog.classList.add('show'); bar.style.width='10%';
  for(let i=0;i<files.length;i++){{
    const fd=new FormData();
    fd.append('csrf_token','{csrf}'); fd.append('path',path); fd.append('files',files[i]);
    bar.style.width=((i+1)/files.length*90+5)+'%';
    const r=await fetch('/upload',{{method:'POST',body:fd}});
    const d=await r.json();
    if(!d.success) toast('上传失败：'+d.error,'err');
  }}
  bar.style.width='100%';
  setTimeout(()=>{{prog.classList.remove('show');bar.style.width='0';location.reload();}},600);
}}
function handleDrop(e){{
  e.preventDefault();
  document.getElementById('dropzone').classList.remove('drag');
  uploadFiles(e.dataTransfer.files,'{upload_path_val}');
}}
async function deleteFile(rel){{
  if(!confirm('确认删除：'+rel+'？')) return;
  const r=await fetch('/api/delete',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{path:rel,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('已删除','ok');location.reload();}}
  else toast('删除失败：'+d.error,'err');
}}
async function doMkdir(parent){{
  const name=prompt('新建文件夹名称：');
  if(!name||!name.trim()) return;
  const r=await fetch('/api/mkdir',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{parent:parent,name:name.trim(),csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('创建成功','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
function switchView(mode){{
  ['list','grid'].forEach(m=>{{
    const el=document.getElementById('pane-'+m);
    if(el) el.style.display=m===mode?'':'none';
    const btn=document.getElementById('vs-'+m);
    if(btn) btn.classList.toggle('active',m===mode);
  }});
  localStorage.setItem('fileViewMode',mode);
}}
// 恢复上次视图模式
(function(){{ const m=localStorage.getItem('fileViewMode'); if(m) switchView(m); }})();
</script>"""
    from routes._ctx import ctx
    return layout(content, "文件浏览", "browse", **ctx())


# ── 文件服务 ─────────────────────────────────────────
@bp.route("/file/<path:filepath>")
@login_required
def serve_file(filepath):
    full = safe_join(config.FILE_ROOT, filepath)
    if not os.path.isfile(full): abort(404)
    if session["role"] != ROLE_SUPER:
        if not _can(filepath) and not _is_shared_to_me(filepath):
            log_action(session["uid"], session["uname"], "ACCESS_DENIED", filepath, request.remote_addr, "ERROR")
            abort(403)
    as_dl = request.args.get("dl", "0") == "1"

    # 对象存储模式（MinIO）：流式返回
    _storage = get_storage()
    if not hasattr(_storage, 'get_local_path'):
        if not _storage.exists(filepath):
            abort(404)
        from flask import Response, stream_with_context
        if as_dl:
            log_action(session["uid"], session["uname"], "DOWNLOAD", filepath, request.remote_addr)
        try:
            _stream = _storage.get_stream(filepath)
        except FileNotFoundError:
            abort(404)
        _mime, _ = mimetypes.guess_type(filepath)
        _mime = _mime or "application/octet-stream"
        _fname = Path(filepath).name
        from urllib.parse import quote as _q
        _cd = (("attachment" if as_dl else "inline") + '; filename="' +
               ("".join(c for c in _fname if ord(c)<128) or "file") + '"; filename*=UTF-8''' + _q(_fname.encode("utf-8"), safe=""))
        def _gen():
            try:
                while True:
                    chunk = _stream.read(65536)
                    if not chunk: break
                    yield chunk
            finally:
                try: _stream.close()
                except Exception: pass
        return Response(stream_with_context(_gen()), mimetype=_mime,
                        headers={"Content-Disposition": _cd, "Cache-Control": "no-cache, private"})

    # 本地存储：继续用 send_file（高性能，支持 Range）
    if as_dl:
        log_action(session["uid"], session["uname"], "DOWNLOAD", filepath, request.remote_addr)
        return safe_send(full, inline=False)
    return safe_send(full, inline=True)


# ── Office 预览 ───────────────────────────────────────
OFFICE_EXTS = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
               ".odt", ".ods", ".odp", ".wps", ".et", ".dps", ".rtf"}


def _pdf_cache_path(src_full):
    h = hashlib.md5(src_full.encode()).hexdigest()[:12]
    cache_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "preview_cache")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, h + ".pdf")


def _convert_to_pdf(src_full, pdf_path):
    for lo in [r"C:\Program Files\LibreOffice\program\soffice.exe",
               r"C:\Program Files (x86)\LibreOffice\program\soffice.exe", "soffice"]:
        if os.path.isfile(lo) or lo == "soffice":
            break
    else:
        return False, "LibreOffice 未安装"
    try:
        result = subprocess.run(
            [lo, "--headless", "--convert-to", "pdf", "--outdir", os.path.dirname(pdf_path), src_full],
            capture_output=True, text=True, timeout=60
        )
        generated = os.path.join(os.path.dirname(pdf_path),
                                 os.path.splitext(os.path.basename(src_full))[0] + ".pdf")
        if os.path.isfile(generated):
            if generated != pdf_path: os.replace(generated, pdf_path)
            return True, ""
        return False, result.stderr or "转换失败"
    except subprocess.TimeoutExpired:
        return False, "转换超时"
    except Exception as e:
        return False, str(e)


@bp.route("/preview/<path:filepath>")
@login_required
def preview_file(filepath):
    full = safe_join(config.FILE_ROOT, filepath)
    if not os.path.isfile(full): abort(404)
    if session["role"] != ROLE_SUPER:
        if not _can(filepath) and not _is_shared_to_me(filepath): abort(403)
    ext = Path(filepath).suffix.lower()
    if ext not in OFFICE_EXTS:
        return safe_send(full, inline=True)
    pdf_path  = _pdf_cache_path(full)
    src_mtime = os.path.getmtime(full)
    if not os.path.isfile(pdf_path) or os.path.getmtime(pdf_path) < src_mtime:
        ok, err = _convert_to_pdf(full, pdf_path)
        if not ok:
            return (f"<html><body style='font-family:sans-serif;padding:40px'>"
                    f"<h2>无法预览</h2><p>{err}</p>"
                    f"<p><a href='/file/{filepath}?dl=1'>下载文件</a></p></body></html>"), 200, \
                   {"Content-Type": "text/html; charset=utf-8"}
    return safe_send(pdf_path, mime="application/pdf", inline=True,
                     dl_name=Path(filepath).stem + ".pdf")


# ── 压缩包预览 ────────────────────────────────────────
@bp.route("/archive/<path:filepath>")
@login_required
def archive_list(filepath):
    import zipfile, tarfile
    full = safe_join(config.FILE_ROOT, filepath)
    if not os.path.isfile(full): abort(404)
    if session["role"] != ROLE_SUPER:
        if not _can(filepath) and not _is_shared_to_me(filepath): abort(403)
    ext     = Path(filepath).suffix.lower()
    entries = []; error = None
    try:
        if ext == ".zip":
            with zipfile.ZipFile(full) as zf:
                for info in zf.infolist():
                    try: name = info.filename.encode("cp437").decode("gbk")
                    except: name = info.filename
                    entries.append({"name": name, "size": info.file_size, "is_dir": info.is_dir()})
        elif ext in (".tar", ".gz", ".bz2", ".xz"):
            with tarfile.open(full, "r:*") as tf:
                for m in tf.getmembers():
                    entries.append({"name": m.name, "size": m.size, "is_dir": m.isdir()})
        elif ext == ".7z":
            import py7zr
            with py7zr.SevenZipFile(full, mode="r") as z:
                for item in z.list():
                    entries.append({"name": item.filename, "size": item.uncompressed or 0, "is_dir": item.is_directory})
        elif ext == ".rar":
            import rarfile
            with rarfile.RarFile(full) as rf:
                for info in rf.infolist():
                    entries.append({"name": info.filename, "size": info.file_size, "is_dir": info.is_dir()})
        else:
            error = f"不支持的格式：{ext}"
    except Exception as e:
        error = f"读取失败：{e}"

    def _fmt(n):
        for u in ("B", "KB", "MB", "GB"):
            if n < 1024: return f"{n:.1f} {u}"
            n /= 1024
        return f"{n:.1f} GB"

    rows = ""
    if error:
        rows = f'<tr><td colspan="2" style="color:#dc2626;padding:20px;text-align:center">{error}</td></tr>'
    elif not entries:
        rows = '<tr><td colspan="2" style="padding:20px;text-align:center">压缩包为空</td></tr>'
    else:
        all_e = sorted([e for e in entries if e["is_dir"]], key=lambda x: x["name"]) + \
                sorted([e for e in entries if not e["is_dir"]], key=lambda x: x["name"])
        rows = "".join(
            f'<tr><td style="padding:6px 12px;font-family:monospace;font-size:13px">'
            f'{"📁" if e["is_dir"] else "📄"} {e["name"]}</td>'
            f'<td style="padding:6px 12px;font-size:12px;color:#64748b;text-align:right">{"—" if e["is_dir"] else _fmt(e["size"])}</td></tr>'
            for e in all_e
        )
    total_files = sum(1 for e in entries if not e["is_dir"])
    total_size  = _fmt(sum(e["size"] for e in entries if not e["is_dir"]))
    html = (f'<!DOCTYPE html><html><head><meta charset="UTF-8">'
            f'<style>body{{margin:0;background:#f8fafc;color:#1e293b;font-family:sans-serif;font-size:14px}}'
            f'.hdr{{background:#1a56a8;color:#fff;padding:12px 16px;display:flex;justify-content:space-between}}'
            f'table{{width:100%;border-collapse:collapse}}tr:nth-child(even)td{{background:#f1f5f9}}'
            f'tr:hover td{{background:#dbeeff}}td{{border-bottom:1px solid #e2e8f0}}</style></head><body>'
            f'<div class="hdr"><h3 style="margin:0;font-family:monospace">🗜 {Path(filepath).name}</h3>'
            f'<span style="font-size:12px;opacity:.85">{total_files} 个文件 · {total_size}</span></div>'
            f'<table><tbody>{rows}</tbody></table></body></html>')
    return html, 200, {"Content-Type": "text/html; charset=utf-8", "X-Frame-Options": "SAMEORIGIN"}


# ── 新建文件夹 ────────────────────────────────────────
@bp.route("/api/mkdir", methods=["POST"])
@login_required
def mkdir():
    data   = request.get_json() or {}
    token  = data.get("csrf_token", "")
    if not csrf_ok(token): return jsonify({"success": False, "error": "CSRF"}), 403
    parent = data.get("parent", "").strip("/")
    name   = data.get("name", "").strip()
    if not name or not re.match(r'^[\w\u4e00-\u9fff\- ]+$', name):
        return jsonify({"success": False, "error": "文件夹名称含非法字符"})
    if session["role"] != ROLE_SUPER and not _can(parent or f"users/{session['uname']}", True):
        return jsonify({"success": False, "error": "无写入权限"}), 403
    target = safe_join(config.FILE_ROOT, parent, name) if parent else os.path.join(config.FILE_ROOT, name)
    try:
        os.makedirs(target, exist_ok=False)
        log_action(session["uid"], session["uname"], "MKDIR", f"{parent}/{name}", request.remote_addr)
        return jsonify({"success": True})
    except FileExistsError:
        return jsonify({"success": False, "error": "文件夹已存在"})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# ── 上传 ─────────────────────────────────────────────
@bp.route("/upload", methods=["POST"])
@login_required
def upload():
    token = request.form.get("csrf_token", "") or request.headers.get("X-CSRF-Token", "")
    if not csrf_ok(token): return jsonify({"success": False, "error": "CSRF 校验失败"}), 403
    rel_path = request.form.get("path", "").strip("/") or f"users/{session['uname']}"
    if session["role"] != ROLE_SUPER and not _can(rel_path, True):
        return jsonify({"success": False, "error": "无写入权限"}), 403

    upload_dir = safe_join(config.FILE_ROOT, rel_path)
    os.makedirs(upload_dir, exist_ok=True)

    udir = os.path.join(config.FILE_ROOT, "users", session["uname"])
    with get_conn() as conn:
        q_row = conn.execute("SELECT quota_mb FROM users WHERE id=%s", (session["uid"],)).fetchone()
    quota_mb = q_row["quota_mb"] if q_row else 1024000
    used_mb  = sum(os.path.getsize(os.path.join(dp, fn))
                   for dp, _, fns in os.walk(udir) for fn in fns) / 1024 / 1024

    saved = []
    for f in request.files.getlist("files"):
        if not f.filename: continue
        ext = Path(f.filename).suffix.lower()
        if ext not in config.UPLOAD_WHITELIST:
            return jsonify({"success": False, "error": f"不允许上传 {ext or '无扩展名'} 类型文件"}), 400
        safe_name = secure_filename(f.filename) or f.filename.replace("/", "_")
        f.seek(0, 2); incoming_mb = f.tell() / 1024 / 1024; f.seek(0)
        if rel_path.startswith(f"users/{session['uname']}") and (used_mb + incoming_mb) > quota_mb:
            return jsonify({"success": False, "error": f"个人配额不足，已用 {used_mb:.1f} MB"}), 400
        dest = os.path.join(upload_dir, safe_name)
        if os.path.isfile(dest):
            save_version(f"{rel_path}/{safe_name}", dest, session["uid"], "上传覆盖前自动备份")
        # 写入存储后端（本地磁盘 or MinIO）
        _st = get_storage()
        f.seek(0)
        if hasattr(_st, 'get_local_path'):
            # 本地存储：直接保存到磁盘
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            f.save(dest)
        else:
            # 对象存储：流式上传
            _st.put(f"{rel_path}/{safe_name}", f.stream)
        used_mb += incoming_mb
        saved.append(safe_name)

    if saved:
        log_action(session["uid"], session["uname"], "UPLOAD",
                   f"{len(saved)} 文件 → /{rel_path}", request.remote_addr)
        for fname in saved:
            async_index(os.path.join(config.FILE_ROOT, rel_path, fname), f"{rel_path}/{fname}")
    return jsonify({"success": True, "saved": saved})


# ── 删除 ─────────────────────────────────────────────
@bp.route("/api/delete", methods=["POST"])
@login_required
def delete_file():
    data  = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    rel  = data.get("path", "").strip("/")
    if session["role"] != ROLE_SUPER and not _can(rel, True):
        return jsonify({"success": False, "error": "无权限删除"}), 403
    full = safe_join(config.FILE_ROOT, rel)
    try:
        if not os.path.exists(full):
            return jsonify({"success": False, "error": "文件不存在"})
        move_to_trash(rel, full, session["uid"])
        delete_index(rel)
        log_action(session["uid"], session["uname"], "DELETE_TO_TRASH", rel, request.remote_addr, "WARN")
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# ── 搜索 ─────────────────────────────────────────────
@bp.route("/search")
@login_required
def search():
    kw      = request.args.get("q", "").strip()
    ftype   = request.args.get("type", "")
    mode    = request.args.get("mode", "full")
    uid     = session["uid"]; role = session["role"]; org_id = session.get("org_id")
    auth_paths = get_authorized_paths(uid, role, org_id)

    ft_results = []
    nm_results = []
    if kw:
        if mode != "name":
            ft_results = search_index(kw, limit=80)
            if ftype: ft_results = [r for r in ft_results if r["ftype"] == ftype]
        nm_results = search_files(uid, role, org_id, kw, ftype or None, 100)

    seen = set(); results = []
    for r in ft_results:
        if r["file_path"] not in seen:
            seen.add(r["file_path"]); results.append({"source": "full", **r})
    for r in nm_results:
        fp = r.get("rel", "")
        if fp not in seen:
            seen.add(fp)
            results.append({"source": "name", "file_path": fp, "file_name": r["name"],
                "ftype": r["ftype"], "file_size": 0, "title": r["name"],
                "summary": "", "snippet": "", "meta": {}, "score": 1,
                "file_url": r["file_url"], "rel": fp})

    ftype_opts = [("", "全部类型"), ("image", "图片"), ("video", "视频"),
                  ("audio", "音频"), ("pdf", "PDF"), ("text", "文本"),
                  ("office", "Office"), ("zip", "压缩包")]
    opts_html = "".join(f'<option value="{v}" {"selected" if ftype==v else ""}>{l}</option>'
                        for v, l in ftype_opts)

    rows_html = ""
    for r in results:
        _fp = r["file_path"]; _fu = r.get("file_url", f"/file/{_fp}")
        _fn = r["file_name"]; _ft = r["ftype"]; q = "'"
        pv  = f'previewFile({q}{_fu}{q},{q}{_fn.replace(q, chr(39))}{q},{q}{_ft}{q})'
        hl  = lambda t: re.sub(re.escape(kw), lambda m: f'<span class="hl">{m.group()}</span>',
                               str(t), flags=re.IGNORECASE) if kw and t else str(t or "")
        rows_html += f"""<tr>
          <td>
            <div class="fname file-click" onclick="{pv}" style="cursor:pointer">
              <span class="ficon">{_ftype_icon(_ft)}</span>{hl(r.get("title") or _fn)}
              <span class="badge {'badge-blue' if r.get('source')=='full' else 'badge-gray'}" style="font-size:9px">
                {'内容' if r.get('source')=='full' else '文件名'}</span>
            </div>
            {f'<div style="font-size:11px;color:var(--text3);padding-left:28px;margin-top:2px">{hl(r.get("snippet",""))}</div>' if r.get("snippet") else ""}
          </td>
          <td class="fdate" style="font-size:11px">{"/".join(_fp.split("/")[:-1]) or "根目录"}</td>
          <td style="text-align:right;white-space:nowrap">
            <a class="btn btn-xs btn-outline" href="{_fu}%sdl=1">下载</a>
          </td></tr>"""

    if kw and not results:
        rows_html = '<tr><td colspan="3"><div class="empty-state"><div class="es-icon">🔍</div><p>未找到匹配内容</p></div></td></tr>'
    elif not kw:
        rows_html = '<tr><td colspan="3"><div class="empty-state"><div class="es-icon">🔍</div><p>输入关键词搜索文件名或文档内容</p></div></td></tr>'

    total_indexed = 0
    try:
        from dao.db import get_conn as _get_conn
        with _get_conn() as _ic:
            _r = _ic.execute("SELECT COUNT(*) FROM file_index WHERE status='done'").fetchone()
            total_indexed = _r[0] if _r else 0
    except Exception:
        pass

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">🔍</span>全文搜索</div>
  <div class="card">
    <form method="GET" action="/search" style="padding:14px 16px">
      <div style="display:flex;gap:8px;margin-bottom:8px">
        <input class="s-inp" name="q" value="{kw}" placeholder="搜索文件名、文档内容..." autofocus style="flex:1">
        <select class="s-sel inp" name="type">{opts_html}</select>
        <select class="s-sel inp" name="mode">
          <option value="full" {"selected" if mode!="name" else ""}>🔍 全文搜索</option>
          <option value="name" {"selected" if mode=="name" else ""}>📄 仅文件名</option>
        </select>
        <button type="submit" class="btn btn-primary">搜索</button>
      </div>
      <div style="font-size:11px;color:var(--text3)">
        已索引 <strong style="color:var(--primary)">{total_indexed}</strong> 个文件
      </div>
    </form>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr">
      <h2>搜索结果</h2>
      <span style="font-size:12px;color:var(--text3)">{"共 "+str(len(results))+" 条" if kw else ""}</span>
    </div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th style="width:60%">文件 / 内容摘要</th><th>目录</th><th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>"""
    from routes._ctx import ctx
    return layout(content, "全文搜索", "search", **ctx())
