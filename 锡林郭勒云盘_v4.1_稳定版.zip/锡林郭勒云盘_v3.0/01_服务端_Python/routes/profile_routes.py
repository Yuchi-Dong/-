# -*- coding: utf-8 -*-
"""
routes/profile_routes.py — 个人中心（图片头像 + 个性化信息 + 统计）

路由：
  GET  /profile/v2              新版个人中心页面
  POST /api/avatar/upload       上传/裁剪头像（base64）
  POST /api/avatar/delete       删除头像
  GET  /avatar/<filename>       提供头像图片
  POST /api/profile/bio         更新签名/位置/职称
  POST /api/profile/color       更新头像颜色
"""
import hashlib
import io
import os
import re
import secrets

import config
from auth import login_required, generate_csrf_token, csrf_ok
from dao.db import get_conn
from dao.file_dao import log_action
from dao.user_dao import (
    update_profile, update_avatar, update_avatar_image, update_bio, get_stats
)
from flask import Blueprint, jsonify, request, session, send_file, abort
from templates import layout

bp = Blueprint("profile_ext", __name__)


# ════════════════════════════════════════════════════
#  头像服务端点（无需登录，供 img src 直接访问）
# ════════════════════════════════════════════════════
@bp.route("/avatar/<path:filename>")
def serve_avatar(filename):
    if not re.match(r'^[\w\-]{4,80}\.(jpg|jpeg|png|webp)$', filename, re.I):
        abort(403)
    avatar_dir = os.path.join(config.FILE_ROOT, '.avatars')
    full = os.path.realpath(os.path.join(avatar_dir, filename))
    if not full.startswith(os.path.realpath(avatar_dir)):
        abort(403)
    if not os.path.isfile(full):
        abort(404)
    import mimetypes
    mime, _ = mimetypes.guess_type(full)
    resp = send_file(full, mimetype=mime or 'image/jpeg')
    resp.headers['Cache-Control'] = 'public, max-age=86400'
    return resp


# ════════════════════════════════════════════════════
#  头像上传（前端裁剪后发 base64）
# ════════════════════════════════════════════════════
@bp.route("/api/avatar/upload", methods=["POST"])
@login_required
def api_avatar_upload():
    import base64

    token = (request.form.get("csrf_token") or
             request.headers.get("X-CSRF-Token") or
             (request.get_json(silent=True) or {}).get("csrf_token", ""))
    if not csrf_ok(token):
        return jsonify({"success": False, "error": "CSRF 校验失败"}), 403

    b64 = request.form.get("image_data", "")
    if not b64:
        j = request.get_json(silent=True) or {}
        b64 = j.get("image_data", "")
    if "," in b64:
        b64 = b64.split(",", 1)[1]
    if not b64:
        return jsonify({"success": False, "error": "没有接收到图片数据"}), 400

    try:
        img_bytes = base64.b64decode(b64)
    except Exception:
        return jsonify({"success": False, "error": "图片数据解析失败"}), 400

    max_b = getattr(config, "AVATAR_MAX_KB", 2048) * 1024
    if len(img_bytes) > max_b:
        return jsonify({"success": False, "error": f"图片超过 {max_b//1024}KB 限制"}), 400

    # Pillow 处理：居中裁正方形 → 缩到 200×200 → JPEG
    try:
        from PIL import Image
        img  = Image.open(io.BytesIO(img_bytes)).convert("RGBA")
        size = getattr(config, "AVATAR_SIZE", 200)
        w, h = img.size
        m    = min(w, h)
        img  = img.crop(((w-m)//2, (h-m)//2, (w+m)//2, (h+m)//2))
        img  = img.resize((size, size), Image.LANCZOS)
        bg   = Image.new("RGB", (size, size), (255, 255, 255))
        bg.paste(img, mask=img.split()[3] if img.mode == "RGBA" else None)
        out  = io.BytesIO()
        bg.save(out, "JPEG", quality=88, optimize=True)
        final = out.getvalue()
    except ImportError:
        # Pillow 未安装，直接存原图
        final = img_bytes
    except Exception as e:
        return jsonify({"success": False, "error": f"图片处理失败: {e}"}), 400

    uid      = session["uid"]
    fhash    = hashlib.sha256(final).hexdigest()[:16]
    filename = f"{uid}_{fhash}.jpg"
    avatar_dir = os.path.join(config.FILE_ROOT, '.avatars')
    os.makedirs(avatar_dir, exist_ok=True)

    # 删旧头像
    with get_conn() as conn:
        row = conn.execute("SELECT avatar_path FROM users WHERE id=%s", (uid,)).fetchone()
    if row and row.get("avatar_path") and row["avatar_path"] != filename:
        old = os.path.join(avatar_dir, row["avatar_path"])
        try:
            if os.path.isfile(old): os.remove(old)
        except Exception:
            pass

    with open(os.path.join(avatar_dir, filename), "wb") as fh:
        fh.write(final)

    update_avatar_image(uid, filename)
    session["avatar_path"] = filename
    log_action(uid, session["uname"], "UPDATE_AVATAR", filename, request.remote_addr)
    return jsonify({"success": True, "url": f"/avatar/{filename}"})


# ════════════════════════════════════════════════════
#  删除头像
# ════════════════════════════════════════════════════
@bp.route("/api/avatar/delete", methods=["POST"])
@login_required
def api_avatar_delete():
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    uid = session["uid"]
    with get_conn() as conn:
        row = conn.execute("SELECT avatar_path FROM users WHERE id=%s", (uid,)).fetchone()
    if row and row.get("avatar_path"):
        fp = os.path.join(config.FILE_ROOT, '.avatars', row["avatar_path"])
        try:
            if os.path.isfile(fp): os.remove(fp)
        except Exception:
            pass
    update_avatar_image(uid, "")
    session.pop("avatar_path", None)
    return jsonify({"success": True})


# ════════════════════════════════════════════════════
#  更新签名 / 位置 / 职称
# ════════════════════════════════════════════════════
@bp.route("/api/profile/bio", methods=["POST"])
@login_required
def api_profile_bio():
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    bio   = (data.get("bio") or "")[:200]
    loc   = (data.get("location") or "")[:50]
    title = (data.get("department_title") or "")[:50]
    update_bio(session["uid"], bio, loc, title)
    return jsonify({"success": True})


# ════════════════════════════════════════════════════
#  更新头像颜色
# ════════════════════════════════════════════════════
@bp.route("/api/profile/color", methods=["POST"])
@login_required
def api_profile_color():
    data = request.get_json(silent=True) or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    color = data.get("color", "#de2910")
    if not re.match(r'^#[0-9a-fA-F]{6}$', color):
        return jsonify({"success": False, "error": "颜色格式错误"}), 400
    update_avatar(session["uid"], color)
    session["avatar_color"] = color
    return jsonify({"success": True})


# ════════════════════════════════════════════════════
#  新版个人中心页面
# ════════════════════════════════════════════════════
@bp.route("/profile/v2")
@login_required
def profile_v2():
    uid = session["uid"]
    with get_conn() as conn:
        user = dict(conn.execute("SELECT * FROM users WHERE id=%s", (uid,)).fetchone())

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    # 基础字段
    uname       = user.get("display_name") or user["username"]
    av_char     = uname[0].upper()
    av_color    = user.get("avatar_color") or "#de2910"
    avatar_path = user.get("avatar_path") or ""
    bio         = user.get("bio") or ""
    location_v  = user.get("location") or ""
    dept_title  = user.get("department_title") or ""

    # 统计
    stats = get_stats(uid)

    # 组织名
    org_name = ""
    if user.get("org_id"):
        try:
            with get_conn() as conn:
                r = conn.execute(
                    "SELECT name FROM organizations WHERE id=%s", (user["org_id"],)
                ).fetchone()
            if r: org_name = r["name"]
        except Exception:
            pass

    # 角色标签
    role_map = {0: ("超级管理员", "#c62828"), 1: ("管理员", "#1560bd"), 2: ("成员", "#15803d")}
    role_label, role_color = role_map.get(user.get("role", 2), ("成员", "#15803d"))

    # 配额
    quota_mb = user.get("quota_mb", 1024000)
    used_mb  = 0.0
    try:
        udir = os.path.join(config.FILE_ROOT, "users", user["username"])
        if os.path.isdir(udir):
            used_mb = sum(
                os.path.getsize(os.path.join(dp, fn))
                for dp, _, fns in os.walk(udir) for fn in fns
            ) / 1024 / 1024
    except Exception:
        pass
    quota_pct = min(100, round(used_mb / max(1, quota_mb) * 100))
    bar_col   = "#ef4444" if quota_pct > 85 else "#f59e0b" if quota_pct > 60 else "#1D9E75"

    # 颜色预设
    presets = ["#de2910","#1a4b9b","#15803d","#7c3aed","#b45309",
               "#0e7de0","#374151","#be185d","#0f766e","#9a3412"]

    def _cbtn(col):
        ring = "outline:2px solid #fff;outline-offset:1px;" if col == av_color else ""
        return ('<button type="button" onclick="setColor(\'' + col + '\')" '
                'style="width:26px;height:26px;border-radius:50%;background:' + col + ';'
                'border:3px solid transparent;cursor:pointer;' + ring + '" '
                'id="cb_' + col[1:] + '"></button>')

    color_btns = "".join(_cbtn(c) for c in presets)

    # 最近操作
    op_ico = {
        "UPLOAD":"📤","DOWNLOAD":"📥","DELETE_TO_TRASH":"🗑️",
        "LOGIN":"🔐","EDIT_SAVE":"✏️","MKDIR":"📁","SHARE_CREATE":"🔗",
    }
    recent_html = ""
    for op in stats.get("last_ops", []):
        ico    = op_ico.get(op.get("action",""), "•")
        detail = (op.get("detail") or "")[:36]
        ts     = str(op.get("ts",""))[:16]
        recent_html += (
            '<div style="display:flex;align-items:center;gap:10px;padding:8px 0;'
            'border-bottom:1px solid var(--border);font-size:12px">'
            '<span style="font-size:15px;flex-shrink:0">' + ico + '</span>'
            '<span style="flex:1;color:var(--text2);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + detail + '</span>'
            '<span style="color:var(--text3);white-space:nowrap">' + ts + '</span>'
            '</div>'
        )
    if not recent_html:
        recent_html = '<div style="color:var(--text3);font-size:12px;padding:14px 0;text-align:center">暂无操作记录</div>'

    # 头像 HTML 片段（避免在大 f-string 内嵌套复杂逻辑）
    if avatar_path:
        av_large_html = (
            '<img src="/avatar/' + avatar_path + '?t=' + str(os.path.getmtime(
                os.path.join(config.FILE_ROOT, '.avatars', avatar_path)
            ) if os.path.isfile(os.path.join(config.FILE_ROOT, '.avatars', avatar_path)) else '0') + '" '
            'id="av-img" style="width:100%;height:100%;object-fit:cover">'
        )
        del_btn_html = ('<button onclick="deleteAvatar()" class="btn btn-sm" '
                        'style="background:#ef4444;color:#fff;border:none;font-size:11px">删除头像</button>')
    else:
        av_large_html = ('<span id="av-char" style="font-size:34px;font-weight:700;color:#fff">'
                         + av_char + '</span>')
        del_btn_html  = ""

    # meta 行
    meta_parts = ['<span style="font-family:var(--font-mono)">@' + user["username"] + '</span>']
    if location_v:  meta_parts.append("📍 " + location_v)
    if dept_title:  meta_parts.append("💼 " + dept_title)
    if org_name:    meta_parts.append("🏛 " + org_name)
    meta_html = " &nbsp;·&nbsp; ".join(meta_parts)

    # 把 HTML 和 JS 分开，彻底规避 f-string 里的 JS 花括号冲突
    html_part = (
        '<div class="view show" style="gap:14px">'

        # ── 顶部个人卡片 ──────────────────────────────
        '<div class="card" style="padding:0;overflow:hidden;margin-bottom:0">'
        '<div id="profile-cover" style="height:88px;background:linear-gradient(135deg,'
        + av_color + ',' + av_color + 'aa)"></div>'
        '<div style="padding:0 24px 20px;position:relative">'

        # 大头像
        '<div style="position:relative;display:inline-block;margin-top:-38px;margin-bottom:10px">'
        '<div id="av-large" onclick="document.getElementById(\'av-file\').click()" title="点击更换头像" '
        'style="width:76px;height:76px;border-radius:50%;overflow:hidden;border:4px solid var(--white);'
        'box-shadow:0 2px 8px rgba(0,0,0,.15);background:' + av_color + ';'
        'display:flex;align-items:center;justify-content:center;cursor:pointer">'
        + av_large_html + '</div>'
        '<div onclick="document.getElementById(\'av-file\').click()" title="更换头像" '
        'style="position:absolute;bottom:2px;right:2px;width:22px;height:22px;'
        'background:var(--primary);border-radius:50%;display:flex;align-items:center;'
        'justify-content:center;cursor:pointer;border:2px solid var(--white);font-size:11px">📷</div>'
        '</div>'
        '<input type="file" id="av-file" accept="image/*" style="display:none" onchange="onPickFile(this)">'

        # 姓名行
        '<div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px">'
        '<div>'
        '<div style="font-size:19px;font-weight:700;color:var(--text)">' + uname + '</div>'
        '<div style="font-size:11px;color:var(--text3);margin-top:3px;line-height:2">' + meta_html + '</div>'
        + ('<div style="font-size:13px;color:var(--text2);margin-top:5px">' + bio + '</div>' if bio else '')
        + '</div>'
        '<span style="font-size:11px;font-weight:600;color:' + role_color + ';'
        'background:' + role_color + '18;padding:3px 12px;border-radius:20px;flex-shrink:0">'
        + role_label + '</span>'
        '</div>'

        # 统计数字
        '<div style="display:flex;gap:24px;margin-top:14px;padding-top:12px;border-top:1px solid var(--border)">'
        + "".join(
            '<div style="text-align:center"><div style="font-size:20px;font-weight:700;color:var(--text)">'
            + str(v) + '</div><div style="font-size:11px;color:var(--text3)">' + k + '</div></div>'
            for k, v in [
                ("上传文件", stats["uploads"]),
                ("发出分享", stats["shares"]),
                ("下载次数", stats["downloads"]),
                ("已用 MB",  round(used_mb, 1)),
            ]
        )
        + '</div>'  # stats row
        '</div>'    # padding div
        '</div>'    # card

        # ── 双列 ──────────────────────────────────────
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">'

        # 左列
        '<div style="display:flex;flex-direction:column;gap:14px">'

        # 基本信息
        '<div class="card" style="padding:20px 24px">'
        '<div style="font-size:13px;font-weight:600;border-left:3px solid var(--primary);padding-left:8px;margin-bottom:14px">基本信息</div>'
        '<form method="POST" action="/profile">'
        '<input type="hidden" name="csrf_token" value="' + csrf + '">'
        '<input type="hidden" name="action" value="profile">'
        '<div class="fg"><label>登录用户名</label>'
        '<input class="inp" value="' + user["username"] + '" readonly style="background:var(--gray50);color:var(--text3)"></div>'
        '<div class="fg"><label>显示姓名 *</label>'
        '<input class="inp" name="display_name" required value="' + (user.get("display_name") or "") + '" placeholder="真实姓名"></div>'
        '<div class="fg"><label>工作邮箱</label>'
        '<input class="inp" name="email" type="email" value="' + (user.get("email") or "") + '" placeholder="工作邮箱（可选）"></div>'
        '<div class="fg" style="margin-bottom:0"><label>联系电话</label>'
        '<input class="inp" name="phone" value="' + (user.get("phone") or "") + '" placeholder="联系电话（可选）"></div>'
        '<div style="margin-top:14px"><button type="submit" class="btn btn-primary btn-sm">保存信息</button></div>'
        '</form></div>'

        # 个性信息
        '<div class="card" style="padding:20px 24px">'
        '<div style="font-size:13px;font-weight:600;border-left:3px solid #7c3aed;padding-left:8px;margin-bottom:14px">个性信息</div>'
        '<div class="fg"><label>个性签名 <span style="font-size:11px;color:var(--text3)" id="bio-cnt">(' + str(len(bio)) + '/200)</span></label>'
        '<textarea class="inp" id="bio-ta" rows="2" style="resize:vertical" maxlength="200" placeholder="一句话介绍自己...">' + bio + '</textarea></div>'
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">'
        '<div class="fg" style="margin:0"><label>所在地点</label>'
        '<input class="inp" id="inp-loc" value="' + location_v + '" placeholder="如：锡林郭勒" maxlength="50"></div>'
        '<div class="fg" style="margin:0"><label>职位/职称</label>'
        '<input class="inp" id="inp-title" value="' + dept_title + '" placeholder="如：系统管理员" maxlength="50"></div>'
        '</div>'
        '<div style="margin-top:14px">'
        '<button type="button" class="btn btn-sm" style="background:#7c3aed;color:#fff;border:none" onclick="saveBio()">保存个性信息</button>'
        '</div></div>'

        # 存储配额
        '<div class="card" style="padding:20px 24px">'
        '<div style="font-size:13px;font-weight:600;border-left:3px solid #0f766e;padding-left:8px;margin-bottom:12px">存储空间</div>'
        '<div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text2);margin-bottom:6px">'
        '<span>已使用 ' + f"{used_mb:.1f}" + ' MB</span>'
        '<span>配额 ' + str(quota_mb // 1024) + ' GB（' + str(quota_pct) + '%）</span>'
        '</div>'
        '<div style="height:6px;background:var(--border);border-radius:3px;overflow:hidden">'
        '<div style="height:100%;width:' + str(quota_pct) + '%;background:' + bar_col + ';border-radius:3px;transition:width .4s"></div>'
        '</div>'
        '<div style="font-size:11px;color:var(--text3);margin-top:6px">个人目录：users/' + user["username"] + '/</div>'
        '</div>'

        '</div>'  # 左列

        # 右列
        '<div style="display:flex;flex-direction:column;gap:14px">'

        # 头像设置
        '<div class="card" style="padding:20px 24px">'
        '<div style="font-size:13px;font-weight:600;border-left:3px solid #de2910;padding-left:8px;margin-bottom:14px">头像设置</div>'

        # 图片区
        '<div style="margin-bottom:16px;padding-bottom:16px;border-bottom:1px solid var(--border)">'
        '<div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:10px">📷 图片头像</div>'
        '<div style="display:flex;align-items:center;gap:14px">'
        '<div id="crop-preview" style="width:66px;height:66px;border-radius:50%;overflow:hidden;'
        'border:2px solid var(--border);background:' + av_color + ';'
        'display:flex;align-items:center;justify-content:center;flex-shrink:0;'
        'font-size:24px;font-weight:700;color:#fff">'
        + ('<img src="/avatar/' + avatar_path + '" style="width:100%;height:100%;object-fit:cover">' if avatar_path else av_char)
        + '</div>'
        '<div><div style="font-size:11px;color:var(--text3);line-height:1.7;margin-bottom:8px">'
        'JPG / PNG / WebP，最大 2MB<br>上传后可拖动裁剪为圆形</div>'
        '<div style="display:flex;gap:8px;flex-wrap:wrap">'
        '<button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById(\'av-file\').click()">📷 选择图片</button>'
        + del_btn_html
        + '</div></div></div></div>'

        # 颜色区
        '<div>'
        '<div style="font-size:12px;font-weight:600;color:var(--text2);margin-bottom:10px">🎨 文字头像颜色</div>'
        '<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px">' + color_btns + '</div>'
        '<div style="display:flex;align-items:center;gap:10px">'
        '<div id="color-dot" style="width:28px;height:28px;border-radius:50%;background:' + av_color + ';border:2px solid var(--border);flex-shrink:0"></div>'
        '<button type="button" class="btn btn-outline btn-sm" onclick="saveColor()">保存颜色</button>'
        '<span style="font-size:11px;color:var(--text3)">无图片时显示此颜色</span>'
        '</div></div>'

        '</div>'  # 头像设置 card

        # 最近操作
        '<div class="card" style="padding:20px 24px;flex:1">'
        '<div style="font-size:13px;font-weight:600;border-left:3px solid var(--gray400);padding-left:8px;margin-bottom:10px">最近操作</div>'
        + recent_html +
        '</div>'

        '</div>'  # 右列
        '</div>'  # grid
        '</div>'  # view

        # ── 裁剪弹窗 ──────────────────────────────────
        '<div id="crop-modal" style="display:none;position:fixed;inset:0;'
        'background:rgba(0,0,0,.65);z-index:9999;align-items:center;justify-content:center">'
        '<div style="background:var(--white);border-radius:10px;padding:22px;'
        'max-width:370px;width:92%;box-shadow:0 20px 60px rgba(0,0,0,.3)">'
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">'
        '<span style="font-size:15px;font-weight:600">裁剪头像</span>'
        '<button onclick="closeCrop()" style="background:none;border:none;font-size:18px;cursor:pointer;color:var(--text3);line-height:1">✕</button>'
        '</div>'
        '<div style="position:relative;margin-bottom:12px;user-select:none;touch-action:none">'
        '<canvas id="crop-canvas" style="width:100%;border-radius:6px;display:block;cursor:move;border:1px solid var(--border)"></canvas>'
        '<div style="position:absolute;inset:0;pointer-events:none;border-radius:6px;overflow:hidden">'
        '<div style="position:absolute;inset:0;background:rgba(0,0,0,.42)"></div>'
        '<div id="crop-ring" style="position:absolute;border-radius:50%;'
        'box-shadow:0 0 0 9999px rgba(0,0,0,.42);background:transparent"></div>'
        '</div></div>'
        '<div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">'
        '<span style="font-size:11px;color:var(--text3)">缩放</span>'
        '<input type="range" id="crop-zoom" min="0.5" max="3" step="0.02" value="1" style="flex:1" oninput="doCrop()">'
        '<span id="zoom-lbl" style="font-size:11px;color:var(--text3);min-width:32px">1.0×</span>'
        '</div>'
        '<div style="display:flex;gap:10px">'
        '<button onclick="closeCrop()" style="flex:1;padding:9px;border:1px solid var(--border);'
        'background:none;border-radius:5px;cursor:pointer;font-size:13px">取消</button>'
        '<button id="crop-confirm" onclick="confirmCrop()" style="flex:1;padding:9px;'
        'background:var(--primary);color:#fff;border:none;border-radius:5px;cursor:pointer;'
        'font-size:13px;font-weight:600">确认上传</button>'
        '</div></div></div>'
    )

    # JS 完全独立，不在 f-string 里，用普通字符串，花括号无冲突
    js_part = """
<script>
var _ci=null,_cx=0,_cy=0,_drag=false,_sx=0,_sy=0,_ox=0,_oy=0;
var _curColor='""" + av_color + """';
var _csrf='""" + csrf + """';

// ── 颜色 ──────────────────────────────────────────
function setColor(c){
  _curColor=c;
  document.getElementById('color-dot').style.background=c;
  document.getElementById('av-large').style.background=c;
  document.getElementById('profile-cover').style.background='linear-gradient(135deg,'+c+','+c+'aa)';
  document.querySelectorAll('[id^="cb_"]').forEach(b=>b.style.outline='none');
  var btn=document.getElementById('cb_'+c.slice(1));
  if(btn){btn.style.outline='2px solid #fff';btn.style.outlineOffset='1px';}
}
async function saveColor(){
  var r=await fetch('/api/profile/color',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({color:_curColor,csrf_token:_csrf})});
  var d=await r.json();
  if(d.success) toast('头像颜色已保存','ok'); else toast(d.error,'err');
}

// ── 个性信息 ─────────────────────────────────────
async function saveBio(){
  var bio=document.getElementById('bio-ta').value;
  var loc=document.getElementById('inp-loc').value;
  var title=document.getElementById('inp-title').value;
  var r=await fetch('/api/profile/bio',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({bio:bio,location:loc,department_title:title,csrf_token:_csrf})});
  var d=await r.json();
  if(d.success) toast('个性信息已保存','ok'); else toast(d.error,'err');
}
var bioTa=document.getElementById('bio-ta');
if(bioTa) bioTa.addEventListener('input',function(){
  document.getElementById('bio-cnt').textContent='('+this.value.length+'/200)';
});

// ── 头像删除 ──────────────────────────────────────
async function deleteAvatar(){
  if(!confirm('确认删除头像图片？')) return;
  var r=await fetch('/api/avatar/delete',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({csrf_token:_csrf})});
  var d=await r.json();
  if(d.success){toast('已删除','ok');setTimeout(function(){location.reload();},700);}
}

// ── 文件选择 → 裁剪弹窗 ──────────────────────────
function onPickFile(inp){
  var file=inp.files[0]; inp.value='';
  if(!file) return;
  if(file.size>2*1024*1024){toast('图片超过2MB','err');return;}
  var fr=new FileReader();
  fr.onload=function(e){openCrop(e.target.result);};
  fr.readAsDataURL(file);
}

// ── 裁剪逻辑 ─────────────────────────────────────
function openCrop(dataUrl){
  var modal=document.getElementById('crop-modal');
  modal.style.display='flex';
  var canvas=document.getElementById('crop-canvas');
  var img=new Image();
  img.onload=function(){
    _ci=img; _cx=0; _cy=0;
    document.getElementById('crop-zoom').value=1;
    document.getElementById('zoom-lbl').textContent='1.0×';
    var sz=Math.min(img.width,img.height,340);
    canvas.width=sz; canvas.height=sz;
    setTimeout(function(){
      var ring=document.getElementById('crop-ring');
      var pad=18, dw=canvas.offsetWidth, cs=dw-pad*2;
      ring.style.width=cs+'px'; ring.style.height=cs+'px';
      ring.style.left=pad+'px'; ring.style.top=pad+'px';
      doCrop();
    },30);
  };
  img.src=dataUrl;
  canvas.onmousedown=function(e){_drag=true;_sx=e.clientX;_sy=e.clientY;_ox=_cx;_oy=_cy;};
  window.onmousemove=function(e){if(!_drag)return;var sc=canvas.width/canvas.offsetWidth;_cx=_ox+(e.clientX-_sx)*sc;_cy=_oy+(e.clientY-_sy)*sc;doCrop();};
  window.onmouseup=function(){_drag=false;};
  canvas.ontouchstart=function(e){_drag=true;_sx=e.touches[0].clientX;_sy=e.touches[0].clientY;_ox=_cx;_oy=_cy;};
  canvas.ontouchmove=function(e){if(!_drag)return;e.preventDefault();var sc=canvas.width/canvas.offsetWidth;_cx=_ox+(e.touches[0].clientX-_sx)*sc;_cy=_oy+(e.touches[0].clientY-_sy)*sc;doCrop();};
  canvas.ontouchend=function(){_drag=false;};
}
function doCrop(){
  if(!_ci) return;
  var canvas=document.getElementById('crop-canvas');
  var ctx=canvas.getContext('2d');
  var zoom=parseFloat(document.getElementById('crop-zoom').value);
  document.getElementById('zoom-lbl').textContent=zoom.toFixed(1)+'×';
  var sz=canvas.width,sw=_ci.width/zoom,sh=_ci.height/zoom;
  var sx=(_ci.width-sw)/2-_cx/zoom, sy=(_ci.height-sh)/2-_cy/zoom;
  ctx.clearRect(0,0,sz,sz);
  ctx.drawImage(_ci,sx,sy,sw,sh,0,0,sz,sz);
}
function closeCrop(){
  document.getElementById('crop-modal').style.display='none'; _ci=null;
}
async function confirmCrop(){
  if(!_ci) return;
  var canvas=document.getElementById('crop-canvas');
  var out=document.createElement('canvas'); out.width=200; out.height=200;
  out.getContext('2d').drawImage(canvas,0,0,canvas.width,canvas.height,0,0,200,200);
  var b64=out.toDataURL('image/jpeg',0.88);
  var btn=document.getElementById('crop-confirm');
  btn.textContent='上传中...'; btn.disabled=true;
  var fd=new FormData();
  fd.append('csrf_token',_csrf); fd.append('image_data',b64);
  var r=await fetch('/api/avatar/upload',{method:'POST',body:fd});
  var d=await r.json();
  btn.textContent='确认上传'; btn.disabled=false;
  if(d.success){
    closeCrop();
    var url=d.url+'?t='+Date.now();
    var imgTag='<img src="'+url+'" style="width:100%;height:100%;object-fit:cover">';
    var ids=['av-large','crop-preview'];
    ids.forEach(function(id){var el=document.getElementById(id);if(el)el.innerHTML=imgTag;});
    toast('头像已更新','ok');
  } else toast('上传失败：'+d.error,'err');
}
</script>
"""

    content = html_part + js_part
    from routes._ctx import ctx
    return layout(content, "个人中心", "profile", **ctx())
