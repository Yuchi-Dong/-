# -*- coding: utf-8 -*-
"""
routes/_ctx.py — 共享上下文辅助
所有路由通过 ctx() 获取模板所需的公共变量

优化：
  - avatar_color 写入 session（登录时设置），不再每次查 DB
  - unread_shares 用 30 秒内存缓存，高并发下减少重复查询
  - 修复残留的 ? 占位符
"""
import time
import threading
from flask import session
from auth import generate_csrf_token

# ── 分享数计数缓存 ─────────────────────────────────
# key: uid, value: (count, expire_ts)
_shares_cache: dict = {}
_shares_lock = threading.Lock()
_SHARES_TTL  = 30  # 秒


def _get_unread_shares(uid: int, org_id) -> int:
    """带 30 秒缓存的分享数查询，避免每次页面渲染都打 DB"""
    now = time.time()
    cache_key = (uid, org_id)

    with _shares_lock:
        cached = _shares_cache.get(cache_key)
        if cached and now < cached[1]:
            return cached[0]

    # 缓存未命中或已过期，查 DB
    try:
        from dao.file_dao import get_shares_received
        shares = get_shares_received(uid, org_id)
        count  = len(shares)
    except Exception:
        count = 0

    with _shares_lock:
        _shares_cache[cache_key] = (count, now + _SHARES_TTL)
        # 顺带清理过期 key（避免内存无限增长）
        expired = [k for k, v in _shares_cache.items() if now >= v[1]]
        for k in expired:
            _shares_cache.pop(k, None)

    return count


def invalidate_shares_cache(uid: int):
    """有新分享时主动失效缓存（在 api_share / api_share_revoke 里调用）"""
    with _shares_lock:
        to_del = [k for k in _shares_cache if k[0] == uid]
        for k in to_del:
            _shares_cache.pop(k, None)


def ctx():
    uid    = session.get("uid", 0)
    org_id = session.get("org_id")

    u = {
        "username":     session.get("uname", ""),
        "display_name": session.get("display_name", ""),
    }

    # avatar_color 从 session 读（登录时已写入，无需查 DB）
    av_color = session.get("avatar_color", "#de2910")

    # 未读分享数（带缓存）
    unread = _get_unread_shares(uid, org_id) if uid else 0

    csrf = session.get("csrf_token") or generate_csrf_token()
    session["csrf_token"] = csrf

    return {
        "user":          u,
        "role":          session.get("role", 2),
        "unread_shares": unread,
        "csrf_token":    csrf,
        "av_color":      av_color,
        "av_path":       session.get("avatar_path", ""),
    }
