# -*- coding: utf-8 -*-
"""
routes/branding_routes.py — 系统品牌定制管理

管理员可在线修改：
  - 系统名称（如"锡盟公安云硬盘"）
  - 单位名称（副标题）
  - 英文名（登录页副标题）
  - 主题色（顶栏/侧栏颜色）
  - 登录页左侧介绍文字
  - 版权信息

修改后无需重启，刷新页面立即生效。
"""
import json
import os
import re
from flask import Blueprint, session, request, jsonify

from auth import login_required, role_required, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER
from templates import layout

bp = Blueprint("branding", __name__)

_CFG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "branding_config.json"
)

_DEFAULTS = {
    "system_name":    "锡林郭勒云盘",
    "system_name_en": "Xilingol Cloud Drive",
    "system_org":     "锡林郭勒盟行政公署",
    "system_short":   "锡林郭勒云盘",
    "primary_color":  "#1560bd",
    "login_desc":     "为各机关单位提供安全、高效的内部文件存储与共享服务。数据存储于本地服务器，安全可控，不上公有云。",
    "login_features": [
        "数据本地存储，安全可控",
        "按组织架构精细化权限管理",
        "全文检索，支持文档内容搜索",
        "操作全程审计，可追溯",
    ],
    "footer_text":    "数据安全 · 自主可控",
    "allow_register": False,   # 是否开放账号申请
    "register_note":  "申请通过后，管理员将在1个工作日内审核并开通账号。",
}


def load_branding() -> dict:
    try:
        with open(_CFG_PATH, "r", encoding="utf-8") as f:
            cfg = json.load(f)
        # 补全缺失字段
        return {**_DEFAULTS, **cfg}
    except Exception:
        return dict(_DEFAULTS)


def save_branding(cfg: dict):
    with open(_CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    _apply(cfg)


def _apply(cfg: dict):
    """将品牌配置写入 templates 模块，立即生效"""
    import templates as _t
    _t.SYSTEM_NAME    = cfg.get("system_name",    _DEFAULTS["system_name"])
    _t.SYSTEM_NAME_EN = cfg.get("system_name_en", _DEFAULTS["system_name_en"])
    _t.SYSTEM_ORG     = cfg.get("system_org",     _DEFAULTS["system_org"])
    _t.SYSTEM_SHORT   = cfg.get("system_short",   _DEFAULTS["system_short"])

    # 更新 CSS 主题色
    pc = cfg.get("primary_color", _DEFAULTS["primary_color"])
    if re.match(r'^#[0-9a-fA-F]{6}$', pc):
        # 计算深色版本（亮度 -15%）
        r, g, b = int(pc[1:3],16), int(pc[3:5],16), int(pc[5:7],16)
        dk_r, dk_g, dk_b = max(0,r-30), max(0,g-30), max(0,b-30)
        dk = f"#{dk_r:02x}{dk_g:02x}{dk_b:02x}"
        # 替换 CSS 中的颜色变量
        _t.BASE_CSS = re.sub(r'--primary:#[0-9a-fA-F]{6}', f'--primary:{pc}', _t.BASE_CSS)
        _t.BASE_CSS = re.sub(r'--primary-dk:#[0-9a-fA-F]{6}', f'--primary-dk:{dk}', _t.BASE_CSS)

    import config as _c
    _c.SYSTEM_NAME    = _t.SYSTEM_NAME
    _c.ALLOW_REGISTER = cfg.get("allow_register", False)


# 启动时加载
try:
    _apply(load_branding())
except Exception:
    pass


# ── 品牌定制页面 ──────────────────────────────────
@bp.route("/admin/branding")
@login_required
@role_required(ROLE_SUPER)
def admin_branding():
    cfg  = load_branding()
    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    def _v(k):
        return str(cfg.get(k, _DEFAULTS.get(k, "")))

    feats = cfg.get("login_features", _DEFAULTS["login_features"])
    feats_val = "\n".join(feats)

    # 预设主题色
    color_presets = [
        ("#1560bd", "政务蓝（默认）"),
        ("#c0392b", "中国红"),
        ("#2c6e49", "军绿"),
        ("#7b2d8b", "紫色"),
        ("#b7410e", "砖红"),
        ("#1a535c", "深青"),
        ("#2d3436", "深灰"),
        ("#d4a017", "金色"),
    ]
    color_btns = "".join(
        f'<button type="button" onclick="setColor(\'{c}\')" title="{n}" '
        f'style="width:28px;height:28px;background:{c};border:2px solid transparent;'
        f'border-radius:4px;cursor:pointer" id="pb_{c[1:]}"></button>'
        for c, n in color_presets
    )

    content = f"""
<div class="view show" style="max-width:860px">
  <div class="page-title"><span class="pt-icon">🎨</span>系统品牌定制</div>

  <div class="card" style="padding:20px 24px;margin-bottom:12px">
    <div style="font-size:13px;font-weight:600;border-left:3px solid var(--primary);
      padding-left:8px;margin-bottom:16px">基本信息</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
      <div class="fg" style="margin:0">
        <label>系统名称（主标题）<span style="color:var(--danger)">*</span></label>
        <input class="inp" id="b-name" value="{_v('system_name')}"
          placeholder="锡林郭勒云盘" oninput="preview()">
        <div style="font-size:11px;color:var(--text3);margin-top:3px">
          显示在顶栏、登录页、浏览器标题
        </div>
      </div>
      <div class="fg" style="margin:0">
        <label>简称（侧边栏）</label>
        <input class="inp" id="b-short" value="{_v('system_short')}"
          placeholder="云盘" oninput="preview()">
      </div>
      <div class="fg" style="margin:0">
        <label>英文名（登录页副标题）</label>
        <input class="inp" id="b-en" value="{_v('system_name_en')}"
          placeholder="Xilingol Cloud Drive">
      </div>
      <div class="fg" style="margin:0">
        <label>单位名称</label>
        <input class="inp" id="b-org" value="{_v('system_org')}"
          placeholder="锡林郭勒盟行政公署">
      </div>
    </div>
  </div>

  <div class="card" style="padding:20px 24px;margin-bottom:12px">
    <div style="font-size:13px;font-weight:600;border-left:3px solid var(--primary);
      padding-left:8px;margin-bottom:16px">主题颜色</div>
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <div style="display:flex;gap:6px;flex-wrap:wrap">{color_btns}</div>
      <div style="display:flex;align-items:center;gap:8px">
        <span style="font-size:12px;color:var(--text2)">自定义：</span>
        <input type="color" id="b-color-picker"
          value="{_v('primary_color')}"
          oninput="setColor(this.value)"
          style="width:36px;height:28px;border:1px solid var(--border);border-radius:4px;cursor:pointer;padding:2px">
        <input class="inp" id="b-color" value="{_v('primary_color')}"
          style="width:110px" placeholder="#1560bd"
          oninput="document.getElementById('b-color-picker').value=this.value;preview()">
      </div>
    </div>
    <div id="color-preview" style="margin-top:12px;height:36px;border-radius:4px;
      background:{_v('primary_color')};display:flex;align-items:center;
      padding:0 14px;color:#fff;font-size:13px;font-weight:600">
      {_v('system_name')} — 顶栏预览
    </div>
  </div>

  <div class="card" style="padding:20px 24px;margin-bottom:12px">
    <div style="font-size:13px;font-weight:600;border-left:3px solid var(--primary);
      padding-left:8px;margin-bottom:16px">登录页内容</div>
    <div class="fg">
      <label>左侧介绍文字</label>
      <textarea class="inp" id="b-desc" rows="3"
        style="resize:vertical">{_v('login_desc')}</textarea>
    </div>
    <div class="fg">
      <label>特性列表（每行一条，最多6条）</label>
      <textarea class="inp" id="b-feats" rows="4"
        style="resize:vertical;font-family:var(--font-mono);font-size:12px">{feats_val}</textarea>
    </div>
    <div class="fg">
      <label>底部版权文字</label>
      <input class="inp" id="b-footer" value="{_v('footer_text')}"
        placeholder="数据安全 · 自主可控">
    </div>
  </div>

  <div class="card" style="padding:20px 24px;margin-bottom:12px">
    <div style="font-size:13px;font-weight:600;border-left:3px solid var(--primary);
      padding-left:8px;margin-bottom:14px">账号申请功能</div>
    <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
      <input type="checkbox" id="b-reg" {'checked' if cfg.get('allow_register') else ''}
        style="width:16px;height:16px">
      <span style="font-weight:500">在登录页显示"申请账号"入口</span>
    </label>
    <div style="font-size:11px;color:var(--text3);margin:6px 0 12px 24px">
      开启后，用户可在登录页填写申请表，管理员在后台审批后开通账号
    </div>
    <div class="fg" style="margin:0">
      <label>申请页说明文字</label>
      <input class="inp" id="b-regnote" value="{_v('register_note')}"
        placeholder="申请通过后，管理员将在1个工作日内审核">
    </div>
  </div>

  <div style="display:flex;gap:10px">
    <button class="btn btn-outline" onclick="previewLogin()">👁 预览登录页</button>
    <span style="flex:1"></span>
    <button class="btn btn-primary" onclick="saveBranding()">💾 保存并应用</button>
  </div>
</div>

<script>
const _initColor = document.getElementById('b-color').value;

function setColor(c) {{
  document.getElementById('b-color').value = c;
  document.getElementById('b-color-picker').value = c;
  document.getElementById('color-preview').style.background = c;
  preview();
  // 高亮选中的预设按钮
  document.querySelectorAll('[id^="pb_"]').forEach(b => b.style.borderColor='transparent');
  const pb = document.getElementById('pb_' + c.replace('#',''));
  if (pb) pb.style.borderColor = '#333';
}}

function preview() {{
  const name = document.getElementById('b-name').value || '系统名称';
  const color = document.getElementById('b-color').value || '#1560bd';
  document.getElementById('color-preview').textContent = name + ' — 顶栏预览';
  document.getElementById('color-preview').style.background = color;
}}

function previewLogin() {{
  window.open('/branding/preview', '_blank');
}}

async function saveBranding() {{
  const feats = document.getElementById('b-feats').value
    .split('\\n').map(s=>s.trim()).filter(Boolean).slice(0,6);
  const data = {{
    system_name:    document.getElementById('b-name').value.trim(),
    system_name_en: document.getElementById('b-en').value.trim(),
    system_org:     document.getElementById('b-org').value.trim(),
    system_short:   document.getElementById('b-short').value.trim(),
    primary_color:  document.getElementById('b-color').value.trim(),
    login_desc:     document.getElementById('b-desc').value.trim(),
    login_features: feats,
    footer_text:    document.getElementById('b-footer').value.trim(),
    allow_register: document.getElementById('b-reg').checked,
    register_note:  document.getElementById('b-regnote').value.trim(),
    csrf_token:     window._csrf,
  }};
  if (!data.system_name) {{ toast('系统名称不能为空', 'err'); return; }}
  const r = await fetch('/api/admin/branding/save', {{
    method: 'POST', headers: {{'Content-Type': 'application/json'}},
    body: JSON.stringify(data)
  }});
  const d = await r.json();
  if (d.success) {{
    toast('品牌配置已保存，刷新页面生效', 'ok');
    setTimeout(() => location.reload(), 1200);
  }} else toast('保存失败：' + d.error, 'err');
}}

// 初始化高亮当前颜色
(function(){{
  const cur = document.getElementById('b-color').value;
  const pb = document.getElementById('pb_' + cur.replace('#',''));
  if (pb) pb.style.borderColor = '#333';
}})();
</script>"""

    from routes._ctx import ctx
    return layout(content, "品牌定制", "branding", **ctx())


@bp.route("/api/admin/branding/save", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_branding_save():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    cfg = {
        "system_name":    (data.get("system_name") or "").strip()[:40] or _DEFAULTS["system_name"],
        "system_name_en": (data.get("system_name_en") or "").strip()[:60],
        "system_org":     (data.get("system_org") or "").strip()[:60],
        "system_short":   (data.get("system_short") or "").strip()[:20] or _DEFAULTS["system_short"],
        "primary_color":  (data.get("primary_color") or "#1560bd").strip(),
        "login_desc":     (data.get("login_desc") or "").strip()[:200],
        "login_features": [str(f)[:40] for f in (data.get("login_features") or [])[:6]],
        "footer_text":    (data.get("footer_text") or "").strip()[:80],
        "allow_register": bool(data.get("allow_register")),
        "register_note":  (data.get("register_note") or "").strip()[:200],
    }

    # 校验颜色格式
    if not re.match(r'^#[0-9a-fA-F]{6}$', cfg["primary_color"]):
        cfg["primary_color"] = "#1560bd"

    try:
        save_branding(cfg)
        from compliance.audit_log import write as aw, AuditCategory
        aw(session["uid"], session["uname"], "BRANDING_UPDATED",
           f"name={cfg['system_name']}", request.remote_addr, "INFO", AuditCategory.ADMIN)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@bp.route("/branding/preview")
@login_required
@role_required(ROLE_SUPER)
def branding_preview():
    """预览当前品牌配置的登录页效果"""
    cfg = load_branding()
    import templates as _t
    # 临时用当前配置渲染登录页
    html = _t._build_login_html(
        cfg.get("system_name", _t.SYSTEM_NAME),
        cfg.get("system_name_en", _t.SYSTEM_NAME_EN),
        cfg.get("system_org", _t.SYSTEM_ORG),
        _t.BASE_CSS,
        csrf_token="preview_mode",
    )
    # 在预览页顶部加提示条
    html = html.replace(
        "<body>",
        "<body><div style='position:fixed;top:0;left:0;right:0;z-index:9999;"
        "background:#f59e0b;color:#1a1a00;text-align:center;padding:6px;font-size:12px;font-weight:600'>"
        "⚠ 这是预览模式，实际效果以保存后为准</div>"
        "<div style='height:30px'></div>"
    )
    return html
