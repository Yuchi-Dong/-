# -*- coding: utf-8 -*-
"""
routes/share_routes.py — 共享文件 / 我的空间 / 分享 API
"""
import os
import json
from pathlib import Path
from datetime import datetime

from flask import Blueprint, session, request, jsonify, abort

import config
from auth import login_required, safe_join, generate_csrf_token, csrf_ok, ROLE_SUPER
from services.permission_service import can_access, get_authorized_paths
from dao.file_dao import (log_action, create_share, revoke_share,
                          get_shares_received, get_shares_sent, save_version)
from dao.user_dao import get_share_targets, search_users_by_name
from dao.org_dao import get_all as get_all_orgs
from dao.db import get_conn
from search import classify, fmt_size
from indexer import async_index
from templates import layout

bp = Blueprint("share", __name__)


def _ftype_icon(ftype):
    return {"image": "🖼", "pdf": "📄", "text": "📝", "office": "📊",
            "zip": "🗜", "dir": "📁", "ofd": "📋", "video": "🎬", "audio": "🎵"}.get(ftype, "📦")


def _can(rel, need_write=False):
    return can_access(rel, session["uid"], session["role"], session.get("org_id"), need_write)


def _js(s):
    return (str(s).replace("\\", "\\\\").replace("'", "\\'")
            .replace('"', '\\"').replace("\n", " ").replace("\r", ""))


# ── 共享文件页 ────────────────────────────────────────
@bp.route("/shared")
@login_required
def shared():
    uid    = session["uid"]
    org_id = session.get("org_id")
    shared_to_me = get_shares_received(uid, org_id)
    my_shares    = get_shares_sent(uid)

    type_badge = {"public": "share-type-public badge", "org": "share-type-org badge", "user": "share-type-user badge"}
    type_label = {"public": "全员公开", "org": "组织共享", "user": "指定用户"}

    def shared_rows(items):
        if not items:
            return '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">📭</div><p>暂无共享文件</p></div></td></tr>'
        rows = ""
        for s in items:
            _fn = Path(s["file_path"]).name
            _ft = classify(Path(s["file_path"]).suffix.lower())
            _fu = "/file/" + s["file_path"]
            pb   = f'<button class="btn btn-xs btn-outline" onclick="previewFile(\'{_fu}\',\'{_fn}\',\'{_ft}\')">预览</button>'
            badge = f'<span class="{type_badge.get(s["share_type"], "")} badge">{type_label.get(s["share_type"], "")}</span>'
            perm  = '<span class="perm-rw">读写</span>' if s["perm"] == "rw" else '<span class="perm-ro">只读</span>'
            owner = s.get("owner_name") or s.get("owner_username", "")
            rows += f"""<tr>
              <td><span class="fname"><span class="ficon">{_ftype_icon(_ft)}</span>{_fn}</span></td>
              <td>{badge}</td><td>{owner}</td><td>{perm}</td>
              <td style="color:var(--text3);font-size:12px">{s.get("note", "")}</td>
              <td style="text-align:right">{pb} <a class="btn btn-xs btn-outline" href="/file/{s['file_path']}" download>下载</a></td>
            </tr>"""
        return rows

    def myshare_rows(items):
        if not items:
            return '<tr><td colspan="5"><div class="empty-state"><div class="es-icon">📤</div><p>暂未发出任何共享</p></div></td></tr>'
        rows = ""
        for s in items:
            _fn  = Path(s["file_path"]).name
            badge = f'<span class="{type_badge.get(s["share_type"], "")} badge">{type_label.get(s["share_type"], "")}</span>'
            if s["share_type"] == "user":    target = s.get("target_user_name", "")
            elif s["share_type"] == "org":   target = s.get("target_org_name", "")
            else:                            target = "全员"
            perm = '<span class="perm-rw">读写</span>' if s["perm"] == "rw" else '<span class="perm-ro">只读</span>'
            rows += f"""<tr>
              <td><span class="fname"><span class="ficon">📄</span>{_fn}</span></td>
              <td>{badge}</td><td>{target}</td><td>{perm}</td>
              <td style="text-align:right">
                <button class="btn btn-xs btn-danger" onclick="revokeShare({s['id']})">撤销</button>
              </td>
            </tr>"""
        return rows

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">🔗</span>共享文件</div>
  <div class="card" style="overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>📥 共享给我的文件</h2>
      <span class="badge badge-blue">{len(shared_to_me)} 项</span></div>
    <div class="card-body"><table class="tbl"><thead><tr>
      <th style="width:30%">文件名</th><th>类型</th><th>来自</th><th>权限</th><th>备注</th><th style="text-align:right">操作</th>
    </tr></thead><tbody>{shared_rows(shared_to_me)}</tbody></table></div>
  </div>
  <div class="card" style="overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>📤 我发出的共享</h2>
      <span class="badge badge-gray">{len(my_shares)} 项</span></div>
    <div class="card-body"><table class="tbl"><thead><tr>
      <th style="width:32%">文件名</th><th>类型</th><th>共享给</th><th>权限</th><th style="text-align:right">操作</th>
    </tr></thead><tbody>{myshare_rows(my_shares)}</tbody></table></div>
  </div>
</div>
<script>
async function revokeShare(id){{
  if(!confirm('确认撤销此共享？')) return;
  const r=await fetch('/api/share/revoke',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{share_id:id,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('已撤销','ok');location.reload();}}
  else toast('失败：'+d.error,'err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "共享文件", "shared", **ctx())


# ── 我的空间 ─────────────────────────────────────────
@bp.route("/my")
@login_required
def my_space():
    uname = session["uname"]
    uid   = session["uid"]
    my_dir = os.path.join(config.FILE_ROOT, "users", uname)
    os.makedirs(my_dir, exist_ok=True)

    files = []
    for entry in sorted(os.scandir(my_dir), key=lambda e: (not e.is_dir(), e.name.lower())):
        try:
            stat  = entry.stat()
            ext   = Path(entry.name).suffix.lower()
            ftype = classify(ext)
            rel   = f"users/{uname}/{entry.name}"
            files.append({"name": entry.name, "is_dir": entry.is_dir(), "ftype": ftype,
                "size_str": fmt_size(stat.st_size) if not entry.is_dir() else "—",
                "mtime": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                "file_url": f"/file/{rel}", "rel": rel})
        except Exception:
            continue

    # 分享标记
    _my_shared = set(); _my_share_info = {}
    for sr in get_shares_sent(uid):
        fp = sr["file_path"].strip("/")
        _my_shared.add(fp)
        info = _my_share_info.setdefault(fp, [])
        tname = "全员公开" if sr["share_type"] == "public" else (sr.get("target_org_name") or sr.get("target_user_name") or "用户")
        info.append({"type": sr["share_type"], "target": tname, "perm": sr["perm"]})

    def _sbadge(rel):
        if rel not in _my_shared: return ""
        infos = _my_share_info.get(rel, [])
        tip   = "；".join(f"{i['target']} ({'只读' if i['perm']=='ro' else '读写'})" for i in infos)
        ij    = json.dumps(infos, ensure_ascii=False).replace("'", "\\'")
        rj    = json.dumps(rel)
        return (f'<span class="share-badge" title="已分享：{tip}" '
                f'onclick="event.stopPropagation();showShareInfo({rj},{ij})">🔗 已分享</span>')

    with get_conn() as conn:
        q_row = conn.execute("SELECT quota_mb FROM users WHERE id=%s", (uid,)).fetchone()
    quota_mb = q_row["quota_mb"] if q_row else 1024000
    used_mb  = sum(os.path.getsize(os.path.join(dp, fn))
                   for dp, _, fns in os.walk(my_dir) for fn in fns) / 1024 / 1024
    pct      = min(100, round(used_mb / quota_mb * 100))
    bar_cls  = "danger" if pct > 85 else "warn" if pct > 60 else ""
    total_files = sum(1 for f in files if not f["is_dir"])

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    def _row(f):
        q = "'"; _rel = f["rel"]; _fu = f["file_url"]; _fn = f["name"]; _ft = f["ftype"]
        _rj = _js(_rel); _fuj = _js(_fu); _fnj = _js(_fn); sb = _sbadge(_rel)
        if f["is_dir"]:
            nc  = f'<a href="/browse/{_rel}" class="fname" style="text-decoration:none;color:var(--text)"><span class="ficon">📁</span>{_fn}</a>{sb}'
            ops = (f'<button class="btn btn-xs btn-outline" onclick="openShare({q}{_rj}{q})">分享</button>'
                   f' <button class="btn btn-xs btn-danger" onclick="deleteFile({q}{_rj}{q})">删除</button>')
        else:
            pv  = f'previewFile({q}{_fuj}{q},{q}{_fnj}{q},{q}{_ft}{q})'
            nc  = f'<span class="fname file-click" onclick="{pv}"><span class="ficon">{_ftype_icon(_ft)}</span>{_fn}</span>{sb}'
            ops = (f'<a class="btn btn-xs btn-outline" href="{_fu}?dl=1">下载</a>'
                   f' <button class="btn btn-xs btn-outline" onclick="openShare({q}{_rj}{q})">分享</button>'
                   f' <button class="btn btn-xs btn-danger" onclick="deleteFile({q}{_rj}{q})">删除</button>')
        return f'<tr><td>{nc}</td><td class="fsize">{f["size_str"]}</td><td class="fdate">{f["mtime"]}</td><td style="text-align:right;white-space:nowrap">{ops}</td></tr>'

    rows_html = "".join(_row(f) for f in files) or '<tr><td colspan="4"><div class="empty-state"><div class="es-icon">📂</div><p>上传第一个文件吧</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">👤</span>我的空间</div>
  <div class="stats">
    <div class="stat"><div class="stat-icon blue">📄</div>
      <div><div class="stat-val">{total_files}</div><div class="stat-lbl">个人文件</div></div></div>
    <div class="stat"><div class="stat-icon green">💾</div>
      <div><div class="stat-val">{used_mb:.1f}<small style="font-size:12px"> MB</small></div><div class="stat-lbl">已用空间</div></div></div>
    <div class="stat"><div class="stat-icon yellow">📊</div>
      <div><div class="stat-val">{quota_mb//1024}<small style="font-size:12px"> GB</small></div><div class="stat-lbl">配额上限</div></div></div>
  </div>
  <div class="card" style="padding:14px 16px;flex-shrink:0">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
      <span style="font-size:12px;color:var(--text2);font-weight:600">存储使用情况</span>
      <span style="font-size:12px;color:var(--text3)">{used_mb:.1f} MB / {quota_mb//1024} GB ({pct}%)</span>
    </div>
    <div class="quota-bar"><div class="quota-fill {bar_cls}" style="width:{pct}%"></div></div>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr">
      <h2>我的文件</h2>
      <div style="display:flex;gap:6px;align-items:center">
        <button class="btn btn-outline btn-sm" onclick="doMkdir('users/{uname}')">📁 新建文件夹</button>
        <label class="btn btn-primary btn-sm" style="cursor:pointer">
          <input type="file" id="my-file-inp" multiple style="display:none"
            onchange="uploadFiles(this.files,'users/{uname}')">⬆ 上传文件</label>
      </div>
    </div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th style="width:46%">文件名</th><th>大小</th><th>修改时间</th><th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>
<script>
async function uploadFiles(files,path){{
  if(!files.length) return;
  for(let i=0;i<files.length;i++){{
    const fd=new FormData(); fd.append('csrf_token','{csrf}'); fd.append('path',path); fd.append('files',files[i]);
    const r=await fetch('/upload',{{method:'POST',body:fd}}); const d=await r.json();
    if(!d.success) toast('上传失败：'+d.error,'err');
  }}
  toast('上传完成','ok'); setTimeout(()=>location.reload(),800);
}}
async function deleteFile(rel){{
  if(!confirm('确认删除 '+rel+'？')) return;
  const r=await fetch('/api/delete',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{path:rel,csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('已删除','ok');location.reload();}} else toast('失败：'+d.error,'err');
}}
async function doMkdir(parent){{
  const name=prompt('新建文件夹名称：'); if(!name||!name.trim()) return;
  const r=await fetch('/api/mkdir',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{parent:parent,name:name.trim(),csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('创建成功','ok');location.reload();}} else toast('失败：'+d.error,'err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "我的空间", "my", **ctx())


# ── 分享 API ─────────────────────────────────────────
@bp.route("/api/share-targets")
@login_required
def share_targets():
    """
    返回当前用户可分享的目标列表。
    权限规则：
      - 超管：可分享给任意用户/任意组织
      - 普通用户：只能分享给同组织成员，以及同组织的下级子组织
        不能跨组织分享，不能全员公开
    支持 %sq=关键词 进行用户搜索（@用户名）
    """
    uid      = session["uid"]
    role     = session["role"]
    org_id   = session.get("org_id")
    is_super = (role == ROLE_SUPER)
    query    = request.args.get("q", "").strip()

    # 用户列表（可搜索）
    if query:
        users = search_users_by_name(query, uid, org_id, is_super)
    else:
        users = get_share_targets(uid, org_id, is_super)

    # 组织列表（超管可见所有；普通用户只能看本组织及其子组织）
    if is_super:
        all_orgs = get_all_orgs()
        orgs = [{"id": o["id"], "name": o["name"]} for o in all_orgs]
    elif org_id:
        from dao.org_dao import get_by_id as get_org_by_id, get_children
        # 本组织 + 所有直接子组织
        org = get_org_by_id(org_id)
        children = get_children(org_id)
        orgs = []
        if org:
            orgs.append({"id": org["id"], "name": org["name"]})
        orgs += [{"id": c["id"], "name": c["name"]} for c in children]
    else:
        orgs = []

    return jsonify({
        "orgs":     orgs,
        "users":    users,
        "is_super": is_super,
        "can_public": is_super,   # 只有超管可以全员公开
    })


@bp.route("/api/share-info")
@login_required
def api_share_info():
    path = request.args.get("path", "").strip("/")
    if not path: return jsonify({"shares": []})
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT fs.id, fs.share_type, fs.perm, fs.note, fs.expires_at,
                   tu.display_name as target_user_name, tu.username as target_username,
                   o.name as target_org_name
            FROM file_shares fs
            LEFT JOIN users tu ON tu.id=fs.target_id AND fs.share_type='user'
            LEFT JOIN organizations o ON o.id=fs.target_id AND fs.share_type='org'
            WHERE fs.owner_id=%s AND fs.file_path=%s AND fs.is_active=1
              AND (fs.expires_at IS NULL OR fs.expires_at > NOW())
            ORDER BY fs.created_at DESC
        """, (session["uid"], path)).fetchall()
    shares = []
    for r in rows:
        if r["share_type"] == "user":   target_name = r["target_user_name"] or r["target_username"] or "未知用户"
        elif r["share_type"] == "org":  target_name = r["target_org_name"] or "未知组织"
        else:                           target_name = "全体成员"
        shares.append({"id": r["id"], "share_type": r["share_type"], "target_name": target_name,
                        "perm": r["perm"], "note": r["note"] or "", "expires_at": r["expires_at"] or "永久"})
    return jsonify({"shares": shares})


@bp.route("/api/share", methods=["POST"])
@login_required
def api_share():
    data  = request.get_json() or {}
    token = data.get("csrf_token", "") or request.headers.get("X-CSRF-Token", "")
    if not csrf_ok(token):
        return jsonify({"success": False, "error": "CSRF 校验失败，请刷新页面重试"}), 403
    path = data.get("path", "").strip("/")
    if not path: return jsonify({"success": False, "error": "路径不能为空"})
    full = safe_join(config.FILE_ROOT, path)
    if not os.path.exists(full):
        return jsonify({"success": False, "error": "文件或目录不存在"})
    if session["role"] != ROLE_SUPER and not _can(path):
        return jsonify({"success": False, "error": "您没有权限分享此文件"}), 403

    share_type = data.get("share_type", "user")
    target_id  = data.get("target_id") or None
    is_super   = session["role"] == ROLE_SUPER
    caller_org = session.get("org_id")

    # ── 权限收紧：非超管不能全员公开，不能跨组织分享 ──
    if not is_super:
        if share_type == "public":
            return jsonify({"success": False, "error": "无权限：仅超级管理员可设置全员公开分享"}), 403

        if share_type == "user" and target_id:
            with get_conn() as conn:
                target = conn.execute(
                    "SELECT id, org_id FROM users WHERE id=%s AND is_active=1", (target_id,)
                ).fetchone()
            if not target:
                return jsonify({"success": False, "error": "目标用户不存在或已禁用"})
            # 跨组织检查：目标用户必须在同一组织
            if target["org_id"] != caller_org:
                return jsonify({"success": False, "error": "只能分享给同组织成员"}), 403

        elif share_type == "org" and target_id:
            with get_conn() as conn:
                target_org = conn.execute(
                    "SELECT id, parent_id FROM organizations WHERE id=%s", (target_id,)
                ).fetchone()
            if not target_org:
                return jsonify({"success": False, "error": "目标组织不存在"})
            # 只能分享给本组织或其直接子组织
            if target_org["id"] != caller_org and target_org["parent_id"] != caller_org:
                return jsonify({"success": False, "error": "只能分享给本组织或其下级科室"}), 403
    else:
        # 超管：验证目标存在即可
        if share_type == "user" and target_id:
            with get_conn() as conn:
                if not conn.execute("SELECT id FROM users WHERE id=%s AND is_active=1", (target_id,)).fetchone():
                    return jsonify({"success": False, "error": "目标用户不存在或已禁用"})
        elif share_type == "org" and target_id:
            with get_conn() as conn:
                if not conn.execute("SELECT id FROM organizations WHERE id=%s", (target_id,)).fetchone():
                    return jsonify({"success": False, "error": "目标组织不存在"})
    try:
        sid = create_share(session["uid"], path, os.path.isdir(full),
                           share_type, target_id, data.get("perm", "ro"),
                           data.get("note", ""), data.get("expires_at") or None)
        log_action(session["uid"], session["uname"], "SHARE_CREATE",
                   f"{path} → {share_type}:{target_id}", request.remote_addr, "WARN")
        return jsonify({"success": True, "share_id": sid})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@bp.route("/api/share/revoke", methods=["POST"])
@login_required
def api_share_revoke():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    revoke_share(data.get("share_id"), session["uid"])
    return jsonify({"success": True})
