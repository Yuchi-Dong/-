# -*- coding: utf-8 -*-
"""
routes/extra_routes.py — 版本历史 / 回收站 / 外链 / 文件锁 / 密级标签 / 公开外链访问
"""
import os
from pathlib import Path
from datetime import datetime

from flask import Blueprint, session, request, jsonify, abort

import config
from auth import login_required, safe_join, generate_csrf_token, csrf_ok, ROLE_SUPER
from services.permission_service import can_access
from dao.file_dao import (
    log_action, save_version, get_versions, get_version_by_id, restore_version,
    get_trash, move_to_trash, restore_from_trash, empty_trash_item,
    create_public_link, get_public_link, verify_link_password,
    increment_link_views, get_my_links, revoke_public_link,
    lock_file, unlock_file, get_lock_info,
    set_label, get_label, LABELS,
)
from indexer import async_index
from search import fmt_size
from templates import layout

bp = Blueprint("extra", __name__)


def _can(rel, need_write=False):
    return can_access(rel, session["uid"], session["role"], session.get("org_id"), need_write)


def safe_send(full_path, mime=None, inline=True, dl_name=None):
    import mimetypes
    from urllib.parse import quote
    from flask import send_file
    if not mime:
        mime, _ = mimetypes.guess_type(full_path)
        mime = mime or "application/octet-stream"
    fname         = dl_name or Path(full_path).name
    fname_encoded = quote(fname.encode("utf-8"), safe="")
    fname_ascii   = "".join(c for c in fname if ord(c) < 128) or "file"
    disposition   = "inline" if inline else "attachment"
    cd = f'{disposition}; filename="{fname_ascii}"; filename*=UTF-8\'\'{fname_encoded}'
    response = send_file(full_path, mimetype=mime)
    response.headers["Content-Disposition"] = cd
    response.headers["Cache-Control"] = "no-cache, private"
    return response


# ── 版本历史 ─────────────────────────────────────────
@bp.route("/versions")
@login_required
def file_versions():
    rel = request.args.get("path", "").strip("/")
    if not rel: abort(400)
    if session["role"] != ROLE_SUPER and not _can(rel): abort(403)

    versions = get_versions(rel)
    csrf     = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    rows = ""
    for v in versions:
        name = v.get("display_name") or v.get("username", "未知")
        rows += f"""<tr>
          <td>v{v['version_no']}</td>
          <td class="fsize">{fmt_size(v['file_size'])}</td>
          <td class="fdate">{v['created_at']}</td>
          <td>{name}</td>
          <td>{v.get('comment') or '—'}</td>
          <td style="text-align:right">
            <a class="btn btn-xs btn-outline" href="/versions/download/{v['id']}">下载此版本</a>
            <button class="btn btn-xs btn-primary" onclick="restoreVersion({v['id']},'{rel}')">恢复</button>
          </td></tr>"""
    if not rows:
        rows = '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">📋</div><p>暂无版本记录</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between">
    <div class="page-title">📋 版本历史</div>
    <a href="/browse/{'/'.join(rel.split('/')[:-1])}" class="btn btn-outline btn-sm">← 返回</a>
  </div>
  <div class="card">
    <div class="card-hdr"><h2>📄 {rel.split('/')[-1]}</h2>
      <span style="font-size:11px;color:var(--text3)">{len(versions)} 个历史版本（最多保留10个）</span></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th>版本</th><th>大小</th><th>保存时间</th><th>操作者</th><th>备注</th><th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows}</tbody></table>
    </div>
  </div>
</div>
<script>
async function restoreVersion(vid,path){{
  if(!confirm('确认将文件恢复到此版本？当前版本将被覆盖（并自动保存为新版本）。')) return;
  const r=await fetch('/api/versions/restore',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{version_id:vid,path:path,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已恢复到该版本','ok');setTimeout(()=>location.reload(),1000);}}
  else toast('恢复失败：'+d.error,'err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "版本历史", "browse", **ctx())


@bp.route("/versions/download/<int:version_id>")
@login_required
def download_version(version_id):
    row = get_version_by_id(version_id)
    if not row or not os.path.isfile(row["backup_path"]): abort(404)
    if session["role"] != ROLE_SUPER and not _can(row["file_path"]): abort(403)
    return safe_send(row["backup_path"], inline=False,
                     dl_name=f"v{row['version_no']}_{Path(row['file_path']).name}")


@bp.route("/api/versions/restore", methods=["POST"])
@login_required
def api_restore_version():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    vid = data.get("version_id")
    rel = (data.get("path") or "").strip("/")
    if not vid or not rel: return jsonify({"success": False, "error": "参数缺失"})
    if session["role"] != ROLE_SUPER and not _can(rel, True):
        return jsonify({"success": False, "error": "无权限"}), 403
    full = safe_join(config.FILE_ROOT, rel)
    save_version(rel, full, session["uid"], "恢复前自动备份")
    ok, err = restore_version(vid, full)
    if ok:
        async_index(os.path.join(config.FILE_ROOT, rel), rel)
        log_action(session["uid"], session["uname"], "RESTORE_VERSION", rel, request.remote_addr)
    return jsonify({"success": ok, "error": err})


# ── 回收站 ───────────────────────────────────────────
@bp.route("/trash")
@login_required
def trash_page():
    is_super = session["role"] == ROLE_SUPER
    items    = get_trash(session["uid"], is_super)
    csrf     = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    rows = ""
    for it in items:
        name = it.get("display_name") or it.get("username", "—")
        ico  = "📁" if it["is_dir"] else "📄"
        rows += f"""<tr>
          <td><span class="fname"><span class="ficon">{ico}</span>{it['orig_path'].split('/')[-1]}</span></td>
          <td class="fdate" style="font-size:11px">{it['orig_path']}</td>
          <td class="fsize">{fmt_size(it['file_size']) if not it['is_dir'] else '—'}</td>
          <td class="fdate">{it['deleted_at']}</td>
          <td>{name}</td>
          <td style="text-align:right">
            <button class="btn btn-xs btn-primary" onclick="restoreTrash({it['id']})">恢复</button>
            <button class="btn btn-xs btn-danger" onclick="deleteTrash({it['id']})">彻底删除</button>
          </td></tr>"""
    if not rows:
        rows = '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">🗑</div><p>回收站为空</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between">
    <div class="page-title">🗑 回收站</div>
    <button class="btn btn-danger btn-sm" onclick="emptyAll()">清空回收站</button>
  </div>
  <div class="card" style="flex:1">
    <div class="card-hdr"><h2>已删除文件</h2>
      <span style="font-size:11px;color:var(--text3)">{len(items)} 项</span></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th style="width:22%">文件名</th><th>原路径</th><th>大小</th><th>删除时间</th><th>删除人</th>
        <th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows}</tbody></table>
    </div>
  </div>
</div>
<script>
async function restoreTrash(id){{
  const r=await fetch('/api/trash/restore',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{trash_id:id,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已恢复','ok');location.reload();}} else toast('失败：'+d.error,'err');
}}
async function deleteTrash(id){{
  if(!confirm('彻底删除后无法恢复，确认吗？')) return;
  const r=await fetch('/api/trash/delete',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{trash_id:id,csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('已彻底删除','ok');location.reload();}} else toast('失败：'+d.error,'err');
}}
async function emptyAll(){{
  if(!confirm('清空所有回收站内容？此操作不可撤销。')) return;
  const r=await fetch('/api/trash/empty',{{method:'POST',headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('回收站已清空','ok');location.reload();}} else toast('失败','err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "回收站", "trash", **ctx())


@bp.route("/api/trash/restore", methods=["POST"])
@login_required
def api_trash_restore():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    ok, err = restore_from_trash(data.get("trash_id"), session["uid"], session["role"] == ROLE_SUPER)
    if ok: log_action(session["uid"], session["uname"], "RESTORE_TRASH", str(data.get("trash_id")), request.remote_addr)
    return jsonify({"success": ok, "error": err})


@bp.route("/api/trash/delete", methods=["POST"])
@login_required
def api_trash_delete():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    ok = empty_trash_item(data.get("trash_id"), session["uid"], session["role"] == ROLE_SUPER)
    return jsonify({"success": ok})


@bp.route("/api/trash/empty", methods=["POST"])
@login_required
def api_trash_empty():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    items = get_trash(session["uid"], session["role"] == ROLE_SUPER)
    for it in items:
        empty_trash_item(it["id"], session["uid"], session["role"] == ROLE_SUPER)
    log_action(session["uid"], session["uname"], "EMPTY_TRASH", "", request.remote_addr, "WARN")
    return jsonify({"success": True})


# ── 公开外链 ─────────────────────────────────────────
@bp.route("/api/links/create", methods=["POST"])
@login_required
def api_link_create():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    rel = (data.get("path") or "").strip("/")
    if not rel: return jsonify({"success": False, "error": "路径不能为空"})
    if session["role"] != ROLE_SUPER and not _can(rel):
        return jsonify({"success": False, "error": "无权限"}), 403
    full   = safe_join(config.FILE_ROOT, rel)
    is_dir = os.path.isdir(full)
    token  = create_public_link(rel, is_dir, data.get("perm", "ro"),
                                data.get("password", ""), data.get("expires_at"), session["uid"])
    log_action(session["uid"], session["uname"], "CREATE_LINK", rel, request.remote_addr)
    return jsonify({"success": True, "token": token, "url": f"{request.host_url}s/{token}"})


@bp.route("/api/links/revoke", methods=["POST"])
@login_required
def api_link_revoke():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    revoke_public_link(data.get("link_id"), session["uid"])
    return jsonify({"success": True})


@bp.route("/api/links/my")
@login_required
def api_my_links():
    return jsonify({"links": get_my_links(session["uid"])})


@bp.route("/s/<token>", methods=["GET", "POST"])
def public_link_access(token):
    link = get_public_link(token)
    if not link: return "<h2>链接无效或已失效</h2>", 404
    if link.get("expires_at"):
        if datetime.now().strftime('%Y-%m-%d %H:%M:%S') > link["expires_at"]:
            return "<h2>链接已过期</h2>", 410
    if link.get("pw_hash"):
        pw_ok = False
        if request.method == "POST":
            pw_ok = verify_link_password(link, request.form.get("password", ""))
        if not pw_ok:
            err = "<p style='color:red'>密码错误</p>" if request.method == "POST" else ""
            return (f"<!DOCTYPE html><html><head><meta charset='UTF-8'><title>访问链接</title></head><body>"
                    f"<div style='max-width:360px;margin:100px auto;font-family:sans-serif'>"
                    f"<h3>🔒 此链接需要密码</h3>{err}"
                    f"<form method='POST'><input type='password' name='password' placeholder='请输入密码' "
                    f"style='padding:8px;width:100%;margin:10px 0;border:1px solid #ccc;border-radius:4px'>"
                    f"<button type='submit' style='background:#1560bd;color:#fff;padding:8px 18px;border:none;border-radius:4px;cursor:pointer'>访问</button>"
                    f"</form></div></body></html>"), 200
    increment_link_views(token)
    full = safe_join(config.FILE_ROOT, link["file_path"])
    if not os.path.exists(full): return "<h2>文件不存在</h2>", 404
    if os.path.isfile(full): return safe_send(full, inline=True)
    # 目录列表
    items = sorted(os.scandir(full), key=lambda e: (not e.is_dir(), e.name))
    rows  = "".join(f"<tr><td>{'📁' if e.is_dir() else '📄'} {e.name}</td>"
                    f"<td>{fmt_size(e.stat().st_size) if not e.is_dir() else '—'}</td></tr>"
                    for e in items)
    return (f"<!DOCTYPE html><html><head><meta charset='UTF-8'><title>共享文件夹</title></head><body>"
            f"<div style='max-width:800px;margin:40px auto;font-family:sans-serif'>"
            f"<h3>📁 {link['file_path'].split('/')[-1]}</h3>"
            f"<table style='width:100%;border-collapse:collapse'>"
            f"<thead><tr><th style='text-align:left;padding:8px;border-bottom:2px solid #eee'>文件名</th>"
            f"<th style='text-align:left;padding:8px;border-bottom:2px solid #eee'>大小</th></tr></thead>"
            f"<tbody>{rows}</tbody></table></div></body></html>")


# ── 文件锁 ───────────────────────────────────────────
@bp.route("/api/lock", methods=["POST"])
@login_required
def api_lock():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    rel = (data.get("path") or "").strip("/")
    if not rel: return jsonify({"success": False, "error": "路径不能为空"})
    if session["role"] != ROLE_SUPER and not _can(rel, True):
        return jsonify({"success": False, "error": "无权限"}), 403
    lock = get_lock_info(rel)
    if lock and lock["locked_by"] != session["uid"]:
        return jsonify({"success": False, "error": f"文件已被 {lock.get('display_name') or lock.get('username')} 锁定"})
    lock_file(rel, session["uid"], int(data.get("hours", 8)))
    log_action(session["uid"], session["uname"], "LOCK_FILE", rel, request.remote_addr)
    return jsonify({"success": True})


@bp.route("/api/unlock", methods=["POST"])
@login_required
def api_unlock():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    rel = (data.get("path") or "").strip("/")
    unlock_file(rel, session["uid"], session["role"] == ROLE_SUPER)
    log_action(session["uid"], session["uname"], "UNLOCK_FILE", rel, request.remote_addr)
    return jsonify({"success": True})


# ── 密级标签 ─────────────────────────────────────────
@bp.route("/api/label", methods=["POST"])
@login_required
def api_set_label():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")): return jsonify({"success": False, "error": "CSRF"}), 403
    rel   = (data.get("path") or "").strip("/")
    label = data.get("label", "internal")
    if not rel: return jsonify({"success": False, "error": "路径不能为空"})
    if session["role"] != ROLE_SUPER and not _can(rel, True):
        return jsonify({"success": False, "error": "无权限"}), 403
    set_label(rel, label, session["uid"])
    log_action(session["uid"], session["uname"], "SET_LABEL", f"{rel}={label}", request.remote_addr)
    return jsonify({"success": True})
