# -*- coding: utf-8 -*-
"""
routes/storage_routes.py — 存储后端管理路由

路由：
  GET  /admin/storage            存储配置与状态页面
  POST /api/admin/storage/save   保存存储配置
  POST /api/admin/storage/test   测试 MinIO 连接
  GET  /api/admin/storage/stats  存储使用统计
"""
import json
import os
from flask import Blueprint, session, request, jsonify

from auth import login_required, role_required, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER
from templates import layout

bp = Blueprint("storage_admin", __name__)

_STORAGE_CFG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(__file__)), "storage_config.json"
)


def _load_cfg() -> dict:
    try:
        with open(_STORAGE_CFG_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_cfg(cfg: dict):
    with open(_STORAGE_CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)
    _apply(cfg)


def _apply(cfg: dict):
    import config as _c
    _c.STORAGE_BACKEND  = cfg.get("backend", "local")
    _c.MINIO_ENDPOINT   = cfg.get("endpoint", "127.0.0.1:9000")
    _c.MINIO_ACCESS_KEY = cfg.get("access_key", "minioadmin")
    _c.MINIO_SECRET_KEY = cfg.get("secret_key", "minioadmin")
    _c.MINIO_BUCKET     = cfg.get("bucket", "secftp-files")
    _c.MINIO_SECURE     = cfg.get("secure", False)
    _c.MINIO_REGION     = cfg.get("region", "")
    from storage import reset_storage
    reset_storage()


try:
    _apply(_load_cfg())
except Exception:
    pass


@bp.route("/admin/storage")
@login_required
@role_required(ROLE_SUPER)
def admin_storage():
    cfg  = _load_cfg()
    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    import config as _c
    backend = cfg.get("backend", "local")

    def _v(k, d=""): return str(cfg.get(k, d))
    def _ck(k): return "checked" if cfg.get(k) else ""

    # 当前实际后端状态
    try:
        from storage import get_storage
        st = get_storage()
        backend_type = "MinIO" if not hasattr(st, 'get_local_path') else "本地磁盘"
        backend_ok   = True
    except Exception as e:
        backend_type = f"初始化失败（{e}）"
        backend_ok   = False

    status_badge = (
        f'<span class="badge badge-green">● {backend_type}</span>'
        if backend_ok else
        f'<span class="badge badge-red">✗ {backend_type}</span>'
    )

    # 存储使用量（异步获取，避免页面卡顿）
    file_root = getattr(_c, "FILE_ROOT", "")

    content = f"""
<div class="view show" style="max-width:780px">
  <div class="page-title"><span class="pt-icon">💾</span>存储后端配置</div>

  <div class="card" style="padding:14px 20px;margin-bottom:12px">
    <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">
      <span style="font-size:13px;font-weight:600">当前后端：</span>{status_badge}
      <span style="flex:1"></span>
      <button class="btn btn-outline btn-sm" onclick="loadStats()">📊 刷新使用统计</button>
    </div>
    <div id="stats-box" style="margin-top:10px;font-size:12px;color:var(--text2)">
      点击「刷新使用统计」查看存储用量
    </div>
  </div>

  <div class="card" style="padding:20px 24px">
    <div class="fg">
      <label style="font-weight:600">存储后端类型</label>
      <div style="display:flex;gap:20px;margin-top:6px">
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
          <input type="radio" name="backend" value="local"
            {"checked" if backend=="local" else ""}
            onchange="toggleBackend(this.value)">
          <span>本地磁盘（当前默认）</span>
        </label>
        <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
          <input type="radio" name="backend" value="minio"
            {"checked" if backend=="minio" else ""}
            onchange="toggleBackend(this.value)">
          <span>MinIO 对象存储</span>
        </label>
      </div>
    </div>

    <div id="local-section" style="{'display:none' if backend=='minio' else ''}">
      <div class="fg">
        <label>本地存储根目录</label>
        <input class="inp" value="{file_root}" readonly
          style="background:var(--gray50);color:var(--text3)">
        <div style="font-size:11px;color:var(--text3);margin-top:3px">
          修改路径请直接编辑 config.py 中的 FILE_ROOT，需重启服务生效
        </div>
      </div>
    </div>

    <div id="minio-section" style="{'display:none' if backend!='minio' else ''}">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
        <div class="fg" style="margin:0">
          <label>MinIO 地址 <span style="color:var(--danger)">*</span></label>
          <input class="inp" id="minio-endpoint" value="{_v('endpoint','127.0.0.1:9000')}"
            placeholder="192.168.1.20:9000">
        </div>
        <div class="fg" style="margin:0">
          <label>存储桶名称 <span style="color:var(--danger)">*</span></label>
          <input class="inp" id="minio-bucket" value="{_v('bucket','secftp-files')}"
            placeholder="secftp-files">
        </div>
        <div class="fg" style="margin:0">
          <label>Access Key <span style="color:var(--danger)">*</span></label>
          <input class="inp" id="minio-ak" value="{_v('access_key','minioadmin')}"
            placeholder="minioadmin">
        </div>
        <div class="fg" style="margin:0">
          <label>Secret Key <span style="color:var(--danger)">*</span></label>
          <input class="inp" id="minio-sk" value="{_v('secret_key','minioadmin')}"
            type="password" placeholder="minioadmin">
        </div>
        <div class="fg" style="margin:0">
          <label>地域（Region）</label>
          <input class="inp" id="minio-region" value="{_v('region','')}"
            placeholder="可留空（MinIO 自建默认 us-east-1）">
        </div>
        <div class="fg" style="margin:0;display:flex;align-items:flex-end">
          <label style="display:flex;align-items:center;gap:8px">
            <input type="checkbox" id="minio-secure" {_ck('secure')}
              style="width:16px;height:16px">
            <span>使用 HTTPS（MinIO 启用了 TLS 时勾选）</span>
          </label>
        </div>
      </div>

      <div class="fg" style="margin-top:14px">
        <div style="background:var(--primary-xlt);border-radius:6px;padding:12px 14px;
          font-size:12px;line-height:1.9;color:var(--text2)">
          <div style="font-weight:600;margin-bottom:4px">MinIO Docker 快速部署</div>
          <code style="font-size:11px">
            docker run -d --name minio -p 9000:9000 -p 9001:9001 \\<br>
            &nbsp;&nbsp;-e MINIO_ROOT_USER=minioadmin \\<br>
            &nbsp;&nbsp;-e MINIO_ROOT_PASSWORD=minioadmin \\<br>
            &nbsp;&nbsp;-v /data/minio:/data \\<br>
            &nbsp;&nbsp;minio/minio server /data --console-address ':9001'
          </code>
          <div style="margin-top:8px">
            ⚠ 切换到 MinIO 后需运行 <code>python storage/migrate.py</code> 将现有文件迁移
          </div>
        </div>
      </div>
    </div>

    <div style="display:flex;gap:10px;margin-top:20px">
      <button class="btn btn-outline" onclick="testStorage()">🔌 测试连接</button>
      <span style="flex:1"></span>
      <button class="btn btn-primary" onclick="saveStorage()">💾 保存配置</button>
    </div>
  </div>

  <div id="storage-result" style="display:none;margin-top:12px"></div>
</div>

<script>
function toggleBackend(v) {{
  document.getElementById('local-section').style.display  = v==='local'  ? '' : 'none';
  document.getElementById('minio-section').style.display  = v==='minio'  ? '' : 'none';
}}

function _getData() {{
  const backend = document.querySelector('input[name=backend]:checked').value;
  return {{
    backend,
    endpoint:   document.getElementById('minio-endpoint')?.value.trim() || '',
    bucket:     document.getElementById('minio-bucket')?.value.trim()   || 'secftp-files',
    access_key: document.getElementById('minio-ak')?.value.trim()       || '',
    secret_key: document.getElementById('minio-sk')?.value              || '',
    region:     document.getElementById('minio-region')?.value.trim()   || '',
    secure:     document.getElementById('minio-secure')?.checked        || false,
  }};
}}

async function saveStorage() {{
  const r = await fetch('/api/admin/storage/save', {{
    method:'POST', headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify({{..._getData(), csrf_token: window._csrf}})
  }});
  const d = await r.json();
  if (d.success) {{ toast('存储配置已保存，立即生效', 'ok'); }}
  else toast('保存失败：' + d.error, 'err');
}}

async function testStorage() {{
  document.getElementById('storage-result').style.display='';
  document.getElementById('storage-result').innerHTML = '<div class="card" style="padding:12px">⏳ 测试中...</div>';
  const r = await fetch('/api/admin/storage/test', {{
    method:'POST', headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify({{..._getData(), csrf_token: window._csrf}})
  }});
  const d = await r.json();
  const cls = d.ok ? 'toast ok' : 'toast err';
  document.getElementById('storage-result').innerHTML =
    '<div class="'+cls+'" style="padding:12px;border-radius:6px">' +
    (d.ok?'✅':'❌') + ' ' + d.message + '</div>';
}}

async function loadStats() {{
  document.getElementById('stats-box').textContent = '⏳ 统计中...';
  const r = await fetch('/api/admin/storage/stats');
  const d = await r.json();
  if (d.error) {{ document.getElementById('stats-box').textContent = '统计失败：' + d.error; return; }}
  document.getElementById('stats-box').innerHTML =
    '后端: <strong>' + d.backend + '</strong>' +
    ' &nbsp;|&nbsp; 总文件数: <strong>' + d.file_count + '</strong>' +
    ' &nbsp;|&nbsp; 已用空间: <strong>' + d.total_size_human + '</strong>';
}}
</script>"""

    from routes._ctx import ctx
    return layout(content, "存储配置", "storage", **ctx())


@bp.route("/api/admin/storage/save", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_storage_save():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    cfg = {
        "backend":    data.get("backend", "local"),
        "endpoint":   data.get("endpoint", "127.0.0.1:9000"),
        "access_key": data.get("access_key", "minioadmin"),
        "bucket":     data.get("bucket", "secftp-files"),
        "secure":     bool(data.get("secure")),
        "region":     data.get("region", ""),
    }
    if data.get("secret_key"):
        cfg["secret_key"] = data["secret_key"]
    else:
        cfg["secret_key"] = _load_cfg().get("secret_key", "minioadmin")
    try:
        _save_cfg(cfg)
        from compliance.audit_log import write as aw, AuditCategory
        aw(session["uid"], session["uname"], "STORAGE_CONFIG_SAVED",
           f"backend={cfg['backend']}", request.remote_addr, "WARN", AuditCategory.ADMIN)
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


@bp.route("/api/admin/storage/test", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_storage_test():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"ok": False, "message": "CSRF"}), 403

    backend = data.get("backend", "local")
    if backend == "local":
        import config as _c
        if os.path.isdir(getattr(_c, "FILE_ROOT", "")):
            return jsonify({"ok": True, "message": f"本地目录可访问：{_c.FILE_ROOT}"})
        return jsonify({"ok": False, "message": f"目录不存在：{_c.FILE_ROOT}"})

    # 临时应用测试配置
    import config as _c
    old_vals = {k: getattr(_c, k, None) for k in
                ["MINIO_ENDPOINT","MINIO_ACCESS_KEY","MINIO_SECRET_KEY",
                 "MINIO_BUCKET","MINIO_SECURE","MINIO_REGION"]}
    _c.MINIO_ENDPOINT   = data.get("endpoint", "127.0.0.1:9000")
    _c.MINIO_ACCESS_KEY = data.get("access_key", "minioadmin")
    _c.MINIO_SECURE     = bool(data.get("secure"))
    _c.MINIO_BUCKET     = data.get("bucket", "secftp-files")
    _c.MINIO_REGION     = data.get("region", "")
    if data.get("secret_key"):
        _c.MINIO_SECRET_KEY = data["secret_key"]
    from storage import reset_storage
    reset_storage()
    try:
        from storage.minio_backend import MinIOStorage
        ms = MinIOStorage()
        # 写一个探针文件验证读写
        ms._client.put_object(ms.bucket, ".probe", __import__("io").BytesIO(b"ok"), 2)
        ms._client.remove_object(ms.bucket, ".probe")
        return jsonify({"ok": True, "message": f"MinIO 连接成功，bucket={ms.bucket}"})
    except Exception as e:
        return jsonify({"ok": False, "message": str(e)})
    finally:
        for k, v in old_vals.items():
            if v is not None: setattr(_c, k, v)
        reset_storage()


@bp.route("/api/admin/storage/stats")
@login_required
@role_required(ROLE_SUPER)
def api_storage_stats():
    try:
        from storage import get_storage
        st = get_storage()
        total_size = st.du("")
        # 文件计数
        file_count = 0
        for _, _, files in st.walk(""):
            file_count += len(files)

        def _fmt(n):
            for u in ("B","KB","MB","GB","TB"):
                if n < 1024: return f"{n:.1f} {u}"
                n /= 1024
            return f"{n:.1f} TB"

        backend = "MinIO" if not hasattr(st, 'get_local_path') else "本地磁盘"
        return jsonify({
            "backend":          backend,
            "file_count":       file_count,
            "total_size":       total_size,
            "total_size_human": _fmt(total_size),
        })
    except Exception as e:
        return jsonify({"error": str(e)})
