# -*- coding: utf-8 -*-
"""
routes/approval_routes.py — 数据导出申请审批流

流程：
  普通用户申请导出文件 → 组织管理员/超管审批 → 审批通过生成下载Token → 限时下载

路由：
  GET  /export/apply          申请页面
  POST /api/export/apply      提交申请
  GET  /export/my             我的申请列表
  GET  /export/review         待审批列表（管理员）
  POST /api/export/approve    审批通过
  POST /api/export/reject     审批拒绝
  GET  /dl/<token>            凭Token下载（不需登录）
"""
import os
import secrets
from datetime import datetime, timedelta
from pathlib import Path
from flask import Blueprint, session, request, jsonify, abort

import config
from auth import login_required, role_required, generate_csrf_token, csrf_ok, safe_join
from auth import ROLE_SUPER, ROLE_DEPT
from dao.db import get_conn
from dao.file_dao import log_action
from compliance.audit_log import write as audit_write, AuditCategory
from templates import layout

bp = Blueprint('approval', __name__)


def _can_review():
    return session.get('role', 2) <= ROLE_DEPT


# ── 申请导出 ─────────────────────────────────────────────
@bp.route('/export/apply')
@login_required
def apply_page():
    file_path = request.args.get('path', '').strip('/')
    csrf = session.get('csrf_token', generate_csrf_token())
    session['csrf_token'] = csrf

    content = f"""
<div class="view show" style="max-width:600px">
  <div class="page-title"><span class="pt-icon">📤</span>申请导出文件</div>
  <div class="card" style="padding:24px">
    <form id="apply-form">
      <input type="hidden" name="csrf_token" value="{csrf}">
      <div class="fg"><label>申请导出路径</label>
        <input class="inp" name="file_path" value="{file_path}" placeholder="文件路径" required></div>
      <div class="fg"><label>申请原因 <span style="color:var(--danger)">*</span></label>
        <textarea class="inp" name="reason" rows="4"
          placeholder="请详细说明导出用途，例如：用于向上级汇报2025年度工作数据..."
          required style="resize:vertical;min-height:100px"></textarea></div>
      <div class="fg"><label>期望有效期</label>
        <select class="inp inp-sel" name="valid_hours">
          <option value="24">24小时</option>
          <option value="72">3天</option>
          <option value="168">7天</option>
        </select></div>
      <div style="display:flex;gap:10px;margin-top:16px">
        <button type="button" class="btn btn-primary" onclick="submitApply()">提交申请</button>
        <a href="javascript:history.back()" class="btn btn-outline">取消</a>
      </div>
    </form>
  </div>
  <div class="card" style="padding:16px;margin-top:12px">
    <div style="font-size:12px;color:var(--text3);line-height:1.8">
      <div style="font-weight:600;color:var(--text2);margin-bottom:6px">ℹ 说明</div>
      <div>· 申请提交后，组织管理员将在1个工作日内审批</div>
      <div>· 审批通过后，系统发放限时下载链接</div>
      <div>· 所有导出操作均记录审计日志，请合规使用</div>
    </div>
  </div>
</div>
<script>
async function submitApply(){{
  const form = document.getElementById('apply-form');
  const data = Object.fromEntries(new FormData(form));
  if(!data.file_path) {{ toast('请填写文件路径','err'); return; }}
  if(!data.reason||data.reason.trim().length<10) {{ toast('申请原因至少10个字','err'); return; }}
  const r = await fetch('/api/export/apply', {{
    method:'POST', headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify(data)
  }});
  const d = await r.json();
  if(d.success) {{
    toast('申请已提交，等待管理员审批','ok',5000);
    setTimeout(()=>location.href='/export/my',1500);
  }} else toast('提交失败：'+d.error,'err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, '申请导出', 'export', **ctx())


@bp.route('/api/export/apply', methods=['POST'])
@login_required
def api_apply():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')):
        return jsonify({'success': False, 'error': 'CSRF'}), 403

    file_path   = data.get('file_path', '').strip('/')
    reason      = data.get('reason', '').strip()
    valid_hours = int(data.get('valid_hours', 24))

    if not file_path: return jsonify({'success': False, 'error': '文件路径不能为空'})
    if len(reason) < 10: return jsonify({'success': False, 'error': '申请原因至少10个字'})

    full = safe_join(config.FILE_ROOT, file_path)
    if not os.path.exists(full):
        return jsonify({'success': False, 'error': '文件不存在'})

    expires_at = (datetime.now() + timedelta(hours=valid_hours)).isoformat()

    with get_conn() as conn:
        conn.execute("""
            INSERT INTO export_requests(applicant_id, file_path, is_dir, reason, expires_at)
            VALUES(%s, %s, %s, %s, %s)
        """, (session['uid'], file_path, 1 if os.path.isdir(full) else 0, reason, expires_at))

    audit_write(session['uid'], session['uname'], 'EXPORT_APPLY',
                file_path, request.remote_addr, 'INFO', AuditCategory.FILE)
    return jsonify({'success': True})


# ── 我的申请 ─────────────────────────────────────────────
@bp.route('/export/my')
@login_required
def my_requests():
    with get_conn() as conn:
        rows = conn.execute("""
            SELECT er.*, u.display_name as reviewer_name
            FROM export_requests er
            LEFT JOIN users u ON u.id = er.reviewer_id
            WHERE er.applicant_id = %s
            ORDER BY er.created_at DESC LIMIT 50
        """, (session['uid'],)).fetchall()

    status_map = {
        'pending':  ('<span class="badge badge-yellow">待审批</span>', ''),
        'approved': ('<span class="badge badge-green">已批准</span>', 'var(--success)'),
        'rejected': ('<span class="badge badge-red">已拒绝</span>', 'var(--danger)'),
    }
    rows_html = ''
    for r in rows:
        s_badge, s_color = status_map.get(r['status'], ('—', ''))
        dl_btn = ''
        if r['status'] == 'approved' and r.get('download_token'):
            dl_url = f"/dl/{r['download_token']}"
            dl_btn = f'<a class="btn btn-xs btn-primary" href="{dl_url}" target="_blank">下载文件</a>'
        rows_html += f"""<tr>
          <td class="fdate" style="font-size:11px">{str(r['created_at'])[:16]}</td>
          <td class="truncate" style="max-width:200px">{r['file_path']}</td>
          <td style="max-width:180px;font-size:12px;color:var(--text2)">{r['reason'][:40]}{'...' if len(r['reason'])>40 else ''}</td>
          <td>{s_badge}</td>
          <td style="font-size:12px;color:var(--text3)">{r.get('review_note','') or '—'}</td>
          <td style="text-align:right">{dl_btn}</td>
        </tr>"""

    if not rows_html:
        rows_html = '<tr><td colspan="6"><div class="empty-state"><div class="es-icon">📭</div><p>暂无申请记录</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between">
    <div class="page-title"><span class="pt-icon">📋</span>我的导出申请</div>
    <a href="/export/apply" class="btn btn-primary btn-sm">➕ 新建申请</a>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th>申请时间</th><th>文件路径</th><th>申请原因</th><th>状态</th><th>审批意见</th><th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>"""
    from routes._ctx import ctx
    return layout(content, '我的导出申请', 'export', **ctx())


# ── 审批管理 ─────────────────────────────────────────────
@bp.route('/export/review')
@login_required
@role_required(ROLE_DEPT)
def review_page():
    uid   = session['uid']
    role  = session['role']

    with get_conn() as conn:
        if role == ROLE_SUPER:
            rows = conn.execute("""
                SELECT er.*, u.display_name as applicant_name, u.username as applicant_uname
                FROM export_requests er
                JOIN users u ON u.id = er.applicant_id
                WHERE er.status = 'pending'
                ORDER BY er.created_at
            """).fetchall()
        else:
            rows = conn.execute("""
                SELECT er.*, u.display_name as applicant_name, u.username as applicant_uname
                FROM export_requests er
                JOIN users u ON u.id = er.applicant_id
                WHERE er.status = 'pending' AND u.org_id = (
                    SELECT org_id FROM users WHERE id = %s
                )
                ORDER BY er.created_at
            """, (uid,)).fetchall()

    csrf = session.get('csrf_token', generate_csrf_token())
    session['csrf_token'] = csrf

    rows_html = ''
    for r in rows:
        rows_html += f"""<tr>
          <td class="fdate" style="font-size:11px">{str(r['created_at'])[:16]}</td>
          <td>{r.get('applicant_name') or r.get('applicant_uname')}</td>
          <td class="truncate" style="max-width:160px">{r['file_path']}</td>
          <td style="max-width:200px;font-size:12px;color:var(--text2)">{r['reason']}</td>
          <td style="text-align:right;white-space:nowrap">
            <button class="btn btn-xs btn-primary" onclick="approve({r['id']})">✓ 批准</button>
            <button class="btn btn-xs btn-danger" onclick="reject({r['id']})">✗ 拒绝</button>
          </td>
        </tr>"""

    if not rows_html:
        rows_html = '<tr><td colspan="5"><div class="empty-state"><div class="es-icon">✅</div><p>暂无待审批申请</p></div></td></tr>'

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">📋</span>导出申请审批</div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>待审批申请</h2>
      <span class="badge badge-yellow">{len(rows)} 条</span></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th>申请时间</th><th>申请人</th><th>文件路径</th><th>申请原因</th><th style="text-align:right">操作</th>
      </tr></thead><tbody>{rows_html}</tbody></table>
    </div>
  </div>
</div>
<div class="overlay" id="m-review" onclick="if(event.target===this)hideModal('m-review')">
  <div class="modal">
    <div class="modal-hdr"><h3 id="m-review-title">审批</h3>
      <button class="modal-close" onclick="hideModal('m-review')">✕</button></div>
    <input type="hidden" id="review-id">
    <input type="hidden" id="review-action">
    <div class="fg"><label>审批意见（可选）</label>
      <textarea class="inp" id="review-note" rows="3" placeholder="填写审批意见或说明..."></textarea></div>
    <div class="mbtns">
      <button class="btn btn-outline" onclick="hideModal('m-review')">取消</button>
      <button class="btn btn-primary" id="review-submit-btn" onclick="submitReview()">确认</button>
    </div>
  </div>
</div>
<script>
function approve(id){{
  document.getElementById('review-id').value=id;
  document.getElementById('review-action').value='approve';
  document.getElementById('m-review-title').textContent='✓ 批准申请';
  document.getElementById('review-submit-btn').className='btn btn-primary';
  document.getElementById('review-submit-btn').textContent='确认批准';
  document.getElementById('review-note').value='';
  showModal('m-review');
}}
function reject(id){{
  document.getElementById('review-id').value=id;
  document.getElementById('review-action').value='reject';
  document.getElementById('m-review-title').textContent='✗ 拒绝申请';
  document.getElementById('review-submit-btn').className='btn btn-danger';
  document.getElementById('review-submit-btn').textContent='确认拒绝';
  document.getElementById('review-note').value='';
  showModal('m-review');
}}
async function submitReview(){{
  const id = document.getElementById('review-id').value;
  const action = document.getElementById('review-action').value;
  const note = document.getElementById('review-note').value.trim();
  const url = action==='approve' ? '/api/export/approve' : '/api/export/reject';
  const r = await fetch(url, {{
    method:'POST', headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify({{request_id:id, note:note, csrf_token:window._csrf}})
  }});
  const d = await r.json();
  if(d.success){{ hideModal('m-review'); toast(action==='approve'?'已批准':'已拒绝','ok'); location.reload(); }}
  else toast('操作失败：'+d.error,'err');
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, '导出审批', 'export', **ctx())


@bp.route('/api/export/approve', methods=['POST'])
@login_required
@role_required(ROLE_DEPT)
def api_approve():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403

    req_id = data.get('request_id')
    note   = data.get('note', '')
    token  = secrets.token_urlsafe(24)

    with get_conn() as conn:
        row = conn.execute("SELECT * FROM export_requests WHERE id=%s AND status='pending'", (req_id,)).fetchone()
        if not row: return jsonify({'success': False, 'error': '申请不存在或已处理'})

        conn.execute("""
            UPDATE export_requests
            SET status='approved', reviewer_id=%s, review_note=%s,
                reviewed_at=NOW(), download_token=%s
            WHERE id=%s
        """, (session['uid'], note, token, req_id))

    audit_write(session['uid'], session['uname'], 'EXPORT_APPROVED',
                f"req_id={req_id} file={row['file_path']}", request.remote_addr,
                'WARN', AuditCategory.FILE)
    return jsonify({'success': True, 'token': token})


@bp.route('/api/export/reject', methods=['POST'])
@login_required
@role_required(ROLE_DEPT)
def api_reject():
    data = request.get_json() or {}
    if not csrf_ok(data.get('csrf_token', '')): return jsonify({'success': False, 'error': 'CSRF'}), 403

    req_id = data.get('request_id')
    note   = data.get('note', '不符合导出条件')

    with get_conn() as conn:
        row = conn.execute("SELECT * FROM export_requests WHERE id=%s AND status='pending'", (req_id,)).fetchone()
        if not row: return jsonify({'success': False, 'error': '申请不存在或已处理'})
        conn.execute("""
            UPDATE export_requests
            SET status='rejected', reviewer_id=%s, review_note=%s, reviewed_at=NOW()
            WHERE id=%s
        """, (session['uid'], note, req_id))

    audit_write(session['uid'], session['uname'], 'EXPORT_REJECTED',
                f"req_id={req_id}", request.remote_addr, 'WARN', AuditCategory.FILE)
    return jsonify({'success': True})


# ── 凭 Token 下载（无需登录）────────────────────────────
@bp.route('/dl/<token>')
def download_by_token(token):
    with get_conn() as conn:
        row = conn.execute("""
            SELECT er.*, u.display_name, u.username
            FROM export_requests er
            JOIN users u ON u.id = er.applicant_id
            WHERE er.download_token = %s AND er.status = 'approved'
        """, (token,)).fetchone()

    if not row:
        return '<h2>下载链接无效或已失效</h2>', 404

    if row.get('expires_at'):
        exp = row['expires_at']
        if isinstance(exp, str):
            exp = datetime.fromisoformat(exp)
        if datetime.now() > exp.replace(tzinfo=None):
            return '<h2>下载链接已过期</h2>', 410

    full = safe_join(config.FILE_ROOT, row['file_path'])
    if not os.path.isfile(full):
        return '<h2>文件不存在</h2>', 404

    import mimetypes
    from flask import send_file
    from urllib.parse import quote

    mime  = mimetypes.guess_type(full)[0] or 'application/octet-stream'
    fname = Path(full).name
    resp  = send_file(full, mimetype=mime)
    resp.headers['Content-Disposition'] = (
        f'attachment; filename="{fname}"; filename*=UTF-8\'\'{quote(fname.encode())}'
    )
    audit_write(row['applicant_id'], row['username'], 'EXPORT_DOWNLOAD',
                row['file_path'], request.remote_addr, 'WARN', AuditCategory.FILE)
    return resp
