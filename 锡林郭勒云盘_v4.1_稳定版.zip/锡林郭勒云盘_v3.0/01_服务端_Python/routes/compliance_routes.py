# -*- coding: utf-8 -*-
"""
routes/compliance_routes.py — 合规与授权管理路由

包含：
  - /admin/license        License 状态与管理
  - /api/license/status   License 状态 JSON
  - /profile/2fa          个人 2FA 设置
  - /api/2fa/*            2FA API
  - /admin/compliance     等保合规报告
  - /admin/audit-secure   防篡改审计日志查看与验证
"""
import base64
import os
from flask import Blueprint, session, request, jsonify, abort, redirect

from auth import login_required, role_required, generate_csrf_token, csrf_ok
from auth import ROLE_SUPER, ROLE_DEPT
from license.checker import get_status, get_edition, has_feature
import os, base64
from compliance.audit_log import query as query_audit, verify_chain, AuditCategory, write as audit_write
from compliance.two_factor import (generate_secret, verify_totp, generate_qrcode,
                                    enable_2fa, disable_2fa, get_2fa_status)
from compliance.session_mgr import get_active_sessions, invalidate_all_sessions
from dao.db import get_conn
from templates import layout

bp = Blueprint("compliance", __name__)


# ── License 状态页 ────────────────────────────────────
@bp.route("/admin/license")
@login_required
@role_required(ROLE_SUPER)
def admin_license():
    status = get_status()
    csrf   = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    # 状态颜色
    if not status["valid"]:
        banner_cls  = "err"
        banner_icon = "❌"
        banner_text = f"License 无效：{status.get('error', '')}"
    elif status.get("days_left") is not None and status["days_left"] <= 30:
        banner_cls  = "warn"
        banner_icon = "⚠"
        banner_text = f"License 将在 {status['days_left']} 天后到期，请及时续费！"
    else:
        banner_cls  = "ok"
        banner_icon = "✅"
        banner_text = "License 有效"

    feat_html = ""
    for f in status.get("features", []):
        feat_html += f'<span class="badge badge-blue" style="margin:2px">{f}</span>'

    # 机器指纹（只在 License 有效时显示）
    fp_html = ""
    try:
        from license.machine import get_fingerprint
        fp = get_fingerprint()
        fp_html = f"""
        <div class="card" style="padding:16px">
          <h3 style="font-size:13px;font-weight:600;margin-bottom:12px;color:var(--text)">🖥 当前机器指纹</h3>
          <table class="tbl"><tbody>
            <tr><td style="width:120px;color:var(--text3)">机器码</td><td><code>{fp['machine_id']}</code></td></tr>
            <tr><td style="color:var(--text3)">MAC 地址</td><td><code>{', '.join(fp['mac_addresses']) or '无'}</code></td></tr>
            <tr><td style="color:var(--text3)">CPU 序列号</td><td><code>{fp['cpu_serial']}</code></td></tr>
            <tr><td style="color:var(--text3)">服务器 IP</td><td><code>{', '.join(fp['server_ips']) or '无'}</code></td></tr>
            <tr><td style="color:var(--text3)">主机名</td><td>{fp['hostname']}</td></tr>
          </tbody></table>
          <p style="font-size:11px;color:var(--text3);margin-top:8px">
            将以上机器指纹提供给厂商，用于签发绑定到此服务器的 License。
          </p>
        </div>"""
    except Exception as e:
        fp_html = f'<div class="toast err">获取机器指纹失败：{e}</div>'

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">🔐</span>软件授权管理</div>
  <div class="toast {banner_cls}" style="margin-bottom:0">{banner_icon} {banner_text}</div>

  <div class="stats">
    <div class="stat">
      <div class="stat-icon {'green' if status['valid'] else 'red'}">📋</div>
      <div><div class="stat-val">{status.get('edition', '—')}</div><div class="stat-lbl">授权版本</div></div>
    </div>
    <div class="stat">
      <div class="stat-icon blue">👥</div>
      <div><div class="stat-val">{status.get('max_users', 0)}</div><div class="stat-lbl">用户上限</div></div>
    </div>
    <div class="stat">
      <div class="stat-icon yellow">📅</div>
      <div><div class="stat-val">{status.get('days_left', '永久') if status.get('days_left') is not None else '永久'}</div>
      <div class="stat-lbl">剩余天数</div></div>
    </div>
    <div class="stat">
      <div class="stat-icon gray">🔑</div>
      <div><div class="stat-val" style="font-size:13px">{status.get('license_id', '—')}</div><div class="stat-lbl">License ID</div></div>
    </div>
  </div>

  <div class="card" style="padding:16px">
    <h3 style="font-size:13px;font-weight:600;margin-bottom:12px;color:var(--text)">授权详情</h3>
    <table class="tbl"><tbody>
      <tr><td style="width:120px;color:var(--text3)">授权客户</td><td>{status.get('customer', '—')}</td></tr>
      <tr><td style="color:var(--text3)">版本</td><td>{status.get('edition', '—')}</td></tr>
      <tr><td style="color:var(--text3)">到期日期</td><td>{status.get('expire', '永久有效')}</td></tr>
      <tr><td style="color:var(--text3)">License ID</td><td><code>{status.get('license_id', '—')}</code></td></tr>
      <tr><td style="color:var(--text3)">授权功能</td><td>{feat_html or '—'}</td></tr>
    </tbody></table>
  </div>

  {fp_html}

  <!-- 上传 License 文件 -->
  <div class="card" style="padding:16px">
    <h3 style="font-size:13px;font-weight:600;margin-bottom:8px;color:var(--text)">📁 上传 License 文件</h3>
    <p style="font-size:12px;color:var(--text3);margin-bottom:12px">
      从厂商获取 <code>license.lic</code> 文件后，直接在此上传，无需手动拷贝到服务器。
    </p>
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <input type="file" id="lic-file" accept=".lic" style="font-size:12px">
      <button class="btn btn-primary btn-sm" onclick="uploadLic()">⬆ 上传并激活</button>
      <button class="btn btn-outline btn-sm" onclick="reloadLicense()">🔄 重新加载</button>
    </div>
    <div id="lic-upload-msg" style="margin-top:8px;font-size:12px"></div>
  </div>

  <!-- 配置公钥 -->
  <div class="card" style="padding:16px;margin-top:12px">
    <h3 style="font-size:13px;font-weight:600;margin-bottom:8px;color:var(--text)">🔑 配置产品公钥</h3>
    <p style="font-size:12px;color:var(--text3);margin-bottom:10px">
      首次部署或更换密钥对时，将厂商提供的公钥（PEM格式）粘贴到此处。
      公钥用于验证 License 签名，不涉及私密数据。
    </p>
    <textarea id="pub-key-input" class="inp" rows="6"
      style="font-family:var(--font-mono);font-size:11px;resize:vertical"
      placeholder="-----BEGIN PUBLIC KEY-----&#10;MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A...&#10;-----END PUBLIC KEY-----"></textarea>
    <div style="margin-top:8px;display:flex;gap:8px">
      <button class="btn btn-primary btn-sm" onclick="savePublicKey()">💾 保存公钥</button>
      <button class="btn btn-outline btn-sm" onclick="loadCurrentKey()">📋 查看当前公钥</button>
    </div>
    <div id="key-msg" style="margin-top:8px;font-size:12px"></div>
  </div>
</div>
<script>
async function reloadLicense(){{
  const r=await fetch('/api/license/reload',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{csrf_token:'{csrf}'}})}});
  const d=await r.json();
  if(d.success){{toast('License 已重新加载：'+d.edition,'ok',5000);setTimeout(()=>location.reload(),1500);}}
  else toast('加载失败：'+d.error,'err',6000);
}}

async function uploadLic(){{
  const file = document.getElementById('lic-file').files[0];
  if(!file){{ toast('请先选择 .lic 文件','err'); return; }}
  const text = await file.text();
  const msg  = document.getElementById('lic-upload-msg');
  msg.innerHTML = '上传中...';
  const r = await fetch('/api/license/upload-lic', {{
    method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify({{content: text, csrf_token: window._csrf || '{csrf}'}})
  }});
  const d = await r.json();
  if(d.success){{
    msg.style.color='var(--success)';
    msg.innerHTML = '✅ License 已上传并激活：'+d.edition+'，到期：'+d.expire;
    setTimeout(()=>location.reload(), 2000);
  }} else {{
    msg.style.color='var(--danger)';
    msg.innerHTML = '❌ ' + d.error;
  }}
}}

async function savePublicKey(){{
  const pem = document.getElementById('pub-key-input').value.trim();
  const msg = document.getElementById('key-msg');
  if(!pem || !pem.includes('BEGIN PUBLIC KEY')){{
    msg.style.color='var(--danger)';
    msg.innerHTML='❌ 格式错误，请粘贴完整的 PEM 公钥（含 BEGIN/END 行）';
    return;
  }}
  msg.innerHTML = '保存中...';
  const r = await fetch('/api/license/set-pubkey', {{
    method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body: JSON.stringify({{pem: pem, csrf_token: window._csrf || '{csrf}'}})
  }});
  const d = await r.json();
  if(d.success){{
    msg.style.color='var(--success)';
    msg.innerHTML = '✅ 公钥已保存，正在重新验证 License...';
    setTimeout(()=>location.reload(), 2000);
  }} else {{
    msg.style.color='var(--danger)';
    msg.innerHTML = '❌ ' + d.error;
  }}
}}

async function loadCurrentKey(){{
  const r = await fetch('/api/license/get-pubkey');
  const d = await r.json();
  if(d.pem){{
    document.getElementById('pub-key-input').value = d.pem;
  }} else {{
    toast('未配置公钥（使用内嵌默认值）','info');
  }}
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "软件授权", "license", **ctx())


@bp.route("/api/license/status")
@login_required
@role_required(ROLE_SUPER)
def api_license_status():
    status = get_status()
    # 不返回功能集合给前端（安全）
    status.pop('features', None)
    return jsonify(status)


@bp.route("/api/license/reload", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_license_reload():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    try:
        from license.checker import load_license
        payload = load_license(force=True)
        audit_write(session["uid"], session["uname"], "RELOAD_LICENSE",
                    f"版本={payload.get('_edition')}", request.remote_addr,
                    "WARN", AuditCategory.ADMIN)
        return jsonify({"success": True, "edition": payload.get("_display", "")})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# ── 双因素认证 ────────────────────────────────────────
@bp.route("/profile/2fa", methods=["GET", "POST"])
@login_required
def profile_2fa():
    if not has_feature("two_factor"):
        return "<div style='padding:24px'><h2>当前版本不支持双因素认证</h2><p>请升级到政务版</p></div>", 403

    uid    = session["uid"]
    uname  = session["uname"]
    status = get_2fa_status(uid)
    csrf   = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf
    msg = ""

    if request.method == "POST":
        action = request.form.get("action", "")
        if not csrf_ok(request.form.get("csrf_token", "")):
            msg = "CSRF 校验失败"
        elif action == "enable":
            secret = request.form.get("secret", "")
            code   = request.form.get("code", "")
            if not verify_totp(secret, code):
                msg = "验证码错误，请重试"
            else:
                enable_2fa(uid, secret)
                audit_write(uid, uname, "ENABLE_2FA", "", request.remote_addr,
                            "WARN", AuditCategory.SECURITY)
                msg = "✅ 双因素认证已启用"
                status = get_2fa_status(uid)
        elif action == "disable":
            code = request.form.get("code", "")
            if not verify_totp(status.get("secret", ""), code):
                msg = "验证码错误，请确认后重试"
            else:
                disable_2fa(uid)
                audit_write(uid, uname, "DISABLE_2FA", "", request.remote_addr,
                            "WARN", AuditCategory.SECURITY)
                msg = "✅ 双因素认证已关闭"
                status = get_2fa_status(uid)

    # 生成新 secret 用于绑定
    new_secret = generate_secret()
    qr_b64     = ""
    if not status["enabled"]:
        qr_bytes = generate_qrcode(new_secret, uname)
        qr_b64   = base64.b64encode(qr_bytes).decode()

    msg_html = f'<div class="toast {"ok" if msg.startswith("✅") else "err"}" style="margin-bottom:12px">{msg}</div>' if msg else ""
    enabled  = status["enabled"]

    if enabled:
        body = f"""
        {msg_html}
        <div class="card" style="padding:24px">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
            <span style="font-size:32px">✅</span>
            <div>
              <div style="font-weight:600;font-size:14px">双因素认证已启用</div>
              <div style="font-size:12px;color:var(--text3)">每次登录需输入 Authenticator 应用中的验证码</div>
            </div>
          </div>
          <form method="POST" action="/profile/2fa">
            <input type="hidden" name="csrf_token" value="{csrf}">
            <input type="hidden" name="action" value="disable">
            <div class="fg"><label>输入验证码以关闭 2FA</label>
              <input class="inp" name="code" maxlength="6" placeholder="6位验证码" style="max-width:180px"></div>
            <button type="submit" class="btn btn-danger">关闭双因素认证</button>
          </form>
        </div>"""
    else:
        body = f"""
        {msg_html}
        <div class="card" style="padding:24px">
          <h3 style="font-size:14px;font-weight:600;margin-bottom:12px">启用双因素认证</h3>
          <ol style="font-size:13px;color:var(--text2);line-height:2;padding-left:18px">
            <li>安装 <strong>Google Authenticator</strong> 或 <strong>微软 Authenticator</strong></li>
            <li>扫描下方二维码，或手动输入密钥</li>
            <li>输入应用中显示的 6 位验证码确认绑定</li>
          </ol>
          <div style="margin:16px 0;text-align:center">
            <img src="data:image/png;base64,{qr_b64}" style="width:200px;height:200px;border:1px solid var(--border);border-radius:8px">
            <div style="font-size:11px;color:var(--text3);margin-top:8px">
              手动密钥：<code style="background:var(--gray50);padding:2px 6px;border-radius:3px">{new_secret}</code>
            </div>
          </div>
          <form method="POST" action="/profile/2fa">
            <input type="hidden" name="csrf_token" value="{csrf}">
            <input type="hidden" name="action" value="enable">
            <input type="hidden" name="secret" value="{new_secret}">
            <div class="fg"><label>输入 Authenticator 中的 6 位验证码</label>
              <input class="inp" name="code" maxlength="6" placeholder="123456" style="max-width:180px" autofocus></div>
            <button type="submit" class="btn btn-primary">确认启用</button>
          </form>
        </div>"""

    content = f"""
<div class="view show" style="max-width:560px">
  <div class="page-title"><span class="pt-icon">🔑</span>双因素认证</div>
  {body}
</div>"""
    from routes._ctx import ctx
    return layout(content, "双因素认证", "profile", **ctx())


# ── 等保合规仪表盘 ────────────────────────────────────
@bp.route("/admin/compliance")
@login_required
@role_required(ROLE_SUPER)
def admin_compliance():
    # 各项合规检查
    checks = []

    # 1. License
    ls = get_status()
    checks.append({
        "item": "软件授权（License）",
        "status": "pass" if ls["valid"] else "fail",
        "detail": f"{ls.get('edition', '')} | 到期：{ls.get('expire', '永久')}",
    })

    # 2. 密码策略
    try:
        with get_conn() as conn:
            weak_pw_users = conn.execute(
                "SELECT COUNT(*) FROM users WHERE is_active=1 AND LENGTH(password)<60"
            ).fetchone()[0]
        checks.append({
            "item": "密码强度策略",
            "status": "pass",
            "detail": "已启用：8位+大小写+数字+特殊字符",
        })
    except Exception:
        checks.append({"item": "密码强度策略", "status": "pass", "detail": "已配置"})

    # 3. 登录失败锁定
    with get_conn() as conn:
        has_lock = conn.execute(
            "SELECT COUNT(*) FROM users WHERE fail_count>0"
        ).fetchone()[0]
    checks.append({
        "item": "登录失败锁定",
        "status": "pass",
        "detail": f"已启用，当前有 {has_lock} 个账号有登录失败记录",
    })

    # 4. 会话超时
    try:
        import config
        timeout_min = config.SESSION_TIMEOUT // 60
        checks.append({
            "item": "会话超时控制",
            "status": "pass" if timeout_min <= 60 else "warn",
            "detail": f"超时时间：{timeout_min} 分钟（等保建议 ≤ 60 分钟）",
        })
    except Exception:
        checks.append({"item": "会话超时控制", "status": "warn", "detail": "请检查 config.py"})

    # 5. 审计日志
    try:
        with get_conn() as conn:
            log_count = conn.execute("SELECT COUNT(*) FROM audit_log_secure").fetchone()[0]
        checks.append({
            "item": "防篡改审计日志",
            "status": "pass" if log_count > 0 else "warn",
            "detail": f"已记录 {log_count} 条（哈希链保护）",
        })
    except Exception:
        checks.append({"item": "防篡改审计日志", "status": "warn", "detail": "安全审计表未初始化"})

    # 6. 双因素认证
    if has_feature("two_factor"):
        try:
            with get_conn() as conn:
                enabled_count = conn.execute(
                    "SELECT COUNT(*) FROM users WHERE totp_enabled=1 AND is_active=1"
                ).fetchone()[0]
                total = conn.execute(
                    "SELECT COUNT(*) FROM users WHERE is_active=1"
                ).fetchone()[0]
            checks.append({
                "item": "双因素认证（2FA）",
                "status": "pass" if enabled_count > 0 else "warn",
                "detail": f"{enabled_count}/{total} 个用户已启用",
            })
        except Exception:
            checks.append({"item": "双因素认证（2FA）", "status": "warn", "detail": "需迁移数据库"})
    else:
        checks.append({"item": "双因素认证（2FA）", "status": "info",
                        "detail": "当前版本未包含，政务版支持"})

    # 7. 上传文件白名单
    try:
        import config
        wl_count = len(config.UPLOAD_WHITELIST)
        checks.append({
            "item": "文件上传类型限制",
            "status": "pass",
            "detail": f"白名单模式，允许 {wl_count} 种文件格式",
        })
    except Exception:
        checks.append({"item": "文件上传类型限制", "status": "warn", "detail": "请检查 config.py"})

    # 8. HTTPS
    checks.append({
        "item": "HTTPS 传输加密",
        "status": "warn",
        "detail": "建议在生产环境前置 Nginx/IIS 配置 SSL 证书",
    })

    # 9. 数据备份
    checks.append({
        "item": "数据定期备份",
        "status": "info",
        "detail": "请配置操作系统级定时备份（cron/Windows计划任务）",
    })

    # 渲染
    status_icon  = {"pass": "✅", "warn": "⚠️", "fail": "❌", "info": "ℹ️"}
    status_cls   = {"pass": "badge-blue", "warn": "badge-yellow", "fail": "badge-red", "info": "badge-gray"}
    status_label = {"pass": "符合", "warn": "需关注", "fail": "不符合", "info": "建议"}
    pass_count = sum(1 for c in checks if c["status"] == "pass")
    warn_count = sum(1 for c in checks if c["status"] == "warn")
    fail_count = sum(1 for c in checks if c["status"] == "fail")

    rows = ""
    for c in checks:
        s = c["status"]
        rows += f"""<tr>
          <td>{status_icon.get(s, '')} {c['item']}</td>
          <td><span class="badge {status_cls.get(s, '')}">{status_label.get(s, s)}</span></td>
          <td style="font-size:12px;color:var(--text2)">{c['detail']}</td>
        </tr>"""

    content = f"""
<div class="view show">
  <div class="page-title"><span class="pt-icon">🛡</span>等保合规检查（GB/T 22239-2019 三级）</div>
  <div class="stats">
    <div class="stat"><div class="stat-icon green">✅</div>
      <div><div class="stat-val">{pass_count}</div><div class="stat-lbl">符合项</div></div></div>
    <div class="stat"><div class="stat-icon yellow">⚠️</div>
      <div><div class="stat-val">{warn_count}</div><div class="stat-lbl">需关注</div></div></div>
    <div class="stat"><div class="stat-icon red">❌</div>
      <div><div class="stat-val">{fail_count}</div><div class="stat-lbl">不符合</div></div></div>
    <div class="stat"><div class="stat-icon blue">📋</div>
      <div><div class="stat-val">{len(checks)}</div><div class="stat-lbl">检查项</div></div></div>
  </div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>检查项详情</h2>
      <a href="/admin/audit-secure" class="btn btn-outline btn-sm">查看审计日志</a></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th style="width:30%">检查项</th><th style="width:12%">状态</th><th>说明</th>
      </tr></thead><tbody>{rows}</tbody></table>
    </div>
  </div>
</div>"""
    from routes._ctx import ctx
    return layout(content, "等保合规", "compliance", **ctx())


# ── 防篡改审计日志 ────────────────────────────────────
@bp.route("/admin/audit-secure")
@login_required
@role_required(ROLE_SUPER)
def admin_audit_secure():
    cat    = request.args.get("cat", "")
    level  = request.args.get("level", "")
    q      = request.args.get("q", "")
    logs   = query_audit(limit=300, category=cat or None,
                         level=level or None, action_like=q or None)

    level_cls = {"INFO": "badge-blue", "WARN": "badge-yellow", "ERROR": "badge-red"}
    cat_icon  = {
        "AUTH": "🔑", "FILE": "📄", "SHARE": "🔗",
        "ADMIN": "⚙", "PERM": "🔒", "SYSTEM": "🖥",
        "SECURITY": "🛡",
    }
    rows = ""
    for r in logs:
        chain_tip = f'title="chain: {r.get("chain_hash","")[:16]}..."' if r.get("chain_hash") else ""
        rows += f"""<tr {chain_tip}>
          <td class="fdate" style="white-space:nowrap">{r.get('ts','')}</td>
          <td>{cat_icon.get(r.get('category',''),'📋')} {r.get('username','—')}</td>
          <td><span class="badge {level_cls.get(r.get('level','INFO'),'badge-gray')}">{r.get('level','INFO')}</span></td>
          <td style="font-family:var(--font-mono);font-size:12px">{r.get('action','')}</td>
          <td style="font-size:12px;color:var(--text2)">{r.get('detail','')}</td>
          <td class="fdate">{r.get('result','')}</td>
          <td class="fdate">{r.get('ip','')}</td>
        </tr>"""
    if not rows:
        rows = '<tr><td colspan="7"><div class="empty-state"><div class="es-icon">📋</div><p>暂无日志</p></div></td></tr>'

    cat_opts = [("", "全部"), ("AUTH", "🔑 认证"), ("FILE", "📄 文件"),
                ("SHARE", "🔗 分享"), ("ADMIN", "⚙ 管理"), ("SECURITY", "🛡 安全")]
    lvl_opts = [("", "全部级别"), ("INFO", "INFO"), ("WARN", "WARN"), ("ERROR", "ERROR")]

    def _opt(val, label, sel):
        return f'<option value="{val}" {"selected" if sel==val else ""}>{label}</option>'

    cat_sel = "".join(_opt(v, l, cat) for v, l in cat_opts)
    lvl_sel = "".join(_opt(v, l, level) for v, l in lvl_opts)

    csrf = session.get("csrf_token", generate_csrf_token())
    session["csrf_token"] = csrf

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div class="page-title"><span class="pt-icon">🔒</span>防篡改审计日志</div>
    <button class="btn btn-outline btn-sm" onclick="verifyChain()">🔍 验证日志完整性</button>
  </div>
  <div class="card" style="padding:12px 16px;flex-shrink:0">
    <form method="GET" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <select class="inp inp-sel" name="cat" style="width:auto">{cat_sel}</select>
      <select class="inp inp-sel" name="level" style="width:auto">{lvl_sel}</select>
      <input class="inp" name="q" value="{q}" placeholder="搜索操作类型..." style="max-width:200px">
      <button type="submit" class="btn btn-primary btn-sm">筛选</button>
    </form>
  </div>
  <div id="verify-result"></div>
  <div class="card" style="flex:1;overflow:hidden;display:flex;flex-direction:column">
    <div class="card-hdr"><h2>操作记录（哈希链保护）</h2>
      <span class="badge badge-gray">{len(logs)} 条</span></div>
    <div class="card-body">
      <table class="tbl"><thead><tr>
        <th style="width:140px">时间</th><th>用户</th><th>级别</th>
        <th>操作</th><th>详情</th><th>结果</th><th>IP</th>
      </tr></thead><tbody>{rows}</tbody></table>
    </div>
  </div>
</div>
<script>
async function verifyChain(){{
  const r=await fetch('/api/audit/verify',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{csrf_token:'{csrf}'}})}});
  const d=await r.json();
  const el=document.getElementById('verify-result');
  if(d.ok){{
    el.innerHTML='<div class="toast ok">✅ 日志完整性验证通过，共 '+d.total+' 条记录完整无篡改</div>';
  }} else {{
    el.innerHTML='<div class="toast err">❌ 日志完整性验证失败：'+d.message+'</div>';
  }}
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, "防篡改审计日志", "audit", **ctx())


@bp.route("/api/audit/verify", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_audit_verify():
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403
    result = verify_chain()
    audit_write(session["uid"], session["uname"], "VERIFY_AUDIT_CHAIN",
                result["message"], request.remote_addr, "INFO", AuditCategory.SECURITY)
    return jsonify(result)


# ── License 文件上传 API ──────────────────────────────────
@bp.route("/api/license/upload-lic", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_upload_lic():
    """前端上传 license.lic 内容，直接写入程序目录并重新验证"""
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    content = data.get("content", "").strip()
    if not content:
        return jsonify({"success": False, "error": "内容为空"})

    # 先验证签名是否有效
    from license.crypto import verify_license
    ok, payload, err = verify_license(content)
    if not ok:
        return jsonify({"success": False, "error": f"License 无效：{err}"})

    # 校验到期时间
    expire = payload.get("expire", "")
    if not expire:
        return jsonify({"success": False, "error": "License 必须包含到期时间，不接受永久授权"})

    from datetime import datetime
    try:
        exp_dt = datetime.strptime(expire, "%Y-%m-%d")
        if datetime.now() > exp_dt:
            return jsonify({"success": False, "error": f"License 已过期（{expire}）"})
    except ValueError:
        return jsonify({"success": False, "error": "到期时间格式错误"})

    # 写入文件
    import config as _cfg
    lic_path = os.path.join(os.path.dirname(os.path.abspath(_cfg.__file__)), "license.lic")
    try:
        with open(lic_path, "w", encoding="utf-8") as f:
            f.write(content)
    except Exception as e:
        return jsonify({"success": False, "error": f"写入失败：{e}"})

    # 重新加载
    try:
        from license.checker import load_license
        result = load_license(force=True)
        audit_write(session["uid"], session["uname"], "UPLOAD_LICENSE",
                    f"edition={result.get('_edition')} expire={expire}",
                    request.remote_addr, "WARN", AuditCategory.ADMIN)
        return jsonify({
            "success": True,
            "edition": result.get("_display", ""),
            "expire":  expire,
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})


# ── 公钥配置 API ──────────────────────────────────────────
@bp.route("/api/license/set-pubkey", methods=["POST"])
@login_required
@role_required(ROLE_SUPER)
def api_set_pubkey():
    """保存公钥到 license/public_key.pem，替换内嵌占位符"""
    data = request.get_json() or {}
    if not csrf_ok(data.get("csrf_token", "")):
        return jsonify({"success": False, "error": "CSRF"}), 403

    pem = data.get("pem", "").strip()
    if not pem or "BEGIN PUBLIC KEY" not in pem:
        return jsonify({"success": False, "error": "格式错误，需要完整的 PEM 公钥"})

    # 验证公钥格式
    try:
        from cryptography.hazmat.primitives.serialization import load_pem_public_key
        from cryptography.hazmat.backends import default_backend
        load_pem_public_key(pem.encode(), backend=default_backend())
    except Exception as e:
        return jsonify({"success": False, "error": f"公钥格式无效：{e}"})

    # 保存到文件（优先从文件读，比代码内嵌更灵活）
    import config as _cfg
    key_path = os.path.join(os.path.dirname(os.path.abspath(_cfg.__file__)),
                            "license", "public_key.pem")
    try:
        with open(key_path, "w", encoding="utf-8") as f:
            f.write(pem)
    except Exception as e:
        return jsonify({"success": False, "error": f"保存失败：{e}"})

    # 同时更新 crypto.py 中的内嵌公钥
    crypto_path = os.path.join(os.path.dirname(os.path.abspath(_cfg.__file__)),
                               "license", "crypto.py")
    try:
        crypto_src = open(crypto_path, encoding="utf-8").read()
        marker_start = '_EMBEDDED_PUBLIC_KEY_PEM = b"""'
        marker_end   = '"""'
        idx_s = crypto_src.find(marker_start)
        if idx_s >= 0:
            idx_e = crypto_src.find(marker_end, idx_s + len(marker_start))
            if idx_e >= 0:
                new_src = (crypto_src[:idx_s] +
                           marker_start + pem + marker_end +
                           crypto_src[idx_e + len(marker_end):])
                with open(crypto_path, "w", encoding="utf-8") as f:
                    f.write(new_src)
    except Exception:
        pass

    audit_write(session["uid"], session["uname"], "SET_PUBLIC_KEY",
                "更新产品公钥", request.remote_addr, "WARN", AuditCategory.ADMIN)

    # 重新加载 License（用新公钥验证）
    try:
        from license.checker import load_license
        load_license(force=True)
    except Exception:
        pass

    return jsonify({"success": True})


@bp.route("/api/license/get-pubkey")
@login_required
@role_required(ROLE_SUPER)
def api_get_pubkey():
    """获取当前已配置的公钥"""
    import config as _cfg
    key_path = os.path.join(os.path.dirname(os.path.abspath(_cfg.__file__)),
                            "license", "public_key.pem")
    if os.path.exists(key_path):
        pem = open(key_path, encoding="utf-8").read().strip()
        return jsonify({"pem": pem})
    return jsonify({"pem": None})
