# -*- coding: utf-8 -*-
"""
routes/license_console.py — License 管理控制台

功能：
  - License 实时状态监控（版本/到期/用户数/功能）
  - 在线重新加载 License
  - 用户数实时统计（对比 License 上限）
  - 功能开关状态总览
  - 在线激活记录
  - 机器指纹展示（方便提供给厂商签发）
"""
import time
from datetime import datetime
from flask import Blueprint, session, request, jsonify

from auth import login_required, role_required, generate_csrf_token, csrf_ok, ROLE_SUPER
from license.checker import get_status, load_license, EDITION_FEATURES
from dao.db import get_conn
from compliance.audit_log import write as audit_write, AuditCategory
from templates import layout

bp = Blueprint('license_console', __name__)

# 功能中文名映射
FEATURE_NAMES = {
    'browse':          '文件浏览',
    'upload':          '文件上传',
    'download':        '文件下载',
    'basic_share':     '基础分享',
    'webdav':          'WebDAV 接入',
    'advanced_share':  '高级分享（组织/用户）',
    'audit':           '审计日志',
    'versions':        '版本历史',
    'trash':           '回收站',
    'public_links':    '公开外链',
    'file_lock':       '文件锁定',
    'search':          '全文搜索',
    'org_tree':        '三级组织架构',
    'watermark':       '文件水印',
    'approval':        '导出审批流',
    'label':           '密级标签',
    'two_factor':      '双因素认证',
    'ip_binding':      'IP 白名单',
    'compliance_report': '等保合规报告',
}

EDITION_BADGE = {
    'BASIC': ('badge-gray',   '基础版'),
    'PRO':   ('badge-blue',   '专业版'),
    'GOV':   ('badge-super',  '政务版'),
}


@bp.route('/admin/license-console')
@login_required
@role_required(ROLE_SUPER)
def console():
    status = get_status()
    csrf   = session.get('csrf_token', generate_csrf_token())
    session['csrf_token'] = csrf

    # 实时用户数
    with get_conn() as conn:
        active_users  = conn.execute("SELECT COUNT(*) FROM users WHERE is_active=1").fetchone()[0]
        total_users   = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        online_now    = conn.execute(
            "SELECT COUNT(DISTINCT user_id) FROM active_sessions WHERE is_active=1"
        ).fetchone()[0]
        today_logins  = conn.execute("""
            SELECT COUNT(*) FROM audit_log WHERE action='LOGIN'
            AND ts > NOW() - INTERVAL '24 hours'
        """).fetchone()[0]

    max_users  = status.get('max_users', 0)
    user_pct   = min(100, round(active_users / max_users * 100)) if max_users else 0
    user_cls   = 'danger' if user_pct > 85 else 'warn' if user_pct > 60 else ''

    # License 状态横幅
    if not status['valid']:
        banner = f'<div class="toast err" style="margin-bottom:0">❌ License 无效：{status.get("error","")}</div>'
    elif status.get('days_left') is not None and status['days_left'] <= 30:
        banner = f'<div class="toast warn" style="margin-bottom:0">⚠ License 将在 {status["days_left"]} 天后到期！请尽快续费。</div>'
    else:
        banner = '<div class="toast ok" style="margin-bottom:0">✅ License 有效，运行正常</div>'

    edition_key = status.get('edition_key', 'BASIC')
    badge_cls, badge_txt = EDITION_BADGE.get(edition_key, ('badge-gray', '未知'))

    # 功能开关网格
    licensed_features = set(status.get('features', []))
    all_features_html = ''
    for feat_key, feat_name in FEATURE_NAMES.items():
        enabled = feat_key in licensed_features
        icon    = '✅' if enabled else '🔒'
        cls     = 'feat-on' if enabled else 'feat-off'
        all_features_html += f"""
        <div class="feat-card {cls}">
          <span class="feat-icon">{icon}</span>
          <span class="feat-name">{feat_name}</span>
        </div>"""

    # 机器指纹
    fp_html = ''
    try:
        from license.machine import get_fingerprint
        fp = get_fingerprint()
        fp_html = f"""
        <div class="card mb-3">
          <div class="card-hdr">🖥 当前机器指纹（提供给厂商用于签发 License）</div>
          <div class="p-4">
            <div style="display:grid;grid-template-columns:120px 1fr;gap:6px;font-size:13px">
              <span style="color:var(--text3)">机器码</span>
              <code style="background:var(--bg);padding:2px 8px;border-radius:4px">{fp['machine_id']}</code>
              <span style="color:var(--text3)">MAC 地址</span>
              <code style="background:var(--bg);padding:2px 8px;border-radius:4px">{', '.join(fp['mac_addresses']) or '无'}</code>
              <span style="color:var(--text3)">CPU 序列号</span>
              <code style="background:var(--bg);padding:2px 8px;border-radius:4px">{fp['cpu_serial']}</code>
              <span style="color:var(--text3)">服务器 IP</span>
              <code style="background:var(--bg);padding:2px 8px;border-radius:4px">{', '.join(fp['server_ips']) or '无'}</code>
              <span style="color:var(--text3)">主机名</span>
              <code style="background:var(--bg);padding:2px 8px;border-radius:4px">{fp['hostname']}</code>
            </div>
            <button class="btn btn-outline btn-sm mt-2" onclick="copyFingerprint()">📋 复制机器指纹</button>
          </div>
        </div>"""
    except Exception as e:
        fp_html = f'<div class="toast err">获取机器指纹失败：{e}</div>'

    # 激活记录
    activation_cache = 0
    try:
        from license.checker import _read_activation_cache
        ts = _read_activation_cache()
        if ts > 0:
            activation_cache = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M')
    except Exception:
        pass

    content = f"""
<div class="view show">
  <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
    <div class="page-title"><span class="pt-icon">🔑</span>License 管理控制台</div>
    <button class="btn btn-outline btn-sm" onclick="reloadLicense()">🔄 重新加载 License</button>
  </div>

  {banner}

  <!-- 统计卡片 -->
  <div class="stats" style="margin-top:12px">
    <div class="stat">
      <div class="stat-icon {'green' if status['valid'] else 'red'}">📋</div>
      <div>
        <div class="stat-val">
          <span class="badge {badge_cls}">{badge_txt}</span>
        </div>
        <div class="stat-lbl">授权版本</div>
      </div>
    </div>
    <div class="stat">
      <div class="stat-icon blue">👥</div>
      <div>
        <div class="stat-val">{active_users}<span style="font-size:13px;color:var(--text3)"> / {max_users}</span></div>
        <div class="stat-lbl">活跃用户 / 授权上限</div>
      </div>
    </div>
    <div class="stat">
      <div class="stat-icon green">🟢</div>
      <div>
        <div class="stat-val">{online_now}</div>
        <div class="stat-lbl">当前在线用户</div>
      </div>
    </div>
    <div class="stat">
      <div class="stat-icon yellow">📊</div>
      <div>
        <div class="stat-val">{today_logins}</div>
        <div class="stat-lbl">今日登录次数</div>
      </div>
    </div>
  </div>

  <!-- 用户数配额 -->
  <div class="card mb-3">
    <div class="card-hdr">👥 用户数配额使用情况</div>
    <div class="p-4">
      <div class="flex justify-between mb-2">
        <span style="font-size:13px">已使用 <strong>{active_users}</strong> 个活跃用户（共 {total_users} 个账号）</span>
        <span style="font-size:13px;color:var(--text3)">上限：{max_users} 用户</span>
      </div>
      <div class="quota-bar" style="height:8px">
        <div class="quota-fill {user_cls}" style="width:{user_pct}%;height:8px"></div>
      </div>
      <div style="font-size:11px;color:var(--text3);margin-top:6px">
        {'⚠ 已接近上限，请联系厂商扩容 License' if user_pct > 85 else
         '⚠ 使用量超过 60%，建议提前规划扩容' if user_pct > 60 else
         '✓ 用户数在正常范围内'}
      </div>
    </div>
  </div>

  <!-- License 详情 -->
  <div class="card mb-3">
    <div class="card-hdr">📋 授权详情</div>
    <div class="p-4">
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
        <div><div style="font-size:11px;color:var(--text3)">授权客户</div>
          <div style="font-weight:600;margin-top:3px">{status.get('customer','—')}</div></div>
        <div><div style="font-size:11px;color:var(--text3)">License ID</div>
          <div style="font-family:var(--font-mono);font-size:12px;margin-top:3px">{status.get('license_id','—')}</div></div>
        <div><div style="font-size:11px;color:var(--text3)">到期日期</div>
          <div style="font-weight:600;margin-top:3px;color:{'var(--danger)' if (status.get('days_left') or 9999) <= 30 else 'var(--text)'}">{status.get('expire','永久有效')}</div></div>
        <div><div style="font-size:11px;color:var(--text3)">上次在线激活</div>
          <div style="font-size:12px;margin-top:3px">{activation_cache or '从未激活（离线授权）'}</div></div>
      </div>
    </div>
  </div>

  <!-- 功能开关 -->
  <div class="card mb-3">
    <div class="card-hdr">🔧 功能授权状态</div>
    <div class="p-4">
      <div class="feat-grid">{all_features_html}</div>
    </div>
  </div>

  {fp_html}
</div>

<style>
.feat-grid{{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px}}
.feat-card{{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:var(--radius);
  border:1px solid var(--border);font-size:12.5px}}
.feat-on{{background:var(--success-lt);border-color:var(--success);color:var(--success)}}
.feat-off{{background:var(--bg);color:var(--text3)}}
.feat-icon{{font-size:14px;flex-shrink:0}}
.feat-name{{font-weight:500}}
</style>

<script>
async function reloadLicense(){{
  const r=await fetch('/api/license/reload',{{method:'POST',
    headers:{{'Content-Type':'application/json'}},
    body:JSON.stringify({{csrf_token:window._csrf}})}});
  const d=await r.json();
  if(d.success){{toast('License 已重新加载：'+d.edition,'ok',5000);setTimeout(()=>location.reload(),1500);}}
  else toast('加载失败：'+d.error,'err',6000);
}}

function copyFingerprint(){{
  const rows = document.querySelectorAll('.feat-grid ~ * code, code');
  const fp = Array.from(document.querySelectorAll('code')).map(e=>e.textContent).join('\\n');
  navigator.clipboard?.writeText(fp).then(()=>toast('机器指纹已复制','ok'));
}}
</script>"""
    from routes._ctx import ctx
    return layout(content, 'License 控制台', 'license', **ctx())
