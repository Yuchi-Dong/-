# -*- coding: utf-8 -*-
"""
SecFTP Pro — Windows 服务包装器

用法（以管理员身份运行 cmd）：

  安装服务:   python win_service.py install
  启动服务:   python win_service.py start
              —— 或 ——
              net start SecFTPWeb
  停止服务:   python win_service.py stop
  重启服务:   python win_service.py restart
  卸载服务:   python win_service.py remove
  调试模式:   python win_service.py debug   （前台运行，Ctrl+C 停止）

依赖:
  pip install pywin32
  安装后还需运行一次: python Scripts/pywin32_postinstall.py -install
"""
import sys
import os
import threading
import logging

# ── 确保 import 路径正确 ────────────────────────────
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)
os.chdir(_HERE)

# ── 日志（写入文件，Windows 服务没有控制台）─────────
_LOG_PATH = os.path.join(_HERE, "secftp_service.log")
logging.basicConfig(
    filename=_LOG_PATH,
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("SecFTPWeb")


def _run_server():
    """在子线程中启动 waitress，主线程保持 Windows 服务控制循环。"""
    try:
        log.info("正在导入应用...")
        from waitress import serve
        from main import app
        import config

        log.info(f"SecFTP Web 服务启动 → http://{config.WEB_HOST}:{config.WEB_PORT}")
        log.info(f"文件根目录: {config.FILE_ROOT}")
        serve(app, host=config.WEB_HOST, port=config.WEB_PORT, threads=8)
    except Exception:
        log.exception("waitress 启动异常")


# ────────────────────────────────────────────────────
# Windows 服务主体
# ────────────────────────────────────────────────────
try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager

    class SecFTPWebService(win32serviceutil.ServiceFramework):
        _svc_name_        = "SecFTPWeb"
        _svc_display_name_= "锡林郭勒云盘 Web 服务"
        _svc_description_ = "SecFTP Pro — 基于 Flask+waitress 的内网文件共享平台"

        # ── 告知 SCM：此服务不支持暂停/继续 ──────────
        # 只接受 STOP 控制，彻底消除 SERVICE_PAUSED 问题
        _svc_controls_accepted_ = win32service.SERVICE_ACCEPT_STOP

        def __init__(self, args):
            win32serviceutil.ServiceFramework.__init__(self, args)
            # 创建一个手动重置事件，stop() 时 set()，主循环 wait() 退出
            self._stop_event = win32event.CreateEvent(None, True, False, None)
            self._server_thread = None

        def SvcStop(self):
            log.info("收到 STOP 控制，正在停止服务...")
            self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
            win32event.SetEvent(self._stop_event)

        def SvcDoRun(self):
            # 向 SCM 报告"正在启动"
            self.ReportServiceStatus(win32service.SERVICE_START_PENDING)

            servicemanager.LogMsg(
                servicemanager.EVENTLOG_INFORMATION_TYPE,
                servicemanager.PYS_SERVICE_STARTED,
                (self._svc_name_, "")
            )

            # 在后台线程启动 waitress（waitress.serve 是阻塞调用）
            self._server_thread = threading.Thread(
                target=_run_server, daemon=True, name="waitress"
            )
            self._server_thread.start()

            # 报告"已运行"
            self.ReportServiceStatus(win32service.SERVICE_RUNNING)
            log.info("服务状态已上报：RUNNING")

            # 等待停止信号（无限等待，每 5 秒检查一次子线程是否意外退出）
            while True:
                rc = win32event.WaitForSingleObject(self._stop_event, 5000)
                if rc == win32event.WAIT_OBJECT_0:
                    # 收到 SetEvent，正常退出
                    break
                # 子线程意外退出 → 自动停止服务，避免僵尸
                if not self._server_thread.is_alive():
                    log.error("waitress 线程意外退出，服务将自动停止")
                    self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
                    break

            log.info("服务已停止")

    # ────────────────────────────────────────────────
    # debug 模式：直接在前台跑，方便排查问题
    # ────────────────────────────────────────────────
    def _run_debug():
        print("[DEBUG] 以前台调试模式运行，Ctrl+C 停止")
        _run_server()

    if __name__ == "__main__":
        if len(sys.argv) >= 2 and sys.argv[1].lower() == "debug":
            _run_debug()
        else:
            win32serviceutil.HandleCommandLine(SecFTPWebService)

except ImportError:
    # ────────────────────────────────────────────────
    # 没有安装 pywin32 时的降级处理：直接前台运行
    # ────────────────────────────────────────────────
    print("[WARN] 未找到 pywin32，以普通前台进程运行（不作为 Windows 服务）")
    print("[WARN] 安装方法：pip install pywin32")
    print("       安装后运行：python Scripts/pywin32_postinstall.py -install")
    if __name__ == "__main__":
        _run_server()
