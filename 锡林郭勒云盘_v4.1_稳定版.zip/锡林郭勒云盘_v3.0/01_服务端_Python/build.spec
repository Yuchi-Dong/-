# -*- mode: python ; coding: utf-8 -*-
# ============================================================
#  锡林郭勒云盘 v3.0  —  PyInstaller 打包配置
#
#  使用方法：
#    pip install pyinstaller
#    pyinstaller build.spec
#
#  输出目录：dist\SecFTP_Pro\
#  运行方式：dist\SecFTP_Pro\SecFTP_Pro.exe
# ============================================================

import sys
import os
from pathlib import Path

ROOT = os.path.dirname(os.path.abspath(SPEC))   # noqa: F821

# ── 收集所有 Python 包数据文件 ──────────────────────────
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

datas = [
    # 模板和静态资源
    (os.path.join(ROOT, 'templates.py'),    '.'),
    (os.path.join(ROOT, 'favicon.ico'),     '.'),
    # 配置文件
    (os.path.join(ROOT, 'config.py'),       '.'),
]

# psycopg2 需要额外数据文件
datas += collect_data_files('psycopg2')

# ── 隐式导入（PyInstaller 可能漏掉）─────────────────────
hiddenimports = [
    'psycopg2',
    'psycopg2.extras',
    'psycopg2.pool',
    'waitress',
    'waitress.server',
    'flask',
    'flask.templating',
    'cryptography',
    'cryptography.hazmat.backends.openssl',
    'cryptography.hazmat.primitives.asymmetric.rsa',
    'cryptography.hazmat.primitives.asymmetric.padding',
    'cryptography.hazmat.primitives.hashes',
    'cryptography.hazmat.primitives.serialization',
    'qrcode',
    'PIL',
    'mutagen',
    'rarfile',
    'py7zr',
    'pypdf',
    'docx',
    'openpyxl',
    'pptx',
]
hiddenimports += collect_submodules('waitress')
hiddenimports += collect_submodules('flask')

# ── 排除不需要的大包（减小体积）────────────────────────
excludes = [
    'tkinter', 'matplotlib', 'numpy', 'pandas', 'scipy',
    'IPython', 'jupyter', 'notebook', 'pytest',
]

# ============================================================
a = Analysis(
    [os.path.join(ROOT, 'run_web.py')],
    pathex=[ROOT],
    binaries=[],
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[os.path.join(ROOT, '_pyinstaller_hooks')],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    noarchive=False,
    optimize=2,   # 等同于 python -OO，去除 docstring
)

pyz = PYZ(a.pure)   # noqa: F821

exe = EXE(   # noqa: F821
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='SecFTP_Pro',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,    # 使用 UPX 压缩（需安装 UPX：https://upx.github.io）
    console=True,  # True = 显示控制台窗口（生产环境可改 False 隐藏）
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=os.path.join(ROOT, 'favicon.ico'),
    version='version_info.txt',   # 版本信息文件（见下方）
)

coll = COLLECT(   # noqa: F821
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='SecFTP_Pro',
)
