# -*- coding: utf-8 -*-
"""
license/machine.py — 机器指纹采集

采集维度：MAC地址 + CPU序列号 + 服务器IP
组合生成机器码（machine_id），用于 License 绑定。

在 Windows 上通过 WMI 获取真实 CPU 序列号；
在 Linux 上读取 /proc/cpuinfo 或 dmidecode；
降级方案：使用网卡 MAC 组合 hostname。
"""
import hashlib
import platform
import socket
import uuid
import subprocess
import re


def _get_mac_addresses() -> list:
    """获取所有非回环网卡的 MAC 地址（去除全零和虚拟网卡）"""
    macs = []
    try:
        import psutil
        for name, addrs in psutil.net_if_addrs().items():
            # 跳过回环和常见虚拟网卡前缀
            if name.lower() in ('lo', 'loopback'):
                continue
            if any(name.lower().startswith(p) for p in ('vmnet', 'veth', 'docker', 'br-', 'virbr')):
                continue
            for addr in addrs:
                if addr.family.name in ('AF_LINK', 'AF_PACKET') or addr.family == -1:
                    mac = addr.address.replace('-', ':').upper()
                    if mac and mac != '00:00:00:00:00:00' and len(mac) == 17:
                        macs.append(mac)
    except ImportError:
        # 降级：uuid 方式（不区分网卡）
        raw = uuid.getnode()
        mac = ':'.join(f'{(raw >> (i * 8)) & 0xFF:02X}' for i in range(5, -1, -1))
        if mac != '00:00:00:00:00:00':
            macs.append(mac)
    return sorted(set(macs))


def _get_cpu_serial() -> str:
    """获取 CPU 序列号"""
    system = platform.system()
    try:
        if system == 'Windows':
            result = subprocess.run(
                ['wmic', 'cpu', 'get', 'ProcessorId', '/value'],
                capture_output=True, text=True, timeout=10
            )
            match = re.search(r'ProcessorId=(\S+)', result.stdout)
            if match:
                return match.group(1).strip()
        elif system == 'Linux':
            # 优先用 dmidecode
            try:
                result = subprocess.run(
                    ['dmidecode', '-s', 'processor-serial-number'],
                    capture_output=True, text=True, timeout=10
                )
                serial = result.stdout.strip()
                if serial and 'Not Specified' not in serial:
                    return serial
            except Exception:
                pass
            # 降级：/proc/cpuinfo
            with open('/proc/cpuinfo', 'r') as f:
                for line in f:
                    if 'Serial' in line:
                        return line.split(':')[-1].strip()
        elif system == 'Darwin':
            result = subprocess.run(
                ['system_profiler', 'SPHardwareDataType'],
                capture_output=True, text=True, timeout=10
            )
            match = re.search(r'Serial Number.*?:\s*(\S+)', result.stdout)
            if match:
                return match.group(1).strip()
    except Exception:
        pass
    return 'UNKNOWN_CPU'


def _get_server_ips() -> list:
    """获取所有非回环 IPv4 地址"""
    ips = []
    try:
        import psutil
        for name, addrs in psutil.net_if_addrs().items():
            if name.lower() in ('lo', 'loopback'):
                continue
            for addr in addrs:
                if addr.family.name == 'AF_INET' or addr.family == 2:
                    ip = addr.address
                    if ip and not ip.startswith('127.') and not ip.startswith('169.254.'):
                        ips.append(ip)
    except ImportError:
        try:
            hostname = socket.gethostname()
            ip = socket.gethostbyname(hostname)
            if ip and not ip.startswith('127.'):
                ips.append(ip)
        except Exception:
            pass
    return sorted(set(ips))


def get_fingerprint() -> dict:
    """
    采集完整机器指纹，返回各维度原始值。
    用于生成 License 时确认绑定目标。
    """
    macs    = _get_mac_addresses()
    cpu     = _get_cpu_serial()
    ips     = _get_server_ips()
    machine_id = _make_machine_id(macs, cpu)
    return {
        'mac_addresses': macs,
        'cpu_serial':    cpu,
        'server_ips':    ips,
        'machine_id':    machine_id,
        'hostname':      platform.node(),
        'platform':      platform.system(),
    }


def _make_machine_id(macs: list, cpu: str) -> str:
    """
    机器码 = SHA-256(排序后MAC列表 + CPU序列号)
    取前16位作为人类可读的标识符
    """
    raw = '|'.join(sorted(macs)) + '||' + cpu
    return hashlib.sha256(raw.encode()).hexdigest()[:16].upper()


def get_machine_id() -> str:
    """快捷函数：只返回机器码"""
    fp = get_fingerprint()
    return fp['machine_id']


def validate_binding(license_data: dict) -> tuple:
    """
    校验当前机器是否匹配 License 中的绑定信息。
    返回 (ok: bool, reason: str)
    """
    fp    = get_fingerprint()
    binds = license_data.get('binding', {})

    # 机器码（主要绑定维度）
    licensed_mid = binds.get('machine_id', '')
    if licensed_mid and fp['machine_id'] != licensed_mid:
        return False, f"机器码不匹配（当前：{fp['machine_id']}，授权：{licensed_mid}）"

    # MAC 地址（至少一个匹配）
    licensed_macs = binds.get('mac_addresses', [])
    if licensed_macs:
        current_macs = set(fp['mac_addresses'])
        if not current_macs.intersection(set(licensed_macs)):
            return False, "MAC 地址不匹配"

    # CPU 序列号
    licensed_cpu = binds.get('cpu_serial', '')
    if licensed_cpu and licensed_cpu != 'UNKNOWN_CPU':
        if fp['cpu_serial'] != licensed_cpu:
            return False, "CPU 序列号不匹配"

    # IP（允许 IP 变化，只做警告不拒绝；严格模式可改为拒绝）
    licensed_ips = binds.get('server_ips', [])
    if licensed_ips:
        current_ips = set(fp['server_ips'])
        if not current_ips.intersection(set(licensed_ips)):
            # IP 可能因网络变化而改变，记录警告但不拒绝
            pass   # 可改为: return False, "服务器 IP 不匹配"

    return True, 'OK'
