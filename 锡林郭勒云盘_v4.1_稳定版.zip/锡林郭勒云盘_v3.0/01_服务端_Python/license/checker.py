# -*- coding: utf-8 -*-
"""
license/checker.py — License 校验引擎

校验流程：
  1. 读取 license.lic 文件
  2. 验证 RSA 签名（离线）
  3. 校验有效期、用户数、机器绑定
  4. 每30天在线激活一次（可选，有网时执行）
  5. 根据 features 字段控制功能开关

版本层级：
  BASIC     - 基础文件管理
  PRO       - 专业版（WebDAV / 分享 / 审计）
  GOV       - 政务版（三级组织 / 水印 / 审批 / 等保）
"""
import json
import os
import time
import hashlib
import logging
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from license.crypto import verify_license
from license.machine import validate_binding, get_fingerprint

log = logging.getLogger('license')

# ── 版本与功能映射 ────────────────────────────────────
EDITION_FEATURES = {
    'BASIC': {
        'max_users': 10,
        'features': ['browse', 'upload', 'download', 'basic_share'],
        'display': '基础版',
    },
    'PRO': {
        'max_users': 200,
        'features': ['browse', 'upload', 'download', 'basic_share',
                     'webdav', 'advanced_share', 'audit', 'versions',
                     'trash', 'public_links', 'file_lock', 'search'],
        'display': '专业版',
    },
    'GOV': {
        'max_users': 99999,
        'features': ['browse', 'upload', 'download', 'basic_share',
                     'webdav', 'advanced_share', 'audit', 'versions',
                     'trash', 'public_links', 'file_lock', 'search',
                     'org_tree', 'watermark', 'approval', 'label',
                     'two_factor', 'ip_binding', 'compliance_report'],
        'display': '政务版',
    },
}

# 激活缓存文件（记录上次在线激活时间）
_ACTIVATION_CACHE_FILE = Path(__file__).parent / '.activation_cache'
_ONLINE_CHECK_INTERVAL = 30 * 24 * 3600   # 30天（秒）

# 全局 License 状态（进程启动时加载一次，后续从缓存读）
_license_cache: Optional[dict] = None
_license_load_time: float = 0
_LICENSE_CACHE_TTL = 300   # 5分钟重新从文件读一次


class LicenseError(Exception):
    pass


class LicenseExpiredError(LicenseError):
    pass


class LicenseUserLimitError(LicenseError):
    pass


class LicenseFeatureError(LicenseError):
    pass


def _get_license_path() -> Path:
    """优先从环境变量读取，否则在程序目录找 license.lic"""
    env = os.environ.get('SECFTP_LICENSE_FILE')
    if env:
        return Path(env)
    return Path(__file__).parent.parent / 'license.lic'


def load_license(force: bool = False) -> dict:
    """
    加载并验证 License。有缓存则用缓存（5分钟）。
    返回解析后的 payload dict。
    抛出 LicenseError 系列异常表示校验失败。
    """
    global _license_cache, _license_load_time

    now = time.time()
    if not force and _license_cache and (now - _license_load_time) < _LICENSE_CACHE_TTL:
        return _license_cache

    lic_path = _get_license_path()
    if not lic_path.exists():
        raise LicenseError(f"未找到 License 文件：{lic_path}\n请联系厂商获取授权文件")

    try:
        license_str = lic_path.read_text(encoding='utf-8').strip()
    except Exception as e:
        raise LicenseError(f"读取 License 文件失败：{e}")

    # RSA 签名验证（优先使用外部公钥文件，允许前端配置）
    pub_key_pem = None
    try:
        import os as _os
        _key_file = _os.path.join(_os.path.dirname(_os.path.abspath(__file__)), 'public_key.pem')
        if _os.path.isfile(_key_file):
            pub_key_pem = open(_key_file, 'rb').read()
    except Exception:
        pass
    ok, payload, err = verify_license(license_str, pub_key_pem)
    if not ok:
        raise LicenseError(f"License 验证失败：{err}")

    # 有效期
    expire_str = payload.get('expire', '')
    if expire_str:
        try:
            expire_dt = datetime.strptime(expire_str, '%Y-%m-%d')
            if datetime.now() > expire_dt:
                raise LicenseExpiredError(
                    f"License 已于 {expire_str} 到期，请联系厂商续费"
                )
        except LicenseExpiredError:
            raise
        except Exception:
            raise LicenseError(f"License 有效期格式错误：{expire_str}")

    # 机器绑定校验
    bind_ok, bind_err = validate_binding(payload)
    if not bind_ok:
        raise LicenseError(f"License 机器绑定校验失败：{bind_err}")

    # 版本功能补全
    edition = payload.get('edition', 'BASIC').upper()
    if edition not in EDITION_FEATURES:
        edition = 'BASIC'
    edition_def = EDITION_FEATURES[edition]

    # License 中的 features 可以是版本默认 + 额外授权的并集
    features_in_license = set(payload.get('features', edition_def['features']))
    payload['_edition']  = edition
    payload['_features'] = features_in_license
    payload['_max_users'] = int(payload.get('max_users', edition_def['max_users']))
    payload['_display']   = edition_def['display']

    _license_cache    = payload
    _license_load_time = now

    # 触发在线激活（异步，不阻塞启动）
    _trigger_online_activation(payload)

    return payload


def _trigger_online_activation(payload: dict):
    """
    检查是否需要在线激活，若需要则在后台线程中执行。
    激活失败不影响使用（宽限期7天）。
    """
    activation_url = payload.get('activation_url', '')
    if not activation_url:
        return   # 离线授权，无需在线激活

    last_check = _read_activation_cache()
    if time.time() - last_check < _ONLINE_CHECK_INTERVAL:
        return   # 未到30天，跳过

    import threading
    t = threading.Thread(
        target=_do_online_activation,
        args=(payload, activation_url),
        daemon=True,
        name='license-activation'
    )
    t.start()


def _do_online_activation(payload: dict, url: str):
    """向激活服务器汇报并验证（后台线程）"""
    try:
        import urllib.request
        import json as _json

        fp = get_fingerprint()
        data = _json.dumps({
            'license_id':  payload.get('license_id', ''),
            'customer':    payload.get('customer', ''),
            'machine_id':  fp['machine_id'],
            'mac_addresses': fp['mac_addresses'],
            'server_ips':  fp['server_ips'],
            'hostname':    fp['hostname'],
            'product':     'SecFTP Pro',
            'version':     payload.get('_edition', 'UNKNOWN'),
            'check_time':  datetime.now().isoformat(),
        }).encode('utf-8')

        req = urllib.request.Request(
            url,
            data=data,
            headers={'Content-Type': 'application/json', 'User-Agent': 'SecFTP-Pro/3.0'},
            method='POST'
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = _json.loads(resp.read().decode())
            if result.get('valid'):
                _write_activation_cache()
                log.info("License 在线激活成功")
            else:
                log.warning(f"License 在线激活返回无效：{result.get('message', '')}")
    except Exception as e:
        log.warning(f"License 在线激活失败（宽限7天）：{e}")
        # 激活失败不立即拒绝，依赖宽限期机制


def _read_activation_cache() -> float:
    """读取上次激活时间戳，文件不存在返回0"""
    try:
        return float(_ACTIVATION_CACHE_FILE.read_text().strip())
    except Exception:
        return 0.0


def _write_activation_cache():
    """更新激活时间戳"""
    try:
        _ACTIVATION_CACHE_FILE.write_text(str(time.time()))
    except Exception:
        pass


# ── 公开 API ──────────────────────────────────────────

def get_license() -> dict:
    """
    获取当前 License 信息。
    启动时调用，License 无效则抛出异常阻止启动。
    """
    return load_license()


def has_feature(feature: str) -> bool:
    """检查当前 License 是否包含某功能"""
    try:
        payload = load_license()
        return feature in payload.get('_features', set())
    except LicenseError:
        return False


def require_feature(feature: str):
    """断言必须有某功能，否则抛出 LicenseFeatureError"""
    if not has_feature(feature):
        raise LicenseFeatureError(f"当前版本不支持功能：{feature}，请升级授权")


def check_user_limit(current_count: int):
    """检查用户数是否超限"""
    try:
        payload = load_license()
        max_u = payload.get('_max_users', 10)
        if current_count >= max_u:
            raise LicenseUserLimitError(
                f"已达用户数上限（{max_u}），请联系厂商扩容授权"
            )
    except (LicenseError, LicenseUserLimitError):
        raise
    except Exception:
        pass


def get_status() -> dict:
    """
    返回 License 状态摘要（供管理后台展示）。
    即使 License 无效也不抛出异常，返回错误状态。
    """
    try:
        payload = load_license()
        expire  = payload.get('expire', '永久')
        days_left = None
        if expire and expire != '永久':
            try:
                dt = datetime.strptime(expire, '%Y-%m-%d')
                days_left = (dt - datetime.now()).days
            except Exception:
                pass
        return {
            'valid':       True,
            'customer':    payload.get('customer', ''),
            'edition':     payload.get('_display', ''),
            'edition_key': payload.get('_edition', ''),
            'expire':      expire,
            'days_left':   days_left,
            'max_users':   payload.get('_max_users', 0),
            'features':    sorted(payload.get('_features', set())),
            'license_id':  payload.get('license_id', ''),
            'last_online_check': _read_activation_cache(),
            'error':       None,
        }
    except LicenseExpiredError as e:
        return {'valid': False, 'error': str(e), 'edition': '已过期'}
    except LicenseError as e:
        return {'valid': False, 'error': str(e), 'edition': '未授权'}
    except Exception as e:
        return {'valid': False, 'error': f"内部错误：{e}", 'edition': '未知'}


def get_edition() -> str:
    """返回版本名：BASIC / PRO / GOV"""
    try:
        return load_license().get('_edition', 'BASIC')
    except Exception:
        return 'BASIC'
