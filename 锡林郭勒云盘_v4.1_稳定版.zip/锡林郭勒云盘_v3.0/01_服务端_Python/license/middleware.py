# -*- coding: utf-8 -*-
"""
license/middleware.py — License 执行层

提供：
  1. Flask before_request 钩子：启动时校验 License
  2. feature_required 路由装饰器
  3. 用户数限制检查（在 create_user 时调用）
  4. 功能降级处理（不直接崩溃，给出友好提示）
"""
import functools
from flask import jsonify, request, session, abort, render_template_string
from license.checker import (
    get_license, get_status, has_feature, check_user_limit,
    LicenseError, LicenseExpiredError, LicenseFeatureError, LicenseUserLimitError,
    get_edition,
)

# 进程启动时的全局 License 状态（由 init_license 设置）
_license_ok = False
_license_error = ''


def init_license(app):
    """
    在 Flask app 启动时校验 License。
    License 无效时：
      - GOV/PRO 功能路由返回 403 + 错误说明
      - 不阻止基础功能（允许管理员登录处理 License）
    """
    global _license_ok, _license_error
    try:
        get_license()
        _license_ok = True
        status = get_status()
        app.logger.info(
            f"License OK | {status['customer']} | {status['edition']} | "
            f"到期：{status['expire']} | 剩余：{status.get('days_left', '永久')}天"
        )
        # 临期预警（30天内）
        dl = status.get('days_left')
        if dl is not None and dl <= 30:
            app.logger.warning(f"⚠ License 将在 {dl} 天后到期，请及时续费！")
    except LicenseExpiredError as e:
        _license_ok = False
        _license_error = str(e)
        app.logger.error(f"License 已过期：{e}")
    except LicenseError as e:
        _license_ok = False
        _license_error = str(e)
        app.logger.error(f"License 无效：{e}")

    @app.before_request
    def _check_license():
        """每次请求前轻量检查 License 状态（不重新验签，只读缓存）"""
        # 登录页和静态资源不拦截
        if request.path in ('/login', '/logout', '/favicon.ico',
                             '/admin/license', '/api/license/status'):
            return
        if request.path.startswith('/s/'):   # 公开外链
            return
        # License 无效时，只允许登录和 License 管理页，其他全拦截
        if not _license_ok:
            if request.path.startswith('/api/'):
                return jsonify({
                    'error': f'系统未授权：{_license_error}',
                    'code': 403
                }), 403
            return _license_wall(_license_error)


def _license_wall(error: str):
    """License 无效时的全屏提示页"""
    return render_template_string("""
<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><title>系统授权异常</title>
<style>
body{margin:0;font-family:'Microsoft YaHei',sans-serif;background:#f4f7fb;
  display:flex;align-items:center;justify-content:center;min-height:100vh}
.box{background:#fff;border-radius:8px;padding:40px 48px;max-width:480px;
  box-shadow:0 4px 20px rgba(0,0,0,.1);text-align:center}
.icon{font-size:56px;margin-bottom:16px}
h2{color:#c62828;margin:0 0 12px}
p{color:#475569;font-size:14px;line-height:1.8}
.err{background:#fff0f0;border:1px solid #fca5a5;border-radius:4px;
  padding:12px 16px;font-size:12px;color:#c62828;margin:16px 0;text-align:left;font-family:monospace}
a{color:#1560bd;font-size:13px}
</style>
</head>
<body>
<div class="box">
  <div class="icon">🔐</div>
  <h2>系统授权异常</h2>
  <p>系统检测到 License 问题，功能已暂停。<br>请联系系统管理员或厂商处理。</p>
  <div class="err">{{ error }}</div>
  <p><a href="/login">管理员登录</a> &nbsp;|&nbsp; <a href="/admin/license">查看授权状态</a></p>
</div>
</body>
</html>
""", error=error), 403


def feature_required(feature: str):
    """
    路由装饰器：要求 License 包含指定功能。

    用法：
        @bp.route('/webdav/...')
        @login_required
        @feature_required('webdav')
        def webdav(...):
            ...
    """
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            if not has_feature(feature):
                edition = get_edition()
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({
                        'error': f'功能「{feature}」在当前版本（{edition}）中未授权，请升级 License',
                        'code': 403,
                        'upgrade_required': True,
                    }), 403
                abort(403)
            return f(*args, **kwargs)
        return wrapper
    return decorator


def check_create_user_limit():
    """
    在创建新用户前调用，检查是否超过用户数限制。
    从数据库实时查询当前用户数。
    """
    try:
        from dao.db import get_conn
        with get_conn() as conn:
            count = conn.execute(
                "SELECT COUNT(*) FROM users WHERE is_active=1"
            ).fetchone()[0]
        check_user_limit(count)
    except LicenseUserLimitError:
        raise
    except Exception:
        pass   # License 检查本身出错不阻断用户创建
