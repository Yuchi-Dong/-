# -*- coding: utf-8 -*-
"""
license/crypto.py — RSA 签名与验证

密钥对管理：
  - 私钥（2048-bit RSA）：厂商保留，用于签发 License
  - 公钥：内嵌在产品代码中，用于验签

签名算法：RSA-PSS + SHA-256
License 格式：JSON payload + Base64(RSA签名)
"""
import base64
import json
import os
from datetime import datetime

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend
from cryptography.exceptions import InvalidSignature


# ── 内嵌公钥（厂商生成后替换此处） ─────────────────
# 这里用 placeholder，实际部署时替换为真实公钥 PEM
_EMBEDDED_PUBLIC_KEY_PEM = b"""-----BEGIN PUBLIC KEY-----
PLACEHOLDER_REPLACE_WITH_REAL_PUBLIC_KEY
-----END PUBLIC KEY-----"""


def generate_keypair(key_size: int = 2048) -> tuple:
    """
    生成 RSA 密钥对。
    厂商在自己的机器上执行一次，私钥妥善保管，公钥嵌入产品。
    返回 (private_key_pem: bytes, public_key_pem: bytes)
    """
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=key_size,
        backend=default_backend()
    )
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    )
    public_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    return private_pem, public_pem


def sign_license(payload: dict, private_key_pem: bytes) -> str:
    """
    用私钥对 License payload 签名。
    返回 License 字符串（payload_b64.signature_b64）
    """
    private_key = serialization.load_pem_private_key(
        private_key_pem, password=None, backend=default_backend()
    )
    # 规范化 JSON：按 key 排序，确保签名确定性
    payload_json  = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    payload_bytes = payload_json.encode('utf-8')
    payload_b64   = base64.b64encode(payload_bytes).decode()

    signature = private_key.sign(
        payload_bytes,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    sig_b64 = base64.b64encode(signature).decode()
    return f"{payload_b64}.{sig_b64}"


def verify_license(license_str: str, public_key_pem: bytes = None) -> tuple:
    """
    验证 License 字符串的签名合法性。
    返回 (ok: bool, payload: dict | None, error: str)
    """
    if public_key_pem is None:
        public_key_pem = _EMBEDDED_PUBLIC_KEY_PEM

    # 检查公钥是否是 placeholder
    if b'PLACEHOLDER_REPLACE_WITH_REAL_PUBLIC_KEY' in public_key_pem:
        return False, None, "产品未配置有效公钥，请联系厂商"

    try:
        parts = license_str.strip().split('.')
        if len(parts) != 2:
            return False, None, "License 格式错误"

        payload_bytes = base64.b64decode(parts[0])
        signature     = base64.b64decode(parts[1])
        payload       = json.loads(payload_bytes.decode('utf-8'))

        public_key = serialization.load_pem_public_key(
            public_key_pem, backend=default_backend()
        )
        public_key.verify(
            signature,
            payload_bytes,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        return True, payload, ''
    except InvalidSignature:
        return False, None, "License 签名无效（可能被篡改）"
    except Exception as e:
        return False, None, f"License 解析失败：{e}"


def load_public_key_from_file(path: str) -> bytes:
    """从文件加载公钥（用于替换内嵌公钥）"""
    with open(path, 'rb') as f:
        return f.read()
