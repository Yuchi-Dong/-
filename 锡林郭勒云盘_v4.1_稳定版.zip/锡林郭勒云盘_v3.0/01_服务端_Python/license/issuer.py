# -*- coding: utf-8 -*-
"""
license/issuer.py — 厂商签发工具（不随产品发布）

使用方法：
  # 1. 首次运行生成密钥对（只做一次，私钥妥善保管）
  python -m license.issuer genkey

  # 2. 查看客户机器指纹
  python -m license.issuer fingerprint

  # 3. 签发 License
  python -m license.issuer issue \
    --customer "锡林郭勒盟大数据中心" \
    --edition GOV \
    --max-users 500 \
    --expire 2027-01-01 \
    --machine-id ABCD1234EFGH5678 \
    --mac "00:0C:29:AB:CD:EF" \
    --cpu "BFEBFBFF000906E9" \
    --ip "192.168.1.100" \
    --activation-url "https://license.yourcompany.com/activate" \
    --features "watermark,approval,two_factor"

  # 4. 验证 License 文件
  python -m license.issuer verify --file license.lic
"""
import json
import sys
import argparse
import os
from datetime import datetime
from pathlib import Path

# 密钥文件路径（厂商保管，绝不随代码发布）
_VENDOR_DIR   = Path.home() / '.secftp_vendor'
_PRIVATE_KEY  = _VENDOR_DIR / 'private.pem'
_PUBLIC_KEY   = _VENDOR_DIR / 'public.pem'


def cmd_genkey(args):
    """生成 RSA 密钥对"""
    from license.crypto import generate_keypair
    _VENDOR_DIR.mkdir(exist_ok=True)
    if _PRIVATE_KEY.exists() and not getattr(args, 'force', False):
        print(f"私钥已存在：{_PRIVATE_KEY}")
        print("如需重新生成，添加 --force 参数（注意：已发布的 License 将全部失效）")
        return

    priv, pub = generate_keypair(2048)
    _PRIVATE_KEY.write_bytes(priv)
    _PRIVATE_KEY.chmod(0o600)
    _PUBLIC_KEY.write_bytes(pub)
    print(f"✅ 私钥已保存：{_PRIVATE_KEY}  （请妥善保管，切勿泄露）")
    print(f"✅ 公钥已保存：{_PUBLIC_KEY}")
    print()
    print("将以下公钥内容替换到 license/crypto.py 的 _EMBEDDED_PUBLIC_KEY_PEM 变量：")
    print("─" * 60)
    print(pub.decode())
    print("─" * 60)


def cmd_fingerprint(args):
    """打印当前机器指纹"""
    from license.machine import get_fingerprint
    fp = get_fingerprint()
    print("\n📋 当前机器指纹：")
    print(f"  机器码（Machine ID）: {fp['machine_id']}")
    print(f"  MAC 地址:             {', '.join(fp['mac_addresses']) or '无'}")
    print(f"  CPU 序列号:           {fp['cpu_serial']}")
    print(f"  服务器 IP:            {', '.join(fp['server_ips']) or '无'}")
    print(f"  主机名:               {fp['hostname']}")
    print(f"  操作系统:             {fp['platform']}")
    print()
    print("将以上信息提供给厂商，以便签发绑定此机器的 License。")


def cmd_issue(args):
    """签发 License"""
    if not _PRIVATE_KEY.exists():
        print("❌ 未找到私钥，请先运行: python -m license.issuer genkey")
        sys.exit(1)

    from license.crypto import sign_license
    from license.checker import EDITION_FEATURES
    import secrets as _sec
    from datetime import datetime

    # 强制要求设置到期时间
    if not args.expire:
        print("❌ 必须指定到期时间 --expire YYYY-MM-DD，不允许签发永久 License")
        sys.exit(1)
    try:
        expire_dt = datetime.strptime(args.expire, '%Y-%m-%d')
        if expire_dt <= datetime.now():
            print(f"❌ 到期时间 {args.expire} 已过期，请指定未来的日期")
            sys.exit(1)
        days = (expire_dt - datetime.now()).days
        if days > 1095:  # 最长3年
            print(f"❌ 授权期限最长3年（{days}天），请缩短有效期")
            sys.exit(1)
    except ValueError:
        print(f"❌ 日期格式错误：{args.expire}，请使用 YYYY-MM-DD 格式")
        sys.exit(1)

    edition = (args.edition or 'GOV').upper()
    if edition not in EDITION_FEATURES:
        print(f"❌ 无效版本：{edition}，可选：{list(EDITION_FEATURES.keys())}")
        sys.exit(1)

    edition_def = EDITION_FEATURES[edition]

    # 功能列表：版本默认 + 额外指定
    features = list(edition_def['features'])
    if args.features:
        extra = [f.strip() for f in args.features.split(',') if f.strip()]
        features = list(set(features + extra))

    # 绑定信息
    binding = {}
    if args.machine_id: binding['machine_id'] = args.machine_id
    if args.mac:        binding['mac_addresses'] = [m.strip() for m in args.mac.split(',')]
    if args.cpu:        binding['cpu_serial'] = args.cpu.strip()
    if args.ip:         binding['server_ips'] = [i.strip() for i in args.ip.split(',')]

    payload = {
        'license_id':      _sec.token_hex(8).upper(),
        'customer':        args.customer or '未指定客户',
        'edition':         edition,
        'max_users':       int(args.max_users or edition_def['max_users']),
        'features':        sorted(features),
        'expire':          args.expire or '',
        'issued_at':       datetime.now().strftime('%Y-%m-%d'),
        'binding':         binding,
        'activation_url':  args.activation_url or '',
        'notes':           args.notes or '',
    }

    priv_pem = _PRIVATE_KEY.read_bytes()
    license_str = sign_license(payload, priv_pem)

    # 输出
    out_file = Path(args.output or 'license.lic')
    out_file.write_text(license_str, encoding='utf-8')

    print(f"\n✅ License 已签发：{out_file}")
    print(f"   License ID:  {payload['license_id']}")
    print(f"   客户:        {payload['customer']}")
    print(f"   版本:        {payload['edition']}（{EDITION_FEATURES[edition]['display']}）")
    print(f"   用户上限:    {payload['max_users']}")
    print(f"   到期时间:    {payload['expire'] or '永久'}")
    print(f"   绑定机器码:  {binding.get('machine_id', '未绑定')}")
    print(f"   功能列表:    {', '.join(sorted(features))}")
    print()
    print(f"将 {out_file} 文件发送给客户，放置于程序目录下即可激活。")


def cmd_verify(args):
    """验证 License 文件"""
    lic_path = Path(args.file or 'license.lic')
    if not lic_path.exists():
        print(f"❌ 文件不存在：{lic_path}")
        sys.exit(1)

    pub_pem = _PUBLIC_KEY.read_bytes() if _PUBLIC_KEY.exists() else None
    if pub_pem is None:
        print("❌ 未找到公钥文件，请先运行 genkey")
        sys.exit(1)

    from license.crypto import verify_license
    license_str = lic_path.read_text(encoding='utf-8').strip()
    ok, payload, err = verify_license(license_str, pub_pem)

    if not ok:
        print(f"❌ 签名验证失败：{err}")
        sys.exit(1)

    print("✅ License 签名验证通过")
    print(json.dumps(payload, ensure_ascii=False, indent=2))


def main():
    parser = argparse.ArgumentParser(description='SecFTP Pro License 管理工具')
    sub = parser.add_subparsers(dest='cmd')

    # genkey
    p_gk = sub.add_parser('genkey', help='生成 RSA 密钥对')
    p_gk.add_argument('--force', action='store_true', help='强制重新生成（慎用）')

    # fingerprint
    sub.add_parser('fingerprint', help='显示当前机器指纹')

    # issue
    p_is = sub.add_parser('issue', help='签发 License')
    p_is.add_argument('--customer',        required=True, help='客户名称')
    p_is.add_argument('--edition',         default='GOV',  help='版本：BASIC/PRO/GOV')
    p_is.add_argument('--max-users',       type=int,       help='最大用户数')
    p_is.add_argument('--expire',                          help='到期日期 YYYY-MM-DD（必填，最长3年）', required=True)
    p_is.add_argument('--machine-id',                      help='机器码')
    p_is.add_argument('--mac',                             help='MAC 地址（多个逗号分隔）')
    p_is.add_argument('--cpu',                             help='CPU 序列号')
    p_is.add_argument('--ip',                              help='服务器 IP（多个逗号分隔）')
    p_is.add_argument('--activation-url',                  help='在线激活接口 URL')
    p_is.add_argument('--features',                        help='额外功能列表（逗号分隔）')
    p_is.add_argument('--notes',                           help='备注')
    p_is.add_argument('--output',          default='license.lic', help='输出文件名')

    # verify
    p_v = sub.add_parser('verify', help='验证 License 文件')
    p_v.add_argument('--file', default='license.lic', help='License 文件路径')

    args = parser.parse_args()
    if args.cmd == 'genkey':        cmd_genkey(args)
    elif args.cmd == 'fingerprint': cmd_fingerprint(args)
    elif args.cmd == 'issue':       cmd_issue(args)
    elif args.cmd == 'verify':      cmd_verify(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
