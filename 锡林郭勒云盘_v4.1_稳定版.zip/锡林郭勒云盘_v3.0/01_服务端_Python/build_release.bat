@echo off
:: ============================================================
:: build_release.bat — 锡林郭勒云盘 生产发布包构建脚本
::
:: 执行步骤：
::   1. 用 pyarmor 混淆 license/ 目录（核心授权逻辑保护）
::   2. 用 PyInstaller 打包为单目录可执行程序
::   3. 将输出复制到 release_build\SecFTP_Pro_v3.0\
:: ============================================================
chcp 65001 >nul
setlocal

set VERSION=3.0.0
set BUILD_DIR=%~dp0release_build
set DIST_DIR=%~dp0dist\SecFTP_Pro
set OUT_DIR=%BUILD_DIR%\SecFTP_Pro_v%VERSION%

echo.
echo ╔══════════════════════════════════════════════════════╗
echo ║     锡林郭勒云盘 v%VERSION% — 生产发布包构建          ║
echo ╚══════════════════════════════════════════════════════╝
echo.

:: ── 检查虚拟环境 ─────────────────────────────────────────
if not exist "venv\Scripts\activate.bat" (
    echo [错误] 未找到 venv，请先运行: python -m venv venv ^&^& venv\Scripts\activate ^&^& pip install -r requirements.txt
    pause & exit /b 1
)
call venv\Scripts\activate

:: ── 安装打包工具 ─────────────────────────────────────────
echo [1/5] 检查打包工具...
pip install pyinstaller pyarmor --quiet
echo      OK

:: ── 混淆 license/ 模块（保护授权核心）────────────────────
echo [2/5] 混淆 license/ 模块...
if exist "license_obfuscated" rmdir /s /q "license_obfuscated"
pyarmor gen --output license_obfuscated license\checker.py license\crypto.py license\machine.py
if errorlevel 1 (
    echo [警告] pyarmor 混淆失败，将使用原始代码继续构建
    echo       生产环境强烈建议修复混淆后再发布
)
echo      混淆完成（输出到 license_obfuscated\）

:: ── 生成版本信息文件 ──────────────────────────────────────
echo [3/5] 生成版本信息...
(
echo VSVersionInfo(
echo   ffi=FixedFileInfo(
echo     filevers=(3, 0, 0, 0^),
echo     prodvers=(3, 0, 0, 0^),
echo     mask=0x3f,
echo     flags=0x0,
echo     OS=0x40004,
echo     fileType=0x1,
echo     subtype=0x0,
echo     date=(0, 0^)
echo   ^),
echo   kids=[
echo     StringFileInfo([
echo       StringTable(
echo         u'080404b0',
echo         [StringStruct(u'CompanyName', u'锡林郭勒盟大数据中心'^),
echo          StringStruct(u'FileDescription', u'锡林郭勒云盘 — 政务数据分级管控平台'^),
echo          StringStruct(u'FileVersion', u'%VERSION%'^),
echo          StringStruct(u'InternalName', u'SecFTP_Pro'^),
echo          StringStruct(u'OriginalFilename', u'SecFTP_Pro.exe'^),
echo          StringStruct(u'ProductName', u'锡林郭勒云盘'^),
echo          StringStruct(u'ProductVersion', u'%VERSION%'^)])
echo     ]^),
echo     VarFileInfo([VarStruct(u'Translation', [0x0804, 1200]^)])
echo   ]
echo ^)
) > version_info.txt
echo      版本信息生成完成

:: ── PyInstaller 打包 ──────────────────────────────────────
echo [4/5] PyInstaller 打包（约需 3~5 分钟）...
if exist "dist" rmdir /s /q "dist"
if exist "build" rmdir /s /q "build"
pyinstaller build.spec --noconfirm --clean
if errorlevel 1 (
    echo [错误] PyInstaller 打包失败，请查看上方错误信息
    pause & exit /b 1
)
echo      打包完成：dist\SecFTP_Pro\

:: ── 整理发布目录 ──────────────────────────────────────────
echo [5/5] 整理发布目录...
if exist "%OUT_DIR%" rmdir /s /q "%OUT_DIR%"
mkdir "%OUT_DIR%"

:: 复制可执行程序
xcopy "%DIST_DIR%\*" "%OUT_DIR%\" /E /I /H /Q

:: 复制部署脚本
copy /Y "setup_postgres.bat" "%OUT_DIR%\"
copy /Y "setup_nginx.bat"    "%OUT_DIR%\"
copy /Y "nginx.conf"          "%OUT_DIR%\"

:: 创建 license 占位文件（客户拿到后放入实际 license.lic）
echo 请将授权文件 license.lic 放置于此目录，然后运行 SecFTP_Pro.exe > "%OUT_DIR%\请放入license.lic.txt"

echo.
echo ══════════════════════════════════════════════════════
echo  构建完成！
echo  发布包位置: %OUT_DIR%\
echo.
echo  发布前检查清单:
echo    □ 将 license.lic 替换为实际签发的客户 License
echo    □ 确认 nginx.conf 中的服务器地址已修改
echo    □ 确认 setup_postgres.bat 中的密码已修改
echo    □ 测试 SecFTP_Pro.exe 能正常启动
echo ══════════════════════════════════════════════════════
pause
