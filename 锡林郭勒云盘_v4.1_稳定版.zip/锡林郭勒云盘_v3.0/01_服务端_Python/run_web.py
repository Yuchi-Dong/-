# -*- coding: utf-8 -*-
"""
run_web.py — 生产启动入口

架构：Nginx（对外）→ Waitress（127.0.0.1:8080，仅本机可达）→ Flask → PostgreSQL

Waitress 只监听 127.0.0.1，不对外暴露，所有外部流量必须经过 Nginx。
Nginx 负责：SSL终止 / 大文件流式上传下载 / 静态资源缓存 / 连接限速。
"""
import multiprocessing, logging, sys, os

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('secftp_web.log', encoding='utf-8'),
    ]
)
log = logging.getLogger('startup')

# Nginx 后端不需要太多线程（Nginx 已处理慢连接）
# CPU核心×2，最少8，最多32
THREADS = max(8, min(32, multiprocessing.cpu_count() * 2))

if __name__ == '__main__':
    from waitress import serve
    import config
    from models import init_db
    from indexer import init_index_db
    from main import app
    from license.middleware import init_license

    init_db()
    init_index_db()
    init_license(app)

    log.info(f"SecFTP Pro v3.0 启动")
    log.info(f"Waitress 监听: 127.0.0.1:{config.WEB_PORT}  (仅本机，外部请求走 Nginx)")
    log.info(f"PostgreSQL: {config.DB_HOST}:{config.DB_PORT}/{config.DB_NAME}")
    log.info(f"Waitress 线程数: {THREADS}")

    serve(
        app,
        host='127.0.0.1',          # ← 只绑定本地，不对外暴露
        port=config.WEB_PORT,
        threads=THREADS,
        connection_limit=500,
        channel_timeout=300,
        recv_bytes=65536,
        send_bytes=65536,
        ident='SecFTP/3.0',
    )
