# 此文件内容用于追加到 models.py init_db() 函数中
# 新增表：export_requests（数据导出审批）、devices（设备绑定）

APPROVAL_TABLES_SQL = """
-- 数据导出审批申请表
CREATE TABLE IF NOT EXISTS export_requests (
    id           SERIAL PRIMARY KEY,
    applicant_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    file_path    TEXT NOT NULL,
    is_dir       INTEGER DEFAULT 0,
    reason       TEXT NOT NULL DEFAULT '',
    status       TEXT NOT NULL DEFAULT 'pending',   -- pending/approved/rejected
    reviewer_id  INTEGER REFERENCES users(id),
    review_note  TEXT DEFAULT '',
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    reviewed_at  TIMESTAMPTZ,
    expires_at   TIMESTAMPTZ,
    download_token TEXT UNIQUE
);

-- 设备绑定表
CREATE TABLE IF NOT EXISTS user_devices (
    id           SERIAL PRIMARY KEY,
    user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    device_id    TEXT NOT NULL,
    device_name  TEXT DEFAULT '',
    ua_hash      TEXT DEFAULT '',
    platform     TEXT DEFAULT '',
    first_seen   TIMESTAMPTZ DEFAULT NOW(),
    last_seen    TIMESTAMPTZ DEFAULT NOW(),
    is_trusted   INTEGER DEFAULT 0,
    is_active    INTEGER DEFAULT 1,
    UNIQUE(user_id, device_id)
);
"""
