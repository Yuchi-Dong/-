# -*- coding: utf-8 -*-
"""
compliance/session_mgr.py — 会话安全管理

等保三级要求：
  - 同一账号不允许多处并发登录（后登录踢出前者）
  - 登录 IP 绑定（可选，管理员配置）
  - 异常登录检测（异地/异常时间）
  - 会话令牌防重放
"""
import secrets
import hashlib
from dao.db import get_conn


# ── 并发会话控制（同账号互踢）─────────────────────────
def create_session_token(user_id: int, ip: str, user_agent: str = '') -> str:
    """
    创建会话令牌，并记录到数据库。
    同一用户的旧会话标记为失效（单点登录）。
    """
    token   = secrets.token_hex(32)
    ua_hash = hashlib.sha256(user_agent.encode()).hexdigest()[:16]
    try:
        with get_conn() as conn:
            # 使旧会话失效（同账号互踢）
            conn.execute(
                "UPDATE active_sessions SET is_active=0, kicked_at=NOW() "
                "WHERE user_id=%s AND is_active=1",
                (user_id,)
            )
            # 创建新会话
            conn.execute(
                "INSERT INTO active_sessions(user_id, token, ip, ua_hash, created_at, last_active) "
                "VALUES(%s,%s,%s,%s,NOW(),NOW())",
                (user_id, token, ip, ua_hash)
            )
    except Exception as _e:
        import logging; logging.getLogger('session').warning(f'create_session_token failed: {_e}')
    return token


def validate_session_token(user_id: int, token: str) -> bool:
    """验证 session token 是否有效（防重放 / 互踢后拒绝旧会话）"""
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT id FROM active_sessions WHERE user_id=%s AND token=%s AND is_active=1",
                (user_id, token)
            ).fetchone()
        return row is not None
    except Exception:
        return True   # 表不存在时不拦截（向后兼容）


def refresh_session_token(user_id: int, token: str, ip: str):
    """更新会话最后活跃时间"""
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE active_sessions SET last_active=NOW(), ip=%s "
                "WHERE user_id=%s AND token=%s AND is_active=1",
                (ip, user_id, token)
            )
    except Exception:
        pass


def invalidate_session(user_id: int, token: str):
    """注销指定会话"""
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE active_sessions SET is_active=0 WHERE user_id=%s AND token=%s",
                (user_id, token)
            )
    except Exception:
        pass


def invalidate_all_sessions(user_id: int):
    """注销用户所有会话（修改密码/禁用账号时调用）"""
    try:
        with get_conn() as conn:
            conn.execute(
                "UPDATE active_sessions SET is_active=0, kicked_at=NOW() "
                "WHERE user_id=%s AND is_active=1",
                (user_id,)
            )
    except Exception:
        pass


def get_active_sessions(user_id: int) -> list:
    """获取用户所有活跃会话（管理员查看）"""
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT token, ip, created_at, last_active FROM active_sessions "
                "WHERE user_id=%s AND is_active=1 ORDER BY last_active DESC",
                (user_id,)
            ).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        return []


# ── IP 绑定（登录白名单）────────────────────────────────
def check_ip_allowed(user_id: int, ip: str) -> tuple:
    """
    检查 IP 是否在用户的允许列表中。
    返回 (ok, reason)
    超管或未配置 IP 限制时总是通过。
    支持精确 IP 和 CIDR /24 段匹配。
    """
    try:
        with get_conn() as conn:
            rows = conn.execute(
                "SELECT allowed_ip FROM user_ip_whitelist WHERE user_id=%s AND is_active=1",
                (user_id,)
            ).fetchall()
        if not rows:
            return True, 'OK'   # 未配置 IP 限制
        allowed = {r['allowed_ip'] for r in rows}
        for pattern in allowed:
            if '/' in pattern:
                # CIDR /24 前缀匹配：取前三段
                try:
                    prefix = '.'.join(pattern.split('/')[0].split('.')[:3]) + '.'
                    if ip.startswith(prefix):
                        return True, 'OK'
                except Exception:
                    pass
            elif ip == pattern:
                return True, 'OK'
        return False, f"登录 IP（{ip}）不在允许列表中，请联系管理员"
    except Exception as _e:
        import logging; logging.getLogger('session').warning(f'check_ip_allowed error: {_e}')
        return True, 'OK'


# ── 异常登录检测 ──────────────────────────────────────
def detect_anomaly(user_id: int, ip: str) -> dict:
    """
    检测异常登录特征，返回风险信息（不阻断，用于审计告警）。
    """
    anomalies = []
    try:
        with get_conn() as conn:
            # 检查是否是新 IP
            row = conn.execute(
                "SELECT COUNT(*) FROM active_sessions WHERE user_id=%s AND ip=%s",
                (user_id, ip)
            ).fetchone()
            if row[0] == 0:
                anomalies.append(f"首次从 IP {ip} 登录")

            # 检查近期登录失败次数
            row2 = conn.execute(
                "SELECT fail_count FROM users WHERE id=%s", (user_id,)
            ).fetchone()
            if row2 and row2['fail_count'] >= 3:
                anomalies.append(f"登录前有 {row2['fail_count']} 次失败尝试")
    except Exception:
        pass
    return {
        'has_anomaly': len(anomalies) > 0,
        'details': anomalies,
    }
