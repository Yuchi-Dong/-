# -*- coding: utf-8 -*-
"""
compliance/audit_log.py — 防篡改审计日志

等保三级要求：
  - 日志不可篡改（哈希链：每条日志包含前一条的哈希）
  - 日志留存 ≥ 180 天
  - 覆盖：用户行为、权限变更、文件操作、登录/登出、异常事件

哈希链机制：
  log[N].chain_hash = SHA-256(log[N-1].chain_hash + log[N].content)
  任何中间记录被篡改都会导致链断裂，可通过 verify_chain() 检测
"""
import hashlib
import json
import logging
from datetime import datetime
from dao.db import get_conn

log = logging.getLogger('audit')


# ── 日志分类 ─────────────────────────────────────────
class AuditCategory:
    AUTH      = 'AUTH'       # 认证：登录/登出/密码变更
    FILE      = 'FILE'       # 文件操作：上传/下载/删除/移动
    SHARE     = 'SHARE'      # 分享操作
    ADMIN     = 'ADMIN'      # 管理操作：用户/组织变更
    PERM      = 'PERM'       # 权限变更
    SYSTEM    = 'SYSTEM'     # 系统事件
    SECURITY  = 'SECURITY'   # 安全事件：失败/异常/攻击尝试


# ── 写入日志 ─────────────────────────────────────────
def write(user_id, username, action, detail='', ip='',
          level='INFO', category=AuditCategory.FILE,
          resource=None, result='SUCCESS'):
    """
    写入一条审计日志（追加模式，带哈希链）。
    level: INFO / WARN / ERROR
    category: AuditCategory 中的常量
    resource: 操作对象（文件路径、用户ID等）
    result: SUCCESS / FAILURE / BLOCKED
    """
    try:
        with get_conn() as conn:
            # 获取上一条记录的 chain_hash（链尾）
            # FOR UPDATE：行级锁，防止并发写入时哈希链分叉断裂
            prev = conn.execute(
                "SELECT chain_hash FROM audit_log_secure ORDER BY id DESC LIMIT 1 FOR UPDATE"
            ).fetchone()
            prev_hash = prev['chain_hash'] if prev else '0' * 64

            # 构造本条记录内容（用于计算哈希）
            ts      = datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
            content = json.dumps({
                'ts':       ts,
                'user_id':  user_id,
                'username': username,
                'action':   action,
                'detail':   detail,
                'ip':       ip,
                'level':    level,
                'category': category,
                'resource': resource or '',
                'result':   result,
            }, sort_keys=True, ensure_ascii=False)

            # 哈希链：chain_hash = SHA-256(prev_hash + content)
            chain_hash = hashlib.sha256(
                (prev_hash + content).encode('utf-8')
            ).hexdigest()

            conn.execute(
                "INSERT INTO audit_log_secure"
                "(ts, user_id, username, action, detail, ip, level, category, resource, result, chain_hash)"
                " VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
                (ts, user_id, username, action, detail, ip,
                 level, category, resource or '', result, chain_hash)
            )
    except Exception as e:
        log.warning(f"审计日志写入失败: {e}")


# ── 查询日志 ─────────────────────────────────────────
def query(limit=200, category=None, user_id=None, level=None,
          start_ts=None, end_ts=None):
    """查询防篡改审计日志"""
    conditions = []
    params     = []

    if category:
        conditions.append("category=%s"); params.append(category)
    if user_id:
        conditions.append("user_id=%s"); params.append(user_id)
    if level:
        conditions.append("level=%s"); params.append(level)
    if start_ts:
        conditions.append("ts>=%s"); params.append(start_ts)
    if end_ts:
        conditions.append("ts<=%s"); params.append(end_ts)

    where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
    params.append(limit)

    with get_conn() as conn:
        rows = conn.execute(
            f"SELECT * FROM audit_log_secure {where} ORDER BY id DESC LIMIT %s",
            params
        ).fetchall()
    return [dict(r) for r in rows]


# ── 哈希链验证 ───────────────────────────────────────
def verify_chain(limit=1000) -> dict:
    """
    验证审计日志哈希链完整性。
    返回 {'ok': bool, 'checked': int, 'broken_at': id or None}
    """
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT id, ts, user_id, username, action, detail, ip, "
            "level, category, resource, result, chain_hash "
            "FROM audit_log_secure ORDER BY id ASC LIMIT %s",
            (limit,)
        ).fetchall()

    if not rows:
        return {'ok': True, 'checked': 0, 'broken_at': None}

    prev_hash = '0' * 64
    for row in rows:
        content = json.dumps({
            'ts':       row['ts'],
            'user_id':  row['user_id'],
            'username': row['username'],
            'action':   row['action'],
            'detail':   row['detail'],
            'ip':       row['ip'],
            'level':    row['level'],
            'category': row['category'],
            'resource': row['resource'],
            'result':   row['result'],
        }, sort_keys=True, ensure_ascii=False)
        expected = hashlib.sha256((prev_hash + content).encode('utf-8')).hexdigest()
        if expected != row['chain_hash']:
            return {'ok': False, 'checked': rows.index(row) + 1, 'broken_at': row['id']}
        prev_hash = row['chain_hash']

    return {'ok': True, 'checked': len(rows), 'broken_at': None}
