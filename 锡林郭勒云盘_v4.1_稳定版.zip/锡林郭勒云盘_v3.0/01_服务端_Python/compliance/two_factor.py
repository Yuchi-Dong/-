# -*- coding: utf-8 -*-
"""
compliance/two_factor.py — 双因素认证（TOTP）

兼容 Google Authenticator / 微软 Authenticator / 任意 TOTP 应用。
算法：RFC 6238 TOTP（HMAC-SHA1，30秒步长，6位数字）
"""
import base64
import hashlib
import hmac
import os
import struct
import time
import secrets
import qrcode
import io
from dao.db import get_conn


def generate_secret() -> str:
    """生成 Base32 编码的 TOTP 密钥（160-bit）"""
    raw = secrets.token_bytes(20)
    return base64.b32encode(raw).decode().rstrip('=')


def get_totp_code(secret: str, timestamp: int = None) -> str:
    """计算当前 TOTP 验证码（6位数字）"""
    if timestamp is None:
        timestamp = int(time.time())
    step     = timestamp // 30
    key      = base64.b32decode(secret.upper() + '=' * ((8 - len(secret) % 8) % 8))
    msg      = struct.pack('>Q', step)
    h        = hmac.new(key, msg, hashlib.sha1).digest()
    offset   = h[-1] & 0x0F
    code     = struct.unpack('>I', h[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(code % 1_000_000).zfill(6)


def verify_totp(secret: str, code: str, window: int = 1) -> bool:
    """
    验证 TOTP 码，允许前后 window 个时间步长的偏差（容忍时钟偏差）。
    """
    if not code or not secret:
        return False
    code = code.strip()
    now  = int(time.time())
    for delta in range(-window, window + 1):
        ts = now + delta * 30
        if get_totp_code(secret, ts) == code:
            return True
    return False


def generate_qrcode(secret: str, username: str,
                    issuer: str = 'SecFTP Pro') -> bytes:
    """生成 TOTP 二维码，返回 PNG 字节流"""
    uri = (f"otpauth://totp/{issuer}:{username}"
           f"?secret={secret}&issuer={issuer}&algorithm=SHA1&digits=6&period=30")
    qr  = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_L, box_size=6)
    qr.add_data(uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color='black', back_color='white')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    return buf.getvalue()


# ── 数据库操作 ────────────────────────────────────────
def enable_2fa(user_id: int, secret: str):
    """为用户启用 2FA"""
    with get_conn() as conn:
        conn.execute(
            "UPDATE users SET totp_secret=%s, totp_enabled=1 WHERE id=%s",
            (secret, user_id)
        )


def disable_2fa(user_id: int):
    """禁用用户 2FA"""
    with get_conn() as conn:
        conn.execute(
                "UPDATE users SET totp_secret=NULL, totp_enabled=0 WHERE id=%s",
                (user_id,)
            )


def get_2fa_status(user_id: int) -> dict:
    """获取用户 2FA 状态"""
    try:
        with get_conn() as conn:
            row = conn.execute(
                "SELECT totp_enabled, totp_secret FROM users WHERE id=?",
                (user_id,)
            ).fetchone()
        if not row:
            return {'enabled': False, 'secret': None}
        return {
            'enabled': bool(row['totp_enabled']),
            'secret':  row['totp_secret'],
        }
    except Exception:
        return {'enabled': False, 'secret': None}


def is_2fa_required(user_id: int) -> bool:
    """判断用户是否需要进行 2FA 验证"""
    status = get_2fa_status(user_id)
    return status['enabled'] and bool(status.get('secret'))
