# -*- coding: utf-8 -*-
"""
models.py — PostgreSQL 数据库初始化

SQLite → PostgreSQL 主要变化：
  AUTOINCREMENT → SERIAL PRIMARY KEY
  TEXT DEFAULT (datetime(...)) → TIMESTAMPTZ DEFAULT NOW()
  PRAGMA / sqlite_master → information_schema / pg_indexes
  INSERT OR IGNORE → INSERT ... ON CONFLICT DO NOTHING
  ? 占位符 → %s（db._pg() 自动转换）
"""
import os, secrets, hashlib, config
from dao.db import get_conn


def _hash_pw(s, p):
    return hashlib.pbkdf2_hmac("sha256", p.encode(), s.encode(), 100_000).hex()


def _idx_exists(conn, name):
    return conn.execute(
        "SELECT 1 FROM pg_indexes WHERE schemaname='public' AND indexname=%s", (name,)
    ).fetchone() is not None


def init_db():
    os.makedirs(config.FILE_ROOT, exist_ok=True)
    with get_conn() as conn:

        conn.execute("""
        CREATE TABLE IF NOT EXISTS organizations (
            id          SERIAL PRIMARY KEY,
            name        TEXT NOT NULL,
            code        TEXT NOT NULL,
            parent_id   INTEGER REFERENCES organizations(id),
            org_level   INTEGER NOT NULL DEFAULT 1,
            level_label TEXT DEFAULT '',
            "desc"      TEXT DEFAULT '',
            dir_path    TEXT NOT NULL,
            created_by  INTEGER,
            created_at  TIMESTAMPTZ DEFAULT NOW()
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id              SERIAL PRIMARY KEY,
            username        TEXT UNIQUE NOT NULL,
            password        TEXT NOT NULL,
            salt            TEXT NOT NULL,
            role            INTEGER NOT NULL DEFAULT 2,
            org_id          INTEGER REFERENCES organizations(id),
            display_name    TEXT DEFAULT '',
            email           TEXT DEFAULT '',
            phone           TEXT DEFAULT '',
            bio             TEXT DEFAULT '',
            avatar_color    TEXT DEFAULT '#de2910',
            is_active       INTEGER DEFAULT 1,
            created_by      INTEGER,
            created_at      TIMESTAMPTZ DEFAULT NOW(),
            last_login      TIMESTAMPTZ,
            fail_count      INTEGER DEFAULT 0,
            locked_until    TIMESTAMPTZ,
            quota_mb        BIGINT DEFAULT 1024000,
            totp_secret     TEXT,
            totp_enabled    INTEGER DEFAULT 0,
            force_pw_change INTEGER DEFAULT 0,
            pw_changed_at   TIMESTAMPTZ
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS dir_perms (
            id         SERIAL PRIMARY KEY,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            dir_path   TEXT NOT NULL,
            perm       TEXT NOT NULL DEFAULT 'ro',
            granted_by INTEGER,
            granted_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(user_id, dir_path)
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS org_permissions (
            id         SERIAL PRIMARY KEY,
            org_id     INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
            path       TEXT NOT NULL,
            perm       TEXT NOT NULL DEFAULT 'ro',
            inherit    INTEGER DEFAULT 1,
            granted_by INTEGER,
            granted_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(org_id, path)
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS file_shares (
            id         SERIAL PRIMARY KEY,
            owner_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            file_path  TEXT NOT NULL,
            is_dir     INTEGER DEFAULT 0,
            share_type TEXT NOT NULL DEFAULT 'user',
            target_id  INTEGER,
            perm       TEXT DEFAULT 'ro',
            note       TEXT DEFAULT '',
            expires_at TIMESTAMPTZ,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            is_active  INTEGER DEFAULT 1
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS file_versions (
            id          SERIAL PRIMARY KEY,
            file_path   TEXT NOT NULL,
            version_no  INTEGER NOT NULL DEFAULT 1,
            file_size   BIGINT DEFAULT 0,
            backup_path TEXT NOT NULL,
            created_by  INTEGER REFERENCES users(id),
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            comment     TEXT DEFAULT ''
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS trash (
            id         SERIAL PRIMARY KEY,
            orig_path  TEXT NOT NULL,
            trash_path TEXT NOT NULL,
            is_dir     INTEGER DEFAULT 0,
            file_size  BIGINT DEFAULT 0,
            deleted_by INTEGER REFERENCES users(id),
            deleted_at TIMESTAMPTZ DEFAULT NOW()
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS public_links (
            id         SERIAL PRIMARY KEY,
            token      TEXT UNIQUE NOT NULL,
            file_path  TEXT NOT NULL,
            is_dir     INTEGER DEFAULT 0,
            perm       TEXT DEFAULT 'ro',
            pw_hash    TEXT DEFAULT '',
            pw_salt    TEXT DEFAULT '',
            expires_at TIMESTAMPTZ,
            view_count INTEGER DEFAULT 0,
            created_by INTEGER REFERENCES users(id),
            created_at TIMESTAMPTZ DEFAULT NOW(),
            is_active  INTEGER DEFAULT 1
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS file_locks (
            file_path TEXT PRIMARY KEY,
            locked_by INTEGER REFERENCES users(id),
            locked_at TIMESTAMPTZ DEFAULT NOW(),
            expires_at TIMESTAMPTZ
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS file_labels (
            file_path TEXT PRIMARY KEY,
            label     TEXT DEFAULT 'internal',
            set_by    INTEGER REFERENCES users(id),
            set_at    TIMESTAMPTZ DEFAULT NOW()
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id       SERIAL PRIMARY KEY,
            ts       TIMESTAMPTZ DEFAULT NOW(),
            user_id  INTEGER,
            username TEXT,
            action   TEXT NOT NULL,
            detail   TEXT,
            ip       TEXT,
            level    TEXT DEFAULT 'INFO'
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log_secure (
            id         SERIAL PRIMARY KEY,
            ts         TEXT NOT NULL,
            user_id    INTEGER,
            username   TEXT,
            action     TEXT NOT NULL,
            detail     TEXT DEFAULT '',
            ip         TEXT DEFAULT '',
            level      TEXT DEFAULT 'INFO',
            category   TEXT DEFAULT 'FILE',
            resource   TEXT DEFAULT '',
            result     TEXT DEFAULT 'SUCCESS',
            chain_hash TEXT NOT NULL DEFAULT ''
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS active_sessions (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            token       TEXT NOT NULL,
            ip          TEXT DEFAULT '',
            ua_hash     TEXT DEFAULT '',
            created_at  TIMESTAMPTZ DEFAULT NOW(),
            last_active TIMESTAMPTZ DEFAULT NOW(),
            is_active   INTEGER DEFAULT 1,
            kicked_at   TIMESTAMPTZ
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS user_ip_whitelist (
            id         SERIAL PRIMARY KEY,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            allowed_ip TEXT NOT NULL,
            note       TEXT DEFAULT '',
            is_active  INTEGER DEFAULT 1,
            created_by INTEGER,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            UNIQUE(user_id, allowed_ip)
        )""")

        conn.execute("""
        CREATE TABLE IF NOT EXISTS password_history (
            id            SERIAL PRIMARY KEY,
            user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            password_hash TEXT NOT NULL,
            salt          TEXT NOT NULL,
            created_at    TIMESTAMPTZ DEFAULT NOW()
        )""")


        # ── 数据导出审批 ──────────────────────────────────
        conn.execute("""
        CREATE TABLE IF NOT EXISTS export_requests (
            id             SERIAL PRIMARY KEY,
            applicant_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            file_path      TEXT NOT NULL,
            is_dir         INTEGER DEFAULT 0,
            reason         TEXT NOT NULL DEFAULT '',
            status         TEXT NOT NULL DEFAULT 'pending',
            reviewer_id    INTEGER REFERENCES users(id),
            review_note    TEXT DEFAULT '',
            created_at     TIMESTAMPTZ DEFAULT NOW(),
            reviewed_at    TIMESTAMPTZ,
            expires_at     TIMESTAMPTZ,
            download_token TEXT UNIQUE
        )""")

        # ── 设备绑定 ──────────────────────────────────────
        conn.execute("""
        CREATE TABLE IF NOT EXISTS user_devices (
            id          SERIAL PRIMARY KEY,
            user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            device_id   TEXT NOT NULL,
            device_name TEXT DEFAULT '',
            ua_hash     TEXT DEFAULT '',
            platform    TEXT DEFAULT '',
            first_seen  TIMESTAMPTZ DEFAULT NOW(),
            last_seen   TIMESTAMPTZ DEFAULT NOW(),
            is_trusted  INTEGER DEFAULT 0,
            is_active   INTEGER DEFAULT 1,
            UNIQUE(user_id, device_id)
        )""")

        # ── 索引 ───────────────────────────────────────────
        for ddl in [
            "CREATE INDEX IF NOT EXISTS idx_fv_path    ON file_versions(file_path)",
            "CREATE INDEX IF NOT EXISTS idx_pl_token   ON public_links(token)",
            "CREATE INDEX IF NOT EXISTS idx_audit_uid  ON audit_log(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_audit_ts   ON audit_log(ts)",
            "CREATE INDEX IF NOT EXISTS idx_als_ts     ON audit_log_secure(ts)",
            "CREATE INDEX IF NOT EXISTS idx_als_uid    ON audit_log_secure(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_share_path ON file_shares(file_path)",
            "CREATE INDEX IF NOT EXISTS idx_as_uid     ON active_sessions(user_id)",
            "CREATE INDEX IF NOT EXISTS idx_as_token   ON active_sessions(token)",
            "CREATE INDEX IF NOT EXISTS idx_ph_uid     ON password_history(user_id)",
            # ── 补全缺失索引（Code Review 发现）────────────
            "CREATE INDEX IF NOT EXISTS idx_fs_owner   ON file_shares(owner_id)",
            "CREATE INDEX IF NOT EXISTS idx_fs_target  ON file_shares(target_id)",
            "CREATE INDEX IF NOT EXISTS idx_fl_path    ON file_labels(file_path)",
            "CREATE INDEX IF NOT EXISTS idx_org_code   ON organizations(code)",
            "CREATE INDEX IF NOT EXISTS idx_usr_org    ON users(org_id)",
        ]:
            conn.execute(ddl)

        if not _idx_exists(conn, 'idx_org_parent_name'):
            conn.execute("CREATE UNIQUE INDEX idx_org_parent_name ON organizations(COALESCE(parent_id,-1),name)")
        if not _idx_exists(conn, 'idx_org_parent_code'):
            conn.execute("CREATE UNIQUE INDEX idx_org_parent_code ON organizations(COALESCE(parent_id,-1),code)")

        # ── 分片上传会话表 ─────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS upload_sessions (
                id            TEXT PRIMARY KEY,
                user_id       INTEGER NOT NULL,
                filename      TEXT NOT NULL,
                rel_path      TEXT NOT NULL,
                file_size     BIGINT DEFAULT 0,
                file_hash     TEXT DEFAULT '',
                total_chunks  INTEGER NOT NULL,
                done_chunks   TEXT DEFAULT '[]',
                status        TEXT DEFAULT 'active',
                created_at    TIMESTAMPTZ DEFAULT NOW(),
                updated_at    TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_us_user ON upload_sessions(user_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_us_status ON upload_sessions(status,updated_at)")

        # ── 编辑器会话表 ────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS editor_sessions (
                token       TEXT PRIMARY KEY,
                user_id     INTEGER NOT NULL,
                username    TEXT NOT NULL,
                file_path   TEXT NOT NULL,
                can_write   BOOLEAN DEFAULT FALSE,
                expires_at  TIMESTAMPTZ NOT NULL,
                created_at  TIMESTAMPTZ DEFAULT NOW()
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_es_exp ON editor_sessions(expires_at)")

        # ── 文件评论表 ──────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS file_comments (
                id          SERIAL PRIMARY KEY,
                file_path   TEXT NOT NULL,
                user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                parent_id   INTEGER REFERENCES file_comments(id) ON DELETE CASCADE,
                content     TEXT NOT NULL,
                created_at  TIMESTAMPTZ DEFAULT NOW(),
                updated_at  TIMESTAMPTZ DEFAULT NOW(),
                is_deleted  BOOLEAN DEFAULT FALSE
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_fc_path ON file_comments(file_path)")

        # ── 账号申请表 ──────────────────────────────────────
        conn.execute("""
            CREATE TABLE IF NOT EXISTS register_requests (
                id           SERIAL PRIMARY KEY,
                realname     TEXT NOT NULL,
                username     TEXT NOT NULL,
                email        TEXT DEFAULT '',
                phone        TEXT DEFAULT '',
                department   TEXT DEFAULT '',
                reason       TEXT NOT NULL,
                status       TEXT DEFAULT 'pending',
                reviewer_id  INTEGER REFERENCES users(id),
                review_note  TEXT DEFAULT '',
                created_at   TIMESTAMPTZ DEFAULT NOW(),
                reviewed_at  TIMESTAMPTZ,
                ip           TEXT DEFAULT ''
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_rr_status ON register_requests(status)")

        # ── 补充字段（升级时幂等 ADD COLUMN）──────────────
        for _alter in [
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS avatar_path TEXT DEFAULT ''",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS bio TEXT DEFAULT ''",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS location TEXT DEFAULT ''",
            "ALTER TABLE users ADD COLUMN IF NOT EXISTS department_title TEXT DEFAULT ''",
        ]:
            try:
                conn.execute(_alter)
            except Exception:
                pass

        # ── 头像目录 ──────────────────────────────────────
        _avatar_dir = os.path.join(config.FILE_ROOT, '.avatars')
        os.makedirs(_avatar_dir, exist_ok=True)

        # ── 默认组织 ──────────────────────────────────────
        for name, code, dirp, desc, level in [
            ("公共资源",   "shared",    "shared",    "所有用户可读的公共区域", 1),
            ("综合办公室", "dept_zzb",  "dept_zzb",  "综合办公",             1),
            ("数据管理部", "dept_sjgl", "dept_sjgl", "数据管理与运维",        1),
            ("业务支撑部", "dept_ywzc", "dept_ywzc", "业务系统支撑",          1),
            ("信息安全部", "dept_xxaq", "dept_xxaq", "信息安全管理",          1),
        ]:
            conn.execute("""
                INSERT INTO organizations(name,code,dir_path,"desc",org_level)
                VALUES(%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING
            """, (name, code, dirp, desc, level))
            os.makedirs(os.path.join(config.FILE_ROOT, dirp), exist_ok=True)

        # ── 默认超管 ──────────────────────────────────────
        if not conn.execute("SELECT id FROM users WHERE role=0").fetchone():
            salt = secrets.token_hex(16)
            conn.execute("""
                INSERT INTO users(username,password,salt,role,display_name)
                VALUES(%s,%s,%s,0,%s)
            """, ("admin", _hash_pw(salt, "Admin@2025!"), salt, "系统管理员"))
            os.makedirs(os.path.join(config.FILE_ROOT, "users", "admin"), exist_ok=True)
            print("  [OK] 默认超管账号已创建：admin，请登录后立即修改密码！")
