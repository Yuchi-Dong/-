import os

# ── PostgreSQL 数据库配置 ─────────────────────────────
# 优先级：环境变量 DATABASE_URL > 以下配置项
DB_HOST     = os.environ.get('DB_HOST', '127.0.0.1')
DB_PORT     = int(os.environ.get('DB_PORT', '5432'))
DB_NAME     = os.environ.get('DB_NAME', 'secftp')
DB_USER     = os.environ.get('DB_USER', 'secftp')
DB_PASS     = os.environ.get('DB_PASS', 'secftp_pass')
DB_POOL_MIN = int(os.environ.get('DB_POOL_MIN', '4'))
DB_POOL_MAX = int(os.environ.get('DB_POOL_MAX', '32'))
# DATABASE_URL 示例: postgresql://secftp:secftp_pass@127.0.0.1:5432/secftp
# -*- coding: utf-8 -*-
"""
SecFTP Pro — 配置文件
"""
import os, secrets

# ── 基础安全 ─────────────────────────────────────────
# 优先从环境变量读取，不存在时生成随机值（重启后 Session 失效，生产环境务必固定设置）
# ⚠ 生产环境必须通过环境变量 SECFTP_SECRET_KEY 设置固定密钥
# 未设置时自动生成随机值，重启后所有 session 失效
SECRET_KEY = os.environ.get("SECFTP_SECRET_KEY") or secrets.token_hex(32)
SECRET_KEY_IS_RANDOM = not bool(os.environ.get("SECFTP_SECRET_KEY"))

# ── 存储路径 ─────────────────────────────────────────
FILE_ROOT = os.environ.get("SECFTP_FILE_ROOT", r"C:\SecFTP\ftp_files")

# ── FTP 服务 ─────────────────────────────────────────
FTP_ENABLED       = False          # 需要时改为 True
FTP_HOST          = "0.0.0.0"
FTP_PORT          = 21
FTP_PASSIVE       = range(60000, 60100)
FTP_MASQUERADE_IP = ""             # 公网 IP（NAT 环境填写）

# ── Web 服务 ─────────────────────────────────────────
SYSTEM_NAME = os.environ.get("SECFTP_SYSTEM_NAME", "锡林郭勒云盘")

WEB_HOST = "0.0.0.0"
WEB_PORT = 8080

# ── 会话安全 ─────────────────────────────────────────
SESSION_TIMEOUT         = 3600     # 秒
SESSION_COOKIE_SECURE   = os.environ.get("SECFTP_HTTPS", "false").lower() in ("1","true","yes")  # HTTPS 环境设 SECFTP_HTTPS=true
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = "Lax"

# ── 登录保护 ─────────────────────────────────────────
MAX_LOGIN_FAIL  = 5                # 连续失败次数上限
LOCKOUT_SECONDS = 300              # 锁定时长（秒）

# ── 上传限制 ─────────────────────────────────────────
MAX_UPLOAD_MB       = 512       # 单次普通上传限制（MB）
CHUNK_SIZE_MB       = 5         # 建议分片大小（MB），前端参考值
MAX_CHUNKED_FILE_GB = 100       # 分片上传最大文件（GB）

# 允许上传的扩展名白名单（注意：此集合在 main.py upload() 中强制执行）
UPLOAD_WHITELIST = {
    ".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tiff",
    ".pdf", ".ofd",
    ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".wps", ".et", ".dps",
    ".txt", ".md", ".csv", ".log", ".json", ".xml", ".yaml", ".ini",
    ".zip", ".rar", ".7z",
    # 注意：.svg 已从白名单移除（SVG 可内嵌 <script>，存在 XSS 风险）
    # 注意：.env .py .sh .bat .exe .php 等可执行格式禁止上传
}

# ── 安全头 ───────────────────────────────────────────
SECURITY_HEADERS = {
    "X-Frame-Options":        "DENY",
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy":        "strict-origin-when-cross-origin",
    "X-XSS-Protection":       "1; mode=block",
    "Content-Security-Policy": (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "   # 模板内联脚本需要
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "font-src 'self';"
    ),
}

# ── IP 管控 ──────────────────────────────────────────
IP_BLACKLIST: set = set()
# IP_WHITELIST: set = set()   # 取消注释并填写 IP 以启用白名单模式

# ── 角色定义（不要修改数字） ─────────────────────────
ROLE_SUPER = 0   # 超级管理员
ROLE_DEPT  = 1   # 组织管理员
ROLE_USER  = 2   # 普通用户

ROLE_NAMES  = {0: "超级管理员", 1: "组织管理员", 2: "普通用户"}
ROLE_BADGES = {0: "SUPER",     1: "DEPT",       2: "USER"}

# ── 数据库 ───────────────────────────────────────────

# ── 组织层级标签（三级结构）─────────────────────────
# 可根据实际单位名称调整显示名
ORG_LEVEL_NAMES = {
    1: "委办局",     # 一级：委办局
    2: "业务科室",   # 二级：科室/处室
    3: "工作小组",   # 三级：小组/项目组
}

# ── 安全告警配置 ─────────────────────────────────────────
# 企业微信 Webhook（在企业微信群中添加机器人获取）
ALERT_WECOM_WEBHOOK   = os.environ.get('ALERT_WECOM_WEBHOOK', '')
# 钉钉 Webhook
ALERT_DINGTALK_WEBHOOK = os.environ.get('ALERT_DINGTALK_WEBHOOK', '')
# 邮件告警（SMTP）
ALERT_SMTP_HOST  = os.environ.get('ALERT_SMTP_HOST', '')
ALERT_SMTP_PORT  = int(os.environ.get('ALERT_SMTP_PORT', '465'))
ALERT_SMTP_USER  = os.environ.get('ALERT_SMTP_USER', '')
ALERT_SMTP_PASS  = os.environ.get('ALERT_SMTP_PASS', '')
ALERT_EMAIL_TO   = os.environ.get('ALERT_EMAIL_TO', '')   # 逗号分隔多个收件人


# ── LDAP / AD 集成（可在管理后台配置，以下为默认值）────────────────
# 也可通过环境变量覆盖，或在 /admin/ldap 页面配置后自动写入 ldap_config.json
LDAP_ENABLED          = False
LDAP_SERVER           = os.environ.get('LDAP_SERVER', '')
LDAP_PORT             = int(os.environ.get('LDAP_PORT', '389'))
LDAP_USE_SSL          = os.environ.get('LDAP_USE_SSL', 'false').lower() in ('1','true','yes')
LDAP_BIND_DN          = os.environ.get('LDAP_BIND_DN', '')
LDAP_BIND_PASSWORD    = os.environ.get('LDAP_BIND_PASSWORD', '')
LDAP_BASE_DN          = os.environ.get('LDAP_BASE_DN', '')
LDAP_USER_FILTER      = os.environ.get('LDAP_USER_FILTER', '(sAMAccountName={username})')
LDAP_SYNC_FILTER      = os.environ.get('LDAP_SYNC_FILTER', '(objectClass=person)')
LDAP_ATTR_USERNAME    = os.environ.get('LDAP_ATTR_USERNAME', 'sAMAccountName')
LDAP_ATTR_DISPLAY_NAME= os.environ.get('LDAP_ATTR_DISPLAY_NAME', 'displayName')
LDAP_ATTR_EMAIL       = os.environ.get('LDAP_ATTR_EMAIL', 'mail')
LDAP_ATTR_PHONE       = os.environ.get('LDAP_ATTR_PHONE', 'telephoneNumber')
LDAP_ATTR_DEPARTMENT  = os.environ.get('LDAP_ATTR_DEPARTMENT', 'department')
LDAP_DEFAULT_ROLE     = int(os.environ.get('LDAP_DEFAULT_ROLE', '2'))
LDAP_DEFAULT_QUOTA_MB = int(os.environ.get('LDAP_DEFAULT_QUOTA_MB', '1024000'))

# ── OnlyOffice 在线编辑（可在管理后台配置）────────────────────────
ONLYOFFICE_ENABLED  = False
ONLYOFFICE_SERVER   = os.environ.get('ONLYOFFICE_SERVER', '')
ONLYOFFICE_JWT_KEY  = os.environ.get('ONLYOFFICE_JWT_KEY', '')
# 本系统对外访问地址（OnlyOffice 需要能访问到这个地址拉取/回调文件）
SECFTP_PUBLIC_URL   = os.environ.get('SECFTP_PUBLIC_URL', '')

# ── 存储后端配置 ─────────────────────────────────────────────────────
# STORAGE_BACKEND = "local"   (默认) 本地磁盘，FILE_ROOT 目录
# STORAGE_BACKEND = "minio"   MinIO / S3 兼容对象存储
STORAGE_BACKEND = os.environ.get('STORAGE_BACKEND', 'local')

# ── MinIO 连接配置（STORAGE_BACKEND = "minio" 时生效）───────────────
MINIO_ENDPOINT   = os.environ.get('MINIO_ENDPOINT',   '127.0.0.1:9000')
MINIO_ACCESS_KEY = os.environ.get('MINIO_ACCESS_KEY', 'minioadmin')
MINIO_SECRET_KEY = os.environ.get('MINIO_SECRET_KEY', 'minioadmin')
MINIO_BUCKET     = os.environ.get('MINIO_BUCKET',     'secftp-files')
MINIO_SECURE     = os.environ.get('MINIO_SECURE',     'false').lower() in ('1','true','yes')
MINIO_REGION     = os.environ.get('MINIO_REGION',     '')

# ── 头像上传配置 ─────────────────────────────────────────────
AVATAR_MAX_KB       = 2048   # 头像最大 2MB
AVATAR_SIZE         = 200    # 裁剪后存储为 200x200 px
AVATAR_THUMB_SIZE   = 40     # 缩略图尺寸（顶栏/卡片用）

# ── 回收站与版本管理 ─────────────────────────────────────────
TRASH_TTL_DAYS  = int(os.environ.get('SECFTP_TRASH_TTL_DAYS', '30'))   # 回收站保留天数
MAX_FILE_VERSIONS = int(os.environ.get('SECFTP_MAX_VERSIONS', '10'))   # 每文件最多版本数
