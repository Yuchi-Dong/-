# -*- coding: utf-8 -*-
"""
main.py — Flask 应用入口

职责：
  - Flask app 初始化
  - 蓝图注册
  - Rate Limiting（flask-limiter）
  - 全局中间件（before_request / after_request）
  - 错误处理器
  - 健康检查接口 /health
"""
import json as _json
import logging
import os as _os
import sys
import traceback

from flask import Flask, abort, jsonify, redirect, request, session

import config
from indexer import init_index_db
from models import init_db

log = logging.getLogger("main")

# ── 蓝图导入 ─────────────────────────────────────────
from routes.auth_routes        import bp as auth_bp
from routes.browse_routes      import bp as browse_bp
from routes.share_routes       import bp as share_bp
from routes.admin_routes       import bp as admin_bp
from routes.extra_routes       import bp as extra_bp
from routes.compliance_routes  import bp as compliance_bp
from routes.approval_routes    import bp as approval_bp
from routes.device_routes      import bp as device_bp
from routes.license_console    import bp as license_console_bp
from routes.ldap_routes        import bp as ldap_bp
from routes.upload_routes      import bp as upload_chunked_bp
from routes.editor_routes      import bp as editor_bp
from routes.storage_routes     import bp as storage_admin_bp
from routes.branding_routes    import bp as branding_bp
from routes.register_routes    import bp as register_bp
from routes.profile_routes     import bp as profile_ext_bp
from routes.dashboard_routes   import bp as dashboard_bp
from webdav.handler            import bp as webdav_bp

app = Flask(__name__)

# ── 安全配置 ─────────────────────────────────────────
app.secret_key                        = config.SECRET_KEY
app.config["MAX_CONTENT_LENGTH"]      = config.MAX_UPLOAD_MB * 1024 * 1024
app.config["SESSION_COOKIE_SECURE"]   = config.SESSION_COOKIE_SECURE
app.config["SESSION_COOKIE_HTTPONLY"] = config.SESSION_COOKIE_HTTPONLY
app.config["SESSION_COOKIE_SAMESITE"] = config.SESSION_COOKIE_SAMESITE

# ── 生产环境 SECRET_KEY 检测 ──────────────────────────
if getattr(config, "SECRET_KEY_IS_RANDOM", False):
    msg = (
        "[WARN] SECFTP_SECRET_KEY 环境变量未设置，已使用随机密钥。\n"
        "       重启服务后所有用户 Session 将立即失效！\n"
        "       生产环境请设置固定密钥：\n"
        "         export SECFTP_SECRET_KEY=$(python3 -c \"import secrets;print(secrets.token_hex(32))\")"
    )
    print(msg, file=sys.stderr)
    # 如果明确声明是生产环境，强制报错退出
    if _os.environ.get("FLASK_ENV") == "production" or _os.environ.get("SECFTP_PROD") == "1":
        raise RuntimeError("生产环境必须设置 SECFTP_SECRET_KEY 环境变量！")

# ── Rate Limiting ────────────────────────────────────
try:
    from flask_limiter import Limiter
    from flask_limiter.util import get_remote_address

    limiter = Limiter(
        app=app,
        key_func=get_remote_address,
        default_limits=["300/minute", "3000/hour"],
        storage_uri="memory://",
        # 超限时返回 JSON 而不是 HTML
        on_breach=None,
    )

    # 登录接口：10次/分钟（防暴力破解）
    @auth_bp.before_request
    def _rate_login():
        if request.endpoint == "auth.login" and request.method == "POST":
            limiter.limit("10/minute")(lambda: None)()

    # 上传接口：30次/分钟
    @upload_chunked_bp.before_request
    def _rate_upload():
        if request.endpoint in ("upload_chunked.upload_init", "upload_chunked.upload_chunk"):
            limiter.limit("30/minute")(lambda: None)()

    # 公开链接接口：60次/分钟（防爬）
    @share_bp.before_request
    def _rate_share():
        if request.endpoint == "share.public_link":
            limiter.limit("60/minute")(lambda: None)()

    app.config["RATELIMIT_ENABLED"] = True
    print("[INFO] Rate Limiting 已启用（flask-limiter）", flush=True)

except ImportError:
    # flask-limiter 未安装时降级：仅打印警告，不阻断启动
    print("[WARN] flask-limiter 未安装，Rate Limiting 未启用。\n"
          "       建议执行：pip install flask-limiter", file=sys.stderr)
    limiter = None

# ── 蓝图注册 ─────────────────────────────────────────
app.register_blueprint(auth_bp)
app.register_blueprint(browse_bp)
app.register_blueprint(share_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(extra_bp)
app.register_blueprint(compliance_bp)
app.register_blueprint(approval_bp)
app.register_blueprint(device_bp)
app.register_blueprint(license_console_bp)
app.register_blueprint(ldap_bp)
app.register_blueprint(upload_chunked_bp)
app.register_blueprint(editor_bp)
app.register_blueprint(storage_admin_bp)
app.register_blueprint(branding_bp)
app.register_blueprint(register_bp)
app.register_blueprint(profile_ext_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(webdav_bp)

# ── 初始化 ────────────────────────────────────────────
init_db()
init_index_db()


# ── 回收站定时清理（每天凌晨 3 点）─────────────────────
def _start_cleanup_scheduler():
    import threading, datetime, time

    def _cleanup_job():
        while True:
            # 计算距离下次凌晨 3 点的秒数
            now     = datetime.datetime.now()
            target  = now.replace(hour=3, minute=0, second=0, microsecond=0)
            if now >= target:
                target += datetime.timedelta(days=1)
            time.sleep((target - now).total_seconds())
            try:
                _do_trash_cleanup()
            except Exception as _e:
                print(f"[WARN] 回收站清理失败: {_e}", flush=True)

    def _do_trash_cleanup():
        import shutil
        from dao.db import get_conn as _gc
        import config as _c
        ttl_days = getattr(_c, 'TRASH_TTL_DAYS', 30)
        with _gc() as conn:
            expired = conn.execute(
                "SELECT id, trash_path FROM trash_items "
                "WHERE deleted_at < NOW() - INTERVAL '%s days'",
                (ttl_days,)
            ).fetchall()
            for row in expired:
                tp = row.get('trash_path','')
                if tp:
                    try:
                        if os.path.isfile(tp): _os.remove(tp)
                        elif _os.path.isdir(tp): shutil.rmtree(tp, ignore_errors=True)
                    except Exception:
                        pass
            if expired:
                ids = [r['id'] for r in expired]
                conn.execute("DELETE FROM trash_items WHERE id = ANY(%s)", (ids,))
                print(f"[INFO] 回收站清理: 删除 {len(expired)} 条过期记录", flush=True)

    t = threading.Thread(target=_cleanup_job, daemon=True, name="trash-cleanup")
    t.start()

_start_cleanup_scheduler()

# License 初始化（等保合规模块）
from license.middleware import init_license
init_license(app)

# ── 加载持久化配置（LDAP / OnlyOffice / 存储 / 品牌）──
for _cfg_file in [
    'ldap_config.json',
    'onlyoffice_config.json',
    'storage_config.json',
    'branding_config.json',
]:
    _cfg_path = _os.path.join(_os.path.dirname(__file__), _cfg_file)
    if _os.path.isfile(_cfg_path):
        try:
            with open(_cfg_path, 'r', encoding='utf-8') as _f:
                _loaded = _json.load(_f)
            if _cfg_file == 'ldap_config.json':
                from routes.ldap_routes import _apply_to_config as _ldap_apply
                _ldap_apply(_loaded)
            elif _cfg_file == 'storage_config.json':
                from routes.storage_routes import _apply as _st_apply
                _st_apply(_loaded)
            elif _cfg_file == 'branding_config.json':
                from routes.branding_routes import _apply as _br_apply
                _br_apply(_loaded)
            elif _cfg_file == 'onlyoffice_config.json':
                config.ONLYOFFICE_ENABLED = _loaded.get('enabled', False)
                config.ONLYOFFICE_SERVER  = _loaded.get('server', '')
                config.SECFTP_PUBLIC_URL  = _loaded.get('public_url', '')
                if _loaded.get('jwt_key'):
                    config.ONLYOFFICE_JWT_KEY = _loaded['jwt_key']
        except Exception as _e:
            print(f'[WARN] 加载 {_cfg_file} 失败: {_e}', file=sys.stderr)


# ── 健康检查 ──────────────────────────────────────────
@app.route("/health")
def health():
    """
    负载均衡器健康检查端点。
    检查 DB 连接是否可用，返回 200 OK 或 503。
    """
    import time
    t0 = time.perf_counter()
    db_ok  = False
    db_err = ""
    try:
        from dao.db import get_conn
        with get_conn() as conn:
            conn.execute("SELECT 1")
        db_ok = True
    except Exception as e:
        db_err = str(e)
    db_ms = round((time.perf_counter() - t0) * 1000, 1)

    payload = {
        "status":   "ok" if db_ok else "error",
        "db":       "ok" if db_ok else db_err,
        "db_ms":    db_ms,
        "version":  "4.1",
    }
    return jsonify(payload), 200 if db_ok else 503


# ── 全局中间件 ────────────────────────────────────────
@app.before_request
def before():
    import time
    ip = request.remote_addr
    if hasattr(config, "IP_BLACKLIST") and ip in config.IP_BLACKLIST:
        abort(403)
    if "uid" in session:
        last = session.get("last_active", 0)
        if (time.time() - last) > config.SESSION_TIMEOUT:
            session.clear()
            return redirect("/login")
        session["last_active"] = time.time()


@app.after_request
def after(response):
    is_file = (request.path.startswith("/file/")
               or request.path.startswith("/preview/")
               or request.path.startswith("/archive/"))
    for k, v in config.SECURITY_HEADERS.items():
        if k == "X-Frame-Options" and is_file:
            continue
        response.headers[k] = v
    if is_file:
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
    return response


# ── 错误处理 ──────────────────────────────────────────
@app.errorhandler(429)
def err429(e):
    return jsonify({"error": "请求过于频繁，请稍后重试"}), 429


@app.errorhandler(500)
def err500(e):
    print("[500 ERROR]\n" + traceback.format_exc(), file=sys.stderr, flush=True)
    return ("<div style='padding:24px;font-family:sans-serif'>"
            "<h2>500 服务器内部错误</h2>"
            "<p>系统发生异常，已记录日志。请联系管理员。</p>"
            "</div>"), 500


@app.errorhandler(403)
def err403(e):
    return ("<div style='padding:24px;font-family:sans-serif'>"
            "<h2>403 无权访问</h2><p>您没有权限访问此资源。</p>"
            "</div>"), 403


if __name__ == "__main__":
    app.run(host=config.WEB_HOST, port=config.WEB_PORT, debug=False)
