@echo off
:: ============================================================
:: setup_nginx.bat — Nginx 安装与配置一键脚本
:: 以管理员身份运行
:: ============================================================
chcp 65001 >nul
setlocal

echo.
echo ╔══════════════════════════════════════════════════════╗
echo ║        锡林郭勒云盘 — Nginx 安装配置脚本            ║
echo ╚══════════════════════════════════════════════════════╝
echo.

set NGINX_DIR=C:\nginx
set NGINX_EXE=%NGINX_DIR%\nginx.exe
set NGINX_CONF=%NGINX_DIR%\conf\nginx.conf
set SECFTP_DIR=C:\SecFTP\secftp_pro

:: ── 检查是否已安装 ───────────────────────────────────────
if exist "%NGINX_EXE%" (
    echo [INFO] 已检测到 Nginx: %NGINX_EXE%
    goto :configure
)

echo [1/3] 未检测到 Nginx，请手动下载并解压到 C:\nginx
echo.
echo  下载地址: https://nginx.org/en/download.html
echo  选择: nginx/Windows-1.24.x  （stable 版本）
echo  解压后目录结构应为:
echo    C:\nginx\
echo    C:\nginx\nginx.exe
echo    C:\nginx\conf\
echo    C:\nginx\logs\
echo.
echo  下载解压完成后，重新运行此脚本。
pause & exit /b 0

:configure
echo [1/3] 备份原配置...
if exist "%NGINX_CONF%" (
    copy /Y "%NGINX_CONF%" "%NGINX_CONF%.bak" >nul
    echo      已备份到 %NGINX_CONF%.bak
)

echo [2/3] 复制锡林郭勒云盘 Nginx 配置...
copy /Y "%SECFTP_DIR%\nginx.conf" "%NGINX_CONF%" >nul
if errorlevel 1 (
    echo [错误] 复制配置失败，请检查路径是否正确
    echo  源文件: %SECFTP_DIR%\nginx.conf
    echo  目标:   %NGINX_CONF%
    pause & exit /b 1
)
echo      配置已复制到 %NGINX_CONF%

echo [3/3] 注册 Nginx 为 Windows 服务（使用 NSSM）...
set NSSM=C:\SecFTP\nssm\nssm.exe
if not exist "%NSSM%" (
    echo [警告] 未找到 NSSM，跳过服务注册
    echo  请手动将 Nginx 注册为服务，或使用以下命令启动：
    echo  cd C:\nginx && nginx.exe
    goto :done
)

:: 停止已有服务
sc query NginxSecFTP >nul 2>&1
if not errorlevel 1 (
    "%NSSM%" stop NginxSecFTP >nul 2>&1
    "%NSSM%" remove NginxSecFTP confirm >nul 2>&1
)

"%NSSM%" install NginxSecFTP "%NGINX_EXE%"
"%NSSM%" set NginxSecFTP AppDirectory "%NGINX_DIR%"
"%NSSM%" set NginxSecFTP AppParameters "-g \"daemon off;\""
"%NSSM%" set NginxSecFTP AppStdout "%NGINX_DIR%\logs\stdout.log"
"%NSSM%" set NginxSecFTP AppStderr "%NGINX_DIR%\logs\stderr.log"
"%NSSM%" set NginxSecFTP Start SERVICE_AUTO_START
"%NSSM%" start NginxSecFTP

:done
echo.
echo ══════════════════════════════════════════════════════
echo  Nginx 配置完成！
echo.
echo  验证步骤：
echo    1. 确认 SecFTPWeb 服务已启动（Waitress 监听 127.0.0.1:8080）
echo    2. 浏览器访问 http://服务器IP  （80端口，通过 Nginx）
echo    3. 查看 Nginx 日志: %NGINX_DIR%\logs\access.log
echo.
echo  常用命令：
echo    重载配置: cd C:\nginx ^&^& nginx.exe -s reload
echo    测试配置: cd C:\nginx ^&^& nginx.exe -t
echo    查看状态: sc query NginxSecFTP
echo ══════════════════════════════════════════════════════
echo.
pause
