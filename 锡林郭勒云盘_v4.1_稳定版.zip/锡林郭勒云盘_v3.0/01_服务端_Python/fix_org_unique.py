# -*- coding: utf-8 -*-
"""
fix_org_unique.py — 组织表唯一索引迁移脚本（PostgreSQL 版）

作用：将 organizations 表的全局唯一约束改为「同父节点内唯一」。
已从 SQLite 版本迁移到 PostgreSQL。

运行方式（首次部署或从旧版本升级时执行一次）：
    python fix_org_unique.py
"""
import sys
from dao.db import get_conn

def run():
    print("[INFO] 开始检查/修复 organizations 唯一约束...")
    with get_conn() as conn:
        # 检查旧的全局唯一约束
        old_idx = conn.execute("""
            SELECT indexname FROM pg_indexes
            WHERE tablename='organizations'
            AND indexdef LIKE '%UNIQUE%'
            AND indexname NOT LIKE 'idx_org_parent%'
        """).fetchall()

        for row in old_idx:
            idx_name = row["indexname"]
            print(f"  [DROP] 删除旧唯一索引: {idx_name}")
            conn.execute(f'DROP INDEX IF EXISTS "{idx_name}"')

        # 确保父节点内唯一索引存在
        exists_name = conn.execute("""
            SELECT 1 FROM pg_indexes
            WHERE indexname='idx_org_parent_name'
        """).fetchone()
        if not exists_name:
            print("  [CREATE] 创建 idx_org_parent_name ...")
            conn.execute("""
                CREATE UNIQUE INDEX idx_org_parent_name
                ON organizations(COALESCE(parent_id,-1), name)
            """)

        exists_code = conn.execute("""
            SELECT 1 FROM pg_indexes
            WHERE indexname='idx_org_parent_code'
        """).fetchone()
        if not exists_code:
            print("  [CREATE] 创建 idx_org_parent_code ...")
            conn.execute("""
                CREATE UNIQUE INDEX idx_org_parent_code
                ON organizations(COALESCE(parent_id,-1), code)
            """)

    print("[OK] organizations 唯一约束已修复为「同父节点内唯一」")

if __name__ == "__main__":
    run()
