# -*- coding: utf-8 -*-
"""
integrations/ldap_auth.py — LDAP / Windows AD 认证集成

支持：
  - Windows Active Directory（LDAP over 389 / LDAPS over 636）
  - OpenLDAP
  - 国产 LDAP 服务（统一身份认证平台）

认证流程：
  1. 用系统 Bind 账号连接 LDAP 服务器
  2. 按 user_filter 搜索用户 DN
  3. 用找到的 DN + 用户输入的密码做 Bind 验证（不暴露系统账号密码）
  4. 读取用户属性（姓名、邮件、部门等）
  5. 在本地数据库创建/更新"影子账号"
  6. 返回本地用户 dict，后续走现有登录流程

配置项在 config.py 的 LDAP_* 系列，均支持环境变量覆盖。
"""
import logging
import os
from typing import Optional

log = logging.getLogger("ldap_auth")


# ── 配置读取 ─────────────────────────────────────────
def _cfg(key: str, default=None):
    import config as _c
    return getattr(_c, key, None) or os.environ.get(key, default)


def is_ldap_enabled() -> bool:
    return str(_cfg("LDAP_ENABLED", "false")).lower() in ("1", "true", "yes")


# ── LDAP 连接 ─────────────────────────────────────────
def _get_conn():
    """
    创建并返回一个已绑定的 LDAP 连接（系统 Bind 账号）。
    使用 ldap3 库，兼容 Windows AD 和 OpenLDAP。
    """
    try:
        import ldap3
    except ImportError:
        raise RuntimeError(
            "ldap3 未安装，请执行：pip install ldap3"
        )

    server_addr = _cfg("LDAP_SERVER", "")
    port        = int(_cfg("LDAP_PORT", "389"))
    use_ssl     = str(_cfg("LDAP_USE_SSL", "false")).lower() in ("1", "true", "yes")
    bind_dn     = _cfg("LDAP_BIND_DN", "")
    bind_pw     = _cfg("LDAP_BIND_PASSWORD", "")

    if not server_addr:
        raise RuntimeError("LDAP_SERVER 未配置")

    server = ldap3.Server(
        server_addr,
        port=port,
        use_ssl=use_ssl,
        get_info=ldap3.ALL,
        connect_timeout=5,
    )
    conn = ldap3.Connection(
        server,
        user=bind_dn,
        password=bind_pw,
        auto_bind=True,
        authentication=ldap3.SIMPLE,
    )
    return conn, ldap3


# ── 搜索用户 DN ───────────────────────────────────────
def _search_user(conn, ldap3_module, username: str) -> Optional[dict]:
    """
    在 LDAP 中搜索用户，返回包含 dn 和属性的 dict，找不到返回 None。
    """
    base_dn     = _cfg("LDAP_BASE_DN", "")
    user_filter = _cfg("LDAP_USER_FILTER", "(sAMAccountName={username})")
    # 支持 {username} 占位符，防止注入（ldap3 内部做转义）
    safe_username = ldap3_module.utils.conv.escape_filter_chars(username)
    search_filter = user_filter.replace("{username}", safe_username)

    attr_map = _get_attr_map()
    attrs_to_fetch = list(set(attr_map.values()))

    conn.search(
        search_base=base_dn,
        search_filter=search_filter,
        search_scope=ldap3_module.SUBTREE,
        attributes=attrs_to_fetch,
    )

    entries = conn.entries
    if not entries:
        return None
    if len(entries) > 1:
        log.warning(f"LDAP 搜索 '{username}' 返回 {len(entries)} 条，取第一条")

    entry = entries[0]
    result = {"dn": str(entry.entry_dn)}
    for local_key, ldap_attr in attr_map.items():
        try:
            val = entry[ldap_attr].value
            result[local_key] = str(val) if val else ""
        except Exception:
            result[local_key] = ""
    return result


def _get_attr_map() -> dict:
    """
    返回 本地字段 → LDAP 属性名 的映射。
    Windows AD 默认值，OpenLDAP 可通过配置覆盖。
    """
    return {
        "display_name": _cfg("LDAP_ATTR_DISPLAY_NAME", "displayName"),
        "email":        _cfg("LDAP_ATTR_EMAIL",        "mail"),
        "phone":        _cfg("LDAP_ATTR_PHONE",         "telephoneNumber"),
        "department":   _cfg("LDAP_ATTR_DEPARTMENT",    "department"),
        "username_ld":  _cfg("LDAP_ATTR_USERNAME",      "sAMAccountName"),
    }


# ── 密码验证（用用户 DN 做 Bind）─────────────────────
def _verify_bind(ldap3_module, user_dn: str, password: str) -> bool:
    """用用户自己的 DN + 密码尝试 Bind，成功则密码正确。"""
    server_addr = _cfg("LDAP_SERVER", "")
    port        = int(_cfg("LDAP_PORT", "389"))
    use_ssl     = str(_cfg("LDAP_USE_SSL", "false")).lower() in ("1", "true", "yes")

    import ldap3
    server = ldap3.Server(server_addr, port=port, use_ssl=use_ssl, connect_timeout=5)
    try:
        conn = ldap3.Connection(
            server,
            user=user_dn,
            password=password,
            auto_bind=True,
            authentication=ldap3.SIMPLE,
        )
        conn.unbind()
        return True
    except Exception as e:
        log.debug(f"LDAP Bind 失败: {e}")
        return False


# ── 本地影子账号 ──────────────────────────────────────
def _sync_local_user(ldap_info: dict) -> dict:
    """
    在本地数据库中创建或更新 LDAP 用户的影子账号。
    - 影子账号的 password 字段存储一个随机哈希（本地密码不可用，强制走 LDAP）
    - 同步：display_name、email、phone
    - 部门映射：按 LDAP department 属性匹配组织表
    """
    import secrets, hashlib
    from dao.db import get_conn
    import config

    username     = ldap_info.get("username_ld") or ""
    display_name = ldap_info.get("display_name") or username
    email        = ldap_info.get("email", "")
    phone        = ldap_info.get("phone", "")
    department   = ldap_info.get("department", "")

    if not username:
        raise ValueError("LDAP 返回的用户名为空")

    with get_conn() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE username=%s", (username,)
        ).fetchone()

        if row:
            # 更新现有影子账号的基本信息
            conn.execute(
                "UPDATE users SET display_name=%s, email=%s, phone=%s, "
                "is_active=1, last_login=NOW() WHERE username=%s",
                (display_name, email, phone, username)
            )
            # 更新部门绑定（如果 LDAP 部门与组织表有对应）
            if department:
                org = conn.execute(
                    "SELECT id FROM organizations WHERE name=%s LIMIT 1",
                    (department,)
                ).fetchone()
                if org:
                    conn.execute(
                        "UPDATE users SET org_id=%s WHERE username=%s",
                        (org["id"], username)
                    )
            return dict(conn.execute(
                "SELECT * FROM users WHERE username=%s", (username,)
            ).fetchone())
        else:
            # 新建影子账号
            # 生成一个不可用的随机密码哈希（LDAP 用户必须走 LDAP 登录）
            rand_salt = secrets.token_hex(16)
            rand_hash = hashlib.pbkdf2_hmac(
                "sha256", secrets.token_bytes(32), rand_salt.encode(), 100_000
            ).hex()

            # 默认角色：普通用户；默认配额：1TB
            default_role  = int(_cfg("LDAP_DEFAULT_ROLE", str(config.ROLE_USER)))
            default_quota = int(_cfg("LDAP_DEFAULT_QUOTA_MB", "1024000"))

            # 尝试按部门名匹配组织
            org_id = None
            if department:
                org = conn.execute(
                    "SELECT id FROM organizations WHERE name=%s LIMIT 1",
                    (department,)
                ).fetchone()
                if org:
                    org_id = org["id"]

            uid = conn.execute(
                "INSERT INTO users(username,password,salt,role,org_id,"
                "display_name,email,phone,quota_mb,is_active,last_login) "
                "VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,1,NOW()) RETURNING id",
                (username, rand_hash, rand_salt, default_role, org_id,
                 display_name, email, phone, default_quota)
            ).fetchone()[0]

            import os
            os.makedirs(
                os.path.join(config.FILE_ROOT, "users", username), exist_ok=True
            )
            log.info(f"LDAP 新用户已创建本地影子账号: {username} (id={uid})")
            return dict(conn.execute(
                "SELECT * FROM users WHERE id=%s", (uid,)
            ).fetchone())


# ── 主入口：LDAP 认证 ─────────────────────────────────
def ldap_authenticate(username: str, password: str) -> tuple:
    """
    使用 LDAP 验证用户名和密码。
    返回 (user_dict, error_msg)
    - 成功：(user_dict, None)
    - 失败：(None, error_msg)

    本函数被 services/user_service.py 的 verify_password 调用。
    """
    if not is_ldap_enabled():
        return None, "LDAP 未启用"

    if not username or not password:
        return None, "用户名或密码不能为空"

    try:
        conn, ldap3 = _get_conn()
    except RuntimeError as e:
        log.error(f"LDAP 连接失败: {e}")
        return None, f"LDAP 服务不可用，请使用本地账号登录（{e}）"

    try:
        ldap_user = _search_user(conn, ldap3, username)
        conn.unbind()
    except Exception as e:
        log.error(f"LDAP 搜索失败: {e}")
        return None, "LDAP 查询失败，请联系管理员"

    if not ldap_user:
        return None, "用户不存在（LDAP 中未找到）"

    # 用用户 DN + 密码做 Bind 验证
    if not _verify_bind(ldap3, ldap_user["dn"], password):
        return None, "密码错误"

    # 同步本地影子账号
    try:
        local_user = _sync_local_user(ldap_user)
    except Exception as e:
        log.error(f"本地影子账号同步失败: {e}")
        return None, f"账号同步失败: {e}"

    # 检查本地账号是否被手动禁用
    if not local_user.get("is_active"):
        return None, "账号已被管理员禁用"

    return local_user, None


# ── 连接测试（管理后台用）────────────────────────────
def test_connection() -> dict:
    """
    测试 LDAP 连接配置是否正确。
    返回 {'ok': bool, 'message': str, 'server_info': str}
    """
    try:
        conn, _ = _get_conn()
        info = str(conn.server.info.vendor_name or "LDAP Server") if conn.server.info else "已连接"
        conn.unbind()
        return {"ok": True, "message": "连接成功", "server_info": info}
    except Exception as e:
        return {"ok": False, "message": str(e), "server_info": ""}


# ── 全量用户同步（定时任务用）────────────────────────
def sync_all_users() -> dict:
    """
    从 LDAP 同步所有用户到本地数据库（新增/更新，不删除）。
    适合定时任务调用（每天凌晨同步一次）。
    返回 {'synced': int, 'created': int, 'updated': int, 'errors': list}
    """
    if not is_ldap_enabled():
        return {"synced": 0, "created": 0, "updated": 0, "errors": ["LDAP 未启用"]}

    try:
        conn, ldap3 = _get_conn()
    except Exception as e:
        return {"synced": 0, "created": 0, "updated": 0, "errors": [str(e)]}

    base_dn       = _cfg("LDAP_BASE_DN", "")
    sync_filter   = _cfg("LDAP_SYNC_FILTER", "(objectClass=person)")
    attr_map      = _get_attr_map()
    attrs         = list(set(attr_map.values()))

    conn.search(base_dn, sync_filter, attributes=attrs)
    entries = conn.entries
    conn.unbind()

    from dao.db import get_conn as db_conn
    created = updated = 0
    errors = []

    for entry in entries:
        try:
            ldap_info = {"dn": str(entry.entry_dn)}
            for local_key, ldap_attr in attr_map.items():
                try:
                    val = entry[ldap_attr].value
                    ldap_info[local_key] = str(val) if val else ""
                except Exception:
                    ldap_info[local_key] = ""

            uname = ldap_info.get("username_ld", "").strip()
            if not uname:
                continue

            with db_conn() as c:
                existing = c.execute(
                    "SELECT id FROM users WHERE username=%s", (uname,)
                ).fetchone()

            _sync_local_user(ldap_info)
            if existing:
                updated += 1
            else:
                created += 1
        except Exception as e:
            errors.append(f"{entry.entry_dn}: {e}")

    return {
        "synced":  len(entries),
        "created": created,
        "updated": updated,
        "errors":  errors,
    }
