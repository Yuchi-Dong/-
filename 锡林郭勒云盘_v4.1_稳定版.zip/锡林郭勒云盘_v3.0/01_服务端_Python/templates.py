
import os as _os

def render_avatar(av_char: str, av_color: str, avatar_path: str = "",
                  size: int = 28, font_size: int = 12,
                  css_class: str = "top-av", extra_style: str = "") -> str:
    """渲染头像 HTML（图片头像 or 颜色字母头像）"""
    base = (
        "width:" + str(size) + "px;height:" + str(size) + "px;border-radius:50%;overflow:hidden;"
        "display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;" + extra_style
    )
    if avatar_path:
        fallback_style = (
            "font-weight:700;font-size:" + str(font_size) + "px;color:#fff"
        )
        return (
            '<div class="' + css_class + '" style="' + base + '">'
            '<img src="/avatar/' + avatar_path + '" '
            'style="width:100%;height:100%;object-fit:cover;border-radius:50%;" '
            'onerror="var p=this.parentElement;p.innerHTML=\'<span style=&quot;' + fallback_style + '&quot;>' + av_char + '</span>\';p.style.background=\'' + av_color + '\'">'
            '</div>'
        )
    return (
        '<div class="' + css_class + '" style="' + base + 'background:' + av_color + ';">'
        '<span style="font-weight:700;font-size:' + str(font_size) + 'px;color:#fff">' + av_char + '</span>'
        '</div>'
    )

SYSTEM_NAME    = "锡林郭勒云盘"
SYSTEM_NAME_EN = "Xilingol Cloud Drive"
SYSTEM_SHORT   = "锡林郭勒云盘"
SYSTEM_ORG     = "锡林郭勒盟行政公署"

BASE_CSS = """<link rel="icon" href="/favicon.ico" type="image/x-icon"><style>
*{box-sizing:border-box;margin:0;padding:0}
:root{
  --primary:#1560bd;--primary-dk:#0e4a9a;--primary-lt:#eaf2ff;--primary-xlt:#f5f9ff;
  --accent:#1a72d9;
  --success:#1a7a40;--success-lt:#e6f5ec;
  --warning:#b8860b;--warning-lt:#fef9e7;
  --danger:#c62828;--danger-lt:#fff0f0;
  --gray50:#f7f8fa;--gray100:#f1f4f8;--gray200:#e2e8f0;--gray300:#c5cfe0;
  --gray400:#94a3b8;--gray500:#64748b;--gray600:#475569;
  --text:#1a1f2e;--text2:#4b5563;--text3:#9ca3af;
  --border:#e2e8f0;--border2:#c5cfe0;
  --white:#ffffff;--bg:#f4f7fb;
  --shadow:0 1px 3px rgba(0,0,0,.07);
  --shadow-md:0 3px 10px rgba(0,0,0,.09);
  --shadow-lg:0 8px 24px rgba(0,0,0,.11);
  --radius:4px;--radius-lg:6px;
  --font:'Microsoft YaHei','PingFang SC','Segoe UI',sans-serif;
  --font-mono:'Consolas','Courier New',monospace;
}
html,body{height:100%;background:var(--bg);color:var(--text);font-family:var(--font);font-size:14px;line-height:1.6;overflow:hidden}
.shell{height:100vh;display:flex;flex-direction:column}
.body{display:flex;flex:1;overflow:hidden}
.topbar{height:54px;background:var(--primary);display:flex;align-items:center;padding:0 18px;gap:12px;flex-shrink:0;border-bottom:3px solid var(--primary-dk)}
.top-emblem{width:34px;height:34px;flex-shrink:0;background:rgba(255,255,255,.15);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:17px}
.top-title{color:#fff;font-size:16px;font-weight:700;letter-spacing:1px;flex:1}
.top-title small{font-size:10px;font-weight:400;color:rgba(255,255,255,.6);display:block;letter-spacing:2px;margin-top:1px}
.top-user{display:flex;align-items:center;gap:8px;font-size:12px}
.top-av{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:12px;color:#fff;overflow:hidden}
.av-md{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:17px;overflow:hidden}
.av-lg{width:80px;height:80px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:32px;overflow:hidden}
.av-xl{width:100px;height:100px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:40px;overflow:hidden;border:3px solid rgba(255,255,255,.3)}
.top-logout{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.22);color:rgba(255,255,255,.85);padding:3px 10px;border-radius:var(--radius);cursor:pointer;font-size:11px;font-family:var(--font)}
.top-logout:hover{background:rgba(255,255,255,.2)}
.sidebar{width:185px;flex-shrink:0;background:var(--white);border-right:1px solid var(--border);display:flex;flex-direction:column;overflow-y:auto}
.sidebar-logo{background:var(--primary-dk);padding:10px 14px 8px}
.sidebar-logo .sysname{color:rgba(255,255,255,.9);font-size:12px;font-weight:600}
.sidebar-logo .ver{color:rgba(255,255,255,.4);font-size:10px;margin-top:2px}
.nav-sect{font-size:10px;color:var(--text3);padding:10px 14px 4px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;border-top:1px solid var(--border);margin-top:2px}
.nav-sect:first-of-type{border-top:none;margin-top:0}
.ni{display:flex;align-items:center;gap:8px;padding:7px 14px;font-size:12px;color:var(--text2);cursor:pointer;transition:all .12s;border-left:3px solid transparent;text-decoration:none;font-weight:500}
.ni:hover{color:var(--primary);background:var(--primary-lt)}
.ni.active{color:var(--primary);background:var(--primary-lt);border-left-color:var(--primary);font-weight:600}
.ni .ico{font-size:13px;width:18px;text-align:center;flex-shrink:0}
.ni-badge{margin-left:auto;background:var(--danger);color:#fff;font-size:9px;padding:1px 5px;border-radius:8px}
.sidebar-foot{margin-top:auto;padding:10px 14px;border-top:1px solid var(--border);background:var(--gray50)}
.qpath-wrap{display:flex;flex-direction:column;gap:3px;margin-top:5px}
.qpath{display:block;padding:4px 8px;font-size:11px;color:var(--text2);text-decoration:none;border:1px solid var(--border);border-radius:var(--radius);background:var(--white);transition:all .12s}
.qpath:hover{border-color:var(--primary);color:var(--primary)}
.main{flex:1;overflow:hidden;display:flex;flex-direction:column;background:var(--bg)}
.view{display:none;flex:1;overflow-y:auto;padding:16px 18px;flex-direction:column;gap:12px}
.view.show{display:flex;animation:fadeIn .18s ease}
@keyframes fadeIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)}}
.card{background:var(--white);border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow)}
.card-hdr{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid var(--border);flex-shrink:0;background:var(--gray50)}
.card-hdr h2{font-size:13px;font-weight:600;color:var(--text);display:flex;align-items:center;gap:5px}
.card-hdr h2::before{content:'';width:2px;height:13px;background:var(--primary);border-radius:1px;display:inline-block}
.card-body{overflow:auto;flex:1}
.page-title{font-size:15px;font-weight:600;color:var(--text);display:flex;align-items:center;gap:7px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;flex-shrink:0}
.stat{background:var(--white);border:1px solid var(--border);border-radius:var(--radius-lg);padding:12px 14px;display:flex;align-items:center;gap:10px;border-top:2px solid var(--primary)}
.stat:nth-child(2){border-top-color:var(--success)}
.stat:nth-child(3){border-top-color:var(--warning)}
.stat:nth-child(4){border-top-color:#6b42c8}
.stat-icon{width:38px;height:38px;border-radius:var(--radius);display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0}
.stat-icon.blue{background:var(--primary-lt);color:var(--primary)}
.stat-icon.green{background:var(--success-lt);color:var(--success)}
.stat-icon.yellow{background:var(--warning-lt);color:var(--warning)}
.stat-icon.red{background:var(--danger-lt);color:var(--danger)}
.stat-val{font-size:20px;font-weight:700;color:var(--text);line-height:1;font-family:var(--font-mono)}
.stat-lbl{font-size:11px;color:var(--text3);margin-top:2px}
.tbl{width:100%;border-collapse:collapse}
.tbl th{font-size:11px;color:var(--text3);padding:8px 12px;text-align:left;border-bottom:1px solid var(--border);background:var(--gray50);font-weight:600;position:sticky;top:0;z-index:1}
.tbl td{padding:8px 12px;font-size:12px;border-bottom:1px solid var(--gray100)}
.tbl tr:hover td{background:var(--primary-xlt)}
.tbl tr:last-child td{border-bottom:none}
.fname{display:flex;align-items:center;gap:7px;font-weight:500;cursor:pointer;color:var(--text);text-decoration:none}
.fname:hover{color:var(--primary)}
.file-click{cursor:pointer}
.file-click:hover{color:var(--primary)}
.ficon{font-size:15px;width:19px;text-align:center;flex-shrink:0}
.fsize{font-family:var(--font-mono);font-size:11px;color:var(--text3)}
.fdate{font-family:var(--font-mono);font-size:11px;color:var(--text3)}
.btn{padding:5px 11px;border-radius:var(--radius);font-size:12px;font-weight:500;cursor:pointer;border:1px solid transparent;transition:all .12s;font-family:var(--font);display:inline-flex;align-items:center;gap:4px;text-decoration:none;white-space:nowrap}
.btn-primary{background:var(--primary);color:#fff;border-color:var(--primary)}
.btn-primary:hover{background:var(--primary-dk)}
.btn-outline{background:var(--white);border-color:var(--border2);color:var(--text2)}
.btn-outline:hover{border-color:var(--primary);color:var(--primary)}
.btn-danger{background:var(--danger-lt);color:var(--danger);border-color:#f5a0a0}
.btn-danger:hover{background:#ffd7d7}
.btn-success{background:var(--success-lt);color:var(--success);border-color:#86efac}
.btn-sm{padding:3px 9px;font-size:11px}
.btn-xs{padding:2px 7px;font-size:11px}
.bc{display:flex;align-items:center;gap:4px;flex-wrap:wrap;flex-shrink:0}
.bc a{font-size:12px;color:var(--primary);text-decoration:none}
.bc a:hover{text-decoration:underline}
.bc .sep{color:var(--text3);font-size:11px}
.bc-current{font-size:12px;color:var(--text2);font-weight:500}
.badge{font-size:10px;padding:1px 5px;border-radius:3px;font-weight:500;display:inline-flex}
.badge-blue{background:var(--primary-lt);color:var(--primary)}
.badge-green{background:var(--success-lt);color:var(--success)}
.badge-red{background:var(--danger-lt);color:var(--danger)}
.badge-yellow{background:var(--warning-lt);color:var(--warning)}
.badge-gray{background:var(--gray100);color:var(--gray600)}
.badge-super{background:var(--danger-lt);color:var(--danger)}
.perm-rw{color:var(--success);font-size:10px;background:var(--success-lt);padding:1px 5px;border-radius:2px;font-weight:500}
.perm-ro{color:var(--text3);font-size:10px;background:var(--gray100);padding:1px 5px;border-radius:2px}
.share-badge{display:inline-flex;align-items:center;gap:2px;font-size:9px;padding:1px 5px;border-radius:2px;font-weight:600;cursor:pointer;margin-left:5px;background:#fff7ed;color:#c2410c;border:1px solid #fed7aa;vertical-align:middle}
.share-badge:hover{background:#ffedd5}
.upload-zone{border:1.5px dashed var(--border2);border-radius:var(--radius-lg);padding:18px;text-align:center;cursor:pointer;transition:all .2s;background:var(--white);flex-shrink:0}
.upload-zone:hover,.upload-zone.drag{border-color:var(--primary);background:var(--primary-lt)}
.upload-zone p{font-size:12px;color:var(--text2)}
.upload-zone strong{color:var(--primary)}
.quota-bar{background:var(--gray200);border-radius:10px;height:5px;overflow:hidden;margin-top:5px}
.quota-fill{height:100%;border-radius:10px;background:linear-gradient(90deg,var(--primary),var(--accent));transition:width .5s}
.quota-fill.warn{background:linear-gradient(90deg,var(--warning),#f59e0b)}
.quota-fill.danger{background:linear-gradient(90deg,var(--danger),#ef4444)}
.fg{margin-bottom:13px}
.fg label{display:block;font-size:11px;color:var(--text2);font-weight:600;margin-bottom:4px}
.inp{width:100%;background:var(--white);border:1px solid var(--border2);color:var(--text);padding:7px 11px;border-radius:var(--radius);font-family:var(--font);font-size:13px;outline:none;transition:border .2s}
.inp:focus{border-color:var(--primary);box-shadow:0 0 0 2px rgba(21,96,189,.1)}
.inp-sel{appearance:none;background:var(--white)}
.s-inp{flex:1;background:var(--gray50);border:1px solid var(--border);color:var(--text);padding:7px 12px;border-radius:var(--radius);font-family:var(--font);font-size:13px;outline:none}
.s-inp:focus{border-color:var(--primary);background:var(--white)}
.s-sel{background:var(--gray50);border:1px solid var(--border);color:var(--text2);padding:7px 11px;border-radius:var(--radius);font-size:13px;outline:none;cursor:pointer}
.hl{background:#fef08a;color:#713f12;border-radius:2px;padding:0 2px}
.fc-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(148px,1fr));gap:10px;padding:14px}
.fc{background:var(--white);border:1px solid var(--border);border-radius:var(--radius-lg);
  overflow:hidden;cursor:pointer;position:relative;transition:box-shadow .18s,transform .15s}
.fc:hover{box-shadow:var(--shadow-md);transform:translateY(-2px)}
.fc-thumb{width:100%;height:100px;flex-shrink:0}
.fc-info{padding:8px 10px}
.fc-name{font-size:12px;font-weight:500;color:var(--text);overflow:hidden;
  text-overflow:ellipsis;white-space:nowrap;line-height:1.4}
.fc-ops{display:none;position:absolute;inset:0;background:rgba(0,0,0,.55);
  padding:8px;flex-direction:column;gap:4px;justify-content:center;align-items:center}
.fc:hover .fc-ops{display:flex}
.fc-op-btn{background:rgba(255,255,255,.92);border:none;border-radius:4px;
  padding:5px 10px;font-size:11px;cursor:pointer;width:100%;text-align:center;
  color:var(--text);font-family:var(--font)}
.fc-op-btn:hover{background:#fff}
.fc-op-del{color:var(--danger)!important}
.user-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:10px;padding:14px}
.ucard{background:var(--white);border:1px solid var(--border);border-radius:var(--radius-lg);padding:14px;transition:box-shadow .2s;border-top:2px solid var(--primary)}
.ucard:hover{box-shadow:var(--shadow-md)}
.ucard .uav{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:17px;margin:0 auto 8px;color:#fff}
.uav-s{background:linear-gradient(135deg,var(--danger),#e53935)}
.uav-d{background:linear-gradient(135deg,var(--primary),var(--accent))}
.uav-u{background:linear-gradient(135deg,var(--gray500),var(--gray600))}
.ucard h3{text-align:center;font-size:13px;font-weight:600;color:var(--text)}
.ucard .uname{text-align:center;font-size:11px;color:var(--text3);font-family:var(--font-mono)}
.ucard .uinfo{font-size:12px;color:var(--text2);margin-top:8px;line-height:1.8;padding-top:8px;border-top:1px solid var(--border)}
.ucard-acts{display:flex;gap:5px;margin-top:9px;flex-wrap:wrap}
.ucard-acts .btn{flex:1;justify-content:center}
.udisabled{opacity:.55}
.org-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px;padding:14px}
.ocard{background:var(--white);border:1px solid var(--border);border-radius:var(--radius-lg);padding:14px;border-left:3px solid var(--primary)}
.ocard h3{font-size:13px;font-weight:600;color:var(--primary);margin-bottom:3px}
.ocard .ocode{font-family:var(--font-mono);font-size:10px;color:var(--text3);margin-bottom:5px}
.ocard .odesc{font-size:12px;color:var(--text2);margin-bottom:8px}
.ocard .ostats{display:flex;gap:12px;font-size:12px;color:var(--text3)}
#toast-wrap{position:fixed;top:62px;right:16px;z-index:9999;display:flex;flex-direction:column;gap:5px}
.toast{padding:9px 14px;border-radius:var(--radius);font-size:12px;max-width:300px;animation:toastIn .25s ease;box-shadow:var(--shadow-md);display:flex;align-items:center;gap:7px}
.toast.ok{background:var(--success-lt);border:1px solid #86efac;color:var(--success)}
.toast.err{background:var(--danger-lt);border:1px solid #f5a0a0;color:var(--danger)}
.toast.in{background:var(--primary-lt);border:1px solid #93c5fd;color:var(--primary)}
@keyframes toastIn{from{opacity:0;transform:translateX(16px)}to{opacity:1;transform:translateX(0)}}
.overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);display:none;align-items:center;justify-content:center;z-index:500;backdrop-filter:blur(2px)}
.overlay.on{display:flex;animation:fadeIn .18s}
.modal{background:var(--white);border-radius:var(--radius-lg);padding:22px;width:480px;max-width:94vw;max-height:88vh;overflow-y:auto;box-shadow:var(--shadow-lg);border-top:3px solid var(--primary)}
.modal-hdr{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;padding-bottom:11px;border-bottom:1px solid var(--border)}
.modal-hdr h3{font-size:14px;font-weight:600;color:var(--text)}
.modal-close{background:none;border:none;color:var(--text3);cursor:pointer;font-size:17px;padding:2px}
.mbtns{display:flex;gap:7px;justify-content:flex-end;margin-top:16px;padding-top:12px;border-top:1px solid var(--border)}
.prev-overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);display:none;align-items:center;justify-content:center;z-index:600;backdrop-filter:blur(3px)}
.prev-overlay.on{display:flex}
.prev-modal{background:var(--white);border-radius:var(--radius-lg);width:92%;max-width:940px;max-height:92vh;display:flex;flex-direction:column;box-shadow:var(--shadow-lg);border-top:3px solid var(--primary)}
.prev-hdr{display:flex;align-items:center;padding:11px 14px;border-bottom:1px solid var(--border);gap:9px;flex-shrink:0;background:var(--gray50)}
.prev-hdr h4{font-size:13px;font-weight:600;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.prev-body{flex:1;overflow:auto;min-height:400px}
.preview-img{max-width:100%;max-height:74vh;object-fit:contain;display:block;margin:auto;padding:14px}
.preview-text{padding:14px;font-family:var(--font-mono);font-size:13px;color:var(--text);line-height:1.7;white-space:pre-wrap;background:var(--gray50);min-height:100%}
.preview-pdf{width:100%;height:74vh;border:none}
.view-switcher{display:flex;gap:2px;background:var(--gray100);padding:2px;border-radius:var(--radius)}
.vs-btn{width:26px;height:26px;border:none;background:transparent;cursor:pointer;border-radius:3px;font-size:14px;display:flex;align-items:center;justify-content:center;color:var(--text3);transition:all .12s}
.vs-btn:hover{background:var(--white);color:var(--text2)}
.vs-btn.active{background:var(--white);color:var(--primary);box-shadow:var(--shadow)}
.fgrid-wrap{display:flex;flex-wrap:wrap;gap:9px;padding:12px;overflow-y:auto;align-content:flex-start}
.fgrid-card{width:130px;border:1px solid var(--border);border-radius:var(--radius-lg);padding:10px 8px 9px;background:var(--white);cursor:pointer;transition:all .12s;display:flex;flex-direction:column;align-items:center;gap:5px}
.fgrid-card:hover{border-color:var(--primary);box-shadow:var(--shadow-md);transform:translateY(-1px)}
.fgrid-icon{font-size:32px;line-height:1}
.fgrid-name{font-size:11px;font-weight:500;color:var(--text);text-align:center;word-break:break-all;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.4}
.fgrid-meta{font-size:10px;color:var(--text3);font-family:var(--font-mono)}
.fgrid-ops{display:flex;gap:3px;flex-wrap:wrap;justify-content:center;margin-top:2px}
.fthumb-wrap-outer{display:flex;flex-wrap:wrap;gap:10px;padding:12px;overflow-y:auto;align-content:flex-start}
.fthumb-card{width:150px;border:1px solid var(--border);border-radius:var(--radius-lg);background:var(--white);cursor:pointer;transition:all .12s;overflow:hidden;display:flex;flex-direction:column}
.fthumb-card:hover{border-color:var(--primary);box-shadow:var(--shadow-md);transform:translateY(-1px)}
.fthumb-wrap{height:100px;display:flex;align-items:center;justify-content:center;background:var(--gray50);border-bottom:1px solid var(--border);overflow:hidden}
.fthumb-img{width:100%;height:100%;object-fit:cover}
.fthumb-icon{font-size:38px;line-height:1}
.fthumb-name{font-size:11px;font-weight:500;padding:7px 7px 3px;color:var(--text);word-break:break-all;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.fthumb-card .fgrid-ops{padding:3px 7px 7px;justify-content:flex-start}
.empty-state{text-align:center;padding:44px 20px;color:var(--text3)}
.empty-state .es-icon{font-size:42px;margin-bottom:10px;opacity:.45}
.empty-state p{font-size:13px}
.progress{background:var(--gray200);border-radius:10px;height:4px;margin-top:7px;overflow:hidden;display:none}
.progress.show{display:block}
.progress-bar{height:100%;background:linear-gradient(90deg,var(--primary),var(--accent));border-radius:10px;transition:width .3s;width:0%}
.share-type-public{background:var(--warning-lt);color:var(--warning)}
.share-type-org{background:var(--primary-lt);color:var(--primary)}
.share-type-user{background:var(--success-lt);color:var(--success)}
.login-page{height:100vh;display:flex;flex-direction:column;background:linear-gradient(150deg,#eaf2ff 0%,#d6e8ff 100%)}
.login-header{background:var(--primary);height:58px;display:flex;align-items:center;padding:0 22px;gap:12px;border-bottom:3px solid var(--primary-dk);flex-shrink:0}
.login-header-title{color:#fff;font-size:17px;font-weight:700;letter-spacing:1px}
.login-header-sub{font-size:10px;color:rgba(255,255,255,.6);margin-top:2px;letter-spacing:1.5px}
.login-body{flex:1;display:flex;align-items:center;justify-content:center}
.login-wrap{display:flex;gap:32px;align-items:flex-start;max-width:700px;width:100%;padding:0 20px}
.login-info{flex:1;padding-top:12px}
.login-info h2{font-size:17px;font-weight:600;color:var(--text);margin-bottom:8px}
.login-info p{font-size:12px;color:var(--text2);line-height:1.9;margin-bottom:12px}
.login-features{display:flex;flex-direction:column;gap:6px}
.login-feat{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--text2);padding:7px 10px;background:var(--white);border-radius:var(--radius);border:1px solid var(--border)}
.login-feat-icon{font-size:15px;width:20px;text-align:center;flex-shrink:0}
.login-card{width:300px;flex-shrink:0;background:var(--white);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);overflow:hidden}
.login-card-hdr{background:var(--primary);padding:13px 18px}
.login-card-title{color:#fff;font-size:13px;font-weight:600;letter-spacing:.5px}
.login-card-sub{color:rgba(255,255,255,.6);font-size:10px;margin-top:2px}
.login-card-body{padding:18px}
.lerr{background:var(--danger-lt);border:1px solid #f5a0a0;color:var(--danger);padding:8px 12px;border-radius:var(--radius);font-size:12px;margin-bottom:12px;display:none}
.login-footer{text-align:center;padding:12px;font-size:11px;color:var(--text3);border-top:1px solid var(--border);margin-top:14px}
.login-bottom{background:var(--primary-dk);padding:8px;text-align:center;font-size:10px;color:rgba(255,255,255,.45);flex-shrink:0}
@media(max-width:768px){.sidebar{display:none}.stats{grid-template-columns:1fr 1fr}}
</style>"""



def _build_login_html(system_name, system_name_en, system_org, base_css, csrf_token=""):
    return (
        '<!DOCTYPE html><html lang="zh-CN"><head>'
        '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
        '<title>' + system_name + ' — 登录</title>'
        + base_css +
        '</head><body>'
        '<div class="login-page">'
        '  <div class="login-header">'
        '    <div style="width:36px;height:36px;background:rgba(255,255,255,.15);border-radius:50%;'
        'display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">&#9729;</div>'
        '    <div>'
        '      <div class="login-header-title">' + system_name + '</div>'
        '      <div class="login-header-sub">' + system_name_en + ' &middot; ' + system_org + '</div>'
        '    </div>'
        '  </div>'
        '  <div class="login-body">'
        '    <div class="login-wrap">'
        '      <div class="login-info">'
        '        <h2>政务云存储平台</h2>'
        '        <p>为各机关单位提供安全、高效的内部文件存储与共享服务。数据存储于本地服务器，安全可控，不上公有云。</p>'
        '        <div class="login-features">'
        '          <div class="login-feat"><span class="login-feat-icon">&#128274;</span>数据本地存储，安全可控</div>'
        '          <div class="login-feat"><span class="login-feat-icon">&#128101;</span>按组织架构精细化权限管理</div>'
        '          <div class="login-feat"><span class="login-feat-icon">&#128269;</span>全文检索，支持文档内容搜索</div>'
        '          <div class="login-feat"><span class="login-feat-icon">&#128203;</span>操作全程审计，可追溯</div>'
        '        </div>'
        '      </div>'
        '      <div class="login-card">'
        '        <div class="login-card-hdr">'
        '          <div class="login-card-title">用户登录</div>'
        '          <div class="login-card-sub">请使用内网账号登录</div>'
        '        </div>'
        '        <div class="login-card-body">'
        '          <div class="lerr" id="lerr"></div>'
        '          <form method="POST" action="/login">'
        '            <input type="hidden" name="csrf_token" value="' + csrf_token + '">'
        '            <div class="fg"><label>用户名</label>'
        '              <input class="inp" name="username" autocomplete="username" autofocus required placeholder="请输入用户名"></div>'
        '            <div class="fg"><label>密码</label>'
        '              <input class="inp" type="password" name="password" required placeholder="请输入密码"></div>'
        '            <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;'
        'padding:9px;font-size:14px;letter-spacing:1px">登&nbsp;&nbsp;录</button>'
        '          </form>'
        '          <div id="reg-link" style="text-align:center;margin-top:12px;font-size:12px;color:#94a3b8">'
        '            还没有账号？<a href="/register" style="color:rgba(255,255,255,.7)">申请账号</a>'
        '          </div>'
        '          <div class="login-footer">内部专用系统 &middot; 未经授权禁止访问</div>'
        '        </div>'
        '      </div>'
        '    </div>'
        '  </div>'
        '  <div class="login-bottom">' + system_name + ' v2.0 &nbsp;|&nbsp; ' + system_org + ' &nbsp;|&nbsp; 数据安全 &middot; 自主可控</div>'
        '</div>'
        '</body></html>'
    )


def _make_login_html(csrf_token=""):
    return _build_login_html(SYSTEM_NAME, SYSTEM_NAME_EN, SYSTEM_ORG, BASE_CSS, csrf_token)


# Keep LOGIN_HTML as property for backwards compatibility
class _LoginHTMLDescriptor:
    def __get__(self, obj, objtype=None):
        return _make_login_html()

import sys as _sys
_mod = _sys.modules[__name__]

def get_login_html(csrf_token=""):
    return _make_login_html(csrf_token)

# Simple LOGIN_HTML without csrf (for import compatibility)
LOGIN_HTML = _make_login_html()



_MODALS = (
    '<!-- 预览模态 -->'
    '<div class="prev-overlay" id="preview-modal" onclick="if(event.target===this)hideModal(\'preview-modal\')">'
    '  <div class="prev-modal">'
    '    <div class="prev-hdr">'
    '      <h4 id="preview-title">预览</h4>'
    '      <a id="preview-dl" href="#" style="font-size:12px;color:var(--primary);margin-right:8px;text-decoration:none">&#8681; 下载</a>'
    '      <button class="btn btn-sm btn-outline" onclick="hideModal(\'preview-modal\')">&#10005; 关闭</button>'
    '    </div>'
    '    <div class="prev-body" id="preview-body"></div>'
    '  </div>'
    '</div>'
    '<!-- 分享模态 -->'
    '<div class="overlay" id="share-modal" onclick="if(event.target===this)hideModal(\'share-modal\')">'
    '  <div class="modal">'
    '    <div class="modal-hdr"><h3>&#128279; 分享文件</h3>'
    '      <button class="modal-close" onclick="hideModal(\'share-modal\')">&#10005;</button></div>'
    '    <input type="hidden" id="share-path">'
    '    <div class="fg"><label>文件路径</label>'
    '      <input class="inp" id="share-path-show" readonly style="background:var(--gray50);color:var(--text3)"></div>'
    '    <div class="fg" id="share-type-wrap"><label>分享范围</label>'
    '      <select class="inp inp-sel" id="share-type" onchange="updateShareTarget()">'
    '        <option value="user">&#128100; 指定用户（@搜索）</option>'
    '        <option value="org">&#127970; 指定科室/组织</option>'
    '        <option value="public" id="share-opt-public" style="display:none">&#127760; 全员公开（仅超管）</option>'
    '      </select></div>'
    '    <!-- 用户搜索框（@搜索） -->'
    '    <div class="fg" id="share-user-search-wrap">'
    '      <label>搜索用户 <span style="font-size:11px;color:var(--text3)">输入 @用户名 或姓名，只显示同组织成员</span></label>'
    '      <div style="display:flex;gap:6px">'
    '        <input class="inp" id="share-user-q" placeholder="@张三 或 张三" oninput="searchShareUser(this.value)" style="flex:1">'
    '        <select class="inp inp-sel" id="share-target" style="flex:2"></select>'
    '      </div>'
    '      <div id="share-scope-tip" style="font-size:11px;color:var(--text3);margin-top:4px"></div>'
    '    </div>'
    '    <!-- 组织选择框 -->'
    '    <div class="fg" id="share-org-wrap" style="display:none">'
    '      <label>目标科室/组织</label>'
    '      <select class="inp inp-sel" id="share-org-target"></select>'
    '    </div>'
    '    <div class="fg"><label>权限</label>'
    '      <select class="inp inp-sel" id="share-perm">'
    '        <option value="ro">只读（可查看和下载）</option>'
    '        <option value="rw">读写（可修改和上传）</option>'
    '      </select></div>'
    '    <div class="fg"><label>备注（可选）</label>'
    '      <input class="inp" id="share-note" placeholder="例如：本季度汇报材料"></div>'
    '    <div class="fg"><label>有效期（可选，留空永久有效）</label>'
    '      <input class="inp" type="date" id="share-expires"></div>'
    '    <div class="mbtns">'
    '      <button class="btn btn-outline" onclick="hideModal(\'share-modal\')">取消</button>'
    '      <button class="btn btn-primary" onclick="submitShare()">确认分享</button>'
    '    </div>'
    '  </div>'
    '</div>'
    '<!-- 分享详情模态 -->'
    '<div class="overlay" id="share-info-modal" onclick="if(event.target===this)hideModal(\'share-info-modal\')">'
    '  <div class="modal" style="max-width:420px">'
    '    <div class="modal-hdr"><h3>&#128228; 分享详情</h3>'
    '      <button class="modal-close" onclick="hideModal(\'share-info-modal\')">&#10005;</button></div>'
    '    <div id="share-info-body" style="font-size:13px;color:var(--text2);line-height:2"></div>'
    '    <div class="mbtns">'
    '      <button class="btn btn-outline" onclick="hideModal(\'share-info-modal\')">关闭</button>'
    '    </div>'
    '  </div>'
    '</div>'
)


_JS = """
function toast(msg,type,dur){
  type=type||'in';dur=dur||3000;
  var w=document.getElementById('toast-wrap');
  var icons={ok:'✅',err:'❌','in':'ℹ️'};
  var t=document.createElement('div');
  t.className='toast '+type;
  t.innerHTML='<span>'+(icons[type]||'')+' </span><span>'+msg+'</span>';
  w.appendChild(t);
  setTimeout(function(){t.style.opacity='0';t.style.transition='opacity .3s';
    setTimeout(function(){t.remove()},350)},dur);
}
function showModal(id){document.getElementById(id).classList.add('on')}
function hideModal(id){document.getElementById(id).classList.remove('on')}
function escHtml(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}

async function previewFile(url,name,ftype){
  var modal=document.getElementById('preview-modal');
  var title=document.getElementById('preview-title');
  var body=document.getElementById('preview-body');
  var dl=document.getElementById('preview-dl');
  if(!modal)return;
  title.textContent=name;
  dl.href=url+'?dl=1';
  dl.download=name;
  body.style.background='';
  body.innerHTML='<div style="text-align:center;padding:48px;color:var(--text3)">⏳ 加载中...</div>';
  showModal('preview-modal');
  var ext=name.split('.').pop().toLowerCase();
  var officeExts=['doc','docx','xls','xlsx','ppt','pptx','odt','ods','odp','wps','et','dps','rtf'];
  var archiveExts=['zip','rar','7z','tar','gz','bz2','xz'];
  var htmlExts=['html','htm','svg'];
  var nativeVideoExts=['mp4','webm','ogv','m4v','mov'];
  var allVideoExts=['mp4','avi','mkv','mov','wmv','flv','webm','m4v','mpg','mpeg','3gp','ts','ogv','rm','rmvb','mts'];
  var audioExts=['mp3','wav','flac','aac','ogg','wma','m4a','opus','ape','aiff'];
  if(ftype==='image'){
    body.innerHTML='<img src="'+url+'" class="preview-img" alt="'+escHtml(name)+'">';
  } else if(ftype==='pdf'){
    body.innerHTML='<iframe src="'+url+'" class="preview-pdf"></iframe>';
  } else if(htmlExts.indexOf(ext)>=0){
    body.innerHTML='<iframe src="'+url+'" style="width:100%;min-height:70vh;border:none" sandbox="allow-scripts allow-same-origin"></iframe>';
  } else if(ftype==='text'){
    fetch(url).then(function(r){return r.text();}).then(function(text){
      body.innerHTML='<pre class="preview-text">'+escHtml(text.substring(0,80000))+'</pre>';
    }).catch(function(){body.innerHTML='<div style="color:var(--danger);padding:24px">加载失败</div>';});
  } else if(ftype==='video'||allVideoExts.indexOf(ext)>=0){
    body.style.background='#000';
    var tip=nativeVideoExts.indexOf(ext)>=0?'':'<div style="background:#111;padding:8px 14px;font-size:11px;color:#aaa">⚠ '+ext.toUpperCase()+' 格式，建议使用 Chrome/Edge &nbsp;<a href="'+url+'?dl=1" style="color:#6af">⬇ 下载</a></div>';
    body.innerHTML=tip+'<video controls autoplay style="width:100%;max-height:70vh;display:block;background:#000" src="'+url+'" preload="metadata"><p style="color:#fff;padding:20px">浏览器无法播放，请<a href="'+url+'?dl=1" style="color:#aef">下载后</a>用本地播放器查看</p></video>';
  } else if(ftype==='audio'||audioExts.indexOf(ext)>=0){
    body.style.background='var(--gray50)';
    body.innerHTML='<div style="display:flex;flex-direction:column;align-items:center;padding:40px 24px;gap:20px">'
      +'<div style="font-size:64px">🎵</div>'
      +'<div style="font-size:14px;font-weight:600">'+escHtml(name)+'</div>'
      +'<audio controls autoplay style="width:100%;max-width:480px" src="'+url+'" preload="metadata">'
      +'<p>浏览器不支持音频，<a href="'+url+'?dl=1">下载</a></p></audio>'
      +'<div style="font-size:11px;color:var(--text3)">支持 MP3/WAV/AAC/OGG/FLAC</div>'
      +'</div>';
  } else if(officeExts.indexOf(ext)>=0){
    var previewUrl=url.replace('/file/','/preview/');
    var sid='ps'+Date.now();
    var pwrap=document.createElement('div');
    pwrap.style.cssText='display:flex;flex-direction:column;height:100%;min-height:65vh';
    var ptip=document.createElement('div');
    ptip.style.cssText='padding:8px 16px;background:#f7f8fa;border-bottom:1px solid #e2e8f0;font-size:12px;color:#9ca3af';
    ptip.id=sid;
    ptip.textContent='🔄 正在转换为 PDF 预览，首次转换需几秒...';
    var pframe=document.createElement('iframe');
    pframe.src=previewUrl;
    pframe.style.cssText='flex:1;width:100%;min-height:60vh;border:none';
    pframe.onload=function(){var el=document.getElementById(sid);if(el)el.textContent='✅ 预览加载完成';};
    pframe.onerror=function(){var el=document.getElementById(sid);if(el){el.style.color='#c62828';el.textContent='❌ 转换失败，请下载查看';}};
    pwrap.appendChild(ptip);pwrap.appendChild(pframe);
    body.innerHTML='';body.appendChild(pwrap);
  } else if(archiveExts.indexOf(ext)>=0){
    var archiveUrl=url.replace('/file/','/archive/');
    var aframe=document.createElement('iframe');
    aframe.src=archiveUrl;
    aframe.style.cssText='width:100%;min-height:55vh;border:none';
    body.innerHTML='';body.appendChild(aframe);
  } else {
    body.innerHTML='<div class="empty-state"><div class="es-icon">📦</div>'
      +'<p style="font-size:14px;margin-bottom:12px">'+escHtml(name)+'</p>'
      +'<p>该文件类型不支持在线预览</p>'
      +'<a href="'+url+'?dl=1" class="btn btn-primary" style="margin-top:16px;display:inline-flex">⬇ 下载文件</a></div>';
  }
}

var _shareOrgs=[], _shareUsers=[], _shareCanPublic=false;
var _shareSearchTimer=null;

async function openShare(path){
  document.getElementById('share-path').value=path;
  document.getElementById('share-path-show').value=path;
  document.getElementById('share-note').value='';
  document.getElementById('share-expires').value='';
  document.getElementById('share-user-q').value='';
  try{
    var r=await fetch('/api/share-targets');
    var d=await r.json();
    _shareOrgs=d.orgs||[];
    _shareUsers=d.users||[];
    _shareCanPublic=!!d.can_public;
    // 超管才显示全员公开选项
    var pubOpt=document.getElementById('share-opt-public');
    if(pubOpt) pubOpt.style.display=_shareCanPublic?'':'none';
    // 默认选指定用户
    document.getElementById('share-type').value='user';
  }catch(e){_shareOrgs=[];_shareUsers=[];_shareCanPublic=false;}
  updateShareTarget();
  showModal('share-modal');
}

function updateShareTarget(){
  var type=document.getElementById('share-type').value;
  var userWrap=document.getElementById('share-user-search-wrap');
  var orgWrap=document.getElementById('share-org-wrap');
  var tipEl=document.getElementById('share-scope-tip');

  if(type==='public'){
    userWrap.style.display='none';
    orgWrap.style.display='none';
    if(tipEl) tipEl.textContent='';
    return;
  }
  if(type==='org'){
    userWrap.style.display='none';
    orgWrap.style.display='';
    var orgSel=document.getElementById('share-org-target');
    orgSel.innerHTML=_shareOrgs.length
      ? _shareOrgs.map(function(o){return '<option value="'+o.id+'">'+escHtml(o.name)+'</option>';}).join('')
      : '<option value="">（无可选组织）</option>';
    if(tipEl) tipEl.textContent=_shareCanPublic?'':'只能分享给本组织或其下级科室';
    return;
  }
  // type === 'user'
  userWrap.style.display='';
  orgWrap.style.display='none';
  _renderUserOptions(_shareUsers);
  if(tipEl) tipEl.textContent=_shareCanPublic?'可搜索全部用户':'只能分享给同组织成员';
}

function _renderUserOptions(users){
  var sel=document.getElementById('share-target');
  if(!users||!users.length){
    sel.innerHTML='<option value="">（无可选用户，当前组织暂无其他成员）</option>';
    return;
  }
  sel.innerHTML=users.map(function(u){
    return '<option value="'+u.id+'">'+escHtml(u.display_name||u.username)+' @'+escHtml(u.username)+'</option>';
  }).join('');
}

async function searchShareUser(q){
  clearTimeout(_shareSearchTimer);
  if(!q||q.trim().length<1){_renderUserOptions(_shareUsers);return;}
  _shareSearchTimer=setTimeout(async function(){
    try{
      var r=await fetch('/api/share-targets?q='+encodeURIComponent(q));
      var d=await r.json();
      _renderUserOptions(d.users||[]);
    }catch(e){}
  },300);
}

async function submitShare(){
  var path=document.getElementById('share-path').value;
  if(!path){toast('未选择文件','err');return;}
  var type=document.getElementById('share-type').value;
  var target='';
  if(type==='user'){
    var sel=document.getElementById('share-target');
    target=sel&&sel.value?sel.value:'';
    if(!target){toast('请选择目标用户','err');return;}
  } else if(type==='org'){
    var orgSel=document.getElementById('share-org-target');
    target=orgSel&&orgSel.value?orgSel.value:'';
    if(!target){toast('请选择目标组织','err');return;}
  }
  var perm=document.getElementById('share-perm').value;
  var note=document.getElementById('share-note').value;
  var exp=document.getElementById('share-expires').value;
  var csrf=window._csrf||'';
  try{
    var res=await fetch('/api/share',{method:'POST',
      headers:{'Content-Type':'application/json','X-CSRF-Token':csrf},
      body:JSON.stringify({path:path,share_type:type,target_id:target||null,perm:perm,note:note,expires_at:exp||null,csrf_token:csrf})});
    var d=await res.json();
    if(d.success){hideModal('share-modal');toast('分享成功，对方可在「共享文件」页查看','ok',4000);}
    else toast('分享失败：'+(d.error||'未知错误'),'err');
  }catch(e){toast('网络错误，请重试','err');}
}
async function showShareInfo(path){
  try{
    var r=await fetch('/api/share-info?path='+encodeURIComponent(path));
    var d=await r.json();
    var body=document.getElementById('share-info-body');
    var typeMap={public:'全员公开',org:'指定组织',user:'指定用户'};
    var permMap={ro:'只读',rw:'读写'};
    if(!d.shares||!d.shares.length){
      body.innerHTML='<div class="empty-state"><p>该文件暂无有效分享</p></div>';
    } else {
      body.innerHTML=d.shares.map(function(s){
        return '<div style="padding:10px 0;border-bottom:1px solid var(--border)">'
          +'<div><strong>分享给：</strong>'+escHtml(s.target_name||typeMap[s.share_type]||s.share_type)+'</div>'
          +'<div><strong>类型：</strong><span class="badge share-type-'+s.share_type+'">'+(typeMap[s.share_type]||s.share_type)+'</span></div>'
          +'<div><strong>权限：</strong>'+(permMap[s.perm]||s.perm)+'</div>'
          +'<div><strong>备注：</strong>'+escHtml(s.note||'—')+'</div>'
          +'<div><strong>有效期：</strong>'+(s.expires_at||'永久')+'</div>'
          +'<button class="btn btn-xs btn-danger" style="margin-top:6px" onclick="revokeShareFromInfo('+s.id+')">撤销</button>'
          +'</div>';
      }).join('');
    }
    showModal('share-info-modal');
  }catch(e){toast('加载失败','err');}
}
async function revokeShareFromInfo(id){
  if(!confirm('确认撤销此分享？'))return;
  var r=await fetch('/api/share/revoke',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({share_id:id,csrf_token:window._csrf})});
  var d=await r.json();
  if(d.success){hideModal('share-info-modal');toast('已撤销','ok');location.reload();}
  else toast('失败：'+d.error,'err');
}
document.addEventListener('keydown',function(e){
  if(e.key==='Escape')document.querySelectorAll('.overlay.on,.prev-overlay.on').forEach(function(el){el.classList.remove('on');});
});
"""


def layout(content, title, active_view, user=None, role=0, unread_shares=0, csrf_token='', av_color='#1560bd', av_path=''):
    from templates import SYSTEM_NAME, SYSTEM_SHORT, BASE_CSS, SYSTEM_ORG, _MODALS, _JS
    role_labels = {0: "超级管理员", 1: "组织管理员", 2: "普通用户"}
    role_badge  = {0: "badge-super", 1: "badge-blue", 2: "badge-gray"}
    uname       = (user or {}).get("display_name") or (user or {}).get("username", "")
    av_char     = uname[0].upper() if uname else "U"
    r_label     = role_labels.get(role, "用户")
    r_badge     = role_badge.get(role, "badge-gray")
    admin_hidden = "" if role <= 1 else "display:none"
    super_hidden = "" if role == 0  else "display:none"
    shares_badge = ('<span class="ni-badge">' + str(unread_shares) + '</span>') if unread_shares > 0 else ""

    sidebar = (
        '    <nav class="sidebar">\n'
        '      <div class="sidebar-logo">\n'
        '        <div class="sysname">&#9729; ' + SYSTEM_SHORT + '</div>\n'
        '        <div class="ver">政务云存储平台 v2.0</div>\n'
        '      </div>\n'
        '      <div class="nav-sect">文件管理</div>\n'
        '      <a class="ni ' + ('active' if active_view == 'dashboard' else '') + '" href="/dashboard"><span class="ico">&#128200;</span>数据仪表盘</a>\n'
        'class="ni ' + ('active' if active_view == 'browse'   else '') + '" href="/browse"><span class="ico">&#128193;</span>文件浏览</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'search'   else '') + '" href="/search"><span class="ico">&#128269;</span>全文搜索</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'shared'   else '') + '" href="/shared"><span class="ico">&#128279;</span>共享文件' + shares_badge + '</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'my'       else '') + '" href="/my"><span class="ico">&#128100;</span>我的空间</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'trash'     else '') + '" href="/trash"><span class="ico">&#128465;</span>回收站</a>\n'
        '      <div class="nav-sect" style="' + admin_hidden + '">系统管理</div>\n'
        '      <a class="ni ' + ('active' if active_view == 'users'    else '') + '" href="/admin/users" style="' + admin_hidden + '"><span class="ico">&#128101;</span>用户管理</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'orgs'     else '') + '" href="/admin/orgs" style="' + super_hidden + '"><span class="ico">&#127970;</span>组织管理</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'audit'    else '') + '" href="/admin/audit" style="' + super_hidden + '"><span class="ico">&#128203;</span>审计日志</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'ldap'     else '') + '" href="/admin/ldap" style="' + super_hidden + '"><span class="ico">&#128279;</span>LDAP/AD</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'editor'   else '') + '" href="/admin/editor" style="' + super_hidden + '"><span class="ico">&#128196;</span>在线编辑</a>\n'
        '      <div class="nav-sect">账号</div>\n'
        '      <a class="ni ' + ('active' if active_view == 'profile'  else '') + '" href="/profile"><span class="ico">&#127912;</span>个人资料</a>\n'
        '      <a class="ni ' + ('active' if active_view == 'changepw' else '') + '" href="/change-password"><span class="ico">&#128274;</span>修改密码</a>\n'
        '      <div class="sidebar-foot">\n'
        '        <div style="font-size:10px;color:var(--text3);margin-bottom:5px;font-weight:700">快速导航</div>\n'
        '        <div class="qpath-wrap" id="qpath-wrap">\n'
        '          <a class="qpath" href="/browse/shared">&#128226; 公共资源</a>\n'
        '          <a class="qpath" href="/my">&#128100; 我的空间</a>\n'
        '        </div>\n'
        '      </div>\n'
        '    </nav>\n'
    )

    return (
        '<!DOCTYPE html>\n'
        '<html lang="zh-CN"><head>\n'
        '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n'
        '<title>' + title + ' \u2014 ' + SYSTEM_SHORT + '</title>\n'
        + BASE_CSS +
        '</head><body>\n'
        '<div class="shell" id="app">\n'
        '  <div class="topbar">\n'
        '    <div class="top-emblem">&#9729;</div>\n'
        '    <div class="top-title">' + SYSTEM_NAME +
             '<small>' + SYSTEM_ORG + ' &middot; 内部文件共享平台</small></div>\n'
        '    <div class="top-user">\n'
        + render_avatar(av_char, av_color, av_path or (user or {}).get('avatar_path',''), size=28, font_size=12, css_class='top-av') + '\n'
        + '      <span style="color:rgba(255,255,255,.9)">' + uname + '</span>\n'
        '      <span class="badge ' + r_badge + '" style="font-size:10px">' + r_label + '</span>\n'
        '      <a href="/logout" class="top-logout">退出</a>\n'
        '    </div>\n'
        '  </div>\n'
        '  <div class="body">\n'
        + sidebar +
        '    <div class="main">\n'
        + content +
        '    </div>\n'
        '  </div>\n'
        '</div>\n'
        '<div id="toast-wrap"></div>\n'
        '<script>window._csrf="' + csrf_token + '";</script>\n'
        + _MODALS +
        '<script>\n'
        + _JS +
        '\n</script>\n'
        '</body></html>\n'
    )
