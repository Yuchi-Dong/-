# -*- coding: utf-8 -*-
"""
storage/migrate.py — 本地磁盘 → MinIO 数据迁移工具

使用方式（命令行）：
    python storage/migrate.py --dry-run        # 预览，不实际操作
    python storage/migrate.py                  # 正式迁移
    python storage/migrate.py --prefix users/  # 只迁移 users/ 目录
    python storage/migrate.py --verify         # 迁移后校验 MD5

迁移策略：
    - 遍历本地 FILE_ROOT 下所有文件
    - 按原始相对路径上传到 MinIO
    - 如果 MinIO 中已有同 key 且大小相同，默认跳过
    - 全量迁移完成后不删除本地文件（安全起见）

迁移完成后：
    1. 确认 MinIO 文件数量和总大小与本地一致
    2. 修改 config.py: STORAGE_BACKEND = "minio"
    3. 重启服务
"""
import argparse
import hashlib
import os
import sys

# 确保可以 import 项目模块
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


def migrate(dry_run: bool = False, prefix: str = "", verify: bool = False):
    import config
    from storage.local import LocalStorage
    from storage.minio_backend import MinIOStorage

    local   = LocalStorage(config.FILE_ROOT)
    minio   = MinIOStorage()
    root    = config.FILE_ROOT

    total_files = 0
    total_bytes = 0
    skipped     = 0
    errors      = []

    print(f"{'[DRY RUN] ' if dry_run else ''}开始迁移：{root} → MinIO bucket={minio.bucket}")
    print(f"前缀过滤：{prefix or '（全部）'}")
    print("-" * 60)

    for dirpath, _, filenames in os.walk(root):
        for fname in filenames:
            abs_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(abs_path, root).replace("\\", "/")

            if prefix and not rel_path.startswith(prefix):
                continue

            size = os.path.getsize(abs_path)

            # 检查 MinIO 是否已有同文件
            if not dry_run:
                try:
                    stat = minio.stat(rel_path)
                    if stat["size"] == size:
                        skipped += 1
                        continue
                except FileNotFoundError:
                    pass

            total_files += 1
            total_bytes += size

            if dry_run:
                print(f"  [WILL UPLOAD] {rel_path}  ({size:,} bytes)")
                continue

            try:
                minio.put_file(rel_path, abs_path)
                print(f"  ✓ {rel_path}  ({size:,} bytes)")

                if verify:
                    # 下载验证 MD5
                    local_md5 = _md5_file(abs_path)
                    remote_data = minio.get(rel_path)
                    remote_md5  = hashlib.md5(remote_data).hexdigest()
                    if local_md5 != remote_md5:
                        errors.append(f"MD5 不匹配: {rel_path}")
                        print(f"  ✗ MD5 校验失败: {rel_path}")

            except Exception as e:
                errors.append(f"{rel_path}: {e}")
                print(f"  ✗ 失败: {rel_path}  {e}")

    print("-" * 60)
    if dry_run:
        print(f"预览完成：共 {total_files} 个文件，{total_bytes / 1024 / 1024:.1f} MB")
    else:
        print(f"迁移完成：上传 {total_files} 个文件，跳过 {skipped} 个，"
              f"失败 {len(errors)} 个，共 {total_bytes / 1024 / 1024:.1f} MB")
        if errors:
            print("\n失败列表：")
            for e in errors:
                print(f"  {e}")
        else:
            print("\n✅ 所有文件迁移成功")
            print("下一步：修改 config.py 中 STORAGE_BACKEND = \"minio\" 后重启服务")


def _md5_file(path: str) -> str:
    md5 = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            md5.update(chunk)
    return md5.hexdigest()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="本地文件迁移到 MinIO")
    parser.add_argument("--dry-run",  action="store_true", help="预览模式，不实际上传")
    parser.add_argument("--prefix",   default="",          help="只迁移指定前缀的文件")
    parser.add_argument("--verify",   action="store_true", help="上传后校验 MD5")
    args = parser.parse_args()
    migrate(dry_run=args.dry_run, prefix=args.prefix, verify=args.verify)
