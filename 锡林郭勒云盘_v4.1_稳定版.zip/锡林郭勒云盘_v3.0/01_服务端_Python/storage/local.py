# -*- coding: utf-8 -*-
"""
storage/local.py — 本地磁盘存储实现

完全兼容原有的 FILE_ROOT 本地目录结构。
现有的 safe_join / os.scandir / send_file 等代码
通过 get_local_path() 获取真实路径后继续正常工作，
不需要修改任何路由逻辑。
"""
from __future__ import annotations

import io
import os
import shutil
import time
from pathlib import Path
from typing import BinaryIO

from storage.base import StorageBackend


class LocalStorage(StorageBackend):

    def __init__(self, root: str):
        self.root = os.path.realpath(root)
        os.makedirs(self.root, exist_ok=True)

    def _abs(self, key: str) -> str:
        """key → 绝对物理路径（防路径穿越）"""
        key = key.lstrip("/\\").replace("\\", "/")
        if not key:
            return self.root
        full = os.path.realpath(os.path.join(self.root, key))
        if not (full == self.root or full.startswith(self.root + os.sep)):
            raise PermissionError(f"路径穿越攻击被拦截: {key}")
        return full

    # ── 便捷：获取本地真实路径（供 send_file 等使用）──
    def get_local_path(self, key: str) -> str:
        return self._abs(key)

    # ── 文件读写 ──────────────────────────────────────

    def put(self, key: str, data: bytes | BinaryIO, *, content_type: str = "") -> None:
        path = self._abs(key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if isinstance(data, (bytes, bytearray)):
            with open(path, "wb") as f:
                f.write(data)
        else:
            with open(path, "wb") as f:
                shutil.copyfileobj(data, f)

    def get(self, key: str) -> bytes:
        path = self._abs(key)
        if not os.path.isfile(path):
            raise FileNotFoundError(key)
        with open(path, "rb") as f:
            return f.read()

    def get_stream(self, key: str) -> BinaryIO:
        path = self._abs(key)
        if not os.path.isfile(path):
            raise FileNotFoundError(key)
        return open(path, "rb")

    def delete(self, key: str) -> None:
        path = self._abs(key)
        if os.path.isfile(path):
            os.remove(path)
        elif os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)

    def copy(self, src_key: str, dst_key: str) -> None:
        src = self._abs(src_key)
        dst = self._abs(dst_key)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.isdir(src):
            shutil.copytree(src, dst, dirs_exist_ok=True)
        else:
            shutil.copy2(src, dst)

    def move(self, src_key: str, dst_key: str) -> None:
        src = self._abs(src_key)
        dst = self._abs(dst_key)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)

    # ── 元数据 ────────────────────────────────────────

    def exists(self, key: str) -> bool:
        try:
            return os.path.exists(self._abs(key))
        except PermissionError:
            return False

    def stat(self, key: str) -> dict:
        path = self._abs(key)
        if not os.path.exists(path):
            raise FileNotFoundError(key)
        st = os.stat(path)
        return {
            "size":         st.st_size,
            "mtime":        st.st_mtime,
            "is_dir":       os.path.isdir(path),
            "content_type": "",
        }

    # ── 目录操作 ──────────────────────────────────────

    def listdir(self, prefix: str) -> list[dict]:
        path = self._abs(prefix)
        if not os.path.isdir(path):
            return []
        result = []
        try:
            for entry in sorted(os.scandir(path),
                                 key=lambda e: (not e.is_dir(), e.name.lower())):
                st = entry.stat()
                sub_key = (f"{prefix}/{entry.name}".lstrip("/")) if prefix else entry.name
                result.append({
                    "key":    sub_key,
                    "name":   entry.name,
                    "is_dir": entry.is_dir(),
                    "size":   st.st_size if not entry.is_dir() else 0,
                    "mtime":  st.st_mtime,
                })
        except PermissionError:
            pass
        return result

    def makedirs(self, key: str) -> None:
        os.makedirs(self._abs(key), exist_ok=True)

    def rmdir(self, key: str, recursive: bool = False) -> None:
        path = self._abs(key)
        if not os.path.isdir(path):
            return
        if recursive:
            shutil.rmtree(path, ignore_errors=True)
        else:
            try:
                os.rmdir(path)
            except OSError:
                raise OSError(f"目录不为空: {key}")

    # ── 性能优化重写 ──────────────────────────────────

    def du(self, prefix: str = "") -> int:
        path = self._abs(prefix)
        total = 0
        for dirpath, _, filenames in os.walk(path):
            for fname in filenames:
                try:
                    total += os.path.getsize(os.path.join(dirpath, fname))
                except OSError:
                    pass
        return total
