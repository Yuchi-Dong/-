# -*- coding: utf-8 -*-
"""
storage/base.py — 存储后端抽象接口

所有存储实现必须继承 StorageBackend 并实现以下方法。
上层代码（routes、dao）只与此接口交互，不感知底层存储类型。

设计原则：
  - key 即相对路径，如 "dept_xxaq/report.pdf"、"users/zhangsan/photo.jpg"
  - 接口同时支持流式（大文件）和字节串（小文件）两种访问方式
  - 元数据（存在性、大小、修改时间）与内容读写分离
  - 目录操作（list、mkdir、rmdir）保持与本地文件系统语义一致
"""
from __future__ import annotations

import abc
import io
from typing import Iterator, BinaryIO


class StorageBackend(abc.ABC):

    # ── 文件读写 ──────────────────────────────────────

    @abc.abstractmethod
    def put(self, key: str, data: bytes | BinaryIO, *, content_type: str = "") -> None:
        """上传文件内容（字节串或文件对象）"""

    @abc.abstractmethod
    def get(self, key: str) -> bytes:
        """下载文件内容，返回字节串；文件不存在抛 FileNotFoundError"""

    @abc.abstractmethod
    def get_stream(self, key: str) -> BinaryIO:
        """返回可读流（大文件用），调用方负责关闭"""

    @abc.abstractmethod
    def delete(self, key: str) -> None:
        """删除文件（不存在时静默忽略）"""

    @abc.abstractmethod
    def copy(self, src_key: str, dst_key: str) -> None:
        """在存储内部复制（避免下载再上传）"""

    @abc.abstractmethod
    def move(self, src_key: str, dst_key: str) -> None:
        """在存储内部移动"""

    # ── 元数据 ────────────────────────────────────────

    @abc.abstractmethod
    def exists(self, key: str) -> bool:
        """判断文件/目录是否存在"""

    @abc.abstractmethod
    def stat(self, key: str) -> dict:
        """
        返回文件元数据：
          {size: int, mtime: float, is_dir: bool, content_type: str}
        """

    # ── 目录操作 ──────────────────────────────────────

    @abc.abstractmethod
    def listdir(self, prefix: str) -> list[dict]:
        """
        列出 prefix 下的直接子项（不递归），每项：
          {key: str, name: str, is_dir: bool, size: int, mtime: float}
        """

    @abc.abstractmethod
    def makedirs(self, key: str) -> None:
        """确保目录存在（等价于 os.makedirs(..., exist_ok=True)）"""

    @abc.abstractmethod
    def rmdir(self, key: str, recursive: bool = False) -> None:
        """删除目录（recursive=True 时删除所有子项）"""

    # ── 便捷方法（默认实现，子类可重写优化）──────────

    def get_size(self, key: str) -> int:
        return self.stat(key).get("size", 0)

    def get_mtime(self, key: str) -> float:
        return self.stat(key).get("mtime", 0.0)

    def walk(self, prefix: str = "") -> Iterator[tuple[str, list[str], list[str]]]:
        """
        类似 os.walk，递归遍历目录。
        Yields: (dirpath, subdirs, files)
        """
        items = self.listdir(prefix)
        subdirs = [i["name"] for i in items if i["is_dir"]]
        files   = [i["name"] for i in items if not i["is_dir"]]
        yield prefix, subdirs, files
        for sd in subdirs:
            sub_key = f"{prefix}/{sd}".lstrip("/")
            yield from self.walk(sub_key)

    def du(self, prefix: str = "") -> int:
        """计算目录总大小（字节）"""
        total = 0
        for _, _, files in self.walk(prefix):
            for f in files:
                pass  # 由子类实现更高效版本
        # 默认实现：通过 walk 递归统计
        total = 0
        for dirpath, _, files in self.walk(prefix):
            for fname in files:
                key = f"{dirpath}/{fname}".lstrip("/")
                try:
                    total += self.get_size(key)
                except Exception:
                    pass
        return total
