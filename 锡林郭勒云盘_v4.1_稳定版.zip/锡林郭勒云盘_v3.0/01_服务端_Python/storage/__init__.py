# -*- coding: utf-8 -*-
"""
storage/__init__.py — 存储后端工厂

用法：
    from storage import get_storage
    storage = get_storage()

    # 写文件
    storage.put("users/zhangsan/report.pdf", file_bytes)

    # 读文件（流式，适合大文件下载）
    stream = storage.get_stream("dept_xxaq/data.xlsx")
    return Response(stream_with_context(stream), ...)

    # 本地存储还支持获取真实路径（兼容现有 send_file 代码）
    if hasattr(storage, 'get_local_path'):
        local_path = storage.get_local_path(key)
        return send_file(local_path, ...)

配置项（config.py）：
    STORAGE_BACKEND = "local"    # 本地磁盘（默认）
    STORAGE_BACKEND = "minio"    # MinIO 对象存储

切换存储后端后，历史文件需要迁移（见 storage/migrate.py）。
"""
from __future__ import annotations

import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from storage.base import StorageBackend

_instance: "StorageBackend | None" = None


def get_storage() -> "StorageBackend":
    """
    返回全局存储后端单例。
    首次调用时根据 config.STORAGE_BACKEND 初始化。
    """
    global _instance
    if _instance is not None:
        return _instance

    import config
    backend = getattr(config, "STORAGE_BACKEND", "local").lower().strip()

    if backend == "minio":
        from storage.minio_backend import MinIOStorage
        _instance = MinIOStorage()
    else:
        from storage.local import LocalStorage
        _instance = LocalStorage(config.FILE_ROOT)

    return _instance


def reset_storage():
    """重置单例（切换配置后调用）"""
    global _instance
    _instance = None
