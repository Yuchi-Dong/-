# -*- coding: utf-8 -*-
"""
storage/minio_backend.py — MinIO / S3 兼容对象存储实现

依赖：minio>=7.2.0（pip install minio）

连接配置（config.py 或环境变量）：
  MINIO_ENDPOINT    : MinIO 地址，如 192.168.1.20:9000
  MINIO_ACCESS_KEY  : Access Key（MinIO Console 中创建）
  MINIO_SECRET_KEY  : Secret Key
  MINIO_BUCKET      : 存储桶名称，默认 secftp-files
  MINIO_SECURE      : 是否使用 HTTPS，默认 False（内网部署通常 False）
  MINIO_REGION      : 地域，默认 us-east-1（MinIO 自建可不填）

key 映射规则：
  本地 key 直接作为 MinIO object name（斜杠分隔，无前导斜杠）
  目录通过前缀匹配模拟，MinIO 本身无目录概念

流式下载：
  get_stream() 返回 urllib3 的 HTTPResponse 对象（可迭代，有 read() 方法）
  适合直接传给 Flask 的 Response(stream_with_context(...))

大文件上传：
  put() 自动使用 minio.put_object（流式），不会一次性读入内存
  对接分片上传时（upload_routes.py）合并后的文件通过 put() 写入 MinIO
"""
from __future__ import annotations

import io
import os
import time
from typing import BinaryIO

from storage.base import StorageBackend


def _cfg(key: str, default: str = "") -> str:
    import config as _c
    return getattr(_c, key, None) or os.environ.get(key, default)


class MinIOStorage(StorageBackend):

    def __init__(self):
        from minio import Minio
        from minio.error import S3Error

        self._S3Error = S3Error
        endpoint   = _cfg("MINIO_ENDPOINT", "127.0.0.1:9000")
        access_key = _cfg("MINIO_ACCESS_KEY", "minioadmin")
        secret_key = _cfg("MINIO_SECRET_KEY", "minioadmin")
        secure     = str(_cfg("MINIO_SECURE", "false")).lower() in ("1","true","yes")
        self.bucket = _cfg("MINIO_BUCKET", "secftp-files")
        self.region = _cfg("MINIO_REGION", "us-east-1")

        self._client = Minio(
            endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure,
            region=self.region or None,
        )
        self._ensure_bucket()

    def _ensure_bucket(self):
        if not self._client.bucket_exists(self.bucket):
            self._client.make_bucket(self.bucket, location=self.region or "us-east-1")

    @staticmethod
    def _key(k: str) -> str:
        """规范化 key：去掉前导斜杠，保留内部斜杠"""
        return k.lstrip("/\\").replace("\\", "/")

    # ── 文件读写 ──────────────────────────────────────

    def put(self, key: str, data: bytes | BinaryIO, *, content_type: str = "") -> None:
        k = self._key(key)
        if not content_type:
            import mimetypes
            content_type, _ = mimetypes.guess_type(k)
            content_type = content_type or "application/octet-stream"

        if isinstance(data, (bytes, bytearray)):
            self._client.put_object(
                self.bucket, k,
                io.BytesIO(data), len(data),
                content_type=content_type,
            )
        else:
            # 流式上传：需要知道大小；先读到内存（适合 <500MB）
            # 对于超大文件，调用方应先写临时文件再 put_object with known size
            data.seek(0, 2)
            size = data.tell()
            data.seek(0)
            self._client.put_object(
                self.bucket, k,
                data, size,
                content_type=content_type,
            )

    def put_file(self, key: str, local_path: str, content_type: str = "") -> None:
        """从本地文件路径上传（MinIO SDK 最优路径，支持分片）"""
        k = self._key(key)
        if not content_type:
            import mimetypes
            content_type, _ = mimetypes.guess_type(local_path)
            content_type = content_type or "application/octet-stream"
        self._client.fput_object(self.bucket, k, local_path, content_type=content_type)

    def get(self, key: str) -> bytes:
        k = self._key(key)
        try:
            resp = self._client.get_object(self.bucket, k)
            data = resp.read()
            resp.close()
            resp.release_conn()
            return data
        except self._S3Error as e:
            if e.code in ("NoSuchKey", "NoSuchObject"):
                raise FileNotFoundError(key)
            raise

    def get_stream(self, key: str) -> BinaryIO:
        k = self._key(key)
        try:
            return self._client.get_object(self.bucket, k)
        except self._S3Error as e:
            if e.code in ("NoSuchKey", "NoSuchObject"):
                raise FileNotFoundError(key)
            raise

    def get_to_file(self, key: str, local_path: str) -> None:
        """下载到本地文件（MinIO SDK 最优路径）"""
        self._client.fget_object(self.bucket, self._key(key), local_path)

    def delete(self, key: str) -> None:
        k = self._key(key)
        try:
            # 先尝试删除文件
            self._client.remove_object(self.bucket, k)
        except self._S3Error:
            pass
        # 如果是目录前缀，递归删除
        prefix = k.rstrip("/") + "/"
        objects = self._client.list_objects(self.bucket, prefix=prefix, recursive=True)
        for obj in objects:
            try:
                self._client.remove_object(self.bucket, obj.object_name)
            except Exception:
                pass

    def copy(self, src_key: str, dst_key: str) -> None:
        from minio.commonconfig import CopySource
        self._client.copy_object(
            self.bucket, self._key(dst_key),
            CopySource(self.bucket, self._key(src_key)),
        )

    def move(self, src_key: str, dst_key: str) -> None:
        self.copy(src_key, dst_key)
        self.delete(src_key)

    # ── 元数据 ────────────────────────────────────────

    def exists(self, key: str) -> bool:
        k = self._key(key)
        try:
            self._client.stat_object(self.bucket, k)
            return True
        except self._S3Error as e:
            if e.code in ("NoSuchKey", "NoSuchObject"):
                pass
        # 检查是否是目录前缀
        prefix = k.rstrip("/") + "/"
        result = list(self._client.list_objects(self.bucket, prefix=prefix, max_keys=1))
        return len(result) > 0

    def stat(self, key: str) -> dict:
        k = self._key(key)
        try:
            obj = self._client.stat_object(self.bucket, k)
            return {
                "size":         obj.size or 0,
                "mtime":        obj.last_modified.timestamp() if obj.last_modified else 0.0,
                "is_dir":       False,
                "content_type": obj.content_type or "",
            }
        except self._S3Error as e:
            if e.code in ("NoSuchKey", "NoSuchObject"):
                # 可能是目录前缀
                prefix = k.rstrip("/") + "/"
                items = list(self._client.list_objects(self.bucket, prefix=prefix, max_keys=1))
                if items:
                    return {"size": 0, "mtime": 0.0, "is_dir": True, "content_type": ""}
                raise FileNotFoundError(key)
            raise

    # ── 目录操作 ──────────────────────────────────────

    def listdir(self, prefix: str) -> list[dict]:
        """列出 prefix 下的直接子项（非递归）"""
        k = self._key(prefix)
        pfx = (k.rstrip("/") + "/") if k else ""
        result = []
        seen = set()

        for obj in self._client.list_objects(self.bucket, prefix=pfx, recursive=False):
            name = obj.object_name
            if name == pfx:
                continue
            # 去掉 prefix
            rel = name[len(pfx):]
            if not rel:
                continue

            if obj.is_dir:
                # 目录
                dir_name = rel.rstrip("/")
                if dir_name and dir_name not in seen:
                    seen.add(dir_name)
                    sub_key = (f"{k}/{dir_name}" if k else dir_name)
                    result.append({
                        "key":    sub_key,
                        "name":   dir_name,
                        "is_dir": True,
                        "size":   0,
                        "mtime":  0.0,
                    })
            else:
                file_name = rel.rstrip("/")
                if "/" not in file_name and file_name not in seen:
                    seen.add(file_name)
                    sub_key = (f"{k}/{file_name}" if k else file_name)
                    result.append({
                        "key":    sub_key,
                        "name":   file_name,
                        "is_dir": False,
                        "size":   obj.size or 0,
                        "mtime":  obj.last_modified.timestamp() if obj.last_modified else 0.0,
                    })

        return sorted(result, key=lambda x: (not x["is_dir"], x["name"].lower()))

    def makedirs(self, key: str) -> None:
        """MinIO 无需创建目录（对象键自带层级），此方法为兼容性空操作"""
        pass

    def rmdir(self, key: str, recursive: bool = False) -> None:
        if recursive:
            self.delete(key)
        else:
            k = self._key(key)
            prefix = k.rstrip("/") + "/"
            items = list(self._client.list_objects(self.bucket, prefix=prefix, max_keys=2))
            if len(items) > 0:
                raise OSError(f"目录不为空: {key}")

    # ── 性能优化 ──────────────────────────────────────

    def du(self, prefix: str = "") -> int:
        k = self._key(prefix)
        pfx = (k.rstrip("/") + "/") if k else ""
        total = 0
        for obj in self._client.list_objects(self.bucket, prefix=pfx, recursive=True):
            total += obj.size or 0
        return total
